import fs from 'fs';

const filePath = 'src/components/AdminDashboard.tsx';
let content = fs.readFileSync(filePath, 'utf-8');

content = content.replace(/activeTab/g, 'activeSection');
content = content.replace(/setActiveTab/g, 'setActiveSection');
content = content.replace(/activeSection === 'orderManagement'/g, "activeSection === 'orders'");
content = content.replace(/setActiveSection\('orderManagement'\)/g, "setActiveSection('orders')");

fs.writeFileSync(filePath, content, 'utf-8');
console.log('Replaced activeTab with activeSection');
