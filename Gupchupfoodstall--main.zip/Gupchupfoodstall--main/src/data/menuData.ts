export interface MenuItem {
  id: string;
  name: string;
  price: number;
  category: string;
  shayari?: string;
  imageUrl: string;
  isCustomizable: boolean;
  // Future-ready fields
  modelURL?: string;
  is3DEnabled?: boolean;
  arEnabled?: boolean;
  availableToppings?: string;
  availableSpiceLevels?: string;
}

export const menuData: MenuItem[] = [
  { id: '1', name: 'Samosa', price: 15, category: 'Food', shayari: 'Garam garam samose ki baat hi kuch aur hai...', imageUrl: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&q=80&w=800', isCustomizable: true, modelURL: '', is3DEnabled: false, arEnabled: false },
  { id: '2', name: 'Panipuri', price: 30, category: 'Food', shayari: 'Khatta meetha teekha, har golgappa ek naya ehsaas!', imageUrl: 'https://images.unsplash.com/photo-1601050690117-94f5f6af8bd3?auto=format&fit=crop&q=80&w=800', isCustomizable: true, modelURL: '', is3DEnabled: false, arEnabled: false },
  { id: '3', name: 'Momos', price: 50, category: 'Food', shayari: 'Garam momos aur teekhi chutney, dil khush kar de.', imageUrl: 'https://images.unsplash.com/photo-1625220194771-7ebdea0b70b9?auto=format&fit=crop&q=80&w=800', isCustomizable: true, modelURL: '', is3DEnabled: false, arEnabled: false },
  { id: '4', name: 'Anda Roll', price: 40, category: 'Food', shayari: 'Zabardast anda roll, bhookh ka perfect ilaaj.', imageUrl: 'https://images.unsplash.com/photo-1626804475297-41609ea0eb49?auto=format&fit=crop&q=80&w=800', isCustomizable: true, modelURL: '', is3DEnabled: false, arEnabled: false },
  { id: '5', name: 'Bati Icecream', price: 30, category: 'Icecream', shayari: 'Thandi thandi bati ice cream, garmi ki chhutti.', imageUrl: 'https://images.unsplash.com/photo-1559703248-dcaaec9fac92?auto=format&fit=crop&q=80&w=800', isCustomizable: false, modelURL: '', is3DEnabled: false, arEnabled: false },
  { id: '6', name: 'Mango Juice', price: 30, category: 'Colddrink', shayari: 'Aam ka ras, sabse khaas.', imageUrl: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&q=80&w=800', isCustomizable: false, modelURL: '', is3DEnabled: false, arEnabled: false },
];
