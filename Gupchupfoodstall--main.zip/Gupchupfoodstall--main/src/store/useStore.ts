import { create } from 'zustand';
import { doc, updateDoc, deleteDoc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

export interface CartItem {
  id: string;
  cartItemId?: string;
  name: string;
  price: number;
  quantity: number;
  imageUrl?: string;
  customizations?: {
    spiceLevel?: string;
    toppings?: string[];
  };
}

export interface PaymentSettings {
  upiId: string;
  qrCodeUrl: string;
}

export interface EventService {
  id: string;
  title: string;
  category: 'Decoration' | 'DJ Sound';
  eventTypes: string[];
  description: string;
  mediaUrls: string[];
  mediaType: 'image' | 'video' | 'gif';
  priceRange?: string;
  active: boolean;
  order: number;
}

export interface RgbConfig {
  globalEnable: boolean;
  sections: {
    hero: boolean;
    menu: boolean;
    events: boolean;
    cart: boolean;
    offers: boolean;
    reels: boolean;
    cashback: boolean;
    moments: boolean;
    photostudio: boolean;
    influencers: boolean;
    sponsored: boolean;
    footerInfo: boolean;
    notifications: boolean;
    featuredInfluencers: boolean;
    stories: boolean;
    partnerCollab: boolean;
    riderList: boolean;
    founders: boolean;
    getDirections: boolean;
    openingHours: boolean;
    contact: boolean;
    chickenStore: boolean;
    banners: boolean;
  };
  targets: {
    background: boolean;
    buttons: boolean;
    borders: boolean;
    cards: boolean;
    headings: boolean;
    icons: boolean;
  };
  speed: 'slow' | 'medium' | 'fast' | 'custom';
  customSpeedMs: number;
  colorMode: 'single' | 'multi' | 'neon' | 'soft';
  singleColor: string;
  glowIntensity: 'low' | 'medium' | 'high';
  batterySaver: boolean;
}

export interface EventOwnerProfile {
  name: string;
  address: string;
  phone: string;
  whatsapp: string;
  experience: string;
  skills: string;
  remark: string;
  imageUrl: string;
  isVerified: boolean;
}

export interface Review {
  id: string;
  customerName: string;
  customerImageUrl?: string;
  customerUrl?: string;
  reviewText: string;
  rating: number;
  imageUrl?: string;
  approved: boolean;
  highlighted: boolean;
  createdAt: any;
}

export interface NovaPromptVersion {
  id: string;
  timestamp: number;
  prompts: {
    masterPrompt: string;
    businessLogicPrompt: string;
    salesStrategyPrompt: string;
    whatsappBehaviorPrompt: string;
    voiceBehaviorPrompt: string;
    cartBehaviorPrompt: string;
  };
}

export interface NovaContentSettings {
  enabled: boolean;
  manualText: string;
}

export interface NovaSettings {
  isEnabled: boolean;
  voiceEnabled: boolean;
  voiceType: 'female' | 'male' | 'neutral';
  language: 'hi' | 'en' | 'bn' | 'ur';
  autoLanguageDetection: boolean;
  entertainmentMode: boolean;
  mixMode: boolean;
  mixIntensity: 'low' | 'medium' | 'high';
  wakeWord: string;
  wakeMode: 'open' | 'strict';
  whatsappTemplate: string;
  includeAiMessage: boolean;
  customInstructions: string;
  // Dual Control System Defaults
  aiModeEnabled: boolean;
  manualModeEnabled: boolean;
  hybridModeEnabled: boolean;
  dataOnlyModeEnabled: boolean;
  permissionMode: 'full' | 'limited' | 'disabled';
  allowManageCart: boolean;
  allowSuggestItems: boolean;
  autoAnalysisEnabled: boolean;
  visibleToCustomers: boolean;
  autoStableModeEnabled: boolean;
  truthFirstModeEnabled: boolean;
  autoSwitchModeEnabled: boolean;
  costSavingModeEnabled: boolean;
  orderTrackingEnabled: boolean;
  liveOrderAnnouncementsEnabled: boolean;
  randomAnnouncementsEnabled: boolean;
  demoModeEnabled: boolean;
  announcementInterval: number;
  maxAnnouncementsPerMinute: number;
  showCustomerName: boolean;
  showOrderDetails: boolean;
  voiceStyle: 'friendly' | 'professional' | 'casual';
  emotionLevel: number;
  viralEngineEnabled: boolean;
  storytellingEngineEnabled: boolean;
  contextualIntelligenceEnabled: boolean;
  marketingEngineEnabled: boolean;
  orderAnnouncementPrompt: string;
  viralStorytellingPrompt: string;
  contextualIntelligencePrompt: string;
  futureGenerationEnabled: boolean;
  evolutionModeEnabled: boolean;
  trendAdaptationEnabled: boolean;
  generationAwarenessEnabled: boolean;
  zeroMissAnalysisEnabled: boolean;
  deepDataIntelligenceEnabled: boolean;
  futureAutoAdaptEnabled: boolean;
  humanLikeSuperBrainEnabled: boolean;
  zeroErrorMaxAccuracyEnabled: boolean;
  autoSpeechEnabled: boolean;
  autoSpeechInterval: number;
  manualVoiceModeEnabled: boolean;
  autoVoiceModeEnabled: boolean;
  hybridVoiceModeEnabled: boolean;
  voiceInterval: number;
  assistantVisible: boolean;
  aiProfileImage: string;
  aiProfileVideo: string;
  whatsappAiAgentEnabled: boolean;
  whatsappNumber: string;
  whatsappReplyMode: 'hybrid' | 'manual' | 'ai';
  whatsappManualReply: string;
  aiUpdatesEnabled: boolean;
  updateMode: 'replace' | 'append';
  safeModeEnabled: boolean;
  masterPrompt: string;
  businessLogicPrompt: string;
  salesStrategyPrompt: string;
  whatsappBehaviorPrompt: string;
  voiceBehaviorPrompt: string;
  cartBehaviorPrompt: string;
  promptHistory: string[];
  dataVisibility: {
    showPrice: boolean;
    showOffers: boolean;
    showStock: boolean;
    showSpecialItems: boolean;
  };
  enabledLanguages: {
    hindiEnglishScript: boolean;
    hindiScript: boolean;
    bengaliScript: boolean;
    english: boolean;
  };
  shayari: { enabled: boolean; manualText: string };
  dialog: { enabled: boolean; manualText: string };
  entertainment: { enabled: boolean; manualText: string };
  funny: { enabled: boolean; manualText: string };
  reaction: { enabled: boolean; manualText: string };
  motionVibe: { enabled: boolean; manualText: string };
  chutkule: { enabled: boolean; manualText: string };
}

export interface SectionConfig {
  enabled: boolean;
  aiAccess: boolean;
  customerVisibility: boolean;
  dataAnalysis: boolean;
}

export interface AppSettings {
  sections: Record<string, SectionConfig>;
  logoName: string;
  logoSubName: string;
  logoImageUrl?: string;
  appLogoUrl?: string;
  appLogoZipUrl?: string;
  heroTitle: string;
  footerName: string;
  bgMusicUrl: string;
  bgMusicVolume: number;
  heroVideoUrl: string;
  offersVideoUrl: string;
  menuVideoUrl: string;
  eventsVideoUrl: string;
  sponsoredVideoUrl: string;
  footerVideoUrl: string;
  enableRgbEffect: boolean;
  rgbAnimationSpeed: number;
  neonGreen: string;
  neonRed: string;
  rgbConfig: RgbConfig;
  novaAI: NovaSettings;
  isOffersEnabled: boolean;
  isMenuEnabled: boolean;
  isInfluencerSectionEnabled: boolean;
  isNotificationSectionEnabled: boolean;
  isReelsEnabled: boolean;
  isSponsoredEnabled: boolean;
  isCollaborationsEnabled: boolean;
  isEventsEnabled: boolean;
  isBannerEnabled: boolean;
  isStoriesEnabled: boolean;
  isAnimationsEnabled: boolean;
  isRiderListEnabled: boolean;
  isStaffEnabled: boolean;
  isMomentsEnabled: boolean;
  isMenuShareEnabled: boolean;
  isEventsShareEnabled: boolean;
  isOffersShareEnabled: boolean;
  isMomentsShareEnabled: boolean;
  isBannersShareEnabled: boolean;
  isInfluencersShareEnabled: boolean;
  isStaffShareEnabled: boolean;
  isFoodPageShareEnabled: boolean;
  isChickenStoreEnabled: boolean;
  isEventsSectionEnabled: boolean;
  isCompetitionSectionEnabled: boolean;
  isDecorationEnabled: boolean;
  isDjSoundEnabled: boolean;
  isDeliveryRestrictionEnabled: boolean;
  isReviewsEnabled: boolean;
  isPanEnabled: boolean;
  isPanAiEnabled: boolean;
  isFounderAiEnabled: boolean;
  reviewsSectionTitle: string;
  reviewsSectionSubtitle: string;
  panSectionTitle: string;
  panSectionSubtitle: string;
  deliveryZones: {
    id: string;
    country: string;
    state: string;
    district: string;
    city: string;
    active: boolean;
  }[];
  momentsSectionTitle: string;
  momentsSectionSubtitle: string;
  competitionSectionTitle: string;
  competitionSectionSubtitle: string;
  animationStyle: 'subtle' | 'bouncy' | 'energetic';
  orderWhatsAppNumber: string;
  storySectionTitle: string;
  storySectionDescription: string;
  riderSectionTitle: string;
  riderSectionDescription: string;
  riderSectionSubtitle: string;
  eventsSectionTitle: string;
  eventsSectionSubtitle: string;
  photoStudioSectionTitle: string;
  photoStudioSectionSubtitle: string;
  cashbackSectionTitle: string;
  cashbackSectionSubtitle: string;
  staffSectionTitle: string;
  staffSectionSubtitle: string;
  bannersSectionTitle: string;
  bannersSectionSubtitle: string;
  menuSectionTitle: string;
  menuSectionSubtitle: string;
  offersSectionTitle: string;
  offersSectionSubtitle: string;
  reelsSectionTitle: string;
  reelsSectionSubtitle: string;
  influencersSectionTitle: string;
  influencersSectionSubtitle: string;
  sponsoredSectionTitle: string;
  sponsoredSectionSubtitle: string;
  partnersSectionTitle: string;
  partnersSectionSubtitle: string;
  chickenStoreSectionTitle: string;
  chickenStoreSectionSubtitle: string;
  foundersSectionTitle: string;
  foundersSectionSubtitle: string;
  openingHoursSectionTitle: string;
  contactSectionTitle: string;
  locationSectionTitle: string;
  socialLinks: {
    instagram: string;
    facebook: string;
    youtube: string;
    twitter: string;
    whatsapp: string;
  };
  competitionSectionOrder: number;
  openingHours: {
    [key: string]: string;
  };
  contactNumbers: {
    owner: string;
    partner: string;
  };
  address: string;
  locationLink: string;
  globalBackgroundVideoUrl: string;
  categories: string[];
  founder1Name: string;
  founder1Role: string;
  founder1Image: string;
  founder1Video: string;
  founder1Logo: string;
  founder1Caption: string;
  founder1StoryType: string;
  founder1SocialLinks: {
    instagram: string;
    facebook: string;
    youtube: string;
    twitter: string;
    whatsapp: string;
  };
  founder2Name: string;
  founder2Role: string;
  founder2Image: string;
  founder2Video: string;
  founder2Logo: string;
  founder2Caption: string;
  founder2StoryType: string;
  founder2SocialLinks: {
    instagram: string;
    facebook: string;
    youtube: string;
    twitter: string;
    whatsapp: string;
  };
  isBrandingVideoEnabled: boolean;
  brandingVideoUrl: string;
  isFoundersEnabled: boolean;
  isDeliveryFeeEnabled: boolean;
  freeDeliveryThreshold: number;
  deliveryFeeByLocation: { id: string; location: string; fee: number }[];
  applicablePaymentMethods: string[];
  isMinimumOrderEnabled: boolean;
  minimumOrderQuantity: number;
  enableOrderTracking: boolean;
  defaultDeliveryTime: string;
  enableDefaultDeliveryTime: boolean;
  heroTitleFontSize: number;
  heroTitleYOffset: number;
  heroLinesYOffset: number;
  heroTitleLetterSpacing: number;
  founderImageSize: number;
  founderSpacing: number;
  founderYOffset: number;
  founderXOffset: number;
  founderSectionOrder: number;
  isSocialMediaPromotionEnabled: boolean;
  socialMediaPromotionMessage: string;
  theme: 'dark' | 'light';
  screenLayouts: { id: string; name: string; sections: string[] }[];
  disabledScreenLayouts: { id: string; name: string; sections: string[] }[];
  disabledLayoutSections: string[];
  paymentSettings: PaymentSettings;
  stallControl: StallSettings;
}

export interface CompetitionWinner {
  id: string;
  name: string;
  address: string;
  mobile: string;
  imageUrl: string;
  videoUrl?: string;
  remark: string;
  rank: 1 | 2 | 3;
  achievementMessage?: string;
}

export interface CompetitionManager {
  id: string;
  name: string;
  imageUrl: string;
  address: string;
  mobile: string;
  role: string;
  remark: string;
  experience?: string;
}

export interface Competition {
  id: string;
  name: string;
  description: string;
  rules?: string;
  entryInfo?: string;
  entryType: 'Free' | 'Paid';
  maxParticipants?: number;
  startDate: string;
  endDate: string;
  days: string[];
  startTime: string;
  endTime: string;
  status: 'upcoming' | 'live' | 'completed';
  managerId: string;
  winners: CompetitionWinner[];
  mediaUrls: string[];
  mediaType: 'image' | 'video' | 'gif' | 'zip';
  active: boolean;
  order: number;
}

export interface CompetitionAnnouncement {
  id: string;
  text: string;
  type: 'banner' | 'popup' | 'scrolling';
  active: boolean;
  competitionId?: string;
}

export interface PanCategory {
  id: string;
  name: string;
  order: number;
  active: boolean;
}

export interface PanItem {
  id: string;
  categoryId: string;
  name: string;
  price: number;
  ingredients: string[];
  description: string;
  imageUrl?: string;
  videoUrl?: string;
  zipUrl?: string;
  active: boolean;
  order: number;
}

export interface PanCombo {
  id: string;
  name: string;
  itemIds: string[];
  price: number;
  discount: number;
  active: boolean;
  isBestOffer: boolean;
}

export interface Slot {
  id: string;
  startTime: string;
  endTime: string;
  limit: number;
  currentOrders: number;
}

export interface StallSettings {
  enabled: boolean;
  status: 'open' | 'closed' | 'busy';
  mode: 'auto' | 'manual';
  openTime: string;
  closeTime: string;
  busyMessage: string;
  openMessage: string;
  closedMessage: string;
  preOrderEnabled: boolean;
  slots: Slot[];
  customMessage: string;
}

const defaultSettings: AppSettings = {
  sections: {
    menu: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
    dailyOffers: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
    staffManage: { enabled: true, aiAccess: false, customerVisibility: false, dataAnalysis: true },
    riders: { enabled: true, aiAccess: false, customerVisibility: false, dataAnalysis: true },
    dailyReels: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
    influencers: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
    sponsored: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
    founders: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
    partners: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
    chickenStore: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
    events: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
    eventBooking: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
    competitions: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
    moments: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
    deliveryZones: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
    photoStudio: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
    reviews: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
    pan: { enabled: true, aiAccess: true, customerVisibility: true, dataAnalysis: true },
  },
  logoName: 'Gup Chup',
  logoSubName: 'Food Stool',
  logoImageUrl: '',
  heroTitle: 'I LOVE CHHOTO MOHODIPUR GRAM BASI',
  footerName: 'Food Cart Pro',
  bgMusicUrl: '',
  bgMusicVolume: 0.5,
  heroVideoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
  offersVideoUrl: '',
  menuVideoUrl: '',
  eventsVideoUrl: '',
  sponsoredVideoUrl: '',
  footerVideoUrl: '',
  enableRgbEffect: true,
  rgbAnimationSpeed: 3,
  neonGreen: '#00ff00',
  neonRed: '#ff0000',
  rgbConfig: {
    globalEnable: true,
    sections: {
      hero: true,
      menu: true,
      events: true,
      cart: true,
      offers: true,
      reels: true,
      cashback: true,
      moments: true,
      photostudio: true,
      influencers: true,
      sponsored: true,
      footerInfo: true,
      notifications: true,
      featuredInfluencers: true,
      stories: true,
      partnerCollab: true,
      riderList: true,
      founders: true,
      getDirections: true,
      openingHours: true,
      contact: true,
      chickenStore: true,
      banners: true
    },
    targets: {
      background: false,
      buttons: true,
      borders: true,
      cards: false,
      headings: true,
      icons: true
    },
    speed: 'medium',
    customSpeedMs: 3000,
    colorMode: 'multi',
    singleColor: '#d4af37',
    glowIntensity: 'medium',
    batterySaver: false
  },
  novaAI: {
    isEnabled: false,
    voiceEnabled: false,
    voiceType: 'female',
    language: 'hi',
    autoLanguageDetection: true,
    entertainmentMode: false,
    mixMode: false,
    mixIntensity: 'medium',
    wakeWord: 'Hey Nova',
    wakeMode: 'open',
    customInstructions: 'You are a helpful assistant for Gup Chup Food Stall.',
    whatsappTemplate: `*NEW ORDER RECEIVED!* 🛍️

*Customer:* {{name}}
*Phone:* {{phone}}
*Address:* {{address}}
*Location Map:* {{mapsLink}}
*Order ID:* {{orderId}}
*Payment:* {{paymentMethod}}

*Items:*
{{orderSummary}}

*Total Amount:* ₹{{totalAmount}}

*Gup Chup Food Stall* 😋🔥`,
    includeAiMessage: true,
    // Dual Control System Defaults
    aiModeEnabled: true,
    manualModeEnabled: false,
    hybridModeEnabled: false,
    dataOnlyModeEnabled: false,
    permissionMode: 'full',
    allowManageCart: true,
    allowSuggestItems: true,
    autoAnalysisEnabled: false,
    visibleToCustomers: true,
    autoStableModeEnabled: true,
    truthFirstModeEnabled: true,
    autoSwitchModeEnabled: true,
    costSavingModeEnabled: false,
    orderTrackingEnabled: true,
    liveOrderAnnouncementsEnabled: true,
    randomAnnouncementsEnabled: true,
    demoModeEnabled: false,
    announcementInterval: 60,
    maxAnnouncementsPerMinute: 3,
    showCustomerName: true,
    showOrderDetails: true,
    voiceStyle: 'friendly',
    emotionLevel: 5,
    viralEngineEnabled: true,
    storytellingEngineEnabled: true,
    contextualIntelligenceEnabled: true,
    marketingEngineEnabled: true,
    orderAnnouncementPrompt: `Generate a highly engaging, human-like, premium announcement for a new order. Order Details: Name: {{customerName}}, Items: {{items}}, Status: {{status}}. Tone: {{voiceStyle}}. Brand Name: {{brandName}}. Rules: No duplicate sentences, be emotional, use respectful tone (ji/bhai), no sensitive data exposure.`,
    viralStorytellingPrompt: `Generate a fun, viral-style or storytelling-based announcement about our food stall {{brandName}}. Include: {{viralEnabled ? 'Viral trend/meme-style content' : ''}} {{storytellingEnabled ? 'Emotional storytelling' : ''}}. Tone: {{voiceStyle}}, Emotion Level: {{emotionLevel}}/10. Rules: Keep it engaging, professional, and brand-friendly.`,
    contextualIntelligencePrompt: `Generate a context-aware message based on: Time of Day: {{timeOfDay}}, User Activity: {{userActivity}}, Order Flow: {{orderFlow}}. Brand Name: {{brandName}}. Tone: {{voiceStyle}}.`,
    futureGenerationEnabled: true,
    evolutionModeEnabled: false,
    trendAdaptationEnabled: true,
    generationAwarenessEnabled: true,
    zeroMissAnalysisEnabled: true,
    deepDataIntelligenceEnabled: true,
    futureAutoAdaptEnabled: true,
    humanLikeSuperBrainEnabled: true,
    zeroErrorMaxAccuracyEnabled: true,
    autoSpeechEnabled: false,
    autoSpeechInterval: 30,
    manualVoiceModeEnabled: true,
    autoVoiceModeEnabled: false,
    hybridVoiceModeEnabled: false,
    voiceInterval: 30,
    assistantVisible: true,
    aiProfileImage: '',
    aiProfileVideo: '',
    whatsappAiAgentEnabled: false,
    whatsappNumber: '',
    whatsappReplyMode: 'hybrid',
    whatsappManualReply: 'Thank you for your message! We will get back to you shortly.',
    aiUpdatesEnabled: true,
    updateMode: 'replace',
    safeModeEnabled: true,
    masterPrompt: 'You are NOVA AI, the premium, proactive sales assistant for Gup Chup Food Stall. Your goal is to provide a personalized, human-like experience. \n- **Proactive:** Always suggest relevant items based on the user\'s current interest or time of day. \n- **Personalized:** Analyze the user\'s browsing behavior to recommend combos or popular items. \n- **Sales-Driven:** Use persuasive, polite language to upsell and cross-sell without being pushy. \n- **Human-like:** Maintain a warm, conversational, and professional tone. \n- **Truthful:** Only recommend items that are currently in stock and available.',
    businessLogicPrompt: '',
    salesStrategyPrompt: '',
    whatsappBehaviorPrompt: '',
    voiceBehaviorPrompt: '',
    cartBehaviorPrompt: '',
    promptHistory: [],
    dataVisibility: {
      showPrice: true,
      showOffers: true,
      showStock: true,
      showSpecialItems: true,
    },
    enabledLanguages: {
      hindiEnglishScript: true,
      hindiScript: true,
      bengaliScript: true,
      english: true,
    },
    shayari: { enabled: true, manualText: '' },
    dialog: { enabled: true, manualText: '' },
    entertainment: { enabled: true, manualText: '' },
    funny: { enabled: true, manualText: '' },
    reaction: { enabled: true, manualText: '' },
    motionVibe: { enabled: true, manualText: '' },
    chutkule: { enabled: true, manualText: '' }
  },
  isOffersEnabled: true,
  isMenuEnabled: true,
  isInfluencerSectionEnabled: true,
  isNotificationSectionEnabled: true,
  isReelsEnabled: true,
  isSponsoredEnabled: true,
  isCollaborationsEnabled: true,
  isEventsEnabled: true,
  isBannerEnabled: true,
  isStoriesEnabled: true,
  isAnimationsEnabled: true,
  isRiderListEnabled: true,
  isStaffEnabled: true,
  isMomentsEnabled: true,
  isMenuShareEnabled: true,
  isEventsShareEnabled: true,
  isOffersShareEnabled: true,
  isMomentsShareEnabled: true,
  isBannersShareEnabled: true,
  isInfluencersShareEnabled: true,
  isStaffShareEnabled: true,
  isFoodPageShareEnabled: true,
  isChickenStoreEnabled: true,
  isEventsSectionEnabled: true,
  isCompetitionSectionEnabled: true,
  isDecorationEnabled: true,
  isDjSoundEnabled: true,
  isDeliveryRestrictionEnabled: false,
  isReviewsEnabled: true,
  isPanEnabled: true,
  isPanAiEnabled: true,
  isFounderAiEnabled: true,
  reviewsSectionTitle: 'Customer Reviews',
  reviewsSectionSubtitle: 'What our customers say',
  panSectionTitle: 'Special Assam Pan',
  panSectionSubtitle: 'Premium Quality',
  disabledLayoutSections: [],
  deliveryZones: [],
  animationStyle: 'bouncy',
  orderWhatsAppNumber: '919735339454',
  momentsSectionTitle: 'Happy Moments',
  momentsSectionSubtitle: 'Customer Celebrations',
  competitionSectionTitle: 'Championship & Games',
  competitionSectionSubtitle: 'Participate & Win Big!',
  storySectionTitle: 'Owner & Partner Stories',
  storySectionDescription: 'Meet the people behind the magic.',
  riderSectionTitle: 'Our Delivery Heroes',
  riderSectionDescription: 'Meet the dedicated team bringing your favorite Gupchup straight to your door.',
  riderSectionSubtitle: 'Fast & Reliable',
  eventsSectionTitle: 'Special Events',
  eventsSectionSubtitle: 'Upcoming Experience',
  photoStudioSectionTitle: 'Photo Studio',
  photoStudioSectionSubtitle: 'Capture Memories',
  cashbackSectionTitle: 'Cashback Wins',
  cashbackSectionSubtitle: 'Real-time Rewards',
  staffSectionTitle: 'Our Team',
  staffSectionSubtitle: 'The Experts',
  bannersSectionTitle: 'Featured Highlights',
  bannersSectionSubtitle: 'Don\'t Miss Out',
  menuSectionTitle: 'Menu Specials',
  menuSectionSubtitle: 'Our Selection',
  offersSectionTitle: 'Exclusive Offers',
  offersSectionSubtitle: 'Limited Time',
  reelsSectionTitle: 'Daily Reels',
  reelsSectionSubtitle: 'Trending Now',
  influencersSectionTitle: 'Influencer Videos',
  influencersSectionSubtitle: 'Influencer Love',
  sponsoredSectionTitle: 'Sponsored By',
  sponsoredSectionSubtitle: 'Premium Partners',
  partnersSectionTitle: 'Partners & Collabs',
  partnersSectionSubtitle: 'Global Network',
  chickenStoreSectionTitle: 'Fresh Chicken Store',
  chickenStoreSectionSubtitle: 'Premium Quality Poultry',
  foundersSectionTitle: 'Founders & Owners',
  foundersSectionSubtitle: 'The Visionaries',
  openingHoursSectionTitle: 'Opening Hours',
  contactSectionTitle: 'Contact Us',
  locationSectionTitle: 'Get Directions',
  socialLinks: {
    instagram: '',
    facebook: '',
    youtube: '',
    twitter: '',
    whatsapp: '',
  },
  competitionSectionOrder: 5,
  openingHours: {
    'Monday': '4:00 PM - 10:00 PM',
    'Tuesday': '4:00 PM - 10:00 PM',
    'Wednesday': '4:00 PM - 10:00 PM',
    'Thursday': '4:00 PM - 10:00 PM',
    'Friday': 'CLOSED',
    'Saturday': '4:00 PM - 10:00 PM',
    'Sunday': '4:00 PM - 10:00 PM'
  },
  contactNumbers: {
    owner: '919735339454',
    partner: '919775964469'
  },
  address: 'Chhoto Mohodipur danesh Ali Tola Tree Mohini',
  locationLink: 'https://maps.google.com',
  globalBackgroundVideoUrl: '',
  categories: ['Food', 'Icecream', 'Colddrink'],
  founder1Name: 'Taimur',
  founder1Role: 'Owner',
  founder1Image: 'https://picsum.photos/seed/taimur/200/200',
  founder1Video: '',
  founder1Logo: '',
  founder1Caption: '',
  founder1StoryType: '',
  founder1SocialLinks: {
    instagram: '',
    facebook: '',
    youtube: '',
    twitter: '',
    whatsapp: '',
  },
  founder2Name: 'Hasan',
  founder2Role: 'Partner',
  founder2Image: 'https://picsum.photos/seed/hasan/200/200',
  founder2Video: '',
  founder2Logo: '',
  founder2Caption: '',
  founder2StoryType: '',
  founder2SocialLinks: {
    instagram: '',
    facebook: '',
    youtube: '',
    twitter: '',
    whatsapp: '',
  },
  isBrandingVideoEnabled: false,
  brandingVideoUrl: '',
  isFoundersEnabled: true,
  isDeliveryFeeEnabled: false,
  freeDeliveryThreshold: 100,
  deliveryFeeByLocation: [],
  applicablePaymentMethods: ['COD', 'UPI', 'QR'],
  isMinimumOrderEnabled: false,
  minimumOrderQuantity: 2,
  enableOrderTracking: true,
  defaultDeliveryTime: '30-45 mins',
  enableDefaultDeliveryTime: true,
  heroTitleFontSize: 100,
  heroTitleYOffset: 0,
  heroLinesYOffset: 0,
  heroTitleLetterSpacing: -0.05,
  founderImageSize: 100,
  founderSpacing: 100,
  founderYOffset: 0,
  founderXOffset: 0,
  founderSectionOrder: 0,
  isSocialMediaPromotionEnabled: true,
  socialMediaPromotionMessage: 'Don\'t forget to follow us on Instagram, Facebook, YouTube, Twitter, and WhatsApp for the latest updates!',
  theme: 'dark',
  screenLayouts: [
    { id: 'screen-1', name: 'Main', sections: ['hero', 'offers', 'reels', 'menu', 'influencers', 'chickenStore', 'events', 'eventBooking', 'pan'] },
    { id: 'screen-2', name: 'Studio & Collab', sections: ['photostudio', 'sponsored', 'collaborations'] },
    { id: 'screen-3', name: 'Info', sections: ['openingHours', 'contact', 'partnerCollab', 'getDirections', 'reviews'] }
  ],
  disabledScreenLayouts: [],
  paymentSettings: {
    upiId: 'example@upi',
    qrCodeUrl: 'https://picsum.photos/seed/qr/200/200'
  },
  stallControl: {
    enabled: true,
    status: 'open',
    mode: 'auto',
    openTime: '16:00',
    closeTime: '22:00',
    busyMessage: 'We are currently busy, please try after some time',
    openMessage: 'Open Now',
    closedMessage: 'Shutdown',
    preOrderEnabled: true,
    slots: [
      { id: '1', startTime: '16:00', endTime: '17:00', limit: 10, currentOrders: 0 },
      { id: '2', startTime: '17:00', endTime: '18:00', limit: 10, currentOrders: 0 }
    ],
    customMessage: ''
  }
};

interface StoreState {
  cart: CartItem[];
  isCartOpen: boolean;
  language: 'en' | 'hi' | 'bn';
  settings: AppSettings;
  eventServices: EventService[];
  eventOwnerProfile: EventOwnerProfile;
  reviews: Review[];
  panCategories: PanCategory[];
  panItems: PanItem[];
  panCombos: PanCombo[];
  competitions: Competition[];
  competitionManagers: CompetitionManager[];
  competitionAnnouncements: CompetitionAnnouncement[];
  addToCart: (item: CartItem) => void;
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  toggleCart: () => void;
  setLanguage: (lang: 'en' | 'hi' | 'bn') => void;
  setSettings: (settings: Partial<AppSettings>) => void;
  addEventService: (service: Omit<EventService, 'id'>) => void;
  updateEventService: (id: string, service: Partial<EventService>) => void;
  deleteEventService: (id: string) => void;
  setEventServices: (services: EventService[]) => void;
  updateEventOwnerProfile: (profile: Partial<EventOwnerProfile>) => void;
  addReview: (review: Omit<Review, 'id' | 'createdAt'>) => void;
  deleteReview: (id: string) => void;
  updateReview: (id: string, review: Partial<Review>) => void;
  approveReview: (id: string) => void;
  rejectReview: (id: string) => void;
  highlightReview: (id: string) => void;
  setReviews: (reviews: Review[]) => void;
  getStallStatus: () => { status: 'open' | 'closed' | 'busy'; message: string };
  // Pan Actions
  setPanCategories: (categories: PanCategory[]) => void;
  addPanCategory: (category: PanCategory) => void;
  updatePanCategory: (id: string, category: Partial<PanCategory>) => void;
  deletePanCategory: (id: string) => void;
  setPanItems: (items: PanItem[]) => void;
  addPanItem: (item: PanItem) => void;
  updatePanItem: (id: string, item: Partial<PanItem>) => void;
  deletePanItem: (id: string) => void;
  setPanCombos: (combos: PanCombo[]) => void;
  // Competition Actions
  setCompetitions: (competitions: Competition[]) => void;
  addCompetition: (competition: Omit<Competition, 'id'>) => void;
  updateCompetition: (id: string, competition: Partial<Competition>) => void;
  deleteCompetition: (id: string) => void;
  setCompetitionManagers: (managers: CompetitionManager[]) => void;
  addCompetitionManager: (manager: Omit<CompetitionManager, 'id'>) => void;
  updateCompetitionManager: (id: string, manager: Partial<CompetitionManager>) => void;
  deleteCompetitionManager: (id: string) => void;
  setCompetitionAnnouncements: (announcements: CompetitionAnnouncement[]) => void;
  addCompetitionAnnouncement: (announcement: Omit<CompetitionAnnouncement, 'id'>) => void;
  updateCompetitionAnnouncement: (id: string, announcement: Partial<CompetitionAnnouncement>) => void;
  deleteCompetitionAnnouncement: (id: string) => void;
}

export const useStore = create<StoreState>((set, get) => ({
  cart: [],
  isCartOpen: false,
  language: 'en',
  settings: defaultSettings,
  eventServices: [
    {
      id: '1',
      title: 'Premium Wedding Decoration',
      category: 'Decoration',
      eventTypes: ['Wedding'],
      description: 'Luxury floral and lighting setup for your special day.',
      mediaUrls: ['https://picsum.photos/seed/wedding1/800/600', 'https://picsum.photos/seed/wedding2/800/600'],
      mediaType: 'image',
      priceRange: '₹50,000 - ₹2,00,000',
      active: true,
      order: 1
    },
    {
      id: '2',
      title: 'High Bass DJ System',
      category: 'DJ Sound',
      eventTypes: ['Wedding', 'New Year Party', 'Birthday'],
      description: 'Professional DJ setup with high bass sound and party lighting.',
      mediaUrls: ['https://picsum.photos/seed/dj1/800/600'],
      mediaType: 'image',
      priceRange: '₹15,000 - ₹50,000',
      active: true,
      order: 2
    }
  ],
  eventOwnerProfile: {
    name: 'Taimur Ali',
    address: 'Chhoto Mohodipur danesh Ali Tola Tree Mohini',
    phone: '919735339454',
    whatsapp: '919735339454',
    experience: '10+ Years',
    skills: 'Event Planning, Sound Engineering, Lighting Design',
    remark: 'Making your special moments unforgettable.',
    imageUrl: 'https://picsum.photos/seed/taimur/400/400',
    isVerified: true
  },
  reviews: [],
  panCategories: [],
  panItems: [],
  panCombos: [],
  competitions: [],
  competitionManagers: [],
  competitionAnnouncements: [],
  addToCart: (item) => set((state) => {
    const cartItemId = item.customizations 
      ? `${item.id}-${item.customizations.spiceLevel}-${item.customizations.toppings?.join(',')}`
      : item.id;
    
    const existing = state.cart.find(i => i.cartItemId === cartItemId);
      
    if (existing) {
      return { cart: state.cart.map(i => i.cartItemId === cartItemId ? { ...i, quantity: i.quantity + 1 } : i), isCartOpen: true };
    }
    return { cart: [...state.cart, { ...item, cartItemId, quantity: 1 }], isCartOpen: true };
  }),
  removeFromCart: (cartItemId) => set((state) => ({
    cart: state.cart.filter(i => i.cartItemId !== cartItemId)
  })),
  updateQuantity: (cartItemId, quantity) => set((state) => ({
    cart: state.cart.map(i => i.cartItemId === cartItemId ? { ...i, quantity } : i)
  })),
  clearCart: () => set({ cart: [], isCartOpen: false }),
  toggleCart: () => set((state) => ({ isCartOpen: !state.isCartOpen })),
  setLanguage: (lang) => set({ language: lang }),
  setSettings: (newSettings) => set((state) => ({ settings: { ...state.settings, ...newSettings } })),
  addEventService: (service) => set((state) => ({
    eventServices: [...state.eventServices, { ...service, id: Math.random().toString(36).substr(2, 9) }]
  })),
  updateEventService: (id, service) => set((state) => ({
    eventServices: state.eventServices.map(s => s.id === id ? { ...s, ...service } : s)
  })),
  deleteEventService: (id) => set((state) => ({
    eventServices: state.eventServices.filter(s => s.id !== id)
  })),
  setEventServices: (eventServices) => set({ eventServices }),
  updateEventOwnerProfile: (profile) => set((state) => ({
    eventOwnerProfile: { ...state.eventOwnerProfile, ...profile }
  })),
  addReview: (review) => set((state) => ({
    reviews: [...state.reviews, { ...review, id: Math.random().toString(36).substr(2, 9), createdAt: new Date() }]
  })),
  deleteReview: async (id: string) => {
    try {
      await deleteDoc(doc(db, 'reviews', id));
      set((state) => ({
        reviews: state.reviews.filter(r => r.id !== id)
      }));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `reviews/${id}`);
    }
  },
  updateReview: async (id: string, review: Partial<Review>) => {
    try {
      await updateDoc(doc(db, 'reviews', id), review as any);
      set((state) => ({
        reviews: state.reviews.map(r => r.id === id ? { ...r, ...review } : r)
      }));
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `reviews/${id}`);
    }
  },
  approveReview: async (id: string) => {
    try {
      await updateDoc(doc(db, 'reviews', id), { approved: true });
      set((state) => ({
        reviews: state.reviews.map(r => r.id === id ? { ...r, approved: true } : r)
      }));
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `reviews/${id}`);
    }
  },
  rejectReview: async (id: string) => {
    try {
      await updateDoc(doc(db, 'reviews', id), { approved: false });
      set((state) => ({
        reviews: state.reviews.map(r => r.id === id ? { ...r, approved: false } : r)
      }));
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `reviews/${id}`);
    }
  },
  highlightReview: async (id: string) => {
    try {
      const review = useStore.getState().reviews.find(r => r.id === id);
      if (!review) return;
      await updateDoc(doc(db, 'reviews', id), { highlighted: !review.highlighted });
      set((state) => ({
        reviews: state.reviews.map(r => r.id === id ? { ...r, highlighted: !r.highlighted } : r)
      }));
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `reviews/${id}`);
    }
  },
  setReviews: (reviews: Review[]) => set({ reviews }),
  setPanCategories: (panCategories) => set({ panCategories }),
  addPanCategory: async (category) => {
    try {
      await setDoc(doc(db, 'settings', 'pan'), { 
        categories: [...useStore.getState().panCategories, category] 
      }, { merge: true });
      set((state) => ({ panCategories: [...state.panCategories, category] }));
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'settings/pan');
    }
  },
  updatePanCategory: async (id, category) => {
    try {
      const newCategories = useStore.getState().panCategories.map(c => c.id === id ? { ...c, ...category } : c);
      await setDoc(doc(db, 'settings', 'pan'), { categories: newCategories }, { merge: true });
      set({ panCategories: newCategories });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'settings/pan');
    }
  },
  deletePanCategory: async (id) => {
    try {
      const newCategories = useStore.getState().panCategories.filter(c => c.id !== id);
      await setDoc(doc(db, 'settings', 'pan'), { categories: newCategories }, { merge: true });
      set({ panCategories: newCategories });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'settings/pan');
    }
  },
  setPanItems: (panItems) => set({ panItems }),
  addPanItem: async (item) => {
    try {
      await setDoc(doc(db, 'settings', 'pan'), { 
        items: [...useStore.getState().panItems, item] 
      }, { merge: true });
      set((state) => ({ panItems: [...state.panItems, item] }));
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'settings/pan');
    }
  },
  updatePanItem: async (id, item) => {
    try {
      const newItems = useStore.getState().panItems.map(i => i.id === id ? { ...i, ...item } : i);
      await setDoc(doc(db, 'settings', 'pan'), { items: newItems }, { merge: true });
      set({ panItems: newItems });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'settings/pan');
    }
  },
  deletePanItem: async (id) => {
    try {
      const newItems = useStore.getState().panItems.filter(i => i.id !== id);
      await setDoc(doc(db, 'settings', 'pan'), { items: newItems }, { merge: true });
      set({ panItems: newItems });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'settings/pan');
    }
  },
  setPanCombos: (panCombos) => set({ panCombos }),
  setCompetitions: (competitions) => set({ competitions }),
  addCompetition: (competition) => set((state) => ({
    competitions: [...state.competitions, { ...competition, id: Math.random().toString(36).substr(2, 9) } as Competition]
  })),
  updateCompetition: (id, competition) => set((state) => ({
    competitions: state.competitions.map(c => c.id === id ? { ...c, ...competition } : c)
  })),
  deleteCompetition: (id) => set((state) => ({
    competitions: state.competitions.filter(c => c.id !== id)
  })),
  setCompetitionManagers: (competitionManagers) => set({ competitionManagers }),
  addCompetitionManager: (manager) => set((state) => ({
    competitionManagers: [...state.competitionManagers, { ...manager, id: Math.random().toString(36).substr(2, 9) } as CompetitionManager]
  })),
  updateCompetitionManager: (id, manager) => set((state) => ({
    competitionManagers: state.competitionManagers.map(m => m.id === id ? { ...m, ...manager } : m)
  })),
  deleteCompetitionManager: (id) => set((state) => ({
    competitionManagers: state.competitionManagers.filter(m => m.id !== id)
  })),
  setCompetitionAnnouncements: (competitionAnnouncements) => set({ competitionAnnouncements }),
  addCompetitionAnnouncement: (announcement) => set((state) => ({
    competitionAnnouncements: [...state.competitionAnnouncements, { ...announcement, id: Math.random().toString(36).substr(2, 9) } as CompetitionAnnouncement]
  })),
  updateCompetitionAnnouncement: (id, announcement) => set((state) => ({
    competitionAnnouncements: state.competitionAnnouncements.map(a => a.id === id ? { ...a, ...announcement } : a)
  })),
  deleteCompetitionAnnouncement: (id) => set((state) => ({
    competitionAnnouncements: state.competitionAnnouncements.filter(a => a.id !== id)
  })),
  getStallStatus: () => {
    const { settings } = get();
    const { stallControl } = settings;
    if (!stallControl.enabled) return { status: 'open', message: '' };
    if (stallControl.mode === 'manual') return { status: stallControl.status, message: stallControl.customMessage };
    
    // Auto mode logic
    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();
    const [openH, openM] = stallControl.openTime.split(':').map(Number);
    const [closeH, closeM] = stallControl.closeTime.split(':').map(Number);
    const openTime = openH * 60 + openM;
    const closeTime = closeH * 60 + closeM;
    
    if (currentTime >= openTime && currentTime < closeTime) {
        if (stallControl.status === 'busy') return { status: 'busy', message: stallControl.busyMessage };
        return { status: 'open', message: stallControl.openMessage };
    }
    return { status: 'closed', message: stallControl.closedMessage };
  },
}));
