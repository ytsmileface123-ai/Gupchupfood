import React, { useEffect, useState } from 'react';
import { collection, query, onSnapshot, where } from 'firebase/firestore';
import { db } from '../firebase';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Instagram, 
  Facebook, 
  Youtube, 
  Twitter, 
  MapPin, 
  Phone, 
  Award, 
  Heart, 
  Play, 
  X, 
  Volume2, 
  VolumeX,
  ExternalLink,
  Users,
  Handshake
} from 'lucide-react';
import InfluencerVideo from './InfluencerVideo';
import { useStore } from '../store/useStore';

export default function PartnerCollabSection() {
  const [collabs, setCollabs] = useState<any[]>([]);
  const { settings } = useStore();

  useEffect(() => {
    const q = query(collection(db, 'collaborations'), where('active', '==', true));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setCollabs(data);
    });

    return () => unsubscribe();
  }, []);

  if (collabs.length === 0) return null;

  return (
    <section className="py-40 relative overflow-hidden bg-transparent">
      {/* Background Effects */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_20%_30%,rgba(230,57,70,0.05),transparent_50%)]"></div>
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_80%_70%,rgba(255,183,3,0.05),transparent_50%)]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[conic-gradient(from_0deg_at_50%_50%,rgba(255,255,255,0.02),transparent_50%)] animate-spin-slow opacity-20"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-12 mb-24"
        >
          <div className="max-w-3xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-px bg-gradient-to-r from-[var(--color-neon-red)] to-transparent"></div>
              <span className="text-[var(--color-neon-red)] font-black uppercase tracking-[0.5em] text-xs">{settings.partnersSectionSubtitle || 'Global Network'}</span>
            </div>
            <h2 className="text-6xl md:text-9xl font-black text-white uppercase tracking-tighter leading-[0.8] mb-8">
              {settings.partnersSectionTitle?.split(' ')[0] || 'Partners'} & <span className="text-gradient">{settings.partnersSectionTitle?.split(' ').slice(1).join(' ') || 'Collabs'}</span>
            </h2>
            <p className="text-gray-400 text-lg md:text-2xl font-medium max-w-2xl leading-relaxed">
              Collaborating with the most innovative brands and creators to redefine the street food experience through technology and taste.
            </p>
          </div>
          
          <motion.div 
            whileHover={{ scale: 1.05 }}
            className="flex items-center gap-6 glass-panel px-8 py-4 rounded-3xl border-white/10 shadow-2xl"
          >
            <div className="flex -space-x-5">
              {collabs.slice(0, 5).map((c, i) => (
                <motion.img 
                  key={c.id}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: i * 0.1 }}
                  src={c.logoUrl || c.imageUrl || undefined} 
                  className="w-14 h-14 rounded-full border-4 border-black object-cover shadow-xl"
                  alt=""
                />
              ))}
            </div>
            <div className="text-sm font-black text-white uppercase tracking-[0.2em]">
              <span className="text-3xl text-[var(--color-neon-red)] mr-2 tracking-tighter">{collabs.length}+</span> 
              <span className="opacity-60">Active Partners</span>
            </div>
          </motion.div>
        </motion.div>

        <div className="flex overflow-x-auto pb-8 gap-4 snap-x md:grid md:grid-cols-4 md:overflow-visible no-scrollbar">
          {collabs.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.9, y: 50 }}
              whileInView={{ opacity: 1, scale: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1, delay: index * 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="min-w-[280px] snap-center md:min-w-0 relative group"
            >
              <div className="absolute -inset-2 bg-gradient-to-r from-[var(--color-neon-red)]/20 to-transparent rounded-[3rem] blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
              <InfluencerVideo 
                videoUrl={item.videoUrl}
                influencerName={item.brandName}
                influencerImage={item.imageUrl || `https://picsum.photos/seed/${item.id}/800/1200`}
                caption={item.remark || item.description}
                logoUrl={item.logoUrl}
                socialLink={item.socialLink || item.instagram || item.facebook || item.youtube || item.twitter}
                musicUrl={item.musicUrl}
                mediaType={item.mediaType}
                zipUrl={item.zipUrl}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
