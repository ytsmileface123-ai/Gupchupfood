import React from 'react';
import { useStore } from '../store/useStore';
import { Plus, Trash2, Save } from 'lucide-react';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

export default function DeliveryFeeManagement() {
  const { settings, setSettings } = useStore();

  const handleUpdate = async (newSettings: any) => {
    try {
      const updatedSettings = { ...settings, ...newSettings };
      await setDoc(doc(db, 'settings', 'global'), updatedSettings);
      setSettings(newSettings);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'settings/global');
    }
  };

  return (
    <div className="p-6 bg-[#111] rounded-xl border border-[#333] text-white">
      <h2 className="text-xl font-black mb-6 uppercase tracking-tighter">Delivery Fee Management</h2>
      
      <div className="space-y-6">
        <div className="flex items-center justify-between p-4 bg-[#222] rounded-lg">
          <span className="font-bold">Enable Delivery Fee System</span>
          <input 
            type="checkbox" 
            checked={settings.isDeliveryFeeEnabled}
            onChange={(e) => handleUpdate({ isDeliveryFeeEnabled: e.target.checked })}
            className="toggle"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Free Delivery Threshold (₹)</label>
            <input 
              type="number"
              value={settings.freeDeliveryThreshold}
              onChange={(e) => handleUpdate({ freeDeliveryThreshold: Number(e.target.value) })}
              className="w-full bg-[#222] border border-[#333] rounded-lg px-4 py-2"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Applicable Payment Methods</label>
          <div className="flex gap-4">
            {['COD', 'UPI', 'QR'].map(method => (
              <label key={method} className="flex items-center gap-2">
                <input 
                  type="checkbox"
                  checked={settings.applicablePaymentMethods.includes(method)}
                  onChange={(e) => {
                    const methods = e.target.checked 
                      ? [...settings.applicablePaymentMethods, method]
                      : settings.applicablePaymentMethods.filter(m => m !== method);
                    handleUpdate({ applicablePaymentMethods: methods });
                  }}
                />
                {method}
              </label>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Delivery Fees by Location</label>
          {settings.deliveryFeeByLocation.map((zone, index) => (
            <div key={zone.id} className="flex gap-2 mb-2">
              <input 
                type="text"
                placeholder="Location"
                value={zone.location}
                readOnly
                className="flex-1 bg-[#222] border border-[#333] rounded-lg px-4 py-2 text-gray-500"
              />
              <input 
                type="number"
                placeholder="Fee"
                value={zone.fee}
                onChange={(e) => {
                  const zones = [...settings.deliveryFeeByLocation];
                  zones[index].fee = Number(e.target.value);
                  handleUpdate({ deliveryFeeByLocation: zones });
                }}
                className="w-24 bg-[#222] border border-[#333] rounded-lg px-4 py-2"
              />
            </div>
          ))}
          <p className="text-xs text-gray-500 mt-2">To add or remove locations, please use the "Delivery Restriction System" settings.</p>
        </div>
      </div>
    </div>
  );
}
