import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { collection, query, onSnapshot, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';
import { useStore } from '../store/useStore';
import { Calendar, MapPin, Heart, Gift, Phone, Sparkles, Star } from 'lucide-react';
import ShareButton from './ShareButton';
import InfluencerVideo from './InfluencerVideo';

export default function MomentsSection() {
  const [moments, setMoments] = useState<any[]>([]);
  const { settings } = useStore();

  useEffect(() => {
    const q = query(collection(db, 'moments'), orderBy('order', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMoments(data.filter((m: any) => m.active));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'moments');
    });
    return () => unsubscribe();
  }, []);

  if (!settings.isMomentsEnabled || moments.length === 0) return null;

  return (
    <motion.section 
      key="moments"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ duration: 1 }}
      className="relative py-16 md:py-24 px-4 md:px-6 border-b border-white/5 overflow-hidden bg-[#020202]"
    >
      {/* Background Decorative Elements */}
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03] mix-blend-overlay"></div>
      <motion.div 
        animate={{ 
          scale: [1, 1.1, 1],
          opacity: [0.15, 0.3, 0.15] 
        }}
        transition={{ 
          duration: 8, 
          repeat: Infinity, 
          ease: "easeInOut" 
        }}
        className="absolute top-0 right-1/4 w-96 h-96 bg-[var(--color-neon-green)]/10 rounded-full blur-[120px]"
      />
      <motion.div 
        animate={{ 
          scale: [1, 1.2, 1],
          opacity: [0.1, 0.2, 0.1] 
        }}
        transition={{ 
          duration: 10, 
          repeat: Infinity, 
          ease: "easeInOut",
          delay: 2
        }}
        className="absolute bottom-0 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-[120px]"
      />

      <div className="relative z-10 max-w-7xl mx-auto">
        <div className="mb-16 text-center">
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] font-black text-[var(--color-neon-green)] uppercase tracking-[0.3em] mb-4 shadow-[0_0_20px_rgba(0,255,0,0.1)]"
          >
            <Star size={14} className="text-yellow-400" /> {settings.momentsSectionSubtitle || 'Customer Spotlight'}
          </motion.div>
          <h3 className="text-4xl md:text-6xl font-black uppercase text-white tracking-tighter leading-none">
            {settings.momentsSectionTitle?.split(' ')[0] || 'Happy'} <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-400 to-gray-700">{settings.momentsSectionTitle?.split(' ').slice(1).join(' ') || 'Moments'}</span>
          </h3>
        </div>

        <div className="flex overflow-x-auto pb-12 pt-4 gap-6 md:gap-8 snap-x no-scrollbar px-4 md:px-0">
          {moments.map((moment, idx) => (
            <motion.div 
              key={moment.id}
              id={`moment-${moment.id}`}
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ delay: idx * 0.1 }}
              className={`snap-center shrink-0 ${moment.isStoryFormat ? 'w-[300px] md:w-[340px]' : 'w-[340px] md:w-[420px]'}`}
            >
              <div className="group relative bg-[#0a0a0a] border border-white/10 rounded-3xl overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)] h-full flex flex-col hover:border-[var(--color-neon-green)]/40 transition-all duration-500">
                {/* Hover Glow */}
                <div className="absolute -inset-1 bg-gradient-to-r from-[var(--color-neon-green)] to-blue-500 rounded-3xl blur opacity-0 group-hover:opacity-20 transition duration-1000 z-0 pointer-events-none"></div>
                
                {/* Header: Avatar, Name, Mobile */}
                <div className="relative z-10 p-4 flex items-center gap-4 border-b border-white/5 bg-white/[0.02] backdrop-blur-md">
                   <div className="relative w-12 h-12 rounded-full border-2 border-[var(--color-neon-green)]/50 p-0.5 overflow-hidden shrink-0 group-hover:border-[var(--color-neon-green)] transition-colors">
                      <img 
                        src={moment.customerImageUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${moment.name}`} 
                        alt="avatar" 
                        className="w-full h-full rounded-full object-cover bg-gray-800" 
                      />
                   </div>
                   <div className="flex-1 min-w-0">
                      <h4 className="text-white font-black uppercase truncate text-sm tracking-wide">{moment.name}</h4>
                      {moment.mobile && (
                        <div className="text-[10px] text-gray-400 font-mono mt-0.5 flex items-center gap-1.5">
                          <Phone size={10} className="text-[var(--color-neon-green)]" />
                          {String(moment.mobile).substring(0, 4)} <span className="text-gray-600">••••</span> {String(moment.mobile).substring(String(moment.mobile).length - 2)}
                        </div>
                      )}
                   </div>
                   <div className="flex items-center gap-2">
                      {settings.isMomentsShareEnabled && (
                        <ShareButton 
                          title={`Moment by ${moment.name}`}
                          text={`Check out this happy moment from ${moment.name}!`}
                          url={`${window.location.origin}/#moment-${moment.id}`}
                          iconSize={14}
                        />
                      )}
                      {/* Verification Badge */}
                      <div className="shrink-0 bg-[var(--color-neon-green)]/10 text-[var(--color-neon-green)] border border-[var(--color-neon-green)]/20 px-2 py-1 rounded text-[9px] font-black uppercase tracking-wider whitespace-nowrap shadow-[0_0_10px_rgba(0,255,0,0.1)]">
                          Verified
                      </div>
                   </div>
                </div>

                {/* Main Media (What they bought) */}
                <div className="relative z-10 w-full overflow-hidden aspect-[9/16] bg-black">
                  <InfluencerVideo 
                    videoUrl={moment.mediaUrl}
                    influencerName={moment.name}
                    influencerImage={moment.customerImageUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${moment.name}`}
                    caption={moment.remark}
                    mediaType={moment.mediaType}
                  />
                </div>

                {/* Footer: Address, Remark, Date */}
                <div className="relative z-10 p-5 flex-1 flex flex-col bg-[#0a0a0a]">
                  <p className="text-gray-300 text-xs md:text-sm italic line-clamp-3 mb-4 flex-1 font-medium leading-relaxed">
                    "{moment.remark}"
                  </p>

                  <div className="flex flex-col gap-3 mt-auto">
                    {moment.address && (
                      <div className="flex items-start gap-2 text-[10px] md:text-xs text-gray-400 font-medium bg-white/5 p-2 rounded-lg border border-white/5">
                        <MapPin size={14} className="text-blue-400 shrink-0 mt-0.5" />
                        <span className="line-clamp-2">{moment.address}</span>
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between pt-3 border-t border-white/5 text-[9px] text-gray-500 font-black uppercase tracking-widest">
                      <div className="flex items-center gap-1.5">
                        <Calendar size={10} />
                        {moment.date}
                      </div>
                      <span>{moment.time}</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.section>
  );
}
