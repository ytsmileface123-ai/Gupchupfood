import React, { useState } from 'react';
import { CheckCircle, Clock, Trash2, XCircle, TrendingUp, ShoppingBag, CreditCard, QrCode, Banknote, RefreshCw, AlertTriangle } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface DashboardViewProps {
  orders: any[];
  updateOrder: (orderId: string, updates: any) => void;
  deleteOrder: (orderId: string) => void;
}

export default function DashboardView({ orders, updateOrder, deleteOrder }: DashboardViewProps) {
  const [isResetting, setIsResetting] = useState<'daily' | 'weekly' | null>(null);

  const completedOrders = orders.filter(o => o.status === 'completed');
  const totalRevenue = completedOrders.reduce((sum, o) => sum + (o.totalAmount || 0), 0);
  const totalOrders = orders.length;
  
  // Advanced Analytics
  const codOrders = orders.filter(o => o.paymentMethod === 'cod');
  const upiOrders = orders.filter(o => o.paymentMethod === 'upi');
  const qrOrders = orders.filter(o => o.paymentMethod === 'qr');
  
  const codRevenue = codOrders.filter(o => o.status === 'completed').reduce((sum, o) => sum + (o.totalAmount || 0), 0);
  const upiRevenue = upiOrders.filter(o => o.status === 'completed').reduce((sum, o) => sum + (o.totalAmount || 0), 0);
  const qrRevenue = qrOrders.filter(o => o.status === 'completed').reduce((sum, o) => sum + (o.totalAmount || 0), 0);

  // Assuming 30% profit margin for now as a placeholder
  const estimatedProfit = totalRevenue * 0.3;

  const handleReset = async (type: 'daily' | 'weekly') => {
    if (isResetting !== type) {
      setIsResetting(type);
      setTimeout(() => setIsResetting(null), 3000);
      return;
    }

    const now = new Date();
    const threshold = new Date();
    if (type === 'daily') {
      threshold.setDate(now.getDate() - 1);
    } else {
      threshold.setDate(now.getDate() - 7);
    }

    const ordersToDelete = orders.filter(o => {
      const orderDate = o.createdAt?.toDate ? o.createdAt.toDate() : new Date(o.createdAt);
      return orderDate < threshold;
    });

    for (const order of ordersToDelete) {
      await deleteOrder(order.id);
    }
    setIsResetting(null);
  };

  // Mock data for chart
  const chartData = [
    { name: 'Mon', revenue: 4000 },
    { name: 'Tue', revenue: 3000 },
    { name: 'Wed', revenue: 2000 },
    { name: 'Thu', revenue: 2780 },
    { name: 'Fri', revenue: 1890 },
    { name: 'Sat', revenue: 2390 },
    { name: 'Sun', revenue: 3490 },
  ];

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // Could add a toast here
  };

  return (
    <div className="space-y-8">
      {/* Analytics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-[#111] border border-[#333] p-6 rounded-2xl flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-[var(--color-neon-green)]/10 flex items-center justify-center text-[var(--color-neon-green)]">
            <TrendingUp size={24} />
          </div>
          <div>
            <div className="text-sm text-gray-400">Total Revenue</div>
            <div className="text-2xl font-black">₹{totalRevenue.toLocaleString()}</div>
          </div>
        </div>
        
        <div className="bg-[#111] border border-[#333] p-6 rounded-2xl flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-purple-500/10 flex items-center justify-center text-purple-500">
            <TrendingUp size={24} />
          </div>
          <div>
            <div className="text-sm text-gray-400">Est. Profit (30%)</div>
            <div className="text-2xl font-black text-purple-400">₹{estimatedProfit.toLocaleString()}</div>
          </div>
        </div>

        <div className="bg-[#111] border border-[#333] p-6 rounded-2xl flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-500">
            <ShoppingBag size={24} />
          </div>
          <div>
            <div className="text-sm text-gray-400">Total Orders</div>
            <div className="text-2xl font-black">{totalOrders}</div>
          </div>
        </div>

        <div className="bg-[#111] border border-[#333] p-6 rounded-2xl flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-yellow-500/10 flex items-center justify-center text-yellow-500">
            <RefreshCw size={24} />
          </div>
          <div className="flex flex-col gap-1 w-full">
            <button 
              onClick={() => handleReset('daily')}
              className={`text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded border transition-all ${isResetting === 'daily' ? 'bg-red-500 text-white border-red-500' : 'border-gray-700 text-gray-400 hover:border-red-500 hover:text-red-500'}`}
            >
              {isResetting === 'daily' ? 'Confirm Daily Reset' : 'Daily Reset'}
            </button>
            <button 
              onClick={() => handleReset('weekly')}
              className={`text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded border transition-all ${isResetting === 'weekly' ? 'bg-red-500 text-white border-red-500' : 'border-gray-700 text-gray-400 hover:border-red-500 hover:text-red-500'}`}
            >
              {isResetting === 'weekly' ? 'Confirm Weekly Reset' : 'Weekly Reset'}
            </button>
          </div>
        </div>
      </div>

      {/* Payment Method Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
          <div className="flex items-center gap-3 mb-4">
            <Banknote className="text-green-500" size={20} />
            <h4 className="font-bold">Cash on Delivery</h4>
          </div>
          <div className="flex justify-between items-end">
            <div>
              <div className="text-2xl font-black">{codOrders.length}</div>
              <div className="text-[10px] text-gray-500 uppercase font-black">Orders</div>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold text-green-500">₹{codRevenue.toLocaleString()}</div>
              <div className="text-[10px] text-gray-500 uppercase font-black">Revenue</div>
            </div>
          </div>
        </div>

        <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
          <div className="flex items-center gap-3 mb-4">
            <CreditCard className="text-blue-500" size={20} />
            <h4 className="font-bold">UPI Payment</h4>
          </div>
          <div className="flex justify-between items-end">
            <div>
              <div className="text-2xl font-black">{upiOrders.length}</div>
              <div className="text-[10px] text-gray-500 uppercase font-black">Orders</div>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold text-blue-500">₹{upiRevenue.toLocaleString()}</div>
              <div className="text-[10px] text-gray-500 uppercase font-black">Revenue</div>
            </div>
          </div>
        </div>

        <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
          <div className="flex items-center gap-3 mb-4">
            <QrCode className="text-purple-500" size={20} />
            <h4 className="font-bold">QR Code Scan</h4>
          </div>
          <div className="flex justify-between items-end">
            <div>
              <div className="text-2xl font-black">{qrOrders.length}</div>
              <div className="text-[10px] text-gray-500 uppercase font-black">Orders</div>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold text-purple-500">₹{qrRevenue.toLocaleString()}</div>
              <div className="text-[10px] text-gray-500 uppercase font-black">Revenue</div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
        <h3 className="text-xl font-bold mb-6">Revenue Overview</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="name" stroke="#666" />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: '#222', border: '1px solid #444' }} />
              <Line type="monotone" dataKey="revenue" stroke="var(--color-neon-green)" strokeWidth={3} dot={{ fill: 'var(--color-neon-green)' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div>
        <h3 className="text-3xl font-black uppercase mb-8">Recent Orders</h3>
        <div className="bg-[#111] border border-[#333] rounded-2xl overflow-hidden shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-[#222] text-gray-400 text-[10px] uppercase tracking-widest">
                  <th className="p-4 font-black">Order ID</th>
                  <th className="p-4 font-black">Customer Details</th>
                  <th className="p-4 font-black">Items Ordered</th>
                  <th className="p-4 font-black">Amount</th>
                  <th className="p-4 font-black">Status & Tracking</th>
                  <th className="p-4 font-black text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#333]">
                {orders.map(order => (
                  <tr key={order.id} className="hover:bg-[#1a1a1a] transition-colors group">
                    <td className="p-4">
                      <div 
                        onClick={() => copyToClipboard(order.id)}
                        className="font-mono text-[10px] text-gray-500 cursor-pointer hover:text-[var(--color-neon-green)] transition-colors flex items-center gap-1"
                        title="Click to copy Order ID"
                      >
                        {order.id}
                      </div>
                      <div className="text-[8px] text-gray-600 mt-1">
                        {order.createdAt?.toDate ? order.createdAt.toDate().toLocaleString() : 'Just now'}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="font-bold text-white flex items-center gap-2">
                        {order.customerName}
                        {order.paymentMethod === 'cod' && <Banknote size={12} className="text-green-500" />}
                        {order.paymentMethod === 'upi' && <CreditCard size={12} className="text-blue-500" />}
                        {order.paymentMethod === 'qr' && <QrCode size={12} className="text-purple-500" />}
                      </div>
                      <div className="text-[10px] text-gray-500">{order.customerPhone}</div>
                      {order.customerAddress && (
                        <div className="text-[10px] text-gray-400 mt-1 leading-tight border-l-2 border-white/10 pl-2">
                          {order.customerAddress}
                        </div>
                      )}
                      {(order.location || order.customerAddress) && (
                        <a 
                          href={order.location ? `https://www.google.com/maps?q=${order.location.lat || order.location.latitude},${order.location.lng || order.location.longitude}` : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(order.customerAddress)}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[10px] text-[var(--color-neon-green)] hover:underline flex items-center gap-1 mt-1 font-bold"
                        >
                          📍 View Location
                        </a>
                      )}
                    </td>
                    <td className="p-4">
                      <div className="text-xs text-gray-300 space-y-2">
                        {order.items?.map((item: any, i: number) => (
                          <div key={`${order.id}-item-${i}`} className="border-b border-white/5 pb-1 last:border-0 last:pb-0">
                            <div className="flex justify-between gap-4">
                              <span className="font-bold">{item.quantity}x {item.name}</span>
                              <span className="text-gray-500">₹{item.price * item.quantity}</span>
                            </div>
                            {item.customizations && (
                              <div className="text-[9px] text-gray-500 uppercase font-black tracking-widest mt-0.5 pl-2 border-l border-white/10">
                                {item.customizations.spiceLevel} {item.customizations.toppings?.length ? `• ${item.customizations.toppings.join(', ')}` : ''}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="font-black text-[var(--color-neon-green)] text-lg">₹{order.totalAmount}</div>
                      <div className="text-[8px] text-gray-500 uppercase font-black">{order.paymentMethod}</div>
                    </td>
                    <td className="p-4 space-y-2 min-w-[200px]">
                      <select 
                        value={order.status} 
                        onChange={(e) => updateOrder(order.id, { status: e.target.value })} 
                        className={`w-full bg-[#1a1a1a] border border-[#333] p-2 rounded-lg text-xs outline-none focus:border-[var(--color-neon-green)] transition-all ${
                          order.status === 'completed' ? 'text-green-500 border-green-500/30' :
                          order.status === 'cancelled' ? 'text-red-500 border-red-500/30' :
                          order.status === 'preparing' ? 'text-yellow-500 border-yellow-500/30' :
                          'text-white'
                        }`}
                      >
                        <option value="pending">Pending</option>
                        <option value="confirmed">Confirmed</option>
                        <option value="preparing">Preparing</option>
                        <option value="out_for_delivery">Out for Delivery</option>
                        <option value="delayed">Delayed</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="relative">
                          <Clock size={10} className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-500" />
                          <input 
                            type="text" 
                            placeholder="Time" 
                            value={order.estimatedTime || ''} 
                            onChange={(e) => updateOrder(order.id, { estimatedTime: e.target.value })} 
                            className="bg-[#1a1a1a] border border-[#333] text-white pl-6 pr-2 py-1.5 rounded-lg text-[10px] w-full outline-none focus:border-[var(--color-neon-green)]" 
                          />
                        </div>
                        <input 
                          type="text" 
                          placeholder="Remarks" 
                          value={order.remarks || ''} 
                          onChange={(e) => updateOrder(order.id, { remarks: e.target.value })} 
                          className="bg-[#1a1a1a] border border-[#333] text-white px-2 py-1.5 rounded-lg text-[10px] w-full outline-none focus:border-[var(--color-neon-green)]" 
                        />
                      </div>
                    </td>
                    <td className="p-4 text-right">
                      <button 
                        onClick={() => deleteOrder(order.id)} 
                        className="p-2 bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white rounded-lg transition-all opacity-0 group-hover:opacity-100" 
                        title="Delete Order"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
                {orders.length === 0 && (
                  <tr>
                    <td colSpan={6} className="p-12 text-center">
                      <div className="flex flex-col items-center gap-4 text-gray-500">
                        <ShoppingBag size={48} className="opacity-20" />
                        <p className="font-bold">No orders found in the system.</p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

