import React, { useEffect, useState } from 'react';
import { db } from '../firebase';
import { doc, getDoc, updateDoc, onSnapshot, setDoc } from 'firebase/firestore';
import { Loader2, FileText, CheckCircle, XCircle } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

export const InvoiceManagement: React.FC = () => {
  const [settings, setSettings] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'invoiceSettings', 'global'), (doc) => {
      if (doc.exists()) {
        setSettings(doc.data());
      } else {
        // Provide default settings if doc doesn't exist
        setSettings({ enabled: true, allowDownload: true });
      }
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'invoiceSettings/global');
      setLoading(false);
    });
    return unsub;
  }, []);

  const toggleSetting = async (field: string) => {
    if (!settings) return;
    try {
      await setDoc(doc(db, 'invoiceSettings', 'global'), { ...settings, [field]: !settings[field] }, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'invoiceSettings/global');
    }
  };

  if (loading || !settings) return <div className="flex justify-center p-10"><Loader2 className="animate-spin text-white" /></div>;

  return (
    <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-[#333]">
      <h2 className="text-xl font-bold mb-6 flex items-center gap-2 text-white"><FileText /> Invoice Settings</h2>
      <div className="space-y-4">
        <div className="flex justify-between items-center bg-[#222] p-4 rounded-lg text-white">
          <span>Enable Invoices</span>
          <button onClick={() => toggleSetting('enabled')} className={settings.enabled ? 'text-green-500' : 'text-red-500'}>
            {settings.enabled ? <CheckCircle /> : <XCircle />}
          </button>
        </div>
        <div className="flex justify-between items-center bg-[#222] p-4 rounded-lg text-white">
          <span>Allow PDF Download</span>
          <button onClick={() => toggleSetting('allowDownload')} className={settings.allowDownload ? 'text-green-500' : 'text-red-500'}>
            {settings.allowDownload ? <CheckCircle /> : <XCircle />}
          </button>
        </div>
      </div>
    </div>
  );
};
