import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Minus, Trash2, MapPin, ShoppingBag, CreditCard, QrCode, Banknote, CheckCircle2, ArrowRight, Truck, Utensils } from 'lucide-react';
import { useStore } from '../store/useStore';
import { collection, addDoc, serverTimestamp, query, onSnapshot, where, orderBy, doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';
import OrderTracking from './OrderTracking';
import { Tag, Ticket } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { useAuth } from '../context/AuthContext';

export default function CartDrawer() {
  const { cart, isCartOpen, toggleCart, updateQuantity, removeFromCart, clearCart, settings, getStallStatus } = useStore();
  const { user } = useAuth();
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const stallStatus = getStallStatus();
  const isStallOpen = stallStatus.status === 'open';
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    zoneId: '',
    paymentMethod: 'COD' as 'COD' | 'UPI' | 'QR',
    deliveryTime: '',
    customerRemark: '',
    orderType: 'Delivery' as 'Delivery' | 'Takeaway' | 'Dine-in',
    customerPreferences: '',
  });
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isConfirmingOrder, setIsConfirmingOrder] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [lastOrderId, setLastOrderId] = useState<string | null>(null);
  const [trackInput, setTrackInput] = useState('');
  const [activeTab, setActiveTab] = useState<'cart' | 'tracking'>('cart');
  
  const [couponInput, setCouponInput] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string; discount: number } | null>(null);
  const [couponError, setCouponError] = useState<string | null>(null);
  const [deliveryError, setDeliveryError] = useState<string | null>(null);
  const [events, setEvents] = useState<any[]>([]);

  useEffect(() => {
    if (user) {
      const fetchProfile = async () => {
        try {
          const userDoc = await getDoc(doc(db, 'users', user.uid));
          if (userDoc.exists()) {
            const data = userDoc.data();
            setFormData(prev => ({
              ...prev,
              name: data.name || prev.name,
              phone: data.mobile || prev.phone,
              address: data.address || prev.address,
            }));
            if (data.location) {
              setLocation(data.location);
            }
          }
        } catch (error) {
          console.error("Error fetching user profile:", error);
        }
      };
      fetchProfile();
    }
  }, [user]);

  useEffect(() => {
    const q = query(collection(db, 'events'), where('active', '==', true));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setEvents(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const orderId = localStorage.getItem('lastOrderId');
    if (orderId) {
      setLastOrderId(orderId);
    }

    // Load saved customer details
    const savedDetails = localStorage.getItem('customerDetails');
    if (savedDetails) {
      try {
        const details = JSON.parse(savedDetails);
        setFormData(prev => ({
          ...prev,
          name: details.name || '',
          phone: details.phone || '',
          address: details.address || '',
        }));
      } catch (e) {
        console.error('Error parsing saved customer details:', e);
      }
    }
  }, [orderSuccess]);

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  
  let deliveryFee = 0;
  if (settings.isDeliveryFeeEnabled && subtotal < settings.freeDeliveryThreshold) {
    if (settings.applicablePaymentMethods.includes(formData.paymentMethod)) {
      // Find the zone in deliveryFeeByLocation based on the selected zoneId
      const selectedZone = settings.deliveryFeeByLocation.find(z => z.id === formData.zoneId);
      if (selectedZone) {
        deliveryFee = selectedZone.fee;
      }
    }
  }

  const discountValue = appliedCoupon ? Math.round((subtotal * appliedCoupon.discount) / 100) : 0;
  const totalAmount = Math.max(0, subtotal - discountValue + deliveryFee);

  const handleApplyCoupon = () => {
    setCouponError(null);
    const code = couponInput.trim().toUpperCase();
    if (!code) return;

    const event = events.find(e => e.couponCode?.toUpperCase() === code);
    
    if (!event) {
      setCouponError("Invalid coupon code.");
      return;
    }

    // Check expiry
    if (event.expiryDate) {
      const expiry = new Date(event.expiryDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (expiry < today) {
        setCouponError("This coupon has expired.");
        return;
      }
    }

    setAppliedCoupon({ code: event.couponCode, discount: event.discountAmount || 0 });
    setCouponInput('');
  };

  const handleGetLocation = () => {
    setIsLocating(true);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
          setIsLocating(false);
        },
        (error) => {
          console.error('Error getting location:', error);
          alert('Could not get location. Please enter address manually.');
          setIsLocating(false);
        }
      );
    } else {
      alert('Geolocation is not supported by your browser.');
      setIsLocating(false);
    }
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    let finalAddress = formData.address;

    // Delivery Restriction Check
    setDeliveryError(null);
    if (settings.isDeliveryRestrictionEnabled && settings.deliveryZones && settings.deliveryZones.filter(z => z.active).length > 0) {
      const activeZones = settings.deliveryZones.filter(z => z.active);
      const selectedZone = activeZones.find(z => z.id === formData.zoneId);
      
      if (!selectedZone) {
        setDeliveryError("Please select a valid delivery area from the dropdown.");
        return;
      }
      
      // Combine detailed address with the selected zone
      finalAddress = `${formData.address}, ${selectedZone.city}, ${selectedZone.district}, ${selectedZone.state}, ${selectedZone.country}`;
    }

    setIsSubmitting(true);
    try {
      const orderData = {
        userId: user?.uid || null,
        customerName: formData.name,
        customerPhone: formData.phone,
        customerAddress: finalAddress,
        location: location,
        items: cart,
        subtotal,
        discount: discountValue,
        couponCode: appliedCoupon?.code || null,
        deliveryFee,
        totalAmount,
        paymentMethod: formData.paymentMethod,
        status: 'pending',
        createdAt: serverTimestamp(),
        estimatedTime: settings.enableDefaultDeliveryTime ? settings.defaultDeliveryTime : (formData.deliveryTime || ''),
        customerRemark: formData.customerRemark || '',
        orderType: formData.orderType,
        customerPreferences: formData.customerPreferences || '',
        isPreOrder: !isStallOpen,
      };

      const docRef = await addDoc(collection(db, 'orders'), orderData);
      const orderId = docRef.id;
      
      // WhatsApp Redirection
      const whatsappNumber = settings.orderWhatsAppNumber || '919735339454';
      const orderSummary = cart.map(item => 
        `• ${item.name} x${item.quantity} (₹${item.price * item.quantity})${item.customizations ? `\n  - ${item.customizations.spiceLevel}${item.customizations.toppings?.length ? `, ${item.customizations.toppings.join(', ')}` : ''}` : ''}`
      ).join('\n');

      const mapsLink = location 
        ? `https://www.google.com/maps?q=${location.lat},${location.lng}`
        : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(finalAddress)}`;

      let message = '';
      
      if (settings.novaAI?.isEnabled && settings.novaAI?.whatsappTemplate) {
        message = settings.novaAI.whatsappTemplate
          .replace('{{name}}', formData.name)
          .replace('{{phone}}', formData.phone)
          .replace('{{address}}', finalAddress)
          .replace('{{mapsLink}}', mapsLink)
          .replace('{{orderId}}', orderId)
          .replace('{{paymentMethod}}', formData.paymentMethod)
          .replace('{{orderSummary}}', orderSummary)
          .replace('{{totalAmount}}', totalAmount.toString());

        if (appliedCoupon) {
          message += `\n*Discount:* -₹${discountValue} (${appliedCoupon.discount}% off via ${appliedCoupon.code})`;
        }
        if (deliveryFee > 0) {
          message += `\n*Delivery Fee:* ₹${deliveryFee}`;
        }

        if (settings.novaAI.includeAiMessage) {
          try {
            // @ts-ignore
            const apiKey = import.meta.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY || process.env.API_KEY;
            if (apiKey) {
              const ai = new GoogleGenAI({ apiKey });
              const prompt = `Write a very short (1-2 lines) friendly thank you message in ${settings.novaAI.language === 'en' ? 'English' : 'Hindi/Hinglish'} for a customer named ${formData.name} who just ordered food from ${settings.logoName}. ${settings.novaAI.entertainmentMode ? 'Include a short food-related shayari or joke.' : 'Keep it professional and warm.'}`;
              
              const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: prompt,
              });
              
              if (response.text) {
                message += `\n\n*NOVA AI Message:*\n${response.text.trim()}`;
              }
            }
          } catch (e) {
            console.error("Failed to generate AI message for WhatsApp", e);
          }
        }
      } else {
        // Fallback to default message
        message = `*NEW ORDER RECEIVED!* 🛍️\n\n` +
          `*Customer:* ${formData.name}\n` +
          `*Phone:* ${formData.phone}\n` +
          `*Address:* ${finalAddress}\n` +
          `*Location Map:* ${mapsLink}\n` +
          `*Order ID:* ${orderId}\n` +
          `*Payment:* ${formData.paymentMethod}\n\n` +
          `*Items:*\n${orderSummary}\n\n` +
          (appliedCoupon ? `*Subtotal:* ₹${subtotal}\n*Discount:* -₹${discountValue} (${appliedCoupon.discount}% off via ${appliedCoupon.code})\n` : '') +
          (deliveryFee > 0 ? `*Delivery Fee:* ₹${deliveryFee}\n` : '') +
          `*Total Amount:* ₹${totalAmount}\n\n` +
          `*${settings.logoName || 'Gup Chup Food Stall'}* 😋🔥`;
      }

      const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
      
      setOrderSuccess(true);
      setErrorMessage(null);
      clearCart();
      
      // Store orderId for tracking
      localStorage.setItem('lastOrderId', orderId);

      // Save customer details for future orders
      localStorage.setItem('customerDetails', JSON.stringify({
        name: formData.name,
        phone: formData.phone,
        address: formData.address
      }));

      // Open WhatsApp after a short delay to let the success screen show
      setTimeout(() => {
        window.open(whatsappUrl, '_blank');
      }, 2000);

    } catch (error) {
      setErrorMessage('Failed to place order. Please try again.');
      handleFirestoreError(error, OperationType.CREATE, 'orders');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            onClick={toggleCart}
            className="fixed inset-0 bg-black z-40"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed top-0 right-0 h-full w-full sm:w-[450px] glass-panel border-l border-white/10 shadow-2xl z-50 flex flex-col overflow-hidden"
          >
            {/* Background Glow - Removed for solid look */}
            
            {/* Header / Tab Switcher */}
            <div className="p-4 border-b border-white/10 flex justify-between items-center bg-black relative z-10">
              <div className="flex bg-white/5 rounded-xl p-1">
                <button 
                  onClick={() => setActiveTab('cart')}
                  className={`px-4 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-colors ${activeTab === 'cart' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400'}`}
                >
                  Cart
                </button>
                <button 
                  onClick={() => setActiveTab('tracking')}
                  className={`px-4 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-colors ${activeTab === 'tracking' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400'}`}
                >
                  Tracking
                </button>
              </div>
              <button onClick={toggleCart} className="text-white hover:text-[var(--color-neon-green)] transition-colors">
                <X size={24} />
              </button>
            </div>

            {activeTab === 'tracking' ? (
              <div className="flex-1 overflow-y-auto p-6 bg-black">
                {lastOrderId ? (
                  <OrderTracking orderId={lastOrderId} />
                ) : (
                  <div className="text-center text-gray-400 mt-20">No active order to track.</div>
                )}
              </div>
            ) : orderSuccess ? (
              <div className="h-full flex flex-col items-center justify-center p-8 text-center bg-black overflow-y-auto no-scrollbar relative z-10">
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: "spring", damping: 12, stiffness: 200 }}
                  className="w-24 h-24 bg-[var(--color-neon-green)] rounded-2xl flex items-center justify-center mb-6 shadow-xl shrink-0"
                >
                  <CheckCircle2 size={40} className="text-black" />
                </motion.div>

                <h2 className="text-3xl font-black text-white mb-2 uppercase tracking-tighter shrink-0 leading-none">ORDER <span className="text-[var(--color-neon-green)]">PLACED!</span></h2>
                <p className="text-gray-400 text-[9px] font-black tracking-[0.3em] mb-10 uppercase shrink-0">THANK YOU FOR ORDERING WITH US.</p>

                {/* Order ID & Tracking */}
                {settings.enableOrderTracking && lastOrderId && (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="w-full bg-white/5 p-6 rounded-2xl border border-white/5 mb-10 relative overflow-hidden group shrink-0"
                  >
                    <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest mb-2">Your Order ID</p>
                    <div className="flex items-center justify-center gap-4">
                      <span className="text-white text-lg font-black tracking-widest">{lastOrderId}</span>
                      <button 
                        onClick={() => navigator.clipboard.writeText(lastOrderId)}
                        className="text-[var(--color-neon-green)] text-xs font-black uppercase hover:underline"
                      >
                        Copy
                      </button>
                    </div>
                  </motion.div>
                )}

                <div className="w-full space-y-3 shrink-0">
                  {settings.enableOrderTracking && lastOrderId && <OrderTracking orderId={lastOrderId} />}
                  <motion.button 
                    whileHover={{ scale: 1.02, y: -2 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => {
                      setIsCheckingOut(false);
                      setOrderSuccess(false);
                      toggleCart();
                    }}
                    className="w-full bg-[var(--color-neon-green)] text-black font-black uppercase tracking-[0.1em] py-4 rounded-xl flex items-center justify-center gap-2 hover:bg-white transition-all group shadow-xl text-sm"
                  >
                    CLOSE <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                  </motion.button>
                </div>
              </div>
) : ( <>
                {/* Content */}
                <div className="flex-1 overflow-y-auto p-4 bg-black relative z-10">
                  {errorMessage ? (
                    <div className="h-full flex flex-col items-center justify-center text-center space-y-6">
                      <div className="w-24 h-24 bg-red-500/20 border border-red-500/40 rounded-full flex items-center justify-center text-red-500 mb-4 shadow-2xl">
                        <X size={48} />
                      </div>
                      <h3 className="text-3xl font-black text-white uppercase tracking-tighter">Order Failed</h3>
                      <p className="text-gray-400 font-medium">{errorMessage}</p>
                      <button onClick={() => setErrorMessage(null)} className="text-[var(--color-neon-green)] font-black uppercase tracking-widest text-xs hover:underline">Try Again</button>
                    </div>
                  ) : cart.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-gray-500 space-y-6">
                      <div className="w-32 h-32 rounded-full bg-white/5 border border-white/10 flex items-center justify-center opacity-20">
                        <ShoppingBag size={64} />
                      </div>
                      <div className="text-center">
                        <p className="text-xl font-black text-white uppercase tracking-tighter mb-2">Cart is Empty</p>
                        <p className="text-xs font-medium text-gray-500 uppercase tracking-widest mb-8">Add some deliciousness!</p>
                        
                        {/* Track Order Section */}
                        <div className="bg-black/90 backdrop-blur-2xl p-6 rounded-2xl border border-white/10 text-left">
                          <h4 className="text-white font-black uppercase tracking-widest text-sm mb-4">Track Existing Order</h4>
                          <div className="flex gap-2 mb-3">
                            <input 
                              type="text" 
                              placeholder="Enter Order ID" 
                              value={trackInput}
                              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white font-bold focus:outline-none focus:border-[var(--color-neon-green)]"
                              onChange={(e) => setTrackInput(e.target.value)}
                            />
                            <button 
                              onClick={() => setLastOrderId(trackInput)}
                              className="bg-[var(--color-neon-green)] text-black font-black uppercase tracking-widest px-6 py-3 rounded-xl hover:bg-white transition-colors"
                            >
                              Track
                            </button>
                          </div>
                          {lastOrderId && <OrderTracking orderId={lastOrderId} />}
                        </div>
                      </div>
                    </div>
                  ) : !isCheckingOut ? (
                    <div className="space-y-6">
                      {cart.map((item, idx) => (
                        <motion.div 
                          layout
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          key={item.cartItemId || item.id || `cart-item-${idx}`} 
                          className="flex gap-6 glass-panel p-6 rounded-[2rem] border-white/5 group hover:bg-white/5 transition-all duration-500"
                        >
                          <div className="w-24 h-24 rounded-2xl overflow-hidden bg-white/5 flex-shrink-0 border border-white/10">
                            {item.imageUrl ? (
                              <img src={item.imageUrl || undefined} alt={item.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-gray-600 font-black text-[10px] uppercase tracking-widest">No Img</div>
                            )}
                          </div>
                          <div className="flex-1 flex flex-col justify-between py-1">
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="text-white font-black uppercase tracking-tight text-lg group-hover:text-[var(--color-neon-green)] transition-colors">{item.name}</h4>
                                {item.customizations && (
                                  <p className="text-[9px] font-black text-gray-500 uppercase tracking-widest mt-1">
                                    {item.customizations.spiceLevel} {item.customizations.toppings?.length ? `• ${item.customizations.toppings.join(', ')}` : ''}
                                  </p>
                                )}
                              </div>
                              <motion.button 
                                whileHover={{ scale: 1.2, color: '#ff0000' }}
                                onClick={() => removeFromCart(item.cartItemId)} 
                                className="text-gray-600 transition-colors"
                              >
                                <Trash2 size={18} />
                              </motion.button>
                            </div>
                            <div className="flex justify-between items-center mt-4">
                              <span className="text-[var(--color-neon-green)] font-black text-xl tracking-tighter">₹{item.price}</span>
                              <div className="flex items-center gap-4 bg-white/5 rounded-full px-4 py-2 border border-white/10">
                                <motion.button 
                                  whileTap={{ scale: 0.8 }}
                                  onClick={() => updateQuantity(item.cartItemId, Math.max(1, item.quantity - 1))}
                                  className="text-gray-400 hover:text-white transition-colors"
                                >
                                  <Minus size={14} />
                                </motion.button>
                                <span className="text-white text-sm font-black w-4 text-center">{item.quantity}</span>
                                <motion.button 
                                  whileTap={{ scale: 0.8 }}
                                  onClick={() => updateQuantity(item.cartItemId, item.quantity + 1)}
                                  className="text-gray-400 hover:text-white transition-colors"
                                >
                                  <Plus size={14} />
                                </motion.button>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))}

                      {/* Coupon Section Removed from here */}
                    </div>
                  ) : (
                    <form id="checkout-form" onSubmit={handleSubmitOrder} className="space-y-8">
                      <div className="space-y-6">
                        {['name', 'phone'].map((field, index) => (
                          <motion.div 
                            key={`checkout-field-${field}-${index}`}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="relative group"
                          >
                            <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-3 ml-2">
                              {field === 'name' ? 'Full Name' : 'Phone Number'}
                            </label>
                            <input 
                              required
                              type={field === 'phone' ? 'tel' : 'text'}
                              value={formData[field as keyof typeof formData]}
                              onChange={e => setFormData({...formData, [field]: e.target.value})}
                              className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-[var(--color-neon-green)] focus:bg-white/10 transition-all placeholder:text-gray-700"
                              placeholder={`Enter your ${field}`}
                            />
                            <motion.div 
                              className="absolute inset-0 rounded-2xl border border-[var(--color-neon-green)] opacity-0 group-focus-within:opacity-30 pointer-events-none"
                              initial={false}
                            />
                          </motion.div>
                        ))}

                        <motion.div 
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="relative group"
                        >
                          <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-3 ml-2">
                            Delivery Time (Optional)
                          </label>
                          <input 
                            type="text"
                            value={formData.deliveryTime}
                            onChange={e => setFormData({...formData, deliveryTime: e.target.value})}
                            className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-[var(--color-neon-green)] focus:bg-white/10 transition-all placeholder:text-gray-700"
                            placeholder="e.g. 30 mins, 8:00 PM"
                          />
                        </motion.div>

                        <motion.div 
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="relative group"
                        >
                          <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-3 ml-2">
                            Customer Remark (Optional)
                          </label>
                          <textarea 
                            value={formData.customerRemark}
                            onChange={e => setFormData({...formData, customerRemark: e.target.value})}
                            className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-[var(--color-neon-green)] focus:bg-white/10 transition-all min-h-[100px] placeholder:text-gray-700 resize-none"
                            placeholder="Any special instructions?"
                          />
                        </motion.div>

                        <motion.div 
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="relative group"
                        >
                          <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-3 ml-2">
                            Order Type
                          </label>
                          <select
                            value={formData.orderType}
                            onChange={e => setFormData({...formData, orderType: e.target.value as any})}
                            className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-[var(--color-neon-green)] focus:bg-white/10 transition-all"
                          >
                            <option value="Delivery">Delivery</option>
                            <option value="Takeaway">Takeaway</option>
                            <option value="Dine-in">Dine-in</option>
                          </select>
                        </motion.div>

                        <motion.div 
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="relative group"
                        >
                          <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-3 ml-2">
                            Customer Preferences (e.g. Allergies)
                          </label>
                          <input 
                            type="text"
                            value={formData.customerPreferences}
                            onChange={e => setFormData({...formData, customerPreferences: e.target.value})}
                            className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-[var(--color-neon-green)] focus:bg-white/10 transition-all placeholder:text-gray-700"
                            placeholder="e.g. No onion, No garlic"
                          />
                        </motion.div>

                        <motion.div 
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="relative group"
                        >
                          {settings.isDeliveryRestrictionEnabled && settings.deliveryZones && settings.deliveryZones.filter(z => z.active).length > 0 ? (
                            <div className="space-y-6">
                              <div>
                                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-3 ml-2">
                                  Select Delivery Area
                                </label>
                                <select
                                  required
                                  value={formData.zoneId}
                                  onChange={e => {
                                    setFormData({...formData, zoneId: e.target.value});
                                    if (deliveryError) setDeliveryError(null);
                                  }}
                                  className={`w-full bg-[#111] border ${deliveryError ? 'border-red-500/50 focus:border-red-500' : 'border-white/10 focus:border-[var(--color-neon-green)]'} rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:bg-white/10 transition-all appearance-none`}
                                >
                                  <option value="" disabled>Select your area...</option>
                                  {settings.deliveryZones.filter(z => z.active).map((zone, index) => (
                                    <option key={zone.id || `zone-${index}`} value={zone.id}>
                                      {zone.city} {zone.district ? `(${zone.district})` : ''}
                                    </option>
                                  ))}
                                </select>
                              </div>
                              <div>
                                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-3 ml-2">
                                  House No. / Street / Landmark
                                </label>
                                <textarea 
                                  required
                                  value={formData.address}
                                  onChange={e => setFormData({...formData, address: e.target.value})}
                                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:border-[var(--color-neon-green)] focus:bg-white/10 transition-all min-h-[100px] placeholder:text-gray-700 resize-none"
                                  placeholder="Enter detailed address"
                                />
                              </div>
                            </div>
                          ) : (
                            <div>
                              <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-3 ml-2">
                                Delivery Address
                              </label>
                              <textarea 
                                required
                                value={formData.address}
                                onChange={e => {
                                  setFormData({...formData, address: e.target.value});
                                  if (deliveryError) setDeliveryError(null);
                                }}
                                className={`w-full bg-white/5 border ${deliveryError ? 'border-red-500/50 focus:border-red-500' : 'border-white/10 focus:border-[var(--color-neon-green)]'} rounded-2xl px-6 py-4 text-white font-bold focus:outline-none focus:bg-white/10 transition-all min-h-[100px] placeholder:text-gray-700 resize-none`}
                                placeholder="Enter full address including City/Village and District"
                              />
                            </div>
                          )}
                          
                          {deliveryError && (
                            <motion.p 
                              initial={{ opacity: 0, y: -10 }}
                              animate={{ opacity: 1, y: 0 }}
                              className="text-red-500 text-xs font-bold bg-red-500/10 border border-red-500/20 p-3 rounded-xl flex items-start gap-2 mt-2"
                            >
                              <span className="text-lg leading-none">⚠️</span>
                              {deliveryError}
                            </motion.p>
                          )}
                        </motion.div>
                      </div>
                      
                      <div className="pt-4">
                        <motion.button 
                          type="button"
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={handleGetLocation}
                          disabled={isLocating}
                          className="w-full flex items-center justify-center gap-3 bg-white/5 border border-white/10 hover:border-[var(--color-neon-green)]/40 text-white rounded-2xl px-6 py-5 transition-all group"
                        >
                          <MapPin size={20} className={location ? "text-[var(--color-neon-green)]" : "text-gray-500 group-hover:text-[var(--color-neon-green)] transition-colors"} />
                          <span className="text-xs font-black uppercase tracking-widest">
                            {isLocating ? 'Locating...' : location ? 'Location Captured ✓' : 'Get Current Location'}
                          </span>
                        </motion.button>
                      </div>

                      <div className="pt-4">
                        <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-4 ml-2">Payment Method</label>
                        <div className="grid grid-cols-3 gap-4">
                          {[
                            { id: 'COD', icon: Banknote, label: 'Cash' },
                            { id: 'UPI', icon: CreditCard, label: 'UPI' },
                            { id: 'QR', icon: QrCode, label: 'QR Code' }
                          ].map((method) => (
                            <motion.button
                              key={method.id}
                              type="button"
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={() => setFormData({...formData, paymentMethod: method.id as any})}
                              className={`flex flex-col items-center justify-center gap-3 p-5 rounded-2xl border transition-all duration-500 ${
                                formData.paymentMethod === method.id 
                                  ? 'border-[var(--color-neon-green)] bg-[var(--color-neon-green)]/10 text-[var(--color-neon-green)] shadow-[0_0_20px_rgba(255,183,3,0.1)]' 
                                  : 'border-white/5 bg-white/5 text-gray-500 hover:border-white/20'
                              }`}
                            >
                              <method.icon size={24} />
                              <span className="text-[10px] font-black uppercase tracking-widest">{method.label}</span>
                            </motion.button>
                          ))}
                        </div>
                        {formData.paymentMethod === 'UPI' && (
                          <div className="mt-4 p-4 bg-white/5 rounded-xl border border-white/10 text-center space-y-3">
                            <p className="text-gray-400 text-xs">Pay via UPI:</p>
                            <p className="text-white font-bold text-lg">{settings.paymentSettings.upiId}</p>
                            <div className="flex gap-2 justify-center">
                              <button 
                                type="button"
                                onClick={() => navigator.clipboard.writeText(settings.paymentSettings.upiId)}
                                className="text-[var(--color-neon-green)] text-xs font-black uppercase hover:underline"
                              >
                                Copy UPI
                              </button>
                              <a 
                                href={`upi://pay?pa=${settings.paymentSettings.upiId}&pn=GupChup&am=${totalAmount}&cu=INR`}
                                className="text-[var(--color-neon-green)] text-xs font-black uppercase hover:underline"
                              >
                                Pay Now
                              </a>
                            </div>
                          </div>
                        )}
                        {formData.paymentMethod === 'QR' && (
                          <div className="mt-4 p-4 bg-white/5 rounded-xl border border-white/10 text-center space-y-3">
                            <p className="text-gray-400 text-xs">Scan QR Code:</p>
                            <img src={settings.paymentSettings.qrCodeUrl} alt="QR Code" className="w-32 h-32 mx-auto rounded-lg" />
                            <a 
                              href={settings.paymentSettings.qrCodeUrl} 
                              download="qr-code.png"
                              className="text-[var(--color-neon-green)] text-xs font-black uppercase hover:underline block"
                            >
                              Download QR
                            </a>
                          </div>
                        )}
                      </div>
                    </form>
                  )}
                </div>

                {/* Footer */}
                {cart.length > 0 && (
                  <div className="p-6 border-t border-white/10 bg-black/95 relative z-10">
                    {/* Compact Coupon Section */}
                    <div className="mb-4">
                      {appliedCoupon ? (
                        <div className="flex items-center justify-between bg-[var(--color-neon-green)]/5 border border-[var(--color-neon-green)]/20 px-3 py-2 rounded-lg">
                          <div className="flex items-center gap-2">
                            <Ticket size={12} className="text-[var(--color-neon-green)]" />
                            <span className="text-white text-[10px] font-bold uppercase tracking-wider">{appliedCoupon.code}</span>
                            <span className="text-gray-400 text-[8px]">({appliedCoupon.discount}%)</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="text-[var(--color-neon-green)] text-[10px] font-black">-₹{discountValue}</span>
                            <button onClick={() => setAppliedCoupon(null)} className="text-gray-500 hover:text-white transition-colors">
                              <X size={12} />
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="relative">
                          <div className="flex gap-2">
                            <div className="relative flex-1">
                              <Ticket size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />
                              <input 
                                type="text" 
                                value={couponInput}
                                onChange={e => setCouponInput(e.target.value)}
                                placeholder="COUPON CODE"
                                className="w-full bg-white/5 border border-white/10 rounded-lg pl-9 pr-3 py-2 text-white font-bold focus:outline-none focus:border-[var(--color-neon-green)] uppercase placeholder:text-gray-700 text-[10px] tracking-widest"
                              />
                            </div>
                            <button 
                              onClick={handleApplyCoupon}
                              className="bg-[var(--color-neon-green)] text-black font-black px-4 py-2 rounded-lg uppercase tracking-widest text-[10px] hover:bg-white transition-colors"
                            >
                              Apply
                            </button>
                          </div>
                          {couponError && <p className="text-red-500 text-[8px] font-bold uppercase tracking-widest mt-1 ml-1">{couponError}</p>}
                        </div>
                      )}
                    </div>

                    <div className="space-y-2 mb-4">
                      {appliedCoupon && (
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-gray-500 font-bold uppercase tracking-widest">Subtotal</span>
                          <span className="text-white font-bold">₹{subtotal}</span>
                        </div>
                      )}
                      {appliedCoupon && (
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-gray-500 font-bold uppercase tracking-widest">Discount ({appliedCoupon.discount}% off)</span>
                          <span className="text-[var(--color-neon-green)] font-bold">-₹{discountValue}</span>
                        </div>
                      )}
                      {deliveryFee > 0 && (
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-gray-500 font-bold uppercase tracking-widest">Delivery Fee</span>
                          <span className="text-white font-bold">₹{deliveryFee}</span>
                        </div>
                      )}
                      <div className="flex justify-between items-center">
                        <span className="text-gray-500 font-bold uppercase tracking-widest text-[10px]">Total Amount</span>
                        <span className="text-2xl font-black text-white tracking-tighter">₹{totalAmount}</span>
                      </div>
                      {settings.isMinimumOrderEnabled && cart.reduce((sum, item) => sum + item.quantity, 0) < settings.minimumOrderQuantity && (
                        <div className="bg-red-500/10 border border-red-500/20 p-3 rounded-xl mt-2">
                          <p className="text-red-500 text-[10px] font-black uppercase tracking-widest text-center">
                            Add {settings.minimumOrderQuantity - cart.reduce((sum, item) => sum + item.quantity, 0)} more item(s) to order!
                          </p>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-3 mb-6 p-3 bg-white/5 rounded-xl border border-white/10">
                      <div className="w-8 h-8 rounded-lg bg-[var(--color-neon-green)]/10 flex items-center justify-center">
                        <Truck size={16} className="text-[var(--color-neon-green)]" />
                      </div>
                      <div>
                        <p className="text-[9px] font-black text-white uppercase tracking-[0.1em]">
                          Fast Delivery
                        </p>
                        <p className="text-[8px] font-bold text-gray-500 uppercase tracking-widest mt-0.5">
                          By Our Rider Boys
                        </p>
                      </div>
                    </div>
                    
                    {/* Stall Status Message */}
                    {!isStallOpen && (
                      <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-xl mb-4 text-center">
                        <p className="text-red-500 text-xs font-black uppercase tracking-widest">
                          {stallStatus.status === 'busy' ? stallStatus.message : `Stall is closed. ${settings.stallControl.preOrderEnabled ? 'You can pre-order for later.' : 'Orders are currently blocked.'}`}
                        </p>
                      </div>
                    )}

                    {!isCheckingOut ? (
                      <motion.button 
                        whileHover={(settings.isMinimumOrderEnabled && cart.reduce((sum, item) => sum + item.quantity, 0) < settings.minimumOrderQuantity) || (!isStallOpen && !settings.stallControl.preOrderEnabled) ? {} : { scale: 1.02, y: -2 }}
                        whileTap={(settings.isMinimumOrderEnabled && cart.reduce((sum, item) => sum + item.quantity, 0) < settings.minimumOrderQuantity) || (!isStallOpen && !settings.stallControl.preOrderEnabled) ? {} : { scale: 0.98 }}
                        onClick={() => setIsCheckingOut(true)}
                        disabled={(settings.isMinimumOrderEnabled && cart.reduce((sum, item) => sum + item.quantity, 0) < settings.minimumOrderQuantity) || (!isStallOpen && !settings.stallControl.preOrderEnabled)}
                        className={`w-full font-black uppercase tracking-[0.1em] py-4 rounded-xl transition-all duration-500 shadow-xl text-sm ${(settings.isMinimumOrderEnabled && cart.reduce((sum, item) => sum + item.quantity, 0) < settings.minimumOrderQuantity) || (!isStallOpen && !settings.stallControl.preOrderEnabled) ? 'bg-gray-700 text-gray-400 cursor-not-allowed' : 'bg-[var(--color-neon-green)] text-black hover:bg-white'}`}
                      >
                        {settings.isMinimumOrderEnabled && cart.reduce((sum, item) => sum + item.quantity, 0) < settings.minimumOrderQuantity ? `Add ${settings.minimumOrderQuantity - cart.reduce((sum, item) => sum + item.quantity, 0)} more item(s)` : !isStallOpen && !settings.stallControl.preOrderEnabled ? 'Orders Blocked' : 'Proceed to Checkout'}
                      </motion.button>
                    ) : (
                      <div className="flex gap-3">
                        <motion.button 
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => setIsCheckingOut(false)}
                          className="flex-1 bg-white/5 border border-white/10 text-white font-black uppercase tracking-[0.1em] py-4 rounded-xl hover:bg-white/10 transition-colors text-sm"
                        >
                          Back
                        </motion.button>
                        <motion.button 
                          type="button"
                          whileHover={settings.isMinimumOrderEnabled && cart.reduce((sum, item) => sum + item.quantity, 0) < settings.minimumOrderQuantity ? {} : { scale: 1.02, y: -2 }}
                          whileTap={settings.isMinimumOrderEnabled && cart.reduce((sum, item) => sum + item.quantity, 0) < settings.minimumOrderQuantity ? {} : { scale: 0.98 }}
                          disabled={isSubmitting || (settings.isMinimumOrderEnabled && cart.reduce((sum, item) => sum + item.quantity, 0) < settings.minimumOrderQuantity)}
                          onClick={() => {
                            const form = document.getElementById('checkout-form') as HTMLFormElement;
                            if (form.checkValidity()) {
                              // Delivery Restriction Check before confirming
                              setDeliveryError(null);
                              if (settings.isDeliveryRestrictionEnabled && settings.deliveryZones && settings.deliveryZones.filter(z => z.active).length > 0) {
                                const activeZones = settings.deliveryZones.filter(z => z.active);
                                const selectedZone = activeZones.find(z => z.id === formData.zoneId);
                                
                                if (!selectedZone) {
                                  setDeliveryError("Please select a valid delivery area from the dropdown.");
                                  return; // Stop here, don't show confirmation
                                }
                              }
                              setIsConfirmingOrder(true);
                            } else {
                              form.reportValidity();
                            }
                          }}
                          className={`flex-[2] font-black uppercase tracking-[0.1em] py-4 rounded-xl transition-all duration-500 shadow-xl disabled:opacity-50 text-sm ${isSubmitting || (settings.isMinimumOrderEnabled && cart.reduce((sum, item) => sum + item.quantity, 0) < settings.minimumOrderQuantity) ? 'bg-gray-700 text-gray-400 cursor-not-allowed' : 'bg-[var(--color-neon-green)] text-black hover:bg-white'}`}
                        >
                          {isSubmitting ? 'Processing...' : isStallOpen ? 'Place Order' : 'Place Pre-order'}
                        </motion.button>
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </motion.div>
        </>
      )}
      {isConfirmingOrder && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }} 
            animate={{ scale: 1, opacity: 1, y: 0 }} 
            className="bg-[#111] border border-white/10 p-8 rounded-[2.5rem] w-full max-w-md text-center shadow-[0_0_50px_rgba(0,0,0,0.5)]"
          >
            <div className="w-20 h-20 bg-[var(--color-neon-green)]/10 rounded-full flex items-center justify-center mx-auto mb-6 text-[var(--color-neon-green)]">
              <ShoppingBag size={32} />
            </div>
            <h3 className="text-2xl font-black text-white uppercase tracking-tighter mb-2">
              {isStallOpen ? 'Confirm Your Order' : 'Confirm Your Pre-order'}
            </h3>
            <div className="text-gray-400 mb-8 text-sm leading-relaxed">
              You are about to place {isStallOpen ? 'an order' : 'a pre-order'} for <span className="text-white font-bold">₹{totalAmount}</span>
              {appliedCoupon && <span className="text-[var(--color-neon-green)] text-xs block mt-1">(Discount of ₹{discountValue} applied)</span>}
              via <span className="text-[var(--color-neon-green)] font-bold uppercase">{formData.paymentMethod}</span>. 
              Please confirm your details before proceeding.
            </div>
            
            <div className="bg-white/5 rounded-2xl p-4 mb-8 text-left space-y-2 border border-white/5">
              <div className="flex justify-between text-[10px] uppercase tracking-widest font-black">
                <span className="text-gray-500">Deliver To:</span>
                <span className="text-white">{formData.name}</span>
              </div>
              <div className="flex justify-between text-[10px] uppercase tracking-widest font-black">
                <span className="text-gray-500">Phone:</span>
                <span className="text-white">{formData.phone}</span>
              </div>
            </div>

            <div className="flex gap-4">
              <button 
                onClick={() => setIsConfirmingOrder(false)} 
                className="flex-1 bg-white/5 hover:bg-white/10 py-4 rounded-2xl text-white font-black uppercase tracking-widest text-xs transition-all"
              >
                Cancel
              </button>
              <button 
                onClick={async () => { 
                  setIsConfirmingOrder(false); 
                  await handleSubmitOrder({ preventDefault: () => {} } as any); 
                }} 
                className="flex-1 bg-[var(--color-neon-green)] hover:bg-white py-4 rounded-2xl text-black font-black uppercase tracking-widest text-xs transition-all shadow-[0_0_20px_rgba(0,255,0,0.2)]"
              >
                Confirm
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
