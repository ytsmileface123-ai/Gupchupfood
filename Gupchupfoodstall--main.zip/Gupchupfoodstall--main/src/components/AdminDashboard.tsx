import React, { useState, useEffect, useCallback } from 'react';
import Cropper, { Area } from 'react-easy-crop';
import 'react-easy-crop/react-easy-crop.css';
import { collection, query, orderBy, onSnapshot, doc, updateDoc, deleteDoc, addDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { signInWithEmailAndPassword, signOut, onAuthStateChanged, createUserWithEmailAndPassword } from 'firebase/auth';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, auth, storage } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';
import { Package, UtensilsCrossed, Settings, Tag, Plus, Trash2, Edit2, CheckCircle, XCircle, X, LogOut, Lock, Calendar, Star, Users, ArrowLeft, TrendingUp, ShoppingBag, Clock, Check, ExternalLink, Play, MapPin, Film, Type, Sparkles, Loader2, FileText, Layout, Menu, Instagram } from 'lucide-react';
import { useStore, AppSettings } from '../store/useStore';
import { useNavigate } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ConfirmModal } from './ConfirmModal';
import DashboardView from './DashboardView';
import RiderManagement from './RiderManagement';
import NotificationManagement from './NotificationManagement';
import CashbackManagement from './CashbackManagement';
import PhotoStudioManagement from './PhotoStudioManagement';
import EventsManagement from './EventsManagement';
import PanManagement from './PanManagement';
import EventServicesManagement from './EventServicesManagement';
import RgbEngineManagement from './RgbEngineManagement';
import MomentsManagement from './MomentsManagement';
import DeliveryZonesManagement from './DeliveryZonesManagement';
import DeliveryFeeManagement from './DeliveryFeeManagement';
import LayoutManager from './LayoutManager';
import ReviewManagement from './ReviewManagement';
import CompetitionManagement from './CompetitionManagement';
import SectionManagement from './SectionManagement';
import { Trophy, Camera, Gift } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { OrderManagement } from './OrderManagement';
import { InvoiceManagement } from './InvoiceManagement';
import AnalyticsDashboard from './AnalyticsDashboard';
import { AdminStallControl } from './AdminStallControl';

const PromptGeneratorButton = ({ 
  onGenerate, 
  isLoading 
}: { 
  onGenerate: () => void, 
  isLoading: boolean 
}) => (
  <button 
    onClick={onGenerate}
    disabled={isLoading}
    className="flex items-center gap-2 bg-[var(--color-neon-green)] text-black text-[10px] font-black py-1.5 px-3 rounded-md hover:bg-opacity-80 transition-colors uppercase tracking-tighter"
  >
    {isLoading ? <Loader2 size={12} className="animate-spin" /> : <Sparkles size={12} />}
    {isLoading ? 'Generating...' : 'Generate with AI'}
  </button>
);

const MediaUploadInput = ({ 
  label, 
  value, 
  onChange, 
  placeholder = "https://...",
  accept = "video/mp4,image/*,image/gif,application/zip",
  buttonText = "Upload Media (MP4/GIF/IMG/ZIP)",
  note = "Uploads directly to secure storage."
}: { 
  label: string, 
  value: string, 
  onChange: (val: string) => void, 
  placeholder?: string,
  accept?: string,
  buttonText?: string,
  note?: string
}) => {
  const [isUploading, setIsUploading] = useState(false);

  return (
    <div>
      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{label}</label>
      <div className="flex flex-col gap-3">
        <input 
          type="url" 
          value={value || ''} 
          onChange={e => onChange(e.target.value)} 
          className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
          placeholder={placeholder} 
        />
        <div className="flex items-center gap-4">
          <label className={`bg-[#222] hover:bg-[#333] text-white text-[10px] font-black py-1.5 px-3 rounded-md cursor-pointer transition-colors border border-[#444] text-center uppercase tracking-tighter flex items-center gap-2 ${isUploading ? 'opacity-50 pointer-events-none' : ''}`}>
            {isUploading ? <Loader2 size={12} className="animate-spin" /> : <Plus size={12} />} 
            {isUploading ? 'Uploading...' : buttonText}
            <input 
              type="file" 
              accept={accept} 
              className="hidden" 
              disabled={isUploading}
              onChange={async (e) => {
                const file = e.target.files?.[0];
                if (file) {
                  if (file.size > 50 * 1024 * 1024) {
                    alert("File is too large (max 50MB).");
                    return;
                  }
                  setIsUploading(true);
                  try {
                    const storageRef = ref(storage, `uploads/${Date.now()}_${file.name}`);
                    await uploadBytes(storageRef, file);
                    const downloadURL = await getDownloadURL(storageRef);
                    onChange(downloadURL);
                  } catch (error) {
                    console.error("Upload failed:", error);
                    alert("Failed to upload file. Please try again.");
                  } finally {
                    setIsUploading(false);
                  }
                }
              }}
            />
          </label>
          {note && <span className="text-[9px] text-gray-500 italic">{note}</span>}
        </div>
      </div>
    </div>
  );
};

const AdminLogoUpload: React.FC = () => {
  const [uploading, setUploading] = useState(false);
  const [zipUrl, setZipUrl] = useState('');
  const { settings } = useStore();

  useEffect(() => {
    if (settings.appLogoZipUrl) {
      setZipUrl(settings.appLogoZipUrl);
    }
  }, [settings.appLogoZipUrl]);

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = reader.result as string;
        
        // Save to Firestore global settings
        await setDoc(doc(db, 'settings', 'global'), {
          appLogoUrl: base64String
        }, { merge: true });
        
        alert('Logo updated successfully! Reload the app to see changes.');
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Error uploading logo:', error);
      alert('Failed to upload logo');
    } finally {
      setUploading(false);
    }
  };

  const handleZipUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 800 * 1024) {
      alert("File is too large (max 800KB). Please use a direct URL link for larger files.");
      return;
    }

    setUploading(true);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = reader.result as string;
        await setDoc(doc(db, 'settings', 'global'), {
          appLogoZipUrl: base64String
        }, { merge: true });
        setZipUrl(base64String);
        alert('ZIP file uploaded successfully!');
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Error uploading zip:', error);
      alert('Failed to upload zip');
    } finally {
      setUploading(false);
    }
  };

  const handleZipUrlSave = async () => {
    setUploading(true);
    try {
      await setDoc(doc(db, 'settings', 'global'), {
        appLogoZipUrl: zipUrl
      }, { merge: true });
      alert('ZIP URL saved successfully!');
    } catch (error) {
      console.error('Error saving zip url:', error);
      alert('Failed to save zip url');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="bg-[#111] border border-[#333] p-6 rounded-xl mb-6">
      <h4 className="text-xl font-bold mb-4 text-[var(--color-neon-green)]">Update App Logo (PWA)</h4>
      
      <div className="space-y-6">
        <div>
          <label className="block text-sm font-bold text-gray-400 mb-2">App Logo Image (PNG/JPG)</label>
          <input 
            type="file" 
            accept="image/png, image/jpeg" 
            onChange={handleLogoUpload}
            disabled={uploading}
            className="block w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-bold file:bg-[var(--color-neon-green)] file:text-black hover:file:bg-opacity-90 transition-all cursor-pointer"
          />
        </div>

        <div className="pt-4 border-t border-[#333]">
          <label className="block text-sm font-bold text-gray-400 mb-2">Logo Assets (ZIP File)</label>
          
          <div className="space-y-4">
            <div>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-1">Upload ZIP (Max 800KB)</p>
              <input 
                type="file" 
                accept=".zip,application/zip,application/x-zip-compressed" 
                onChange={handleZipUpload}
                disabled={uploading}
                className="block w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-bold file:bg-blue-500 file:text-white hover:file:bg-opacity-90 transition-all cursor-pointer"
              />
            </div>
            
            <div>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-1">Or Provide ZIP URL Link</p>
              <div className="flex gap-2">
                <input 
                  type="url" 
                  value={zipUrl}
                  onChange={(e) => setZipUrl(e.target.value)}
                  placeholder="https://..."
                  className="flex-1 bg-black border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                />
                <button 
                  onClick={handleZipUrlSave}
                  disabled={uploading}
                  className="bg-[var(--color-neon-green)] text-black font-bold px-4 py-2 rounded-lg hover:opacity-90 transition-opacity"
                >
                  Save URL
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {uploading && <p className="text-[var(--color-neon-green)] mt-3 font-bold text-sm animate-pulse">Processing...</p>}
    </div>
  );
};

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const { settings, setSettings } = useStore();
  const [localSettings, setLocalSettings] = useState<AppSettings>(settings);
  const [isGenerating, setIsGenerating] = useState<string | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [activeSection, setActiveSection] = useState<'dashboard' | 'orders' | 'menu' | 'offers' | 'staff' | 'reels' | 'influencers' | 'sponsored' | 'banners' | 'stories' | 'riders' | 'notifications' | 'settings' | 'cashback' | 'photostudio' | 'events' | 'eventServices' | 'moments' | 'deliveryZones' | 'founders' | 'partners' | 'layouts' | 'titles' | 'deliveryFee' | 'chickenStore' | 'rgbEngine' | 'reviews' | 'nova' | 'invoiceSettings' | 'analytics' | 'competitions' | 'sectionManagement' | 'pan' | 'stallControl'>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [orders, setOrders] = useState<any[]>([]);
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const [chickenItems, setChickenItems] = useState<any[]>([]);
  const [offers, setOffers] = useState<any[]>([]);
  const [reels, setReels] = useState<any[]>([]);
  const [influencers, setInfluencers] = useState<any[]>([]);
  const [sponsoredVideos, setSponsoredVideos] = useState<any[]>([]);
  const [collaborations, setCollaborations] = useState<any[]>([]);
  const [staffList, setStaffList] = useState<any[]>([]);
  const [banners, setBanners] = useState<any[]>([]);
  const [stories, setStories] = useState<any[]>([]);
  const [loadingStates, setLoadingStates] = useState({
    orders: true,
    menuItems: true,
    chickenItems: true,
    offers: true,
    reels: true,
    influencers: true,
    sponsoredVideos: true,
    collaborations: true,
    staff: true,
    banners: true,
    stories: true,
  });
  const [isMenuModalOpen, setIsMenuModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [menuForm, setMenuForm] = useState({
    name: '',
    price: '',
    category: 'Food',
    shayari: '',
    imageUrl: '',
    videoUrl: '',
    isVideoEnabled: false,
    isCustomizable: false,
    availableToppings: '',
    availableSpiceLevels: ''
  });
  const [isOfferModalOpen, setIsOfferModalOpen] = useState(false);
  const [editingOffer, setEditingOffer] = useState<any>(null);
  const [offerForm, setOfferForm] = useState({
    title: '',
    description: '',
    imageUrl: '',
    videoUrl: '',
    price: '',
    originalPrice: '',
    active: true
  });
  const [isStaffModalOpen, setIsStaffModalOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<any>(null);
  const [staffForm, setStaffForm] = useState({
    name: '',
    mobile: '',
    address: '',
    remark: '',
    experience: '',
    category: 'Chef',
    imageUrl: '',
    videoUrl: ''
  });
  const [isReelModalOpen, setIsReelModalOpen] = useState(false);
  const [editingReel, setEditingReel] = useState<any>(null);
  const [reelForm, setReelForm] = useState({
    videoUrl: '',
    title: '',
    quote: '',
    logoUrl: '',
    socialLink: '',
    musicUrl: '',
    mediaType: 'video' as 'video' | 'gif' | 'image',
    active: true
  });
  const [isInfluencerModalOpen, setIsInfluencerModalOpen] = useState(false);
  const [editingInfluencer, setEditingInfluencer] = useState<any>(null);
  const [influencerForm, setInfluencerForm] = useState({
    name: '',
    instagramHandle: '',
    socialLink: '',
    quote: '',
    imageUrl: '',
    logoUrl: '',
    videoUrl: '',
    musicUrl: '',
    mediaType: 'video' as 'video' | 'gif' | 'image'
  });
  const [isSponsoredModalOpen, setIsSponsoredModalOpen] = useState(false);
  const [editingSponsored, setEditingSponsored] = useState<any>(null);
  const [sponsoredForm, setSponsoredForm] = useState({
    title: '',
    videoUrl: '',
    sponsorName: '',
    logoUrl: '',
    socialLink: '',
    musicUrl: '',
    mediaType: 'video' as 'video' | 'gif' | 'image',
    zipUrl: '',
    active: true
  });
  const [isChickenModalOpen, setIsChickenModalOpen] = useState(false);
  const [isCollaborationModalOpen, setIsCollaborationModalOpen] = useState(false);
  const [editingChicken, setEditingChicken] = useState<any>(null);
  const [chickenForm, setChickenForm] = useState<{
    name: string;
    category: 'Broiler Chicken' | 'Desi Chicken';
    quality: string;
    remark: string;
    imageUrl: string;
    videoUrl: string;
    isVideoEnabled: boolean;
    rates: { id: string; weight: string; price: number }[];
    active: boolean;
    order: number;
  }>({
    name: '',
    category: 'Broiler Chicken',
    quality: '',
    remark: '',
    imageUrl: '',
    videoUrl: '',
    isVideoEnabled: false,
    rates: [{ id: crypto.randomUUID(), weight: '1kg', price: 0 }],
    active: true,
    order: 0
  });
  const [editingCollaboration, setEditingCollaboration] = useState<any>(null);
  const [collaborationForm, setCollaborationForm] = useState({
    brandName: '',
    description: '',
    address: '',
    mobile: '',
    remark: '',
    experience: '',
    hobby: '',
    imageUrl: '',
    logoUrl: '',
    videoUrl: '',
    socialLink: '',
    musicUrl: '',
    instagram: '',
    facebook: '',
    youtube: '',
    twitter: '',
    mediaType: 'video' as 'video' | 'gif' | 'image',
    zipUrl: '',
    active: true
  });
  const [isBannerModalOpen, setIsBannerModalOpen] = useState(false);
  const [isCroppingOpen, setIsCroppingOpen] = useState(false);
  const [editingBanner, setEditingBanner] = useState<any>(null);
  const [bannerForm, setBannerForm] = useState({
    title: '',
    imageUrl: '',
    videoUrl: '',
    mediaType: 'image' as 'image' | 'video' | 'gif',
    link: '',
    active: true,
    order: 0,
    crop: { x: 0, y: 0 },
    zoom: 1,
    aspect: 16 / 9
  });
  const [isStoryModalOpen, setIsStoryModalOpen] = useState(false);
  const [editingStory, setEditingStory] = useState<any>(null);
  const [storyForm, setStoryForm] = useState({
    title: '',
    logoUrl: '',
    mediaUrl: '',
    mediaType: 'video' as 'video' | 'image',
    active: true,
    order: 0
  });

  const isAnyLoading = Object.values(loadingStates).some(loading => loading);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoadingStates(prev => {
        const newState = { ...prev };
        Object.keys(newState).forEach(key => (newState as any)[key] = false);
        return newState;
      });
    }, 10000); // 10 seconds timeout
    return () => clearTimeout(timer);
  }, []);

  const generatePrompt = async (type: string) => {
    setIsGenerating(type);
    try {
      const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
      const ai = new GoogleGenAI({ apiKey });
      
      const context = `
        Business Name: ${settings.logoName} ${settings.logoSubName}
        Categories: ${settings.categories.join(', ')}
        Menu Items: ${menuItems.map(i => `${i.name} (${i.price})`).join(', ')}
        Offers: ${offers.map(o => o.title).join(', ')}
      `;

      const enabledLanguages = localSettings.novaAI?.enabledLanguages || { hindiEnglishScript: true, hindiScript: true, bengaliScript: true, english: true };
      const languages = [];
      if (enabledLanguages.hindiEnglishScript) languages.push('Hindi (in English script/Hinglish)');
      if (enabledLanguages.hindiScript) languages.push('Hindi (in Devanagari script)');
      if (enabledLanguages.bengaliScript) languages.push('Bengali (in Bengali script)');
      if (enabledLanguages.english) languages.push('English');

      const prompt = `Generate a professional, premium, and sales-oriented ${type} for a food stall named ${settings.logoName}. 
      The tone should be human-like, proactive, and persuasive.
      Generate the content in the following enabled languages: ${languages.join(', ')}.
      Context: ${context}
      
      Return ONLY the prompt text in the requested languages.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });

      const generatedPrompt = response.text || '';
      
      // Update the state based on type
      setLocalSettings(prev => {
        const newNovaAI = { ...prev.novaAI };
        
        // Handle nested content type updates
        if (type.endsWith('ManualText')) {
          const contentType = type.replace('ManualText', '');
          newNovaAI[contentType] = {
            ...newNovaAI[contentType],
            manualText: generatedPrompt
          };
        } else {
          newNovaAI[type] = generatedPrompt;
        }
        
        return {
          ...prev,
          novaAI: newNovaAI
        };
      });
    } catch (error) {
      console.error('Error generating prompt:', error);
      alert('Failed to generate prompt. Please try again.');
    } finally {
      setIsGenerating(null);
    }
  };

  const generateSystemPromptWithAI = async (promptType: 'order' | 'viral') => {
    setIsGenerating(promptType);
    try {
      const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
      const ai = new GoogleGenAI({ apiKey });
      
      const instruction = promptType === 'order' 
        ? `Generate a highly engaging, human-like, premium announcement prompt for a new order. Include placeholders like {{customerName}}, {{items}}, {{status}}, {{voiceStyle}}, {{brandName}}. Rules: No duplicate sentences, be emotional, use respectful tone (ji/bhai), no sensitive data exposure.`
        : `Generate a fun, viral-style or storytelling-based announcement prompt about our food stall {{brandName}}. Include placeholders like {{brandName}}, {{viralEnabled ? 'Viral trend/meme-style content' : ''}}, {{storytellingEnabled ? 'Emotional storytelling' : ''}}, {{voiceStyle}}, {{emotionLevel}}. Rules: Keep it engaging, professional, and brand-friendly.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: instruction,
      });
      const generatedPrompt = response.text || '';
      
      setLocalSettings(prev => ({
        ...prev,
        novaAI: {
          ...prev.novaAI,
          [promptType === 'order' ? 'orderAnnouncementPrompt' : 'viralStorytellingPrompt']: generatedPrompt
        }
      }));
    } catch (error) {
      console.error('Error generating prompt:', error);
      alert('Failed to generate prompt. Please try again.');
    } finally {
      setIsGenerating(null);
    }
  };

  const handleUpdateSettings = async (newSettings: Partial<AppSettings>) => {
    try {
      const updatedSettings = { ...settings, ...newSettings };
      await setDoc(doc(db, 'settings', 'global'), updatedSettings);
      setSettings(updatedSettings);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'settings/global');
    }
  };

  useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
    });

    return () => unsubscribeAuth();
  }, []);

  useEffect(() => {
    if (!user) return;

    // Fetch Orders
    const qOrders = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    const unsubscribeOrders = onSnapshot(qOrders, (snapshot) => {
      const ordersData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setOrders(ordersData);
      setLoadingStates(prev => ({ ...prev, orders: false }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'orders');
      setLoadingStates(prev => ({ ...prev, orders: false }));
    });

    // Fetch Menu Items
    const qMenu = query(collection(db, 'menuItems'));
    const unsubscribeMenu = onSnapshot(qMenu, (snapshot) => {
      const menuData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMenuItems(menuData);
      setLoadingStates(prev => ({ ...prev, menuItems: false }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'menuItems');
      setLoadingStates(prev => ({ ...prev, menuItems: false }));
    });

    // Fetch Offers
    const qOffers = query(collection(db, 'offers'));
    const unsubscribeOffers = onSnapshot(qOffers, (snapshot) => {
      const offersData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setOffers(offersData);
      setLoadingStates(prev => ({ ...prev, offers: false }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'offers');
      setLoadingStates(prev => ({ ...prev, offers: false }));
    });

    // Fetch Staff
    const qStaff = query(collection(db, 'staff'));
    const unsubscribeStaff = onSnapshot(qStaff, (snapshot) => {
      const staffData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setStaffList(staffData);
      setLoadingStates(prev => ({ ...prev, staff: false }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'staff');
      setLoadingStates(prev => ({ ...prev, staff: false }));
    });

    // Fetch Reels
    const qReels = query(collection(db, 'reels'));
    const unsubscribeReels = onSnapshot(qReels, (snapshot) => {
      const reelsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setReels(reelsData);
      setLoadingStates(prev => ({ ...prev, reels: false }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'reels');
      setLoadingStates(prev => ({ ...prev, reels: false }));
    });

    // Fetch Influencers
    const qInfluencers = query(collection(db, 'influencers'));
    const unsubscribeInfluencers = onSnapshot(qInfluencers, (snapshot) => {
      const influencersData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setInfluencers(influencersData);
      setLoadingStates(prev => ({ ...prev, influencers: false }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'influencers');
      setLoadingStates(prev => ({ ...prev, influencers: false }));
    });

    // Fetch Sponsored Videos
    const qSponsored = query(collection(db, 'sponsoredVideos'));
    const unsubscribeSponsored = onSnapshot(qSponsored, (snapshot) => {
      const sponsoredData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setSponsoredVideos(sponsoredData);
      setLoadingStates(prev => ({ ...prev, sponsoredVideos: false }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'sponsoredVideos');
      setLoadingStates(prev => ({ ...prev, sponsoredVideos: false }));
    });

    // Fetch Collaborations
    const qCollaborations = query(collection(db, 'collaborations'));
    const unsubscribeCollaborations = onSnapshot(qCollaborations, (snapshot) => {
      const collaborationsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setCollaborations(collaborationsData);
      setLoadingStates(prev => ({ ...prev, collaborations: false }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'collaborations');
      setLoadingStates(prev => ({ ...prev, collaborations: false }));
    });

    // Fetch Banners
    const qBanners = query(collection(db, 'banners'), orderBy('order', 'asc'));
    const unsubscribeBanners = onSnapshot(qBanners, (snapshot) => {
      const bannerData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setBanners(bannerData);
      setLoadingStates(prev => ({ ...prev, banners: false }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'banners');
      setLoadingStates(prev => ({ ...prev, banners: false }));
    });

    // Fetch Stories
    const qStories = query(collection(db, 'stories'), orderBy('order', 'asc'));
    const unsubscribeStories = onSnapshot(qStories, (snapshot) => {
      const storyData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setStories(storyData);
      setLoadingStates(prev => ({ ...prev, stories: false }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'stories');
      setLoadingStates(prev => ({ ...prev, stories: false }));
    });

    // Fetch Chicken Items
    const qChicken = query(collection(db, 'chickenItems'), orderBy('order', 'asc'));
    const unsubscribeChicken = onSnapshot(qChicken, (snapshot) => {
      const chickenData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setChickenItems(chickenData);
      setLoadingStates(prev => ({ ...prev, chickenItems: false }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'chickenItems');
      setLoadingStates(prev => ({ ...prev, chickenItems: false }));
    });

    return () => {
      unsubscribeOrders();
      unsubscribeMenu();
      unsubscribeChicken();
      unsubscribeOffers();
      unsubscribeStaff();
      unsubscribeReels();
      unsubscribeInfluencers();
      unsubscribeSponsored();
      unsubscribeCollaborations();
      unsubscribeBanners();
      unsubscribeStories();
    };
  }, [user]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (error: any) {
      console.error("Login error:", error);
      if (error.code === 'auth/user-not-found' || error.code === 'auth/invalid-credential') {
        setLoginError('Account not found or invalid credentials. Please click "Create Account" first.');
      } else if (error.code === 'auth/operation-not-allowed') {
        setLoginError('Email/Password login is disabled. Please enable it in Firebase Console -> Authentication -> Sign-in method.');
      } else {
        setLoginError(error.message || 'Failed to login.');
      }
    }
  };

  const handleSignUp = async () => {
    if (!email || !password) {
      setLoginError('Please enter email and password to create an account.');
      return;
    }
    setLoginError('');
    try {
      await createUserWithEmailAndPassword(auth, email, password);
    } catch (error: any) {
      console.error("Signup error:", error);
      if (error.code === 'auth/email-already-in-use') {
        setLoginError('Account already exists. Please click Login.');
      } else if (error.code === 'auth/operation-not-allowed') {
        setLoginError('Email/Password login is disabled. Please enable it in Firebase Console -> Authentication -> Sign-in method.');
      } else {
        setLoginError(error.message || 'Failed to create account.');
      }
    }
  };

  const handleSectionChange = (section: any) => {
    setActiveSection(section);
    setIsMobileMenuOpen(false);
  };

  const getCroppedImg = async (imageSrc: string, pixelCrop: Area): Promise<string> => {
    const image = new Image();
    image.src = imageSrc;
    image.crossOrigin = 'anonymous';

    await new Promise((resolve, reject) => {
      image.onload = resolve;
      image.onerror = reject;
    });

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      return imageSrc;
    }

    canvas.width = pixelCrop.width;
    canvas.height = pixelCrop.height;

    ctx.drawImage(
      image,
      pixelCrop.x,
      pixelCrop.y,
      pixelCrop.width,
      pixelCrop.height,
      0,
      0,
      pixelCrop.width,
      pixelCrop.height
    );

    return new Promise((resolve) => {
      canvas.toBlob((blob) => {
        if (!blob) {
          resolve(imageSrc);
          return;
        }
        resolve(URL.createObjectURL(blob));
      }, 'image/jpeg');
    });
  };

  const onCropChange = (crop: any) => setBannerForm(prev => ({ ...prev, crop }));
  const onZoomChange = (zoom: number) => setBannerForm(prev => ({ ...prev, zoom }));
  const onCropComplete = useCallback(async (_croppedArea: Area, croppedAreaPixels: Area) => {
    if (bannerForm.imageUrl) {
      const croppedImage = await getCroppedImg(bannerForm.imageUrl, croppedAreaPixels);
      setBannerForm(prev => ({ ...prev, imageUrl: croppedImage }));
    }
  }, [bannerForm.imageUrl]);

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const updateOrder = async (orderId: string, updates: any) => {
    try {
      const orderRef = doc(db, 'orders', orderId);
      const updateData = { ...updates };
      if (updates.status) {
        updateData[`statusTimestamps.${updates.status}`] = serverTimestamp();
      }
      await updateDoc(orderRef, updateData);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `orders/${orderId}`);
    }
  };

  const deleteOrder = async (orderId: string) => {
    if (window.confirm('Are you sure you want to delete this order?')) {
      try {
        await deleteDoc(doc(db, 'orders', orderId));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `orders/${orderId}`);
      }
    }
  };

  const handleOpenChickenModal = (item?: any) => {
    if (item) {
      setEditingChicken(item);
      setChickenForm({
        name: item.name,
        category: item.category,
        quality: item.quality || '',
        remark: item.remark || '',
        imageUrl: item.imageUrl || item.mediaUrl || '',
        videoUrl: item.videoUrl || '',
        isVideoEnabled: item.isVideoEnabled || false,
        rates: (item.rates || [{ weight: '1kg', price: 0 }]).map((r: any) => ({ ...r, id: r.id || crypto.randomUUID() })),
        active: item.active ?? true,
        order: item.order || 0
      });
    } else {
      setEditingChicken(null);
      setChickenForm({
        name: '',
        category: 'Broiler Chicken',
        quality: '',
        remark: '',
        imageUrl: '',
        videoUrl: '',
        isVideoEnabled: false,
        rates: [{ id: crypto.randomUUID(), weight: '1kg', price: 0 }],
        active: true,
        order: chickenItems.length
      });
    }
    setIsChickenModalOpen(true);
  };

  const handleSaveChicken = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        ...chickenForm,
        rates: chickenForm.rates.map(r => ({ ...r, price: Number(r.price) }))
      };

      if (editingChicken) {
        await updateDoc(doc(db, 'chickenItems', editingChicken.id), data);
      } else {
        await addDoc(collection(db, 'chickenItems'), data);
      }
      setIsChickenModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'chickenItems');
    }
  };

  const handleDeleteChicken = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      try {
        await deleteDoc(doc(db, 'chickenItems', id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `chickenItems/${id}`);
      }
    }
  };

  const handleOpenMenuModal = (item?: any) => {
    if (item) {
      setEditingItem(item);
      setMenuForm({
        name: item.name,
        price: item.price?.toString() || '',
        category: item.category,
        shayari: item.shayari || '',
        imageUrl: item.imageUrl || '',
        videoUrl: item.videoUrl || '',
        isVideoEnabled: item.isVideoEnabled || false,
        isCustomizable: item.isCustomizable ?? false,
        availableToppings: item.availableToppings || '',
        availableSpiceLevels: item.availableSpiceLevels || ''
      });
    } else {
      setEditingItem(null);
      setMenuForm({ 
        name: '', 
        price: '', 
        category: 'Food', 
        shayari: '', 
        imageUrl: '', 
        videoUrl: '', 
        isVideoEnabled: false, 
        isCustomizable: false,
        availableToppings: '',
        availableSpiceLevels: ''
      });
    }
    setIsMenuModalOpen(true);
  };

  const handleSaveMenuItem = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        name: menuForm.name,
        price: Number(menuForm.price),
        category: menuForm.category,
        shayari: menuForm.shayari,
        imageUrl: menuForm.imageUrl,
        videoUrl: menuForm.videoUrl,
        isVideoEnabled: menuForm.isVideoEnabled,
        isCustomizable: menuForm.isCustomizable,
        availableToppings: menuForm.availableToppings,
        availableSpiceLevels: menuForm.availableSpiceLevels
      };

      if (editingItem) {
        await updateDoc(doc(db, 'menuItems', editingItem.id), data);
      } else {
        await addDoc(collection(db, 'menuItems'), data);
      }
      setIsMenuModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, editingItem ? OperationType.UPDATE : OperationType.CREATE, editingItem ? `menuItems/${editingItem.id}` : 'menuItems');
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await setDoc(doc(db, 'settings', 'global'), localSettings);
      alert('Settings saved successfully!');
    } catch (error: any) {
      handleFirestoreError(error, OperationType.UPDATE, 'settings/global');
    }
  };

  const seedInitialMenu = async () => {
    if (window.confirm('This will add the default items (Samosa, Panipuri, etc.) to your database so you can edit them. Continue?')) {
      const MOCK_MENU = [
        { name: 'Samosa', price: 15, category: 'Food', shayari: 'Garam garam samose ki baat hi kuch aur hai...', imageUrl: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&q=80&w=800', isCustomizable: true, availableToppings: 'Extra Chutney, Onion', availableSpiceLevels: 'Mild, Medium, Hot' },
        { name: 'Panipuri', price: 30, category: 'Food', shayari: 'Khatta meetha teekha, har golgappa ek naya ehsaas!', imageUrl: 'https://images.unsplash.com/photo-1601050690117-94f5f6af8bd3?auto=format&fit=crop&q=80&w=800', isCustomizable: true, availableToppings: 'Extra Pani, Boondi', availableSpiceLevels: 'Teekha, Meetha, Mixed' },
        { name: 'Momos', price: 50, category: 'Food', shayari: 'Garam momos aur teekhi chutney, dil khush kar de.', imageUrl: 'https://images.unsplash.com/photo-1625220194771-7ebdea0b70b9?auto=format&fit=crop&q=80&w=800', isCustomizable: true, availableToppings: 'Mayonnaise, Extra Chutney', availableSpiceLevels: 'Mild, Spicy, Extra Spicy' },
        { name: 'Anda Roll', price: 40, category: 'Food', shayari: 'Zabardast anda roll, bhookh ka perfect ilaaj.', imageUrl: 'https://images.unsplash.com/photo-1626804475297-41609ea0eb49?auto=format&fit=crop&q=80&w=800', isCustomizable: true, availableToppings: 'Extra Egg, Cheese, Onion', availableSpiceLevels: 'Mild, Medium, Spicy' },
        { name: 'Bati Icecream', price: 30, category: 'Icecream', shayari: 'Thandi thandi bati ice cream, garmi ki chhutti.', imageUrl: 'https://images.unsplash.com/photo-1559703248-dcaaec9fac92?auto=format&fit=crop&q=80&w=800', isCustomizable: false },
        { name: 'Mango Juice', price: 30, category: 'Colddrink', shayari: 'Aam ka ras, sabse khaas.', imageUrl: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&q=80&w=800', isCustomizable: false },
      ];

      try {
        for (const item of MOCK_MENU) {
          await addDoc(collection(db, 'menuItems'), item);
        }
        alert('Default menu items added successfully! You can now edit them.');
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'menuItems');
      }
    }
  };

  const handleDeleteMenuItem = async (itemId: string) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      try {
        await deleteDoc(doc(db, 'menuItems', itemId));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `menuItems/${itemId}`);
      }
    }
  };

  const handleOpenOfferModal = (offer?: any) => {
    if (offer) {
      setEditingOffer(offer);
      setOfferForm({
        title: offer.title || '',
        description: offer.description || '',
        imageUrl: offer.imageUrl || '',
        videoUrl: offer.videoUrl || '',
        price: offer.price?.toString() || '',
        originalPrice: offer.originalPrice?.toString() || '',
        active: offer.active ?? true
      });
    } else {
      setEditingOffer(null);
      setOfferForm({ title: '', description: '', imageUrl: '', videoUrl: '', price: '', originalPrice: '', active: true });
    }
    setIsOfferModalOpen(true);
  };

  const [isGeneratingOffer, setIsGeneratingOffer] = useState(false);
  const generateOfferWithAI = async () => {
    setIsGeneratingOffer(true);
    try {
      const ai = new GoogleGenAI({ apiKey: (import.meta as any).env.VITE_GEMINI_API_KEY || '' });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Generate a catchy and appealing daily offer for a food stall. 
        Return ONLY a JSON object with two keys: "title" (a short, catchy title) and "description" (a 1-2 sentence description of the offer).
        Do not include markdown formatting like \`\`\`json. Just the raw JSON object.`,
      });
      
      const generatedText = response.text || '';
      try {
        const parsed = JSON.parse(generatedText.trim().replace(/^```json\s*|```$/g, ''));
        setOfferForm(prev => ({
          ...prev,
          title: parsed.title || prev.title,
          description: parsed.description || prev.description
        }));
      } catch (e) {
        console.error("Failed to parse AI response:", e);
        alert("AI generated invalid format. Please try again.");
      }
    } catch (error) {
      console.error('Error generating offer:', error);
      alert('Failed to generate offer. Please try again.');
    } finally {
      setIsGeneratingOffer(false);
    }
  };

  const handleSaveOffer = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        title: offerForm.title,
        description: offerForm.description,
        imageUrl: offerForm.imageUrl,
        videoUrl: offerForm.videoUrl,
        price: parseFloat(offerForm.price) || 0,
        originalPrice: offerForm.originalPrice ? parseFloat(offerForm.originalPrice) : null,
        active: offerForm.active
      };

      if (editingOffer) {
        await updateDoc(doc(db, 'offers', editingOffer.id), data);
      } else {
        await addDoc(collection(db, 'offers'), {
          ...data,
          createdAt: new Date().toISOString()
        });
      }
      setIsOfferModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, editingOffer ? OperationType.UPDATE : OperationType.CREATE, editingOffer ? `offers/${editingOffer.id}` : 'offers');
    }
  };

  const handleDeleteOffer = async (offerId: string) => {
    if (window.confirm('Are you sure you want to delete this offer?')) {
      try {
        await deleteDoc(doc(db, 'offers', offerId));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `offers/${offerId}`);
      }
    }
  };

  const handleOpenStaffModal = (staff?: any) => {
    if (staff) {
      setEditingStaff(staff);
      setStaffForm({
        name: staff.name || '',
        mobile: staff.mobile || '',
        address: staff.address || '',
        remark: staff.remark || '',
        experience: staff.experience || '',
        category: staff.category || 'Chef',
        imageUrl: staff.imageUrl || '',
        videoUrl: staff.videoUrl || ''
      });
    } else {
      setEditingStaff(null);
      setStaffForm({ name: '', mobile: '', address: '', remark: '', experience: '', category: 'Chef', imageUrl: '', videoUrl: '' });
    }
    setIsStaffModalOpen(true);
  };

  const handleSaveStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        name: staffForm.name,
        mobile: staffForm.mobile,
        address: staffForm.address,
        remark: staffForm.remark,
        experience: staffForm.experience,
        category: staffForm.category,
        imageUrl: staffForm.imageUrl,
        videoUrl: staffForm.videoUrl
      };

      if (editingStaff) {
        await updateDoc(doc(db, 'staff', editingStaff.id), data);
      } else {
        await addDoc(collection(db, 'staff'), data);
      }
      setIsStaffModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, editingStaff ? OperationType.UPDATE : OperationType.CREATE, editingStaff ? `staff/${editingStaff.id}` : 'staff');
    }
  };

  const handleDeleteStaff = async (staffId: string) => {
    if (window.confirm('Are you sure you want to delete this staff member?')) {
      try {
        await deleteDoc(doc(db, 'staff', staffId));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `staff/${staffId}`);
      }
    }
  };

  const handleOpenReelModal = (reel?: any) => {
    if (reel) {
      setEditingReel(reel);
      setReelForm({
        videoUrl: reel.videoUrl || '',
        title: reel.title || '',
        quote: reel.quote || '',
        logoUrl: reel.logoUrl || '',
        socialLink: reel.socialLink || '',
        musicUrl: reel.musicUrl || '',
        mediaType: reel.mediaType || 'video',
        active: reel.active ?? true
      });
    } else {
      setEditingReel(null);
      setReelForm({ 
        videoUrl: '', 
        title: '', 
        quote: '', 
        logoUrl: '',
        socialLink: '',
        musicUrl: '',
        mediaType: 'video',
        active: true 
      });
    }
    setIsReelModalOpen(true);
  };

  const handleSaveReel = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = { ...reelForm };
      if (editingReel) {
        await updateDoc(doc(db, 'reels', editingReel.id), data);
      } else {
        await addDoc(collection(db, 'reels'), data);
      }
      setIsReelModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, editingReel ? OperationType.UPDATE : OperationType.CREATE, editingReel ? `reels/${editingReel.id}` : 'reels');
    }
  };

  const handleDeleteReel = async (id: string) => {
    if (window.confirm('Delete this reel?')) {
      try {
        await deleteDoc(doc(db, 'reels', id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `reels/${id}`);
      }
    }
  };

  const handleOpenInfluencerModal = (inf?: any) => {
    if (inf) {
      setEditingInfluencer(inf);
      setInfluencerForm({
        name: inf.name || '',
        instagramHandle: inf.instagramHandle || '',
        socialLink: inf.socialLink || '',
        quote: inf.quote || '',
        imageUrl: inf.imageUrl || '',
        logoUrl: inf.logoUrl || '',
        videoUrl: inf.videoUrl || '',
        musicUrl: inf.musicUrl || '',
        mediaType: inf.mediaType || 'video'
      });
    } else {
      setEditingInfluencer(null);
      setInfluencerForm({ 
        name: '', 
        instagramHandle: '', 
        socialLink: '',
        quote: '', 
        imageUrl: '', 
        logoUrl: '',
        videoUrl: '',
        musicUrl: '',
        mediaType: 'video'
      });
    }
    setIsInfluencerModalOpen(true);
  };

  const handleSaveInfluencer = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = { ...influencerForm };
      if (editingInfluencer) {
        await updateDoc(doc(db, 'influencers', editingInfluencer.id), data);
      } else {
        await addDoc(collection(db, 'influencers'), data);
      }
      setIsInfluencerModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, editingInfluencer ? OperationType.UPDATE : OperationType.CREATE, editingInfluencer ? `influencers/${editingInfluencer.id}` : 'influencers');
    }
  };

  const handleDeleteInfluencer = async (id: string) => {
    if (window.confirm('Delete this influencer?')) {
      try {
        await deleteDoc(doc(db, 'influencers', id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `influencers/${id}`);
      }
    }
  };

  const handleOpenSponsoredModal = (sv?: any) => {
    if (sv) {
      setEditingSponsored(sv);
      setSponsoredForm({
        title: sv.title || '',
        videoUrl: sv.videoUrl || '',
        sponsorName: sv.sponsorName || '',
        logoUrl: sv.logoUrl || '',
        socialLink: sv.socialLink || '',
        musicUrl: sv.musicUrl || '',
        mediaType: sv.mediaType || 'video',
        zipUrl: sv.zipUrl || '',
        active: sv.active ?? true
      });
    } else {
      setEditingSponsored(null);
      setSponsoredForm({ 
        title: '', 
        videoUrl: '', 
        sponsorName: '', 
        logoUrl: '',
        socialLink: '',
        musicUrl: '',
        mediaType: 'video',
        zipUrl: '',
        active: true 
      });
    }
    setIsSponsoredModalOpen(true);
  };

  const handleSaveSponsored = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = { ...sponsoredForm };
      if (editingSponsored) {
        await updateDoc(doc(db, 'sponsoredVideos', editingSponsored.id), data);
      } else {
        await addDoc(collection(db, 'sponsoredVideos'), data);
      }
      setIsSponsoredModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, editingSponsored ? OperationType.UPDATE : OperationType.CREATE, editingSponsored ? `sponsoredVideos/${editingSponsored.id}` : 'sponsoredVideos');
    }
  };

  const handleDeleteSponsored = async (id: string) => {
    if (window.confirm('Delete this sponsored video?')) {
      try {
        await deleteDoc(doc(db, 'sponsoredVideos', id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `sponsoredVideos/${id}`);
      }
    }
  };

  const handleOpenCollaborationModal = (col?: any) => {
    if (col) {
      setEditingCollaboration(col);
      setCollaborationForm({
        brandName: col.brandName || '',
        description: col.description || '',
        address: col.address || '',
        mobile: col.mobile || '',
        remark: col.remark || '',
        experience: col.experience || '',
        hobby: col.hobby || '',
        imageUrl: col.imageUrl || '',
        logoUrl: col.logoUrl || '',
        videoUrl: col.videoUrl || '',
        socialLink: col.socialLink || '',
        musicUrl: col.musicUrl || '',
        instagram: col.instagram || '',
        facebook: col.facebook || '',
        youtube: col.youtube || '',
        twitter: col.twitter || '',
        mediaType: col.mediaType || 'video',
        zipUrl: col.zipUrl || '',
        active: col.active ?? true
      });
    } else {
      setEditingCollaboration(null);
      setCollaborationForm({ 
        brandName: '', 
        description: '', 
        address: '',
        mobile: '',
        remark: '',
        experience: '',
        hobby: '',
        imageUrl: '', 
        logoUrl: '',
        videoUrl: '', 
        socialLink: '',
        musicUrl: '',
        instagram: '',
        facebook: '',
        youtube: '',
        twitter: '',
        mediaType: 'video',
        zipUrl: '',
        active: true 
      });
    }
    setIsCollaborationModalOpen(true);
  };

  const handleSaveCollaboration = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = { ...collaborationForm };
      if (editingCollaboration) {
        await updateDoc(doc(db, 'collaborations', editingCollaboration.id), data);
      } else {
        await addDoc(collection(db, 'collaborations'), data);
      }
      setIsCollaborationModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, editingCollaboration ? OperationType.UPDATE : OperationType.CREATE, editingCollaboration ? `collaborations/${editingCollaboration.id}` : 'collaborations');
    }
  };

  const handleDeleteCollaboration = async (id: string) => {
    if (window.confirm('Delete this collaboration?')) {
      try {
        await deleteDoc(doc(db, 'collaborations', id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `collaborations/${id}`);
      }
    }
  };

  const handleOpenBannerModal = (banner?: any) => {
    if (banner) {
      setEditingBanner(banner);
      setBannerForm({
        title: banner.title || '',
        imageUrl: banner.imageUrl || '',
        videoUrl: banner.videoUrl || '',
        mediaType: banner.mediaType || 'image',
        link: banner.link || '',
        active: banner.active ?? true,
        order: banner.order || 0,
        crop: { x: 0, y: 0 },
        zoom: 1,
        aspect: 16 / 9
      });
    } else {
      setEditingBanner(null);
      setBannerForm({ 
        title: '', 
        imageUrl: '', 
        videoUrl: '', 
        mediaType: 'image', 
        link: '', 
        active: true, 
        order: banners.length,
        crop: { x: 0, y: 0 },
        zoom: 1,
        aspect: 16 / 9
      });
    }
    setIsBannerModalOpen(true);
  };

  const handleSaveBanner = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = { 
        ...bannerForm, 
        order: Number(bannerForm.order) 
      };
      if (editingBanner) {
        await updateDoc(doc(db, 'banners', editingBanner.id), data);
      } else {
        await addDoc(collection(db, 'banners'), data);
      }
      setIsBannerModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, editingBanner ? OperationType.UPDATE : OperationType.CREATE, editingBanner ? `banners/${editingBanner.id}` : 'banners');
    }
  };

  const handleDeleteBanner = async (id: string) => {
    if (window.confirm('Delete this banner?')) {
      try {
        await deleteDoc(doc(db, 'banners', id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `banners/${id}`);
      }
    }
  };

  const handleOpenStoryModal = (story?: any) => {
    if (story) {
      setEditingStory(story);
      setStoryForm({
        title: story.title || '',
        logoUrl: story.logoUrl || '',
        mediaUrl: story.mediaUrl || '',
        mediaType: story.mediaType || 'video',
        active: story.active ?? true,
        order: story.order || 0
      });
    } else {
      setEditingStory(null);
      setStoryForm({ title: '', logoUrl: '', mediaUrl: '', mediaType: 'video', active: true, order: stories.length });
    }
    setIsStoryModalOpen(true);
  };

  const handleSaveStory = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = { ...storyForm, order: Number(storyForm.order) };
      if (editingStory) {
        await updateDoc(doc(db, 'stories', editingStory.id), data);
      } else {
        await addDoc(collection(db, 'stories'), data);
      }
      setIsStoryModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, editingStory ? OperationType.UPDATE : OperationType.CREATE, editingStory ? `stories/${editingStory.id}` : 'stories');
    }
  };

  const [storyError, setStoryError] = useState<string | null>(null);

  const handleDeleteStory = async (id: string) => {
    if (window.confirm('Delete this story?')) {
      try {
        await deleteDoc(doc(db, 'stories', id));
      } catch (error) {
        setStoryError("Failed to delete story.");
        handleFirestoreError(error, OperationType.DELETE, `stories/${id}`);
      }
    }
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-black text-white">
        <div className="flex flex-col items-center gap-4">
          <Loader2 size={48} className="animate-spin text-[var(--color-neon-green)]" />
          <p className="text-sm font-bold uppercase tracking-widest">Checking Authentication...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-4 relative">
        <div className="bg-[#111] border border-[#333] p-8 rounded-2xl w-full max-w-md relative">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 bg-[var(--color-neon-green)]/10 rounded-full flex items-center justify-center border border-[var(--color-neon-green)]">
              <Lock className="text-[var(--color-neon-green)]" size={32} />
            </div>
          </div>
          <h2 className="text-2xl font-black text-center text-white uppercase tracking-widest mb-8">Admin Login</h2>
          
          <button 
            onClick={() => navigate('/')}
            className="absolute top-4 left-4 flex items-center gap-2 text-gray-400 hover:text-white transition-colors text-sm font-bold"
          >
            <ArrowLeft size={16} /> Back to Website
          </button>

          {loginError && (
            <div className="bg-red-500/10 border border-red-500/50 text-red-500 p-3 rounded-lg text-sm mb-6 text-center">
              {loginError}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Email</label>
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-colors" 
                placeholder="gupchupfoodstall@gmail.com" 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Password</label>
              <input 
                type="password" 
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-colors" 
                placeholder="••••••••" 
              />
            </div>
            <div className="flex gap-3 mt-4">
              <button 
                type="submit" 
                className="flex-1 bg-[var(--color-neon-green)] text-black font-bold py-3 rounded-xl hover:bg-[#00cc00] transition-colors"
              >
                Login
              </button>
              <button 
                type="button" 
                onClick={handleSignUp}
                className="flex-1 bg-[#1a1a1a] text-white font-bold py-3 rounded-xl hover:bg-[#222] transition-colors border border-[#333]"
              >
                Create Account
              </button>
            </div>
          </form>
          <div className="mt-6 text-center text-xs text-gray-500">
            <p>Admin Credentials:</p>
            <p>Email: gupchupfoodstall@gmail.com</p>
            <p>Password: admin@54433221</p>
          </div>
        </div>
      </div>
    );
  }

  if (isAnyLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-black text-white">
        <div className="flex flex-col items-center gap-4">
          <Loader2 size={48} className="animate-spin text-[var(--color-neon-green)]" />
          <p className="text-sm font-bold uppercase tracking-widest">Loading Dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex flex-col md:flex-row">
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 bg-[#111] border-b border-[#333] sticky top-0 z-[110]">
        <h2 className="text-xl font-black text-[var(--color-neon-green)] uppercase tracking-widest">Admin Pro</h2>
        <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2 bg-[#222] rounded-lg text-white">
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Sidebar */}
      <div className={`w-full md:w-64 bg-[#111] border-r border-[#333] p-6 flex-col gap-2 h-[calc(100vh-73px)] md:h-screen overflow-y-auto custom-scrollbar sticky top-[73px] md:top-0 z-[100] ${isMobileMenuOpen ? 'flex' : 'hidden md:flex'}`}>
        <div className="hidden md:flex items-center justify-between mb-8">
          <h2 className="text-2xl font-black text-[var(--color-neon-green)] uppercase tracking-widest">Admin Pro</h2>
        </div>
        
        <button 
          onClick={() => navigate('/')}
          className="flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors text-white bg-[#222] hover:bg-[#333] border border-[#444] mb-4"
        >
          <ArrowLeft size={20} /> Back to Website
        </button>

        <button 
          onClick={() => handleSectionChange('dashboard')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'dashboard' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Layout size={20} /> Dashboard
        </button>
        <button 
          onClick={() => handleSectionChange('stallControl')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'stallControl' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Settings size={20} /> Stall Control
        </button>
        <button 
          onClick={() => handleSectionChange('sectionManagement')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'sectionManagement' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Settings size={20} /> Section Intelligence
        </button>
        <button 
          onClick={() => handleSectionChange('nova')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'nova' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Sparkles size={20} /> Nova AI Control
        </button>
        <button 
          onClick={() => handleSectionChange('analytics')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'analytics' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <TrendingUp size={20} /> Analytics
        </button>
        <button 
          onClick={() => handleSectionChange('orders')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'orders' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Package size={20} /> Order Management
        </button>
        <button 
          onClick={() => handleSectionChange('pan')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'pan' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <UtensilsCrossed size={20} /> Pan Management
        </button>
        <button 
          onClick={() => handleSectionChange('invoiceSettings')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'invoiceSettings' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <FileText size={20} /> Invoice Settings
        </button>
        <button 
          onClick={() => handleSectionChange('menu')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'menu' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <UtensilsCrossed size={20} /> Menu Items
        </button>
        <button 
          onClick={() => handleSectionChange('offers')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'offers' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Tag size={20} /> Daily Offers
        </button>
        <button 
          onClick={() => handleSectionChange('staff')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'staff' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Users size={20} /> Staff Manage
        </button>
        <button 
          onClick={() => handleSectionChange('riders')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'riders' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Users size={20} /> Riders
        </button>
        <button 
          onClick={() => handleSectionChange('reels')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'reels' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <TrendingUp size={20} /> Daily Reels
        </button>
        <button 
          onClick={() => handleSectionChange('influencers')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'influencers' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Star size={20} /> Influencers
        </button>
        <button 
          onClick={() => handleSectionChange('sponsored')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'sponsored' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Package size={20} /> Sponsored
        </button>
        <button 
          onClick={() => handleSectionChange('founders')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'founders' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Users size={20} /> Founders & Owners
        </button>
        <button 
          onClick={() => handleSectionChange('partners')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'partners' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Users size={20} /> Partners & Collabs
        </button>
        <button 
          onClick={() => handleSectionChange('chickenStore')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'chickenStore' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <ShoppingBag size={20} /> Chicken Store
        </button>
        <button 
          onClick={() => handleSectionChange('notifications')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'notifications' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Tag size={20} /> Notifications
        </button>
        <button 
          onClick={() => handleSectionChange('eventServices')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'eventServices' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Sparkles size={20} /> Event Booking
        </button>
        <button 
          onClick={() => handleSectionChange('competitions')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'competitions' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Trophy size={20} /> Competitions
        </button>
        <button 
          onClick={() => handleSectionChange('events')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'events' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Calendar size={20} /> Events
        </button>
        <button 
          onClick={() => handleSectionChange('moments')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'moments' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Gift size={20} /> Moments
        </button>
        <button 
          onClick={() => handleSectionChange('deliveryZones')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'deliveryZones' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <MapPin size={20} /> Delivery Zones
        </button>
        <button 
          onClick={() => handleSectionChange('deliveryFee')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'deliveryFee' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Package size={20} /> Delivery Fee
        </button>
        <button 
          onClick={() => handleSectionChange('banners')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'banners' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <TrendingUp size={20} /> Banners
        </button>
        <button 
          onClick={() => handleSectionChange('cashback')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'cashback' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Trophy size={20} /> Cashback Rewards
        </button>
        <button 
          onClick={() => handleSectionChange('photostudio')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'photostudio' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Camera size={20} /> Photo Studio
        </button>
        <button 
          onClick={() => handleSectionChange('stories')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'stories' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <TrendingUp size={20} /> Owner & Partner Stories
        </button>
        <button 
          onClick={() => handleSectionChange('layouts')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'layouts' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Package size={20} /> Screen Layouts
        </button>
        <button 
          onClick={() => handleSectionChange('titles')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'titles' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Type size={20} /> Section Titles
        </button>
        <button 
          onClick={() => handleSectionChange('rgbEngine')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'rgbEngine' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Sparkles size={20} /> RGB Engine
        </button>
        <button 
          onClick={() => handleSectionChange('reviews')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'reviews' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Star size={20} /> Reviews
        </button>
        <button 
          onClick={() => handleSectionChange('settings')}
          className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold transition-colors ${activeSection === 'settings' ? 'bg-[var(--color-neon-green)] text-black' : 'text-gray-400 hover:bg-[#222] hover:text-white'}`}
        >
          <Settings size={20} /> Settings
        </button>

        <div className="mt-auto pt-8">
          <button 
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500/20 px-4 py-3 rounded-lg transition-colors font-bold"
          >
            <LogOut size={18} /> Logout
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-6 md:p-10 overflow-y-auto">
        {activeSection === 'dashboard' && <DashboardView orders={orders} updateOrder={updateOrder} deleteOrder={deleteOrder} />}
        {activeSection === 'stallControl' && <AdminStallControl />}
        {activeSection === 'sectionManagement' && <SectionManagement />}
        {activeSection === 'analytics' && <AnalyticsDashboard orders={orders} />}
        {activeSection === 'orders' && <OrderManagement />}
        {activeSection === 'pan' && <PanManagement />}
        {activeSection === 'invoiceSettings' && <InvoiceManagement />}
        {activeSection === 'competitions' && <CompetitionManagement />}

        {activeSection === 'menu' && (
          <div>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
              <h3 className="text-3xl font-black uppercase">Menu Management</h3>
              <div className="flex gap-3">
                {menuItems.length === 0 && (
                  <button 
                    onClick={seedInitialMenu}
                    className="flex items-center gap-2 bg-blue-600 text-white font-bold px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Plus size={20} /> Import Default Menu
                  </button>
                )}
                <button 
                  onClick={() => handleOpenMenuModal()}
                  className="flex items-center gap-2 bg-[var(--color-neon-green)] text-black font-bold px-4 py-2 rounded-lg hover:bg-[#00cc00] transition-colors"
                >
                  <Plus size={20} /> Add Item
                </button>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {menuItems.length === 0 ? (
                <p className="text-gray-500 col-span-full">No custom menu items found. Using mock data on frontend.</p>
              ) : (
                menuItems.map(item => (
                  <div key={item.id} className="bg-[#111] border border-[#333] rounded-xl overflow-hidden flex flex-col">
                    <img src={item.imageUrl || 'https://via.placeholder.com/400x200'} alt={item.name} className="w-full h-48 object-cover" />
                    <div className="p-4 flex-1 flex flex-col">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="text-lg font-bold">{item.name}</h4>
                        <span className="text-[var(--color-neon-green)] font-bold">₹{item.price}</span>
                      </div>
                      <p className="text-sm text-gray-400 mb-4 line-clamp-2 flex-1">{item.shayari}</p>
                      <div className="flex gap-2 mt-auto">
                        <button 
                          onClick={() => handleOpenMenuModal(item)}
                          className="flex-1 flex items-center justify-center gap-2 bg-[#222] hover:bg-[#333] py-2 rounded-lg transition-colors text-sm font-bold"
                        >
                          <Edit2 size={16} /> Edit
                        </button>
                        <button 
                          onClick={() => handleDeleteMenuItem(item.id)}
                          className="flex-1 flex items-center justify-center gap-2 bg-red-500/10 text-red-500 hover:bg-red-500/20 py-2 rounded-lg transition-colors text-sm font-bold"
                        >
                          <Trash2 size={16} /> Delete
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeSection === 'offers' && (
          <div>
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-3xl font-black uppercase">Daily Offers</h3>
              <button 
                onClick={() => handleOpenOfferModal()}
                className="flex items-center gap-2 bg-[var(--color-neon-green)] text-black font-bold px-4 py-2 rounded-lg hover:bg-[#00cc00] transition-colors"
              >
                <Plus size={20} /> Add Offer
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {offers.length === 0 ? (
                <p className="text-gray-500 col-span-full">No offers found. Add some to display on the homepage.</p>
              ) : (
                offers.map(offer => (
                  <div key={offer.id} className={`bg-[#111] border ${offer.active ? 'border-[var(--color-neon-green)]' : 'border-[#333] opacity-60'} rounded-xl overflow-hidden flex flex-col`}>
                    {offer.imageUrl ? (
                      <img src={offer.imageUrl} alt={offer.title} className="w-full h-48 object-cover" />
                    ) : (
                      <div className="w-full h-48 bg-[#1a1a1a] flex items-center justify-center text-gray-600">No Image</div>
                    )}
                    <div className="p-4 flex-1 flex flex-col">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="text-lg font-bold">{offer.title}</h4>
                        <span className={`text-xs font-bold px-2 py-1 rounded-full ${offer.active ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'}`}>
                          {offer.active ? 'ACTIVE' : 'INACTIVE'}
                        </span>
                      </div>
                      <p className="text-sm text-gray-400 mb-2 line-clamp-3 flex-1">{offer.description}</p>
                      <div className="mb-4">
                        <span className="text-xl font-black text-[var(--color-neon-green)]">₹{offer.price || 0}</span>
                        {offer.originalPrice && (
                          <span className="text-sm text-gray-500 line-through ml-2">₹{offer.originalPrice}</span>
                        )}
                      </div>
                      <div className="flex gap-2 mt-auto">
                        <button 
                          onClick={() => handleOpenOfferModal(offer)}
                          className="flex-1 flex items-center justify-center gap-2 bg-[#222] hover:bg-[#333] py-2 rounded-lg transition-colors text-sm font-bold"
                        >
                          <Edit2 size={16} /> Edit
                        </button>
                        <button 
                          onClick={() => handleDeleteOffer(offer.id)}
                          className="flex-1 flex items-center justify-center gap-2 bg-red-500/10 text-red-500 hover:bg-red-500/20 py-2 rounded-lg transition-colors text-sm font-bold"
                        >
                          <Trash2 size={16} /> Delete
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeSection === 'staff' && (
          <div>
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-3xl font-black uppercase">Staff Management</h3>
              <button 
                onClick={() => handleOpenStaffModal()}
                className="flex items-center gap-2 bg-[var(--color-neon-green)] text-black font-bold px-4 py-2 rounded-lg hover:bg-[#00cc00] transition-colors"
              >
                <Plus size={20} /> Add Staff
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {staffList.length === 0 ? (
                <p className="text-gray-500 col-span-full">No staff members found.</p>
              ) : (
                staffList.map(staff => (
                  <div key={staff.id} className="bg-[#111] border border-[#333] rounded-xl overflow-hidden flex flex-col">
                    {staff.imageUrl ? (
                      <img src={staff.imageUrl} alt={staff.name} className="w-full h-48 object-cover" />
                    ) : (
                      <div className="w-full h-48 bg-[#1a1a1a] flex items-center justify-center text-gray-600">No Image</div>
                    )}
                    <div className="p-4 flex-1 flex flex-col">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="text-lg font-bold">{staff.name}</h4>
                        <span className="text-xs font-bold px-2 py-1 rounded-full bg-[var(--color-neon-green)]/20 text-[var(--color-neon-green)]">
                          {staff.category}
                        </span>
                      </div>
                      <div className="text-sm text-gray-400 mb-4 space-y-1">
                        <p><span className="font-bold text-gray-300">Mobile:</span> {staff.mobile}</p>
                        <p><span className="font-bold text-gray-300">Exp:</span> {staff.experience}</p>
                        <p><span className="font-bold text-gray-300">Address:</span> {staff.address}</p>
                        {staff.remark && <p className="italic text-gray-500 line-clamp-2">"{staff.remark}"</p>}
                      </div>
                      <div className="flex gap-2 mt-auto">
                        <button 
                          onClick={() => handleOpenStaffModal(staff)}
                          className="flex-1 flex items-center justify-center gap-2 bg-[#222] hover:bg-[#333] py-2 rounded-lg transition-colors text-sm font-bold"
                        >
                          <Edit2 size={16} /> Edit
                        </button>
                        <button 
                          onClick={() => handleDeleteStaff(staff.id)}
                          className="flex-1 flex items-center justify-center gap-2 bg-red-500/10 text-red-500 hover:bg-red-500/20 py-2 rounded-lg transition-colors text-sm font-bold"
                        >
                          <Trash2 size={16} /> Delete
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeSection === 'riders' && (
          <div className="space-y-8">
            <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <MapPin className="text-[var(--color-neon-green)]" size={20} />
                Rider Section Settings
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Section Title</label>
                  <input 
                    type="text" 
                    value={localSettings.riderSectionTitle}
                    onChange={(e) => setLocalSettings({ ...localSettings, riderSectionTitle: e.target.value })}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Section Description</label>
                  <input 
                    type="text" 
                    value={localSettings.riderSectionDescription}
                    onChange={(e) => setLocalSettings({ ...localSettings, riderSectionDescription: e.target.value })}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                  />
                </div>
              </div>
            </div>
            <RiderManagement />
          </div>
        )}

        {activeSection === 'reels' && (
          <div>
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-3xl font-black uppercase">Daily Reels</h3>
              <button 
                onClick={() => handleOpenReelModal()}
                className="flex items-center gap-2 bg-[var(--color-neon-green)] text-black font-bold px-4 py-2 rounded-lg hover:bg-[#00cc00] transition-colors"
              >
                <Plus size={20} /> Add Reel
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {reels.map(reel => (
                <div key={reel.id} className="bg-[#111] border border-[#333] rounded-2xl overflow-hidden group">
                  <div className="aspect-video bg-black relative">
                    <video src={reel.videoUrl || undefined} className="w-full h-full object-cover opacity-50" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <TrendingUp className="text-white/20" size={48} />
                    </div>
                  </div>
                  <div className="p-6">
                    <h4 className="text-xl font-bold text-white mb-2">{reel.title}</h4>
                    <p className="text-gray-400 text-sm italic mb-4">"{reel.quote}"</p>
                    <div className="flex gap-3">
                      <button onClick={() => handleOpenReelModal(reel)} className="flex-1 bg-white/5 hover:bg-white/10 text-white py-2 rounded-lg transition-colors font-bold flex items-center justify-center gap-2">
                        <Edit2 size={16} /> Edit
                      </button>
                      <button onClick={() => handleDeleteReel(reel.id)} className="flex-1 bg-red-500/10 hover:bg-red-500/20 text-red-500 py-2 rounded-lg transition-colors font-bold flex items-center justify-center gap-2">
                        <Trash2 size={16} /> Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeSection === 'influencers' && (
          <div>
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-3xl font-black uppercase">Influencers</h3>
              <button 
                onClick={() => handleOpenInfluencerModal()}
                className="flex items-center gap-2 bg-[var(--color-neon-green)] text-black font-bold px-4 py-2 rounded-lg hover:bg-[#00cc00] transition-colors"
              >
                <Plus size={20} /> Add Influencer
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {influencers.map(inf => (
                <div key={inf.id} className="bg-[#111] border border-[#333] rounded-2xl overflow-hidden group">
                  <div className="aspect-square bg-black relative">
                    {inf.imageUrl && <img src={inf.imageUrl} className="w-full h-full object-cover" referrerPolicy="no-referrer" alt={inf.name} />}
                    <div className="absolute bottom-4 left-4 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                      <span className="text-[var(--color-neon-green)] text-xs font-bold">{inf.instagramHandle}</span>
                    </div>
                  </div>
                  <div className="p-6">
                    <h4 className="text-xl font-bold text-white mb-2">{inf.name}</h4>
                    <p className="text-gray-400 text-sm italic mb-4">"{inf.quote}"</p>
                    <div className="flex gap-3">
                      <button onClick={() => handleOpenInfluencerModal(inf)} className="flex-1 bg-white/5 hover:bg-white/10 text-white py-2 rounded-lg transition-colors font-bold flex items-center justify-center gap-2">
                        <Edit2 size={16} /> Edit
                      </button>
                      <button onClick={() => handleDeleteInfluencer(inf.id)} className="flex-1 bg-red-500/10 hover:bg-red-500/20 text-red-500 py-2 rounded-lg transition-colors font-bold flex items-center justify-center gap-2">
                        <Trash2 size={16} /> Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeSection === 'sponsored' && (
          <div>
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-3xl font-black uppercase">Sponsored Videos</h3>
              <button 
                onClick={() => handleOpenSponsoredModal()}
                className="flex items-center gap-2 bg-[var(--color-neon-green)] text-black font-bold px-4 py-2 rounded-lg hover:bg-[#00cc00] transition-colors"
              >
                <Plus size={20} /> Add Sponsored Video
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {sponsoredVideos.map(sv => (
                <div key={sv.id} className="bg-[#111] border border-[#333] rounded-2xl overflow-hidden group">
                  <div className="aspect-video bg-black relative">
                    <video src={sv.videoUrl || undefined} className="w-full h-full object-cover opacity-50" />
                    <div className="absolute top-4 right-4 bg-[var(--color-neon-green)] text-black text-[10px] font-black px-2 py-1 rounded uppercase">SPONSORED</div>
                  </div>
                  <div className="p-6">
                    <h4 className="text-xl font-bold text-white mb-1">{sv.title}</h4>
                    <p className="text-[var(--color-neon-green)] text-xs font-bold uppercase tracking-widest mb-4">By {sv.sponsorName}</p>
                    <div className="flex gap-3">
                      <button onClick={() => handleOpenSponsoredModal(sv)} className="flex-1 bg-white/5 hover:bg-white/10 text-white py-2 rounded-lg transition-colors font-bold flex items-center justify-center gap-2">
                        <Edit2 size={16} /> Edit
                      </button>
                      <button onClick={() => handleDeleteSponsored(sv.id)} className="flex-1 bg-red-500/10 hover:bg-red-500/20 text-red-500 py-2 rounded-lg transition-colors font-bold flex items-center justify-center gap-2">
                        <Trash2 size={16} /> Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeSection === 'chickenStore' && (
          <div>
            <div className="bg-[#111] border border-[#333] p-6 rounded-2xl mb-8">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <ShoppingBag className="text-[var(--color-neon-green)]" size={20} />
                Chicken Store Settings
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Section Title</label>
                  <input 
                    type="text" 
                    value={localSettings.chickenStoreSectionTitle}
                    onChange={(e) => setLocalSettings({ ...localSettings, chickenStoreSectionTitle: e.target.value })}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Section Subtitle</label>
                  <input 
                    type="text" 
                    value={localSettings.chickenStoreSectionSubtitle}
                    onChange={(e) => setLocalSettings({ ...localSettings, chickenStoreSectionSubtitle: e.target.value })}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center mb-8">
              <h3 className="text-3xl font-black uppercase">Chicken Items</h3>
              <button 
                onClick={() => handleOpenChickenModal()}
                className="flex items-center gap-2 bg-[var(--color-neon-green)] text-black font-bold px-4 py-2 rounded-lg hover:bg-[#00cc00] transition-colors"
              >
                <Plus size={20} /> Add Chicken Item
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {chickenItems.map(item => (
                <div key={item.id} className="bg-[#111] border border-[#333] rounded-2xl overflow-hidden group">
                  <div className="aspect-video bg-black relative">
                    {item.mediaType === 'video' ? (
                      <video src={item.mediaUrl} className="w-full h-full object-cover opacity-50" />
                    ) : (
                      <img src={item.mediaUrl} className="w-full h-full object-cover opacity-50" referrerPolicy="no-referrer" />
                    )}
                    <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[10px] font-bold text-[var(--color-neon-green)] border border-white/10 uppercase">
                      {item.category}
                    </div>
                  </div>
                  <div className="p-6">
                    <h4 className="text-xl font-bold text-white mb-1">{item.name}</h4>
                    <p className="text-gray-400 text-xs italic mb-4 line-clamp-1">"{item.remark}"</p>
                    <div className="space-y-2 mb-4">
                      {item.rates?.map((r: any, i: number) => (
                        <div key={`rate-${i}-${r.weight}`} className="flex justify-between text-xs">
                          <span className="text-gray-500">{r.weight}</span>
                          <span className="font-bold text-[var(--color-neon-green)]">₹{r.price}</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex gap-3">
                      <button onClick={() => handleOpenChickenModal(item)} className="flex-1 bg-white/5 hover:bg-white/10 text-white py-2 rounded-lg transition-colors font-bold flex items-center justify-center gap-2 text-sm">
                        <Edit2 size={16} /> Edit
                      </button>
                      <button onClick={() => handleDeleteChicken(item.id)} className="flex-1 bg-red-500/10 hover:bg-red-500/20 text-red-500 py-2 rounded-lg transition-colors font-bold flex items-center justify-center gap-2 text-sm">
                        <Trash2 size={16} /> Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeSection === 'founders' && (
          <div className="space-y-8">
            <h3 className="text-3xl font-black uppercase">Founder & Owner Management</h3>
            <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-6">
              <h4 className="font-bold text-xl">Founder Details</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-bold text-lg">Founder 1</h4>
                  <input type="text" value={localSettings.founder1Name} onChange={e => setLocalSettings({...localSettings, founder1Name: e.target.value})} placeholder="Name" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                  <input type="text" value={localSettings.founder1Role} onChange={e => setLocalSettings({...localSettings, founder1Role: e.target.value})} placeholder="Role" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                  <input type="text" value={localSettings.founder1Caption} onChange={e => setLocalSettings({...localSettings, founder1Caption: e.target.value})} placeholder="Caption" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                  <input type="text" value={localSettings.founder1StoryType} onChange={e => setLocalSettings({...localSettings, founder1StoryType: e.target.value})} placeholder="Story Type" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                  <MediaUploadInput label="Founder 1 Image" value={localSettings.founder1Image} onChange={val => setLocalSettings({...localSettings, founder1Image: val})} />
                  <MediaUploadInput label="Founder 1 Video" value={localSettings.founder1Video} onChange={val => setLocalSettings({...localSettings, founder1Video: val})} />
                  <MediaUploadInput label="Founder 1 Logo" value={localSettings.founder1Logo} onChange={val => setLocalSettings({...localSettings, founder1Logo: val})} />
                  <div className="grid grid-cols-1 gap-2 pt-2">
                    <input type="text" value={localSettings.founder1SocialLinks.instagram} onChange={e => setLocalSettings({...localSettings, founder1SocialLinks: {...localSettings.founder1SocialLinks, instagram: e.target.value}})} placeholder="Instagram Link" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                    <input type="text" value={localSettings.founder1SocialLinks.facebook} onChange={e => setLocalSettings({...localSettings, founder1SocialLinks: {...localSettings.founder1SocialLinks, facebook: e.target.value}})} placeholder="Facebook Link" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                    <input type="text" value={localSettings.founder1SocialLinks.youtube} onChange={e => setLocalSettings({...localSettings, founder1SocialLinks: {...localSettings.founder1SocialLinks, youtube: e.target.value}})} placeholder="YouTube Link" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                    <input type="text" value={localSettings.founder1SocialLinks.twitter} onChange={e => setLocalSettings({...localSettings, founder1SocialLinks: {...localSettings.founder1SocialLinks, twitter: e.target.value}})} placeholder="Twitter Link" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                    <input type="text" value={localSettings.founder1SocialLinks.whatsapp} onChange={e => setLocalSettings({...localSettings, founder1SocialLinks: {...localSettings.founder1SocialLinks, whatsapp: e.target.value}})} placeholder="WhatsApp Link" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                  </div>
                </div>
                <div className="space-y-4">
                  <h4 className="font-bold text-lg">Founder 2</h4>
                  <input type="text" value={localSettings.founder2Name} onChange={e => setLocalSettings({...localSettings, founder2Name: e.target.value})} placeholder="Name" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                  <input type="text" value={localSettings.founder2Role} onChange={e => setLocalSettings({...localSettings, founder2Role: e.target.value})} placeholder="Role" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                  <input type="text" value={localSettings.founder2Caption} onChange={e => setLocalSettings({...localSettings, founder2Caption: e.target.value})} placeholder="Caption" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                  <input type="text" value={localSettings.founder2StoryType} onChange={e => setLocalSettings({...localSettings, founder2StoryType: e.target.value})} placeholder="Story Type" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                  <MediaUploadInput label="Founder 2 Image" value={localSettings.founder2Image} onChange={val => setLocalSettings({...localSettings, founder2Image: val})} />
                  <MediaUploadInput label="Founder 2 Video" value={localSettings.founder2Video} onChange={val => setLocalSettings({...localSettings, founder2Video: val})} />
                  <MediaUploadInput label="Founder 2 Logo" value={localSettings.founder2Logo} onChange={val => setLocalSettings({...localSettings, founder2Logo: val})} />
                  <div className="grid grid-cols-1 gap-2 pt-2">
                    <input type="text" value={localSettings.founder2SocialLinks.instagram} onChange={e => setLocalSettings({...localSettings, founder2SocialLinks: {...localSettings.founder2SocialLinks, instagram: e.target.value}})} placeholder="Instagram Link" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                    <input type="text" value={localSettings.founder2SocialLinks.facebook} onChange={e => setLocalSettings({...localSettings, founder2SocialLinks: {...localSettings.founder2SocialLinks, facebook: e.target.value}})} placeholder="Facebook Link" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                    <input type="text" value={localSettings.founder2SocialLinks.youtube} onChange={e => setLocalSettings({...localSettings, founder2SocialLinks: {...localSettings.founder2SocialLinks, youtube: e.target.value}})} placeholder="YouTube Link" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                    <input type="text" value={localSettings.founder2SocialLinks.twitter} onChange={e => setLocalSettings({...localSettings, founder2SocialLinks: {...localSettings.founder2SocialLinks, twitter: e.target.value}})} placeholder="Twitter Link" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                    <input type="text" value={localSettings.founder2SocialLinks.whatsapp} onChange={e => setLocalSettings({...localSettings, founder2SocialLinks: {...localSettings.founder2SocialLinks, whatsapp: e.target.value}})} placeholder="WhatsApp Link" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                  </div>
                </div>
              </div>
              <h4 className="font-bold text-xl mt-8">Owner & Partner Contacts</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <input type="text" value={localSettings.contactNumbers.owner} onChange={e => setLocalSettings({...localSettings, contactNumbers: {...localSettings.contactNumbers, owner: e.target.value}})} placeholder="Owner Contact" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                <input type="text" value={localSettings.contactNumbers.partner} onChange={e => setLocalSettings({...localSettings, contactNumbers: {...localSettings.contactNumbers, partner: e.target.value}})} placeholder="Partner Contact" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
              </div>
              <button onClick={(e) => handleSaveSettings(e as any)} className="bg-[var(--color-neon-green)] text-black font-bold px-6 py-3 rounded-lg hover:bg-[#00cc00]">Save Changes</button>
            </div>
          </div>
        )}

        {activeSection === 'partners' && (
          <div>
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-3xl font-black uppercase">Partners & Collaborations</h3>
              <button 
                onClick={() => handleOpenCollaborationModal()}
                className="flex items-center gap-2 bg-[var(--color-neon-green)] text-black font-bold px-4 py-2 rounded-lg hover:bg-[#00cc00] transition-colors"
              >
                <Plus size={20} /> Add Partner
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {collaborations.map(col => (
                <div key={col.id} className="bg-[#111] border border-[#333] rounded-2xl overflow-hidden group">
                  <div className="aspect-video bg-black relative">
                    {col.mediaType === 'video' ? (
                      <div className="w-full h-full relative">
                        <video src={col.videoUrl || undefined} className="w-full h-full object-cover opacity-50" />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Play className="text-white opacity-40" size={32} />
                        </div>
                      </div>
                    ) : (
                      <img src={col.videoUrl || col.imageUrl || undefined} className="w-full h-full object-cover opacity-50" referrerPolicy="no-referrer" />
                    )}
                    <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[8px] font-bold text-white uppercase">
                      {col.mediaType || 'Media'}
                    </div>
                  </div>
                  <div className="p-6">
                    <h4 className="text-xl font-bold text-white mb-2">{col.brandName}</h4>
                    <p className="text-gray-400 text-sm mb-4 line-clamp-2 italic">"{col.description}"</p>
                    <div className="flex gap-3">
                      <button onClick={() => handleOpenCollaborationModal(col)} className="flex-1 bg-white/5 hover:bg-white/10 text-white py-2 rounded-lg transition-colors font-bold flex items-center justify-center gap-2">
                        <Edit2 size={16} /> Edit
                      </button>
                      <button onClick={() => handleDeleteCollaboration(col.id)} className="flex-1 bg-red-500/10 hover:bg-red-500/20 text-red-500 py-2 rounded-lg transition-colors font-bold flex items-center justify-center gap-2">
                        <Trash2 size={16} /> Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeSection === 'titles' && (
          <div className="space-y-8">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-3xl font-black uppercase">Section Titles & Subtitles</h3>
              <button 
                onClick={(e) => handleSaveSettings(e as any)}
                className="bg-[var(--color-neon-green)] text-black font-bold px-6 py-2 rounded-lg hover:bg-[#00cc00] transition-colors"
              >
                Save All Titles
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Menu Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Menu Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.menuSectionTitle} onChange={e => setLocalSettings({...localSettings, menuSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.menuSectionSubtitle} onChange={e => setLocalSettings({...localSettings, menuSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Offers Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Offers Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.offersSectionTitle} onChange={e => setLocalSettings({...localSettings, offersSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.offersSectionSubtitle} onChange={e => setLocalSettings({...localSettings, offersSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Reels Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Daily Reels Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.reelsSectionTitle} onChange={e => setLocalSettings({...localSettings, reelsSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.reelsSectionSubtitle} onChange={e => setLocalSettings({...localSettings, reelsSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Influencers Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Influencers Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.influencersSectionTitle} onChange={e => setLocalSettings({...localSettings, influencersSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.influencersSectionSubtitle} onChange={e => setLocalSettings({...localSettings, influencersSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Moments Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Moments Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.momentsSectionTitle || ''} onChange={e => setLocalSettings({...localSettings, momentsSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.momentsSectionSubtitle || ''} onChange={e => setLocalSettings({...localSettings, momentsSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Sponsored Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Sponsored Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.sponsoredSectionTitle} onChange={e => setLocalSettings({...localSettings, sponsoredSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.sponsoredSectionSubtitle} onChange={e => setLocalSettings({...localSettings, sponsoredSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Partners Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Partners & Collabs Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.partnersSectionTitle} onChange={e => setLocalSettings({...localSettings, partnersSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.partnersSectionSubtitle} onChange={e => setLocalSettings({...localSettings, partnersSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Founders Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Founders Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.foundersSectionTitle} onChange={e => setLocalSettings({...localSettings, foundersSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.foundersSectionSubtitle} onChange={e => setLocalSettings({...localSettings, foundersSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Events Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Events Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.eventsSectionTitle} onChange={e => setLocalSettings({...localSettings, eventsSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.eventsSectionSubtitle} onChange={e => setLocalSettings({...localSettings, eventsSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Photo Studio Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Photo Studio Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.photoStudioSectionTitle} onChange={e => setLocalSettings({...localSettings, photoStudioSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.photoStudioSectionSubtitle} onChange={e => setLocalSettings({...localSettings, photoStudioSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Cashback Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Cashback Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.cashbackSectionTitle} onChange={e => setLocalSettings({...localSettings, cashbackSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.cashbackSectionSubtitle} onChange={e => setLocalSettings({...localSettings, cashbackSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Rider Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Rider Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.riderSectionTitle} onChange={e => setLocalSettings({...localSettings, riderSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.riderSectionSubtitle} onChange={e => setLocalSettings({...localSettings, riderSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Staff Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Staff Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.staffSectionTitle} onChange={e => setLocalSettings({...localSettings, staffSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.staffSectionSubtitle} onChange={e => setLocalSettings({...localSettings, staffSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Banners Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Banners Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.bannersSectionTitle} onChange={e => setLocalSettings({...localSettings, bannersSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.bannersSectionSubtitle} onChange={e => setLocalSettings({...localSettings, bannersSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Chicken Store Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Chicken Store Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.chickenStoreSectionTitle} onChange={e => setLocalSettings({...localSettings, chickenStoreSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.chickenStoreSectionSubtitle} onChange={e => setLocalSettings({...localSettings, chickenStoreSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Reviews Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Reviews Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.reviewsSectionTitle} onChange={e => setLocalSettings({...localSettings, reviewsSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Subtitle</label>
                  <input type="text" value={localSettings.reviewsSectionSubtitle} onChange={e => setLocalSettings({...localSettings, reviewsSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Competition Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Competition Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.competitionSectionTitle} onChange={e => setLocalSettings({...localSettings, competitionSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Subtitle</label>
                  <input type="text" value={localSettings.competitionSectionSubtitle} onChange={e => setLocalSettings({...localSettings, competitionSectionSubtitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Story Section */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Story Section</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Main Title</label>
                  <input type="text" value={localSettings.storySectionTitle} onChange={e => setLocalSettings({...localSettings, storySectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Description</label>
                  <input type="text" value={localSettings.storySectionDescription} onChange={e => setLocalSettings({...localSettings, storySectionDescription: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>

              {/* Info Sections */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-2xl space-y-4">
                <h4 className="text-lg font-bold text-[var(--color-neon-green)] uppercase tracking-widest border-b border-white/5 pb-2">Info Section Titles</h4>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Opening Hours Title</label>
                  <input type="text" value={localSettings.openingHoursSectionTitle} onChange={e => setLocalSettings({...localSettings, openingHoursSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Contact Us Title</label>
                  <input type="text" value={localSettings.contactSectionTitle} onChange={e => setLocalSettings({...localSettings, contactSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Location/Directions Title</label>
                  <input type="text" value={localSettings.locationSectionTitle} onChange={e => setLocalSettings({...localSettings, locationSectionTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                </div>
              </div>
            </div>
          </div>
        )}

        {activeSection === 'notifications' && (
          <NotificationManagement />
        )}

        {activeSection === 'events' && (
          <EventsManagement />
        )}

        {activeSection === 'eventServices' && (
          <EventServicesManagement />
        )}

        {activeSection === 'rgbEngine' && (
          <RgbEngineManagement />
        )}

        {activeSection === 'reviews' && (
          <ReviewManagement />
        )}

        {activeSection === 'nova' && (
          <div className="bg-[#111] border border-[#333] p-6 rounded-xl space-y-6">
            <div className="flex items-center gap-3 mb-6">
              <Sparkles className="text-[var(--color-neon-green)]" size={32} />
              <h3 className="text-3xl font-black uppercase text-white">NOVA AI Engine Settings</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Mode Control */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333]">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">Generation Modes</h4>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">AI Generation Mode</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.aiModeEnabled ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, aiModeEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Manual Admin Mode</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.manualModeEnabled ?? false}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, manualModeEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Hybrid Mode</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.hybridModeEnabled ?? false}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, hybridModeEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Data Only Mode</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.dataOnlyModeEnabled ?? false}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, dataOnlyModeEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>
              </div>

              {/* Admin Permission Control */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333]">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">Admin Permission Control</h4>
                
                <div className="flex flex-col gap-2 mb-4">
                  <span className="text-sm font-bold text-white">Permission Mode</span>
                  <select 
                    value={localSettings.novaAI?.permissionMode || 'full'}
                    onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, permissionMode: e.target.value as any}})}
                    className="bg-[#111] border border-[#333] rounded-lg px-3 py-2 text-white outline-none focus:border-[var(--color-neon-green)] text-sm"
                  >
                    <option value="full">Full Permission Mode (Manage Everything)</option>
                    <option value="limited">Limited Mode (Only Suggest & Talk)</option>
                    <option value="disabled">Disabled Mode (No AI Action)</option>
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Allow AI to Manage Cart</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.allowManageCart ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, allowManageCart: e.target.checked}})}
                      disabled={localSettings.novaAI?.permissionMode === 'disabled'}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Allow AI to Suggest Items</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.allowSuggestItems ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, allowSuggestItems: e.target.checked}})}
                      disabled={localSettings.novaAI?.permissionMode === 'disabled'}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Order Tracking Intelligence</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.orderTrackingEnabled ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, orderTrackingEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>
              </div>

              {/* Live Order Announcement System */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333]">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">Live Order Announcements (Pro Max)</h4>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Live Order Announcements</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.liveOrderAnnouncementsEnabled ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, liveOrderAnnouncementsEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Random Viral Announcements</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.randomAnnouncementsEnabled ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, randomAnnouncementsEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Demo Mode</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.demoModeEnabled ?? false}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, demoModeEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Show Customer Name</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.showCustomerName ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, showCustomerName: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-white">Announcement Interval (sec)</label>
                  <input 
                    type="number"
                    className="w-full bg-[#111] border border-[#333] rounded-lg p-2 text-white"
                    value={localSettings.novaAI?.announcementInterval ?? 60}
                    onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, announcementInterval: parseInt(e.target.value)}})}
                  />
                </div>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-bold text-white">Order Announcement Prompt</label>
                    <PromptGeneratorButton 
                      onGenerate={() => generateSystemPromptWithAI('order')} 
                      isLoading={isGenerating === 'order'} 
                    />
                  </div>
                  <textarea 
                    className="w-full bg-[#111] border border-[#333] rounded-lg p-2 text-white h-24"
                    value={localSettings.novaAI?.orderAnnouncementPrompt ?? ''}
                    onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, orderAnnouncementPrompt: e.target.value}})}
                  />
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-bold text-white">Viral/Storytelling Prompt</label>
                    <PromptGeneratorButton 
                      onGenerate={() => generateSystemPromptWithAI('viral')} 
                      isLoading={isGenerating === 'viral'} 
                    />
                  </div>
                  <textarea 
                    className="w-full bg-[#111] border border-[#333] rounded-lg p-2 text-white h-24"
                    value={localSettings.novaAI?.viralStorytellingPrompt ?? ''}
                    onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, viralStorytellingPrompt: e.target.value}})}
                  />
                </div>
              </div>

              {/* Intelligence Engines */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333]">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">Intelligence Engines</h4>
                
                <div className="space-y-3">
                  {[
                    { key: 'viralEngineEnabled', label: 'Viral Engine' },
                    { key: 'storytellingEngineEnabled', label: 'Storytelling Engine' },
                    { key: 'contextualIntelligenceEnabled', label: 'Contextual Intelligence' },
                    { key: 'marketingEngineEnabled', label: 'Marketing Engine' },
                    { key: 'futureGenerationEnabled', label: 'Future Generation Intelligence' },
                    { key: 'evolutionModeEnabled', label: 'Evolution Mode (Controlled)' },
                    { key: 'trendAdaptationEnabled', label: 'Trend Adaptation Engine' },
                    { key: 'generationAwarenessEnabled', label: 'Generation Awareness' },
                  ].map((engine) => (
                    <div key={engine.key} className="flex items-center justify-between">
                      <span className="text-sm font-bold text-white">{engine.label}</span>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          className="sr-only peer"
                          checked={!!localSettings.novaAI?.[engine.key as keyof typeof localSettings.novaAI]}
                          onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, [engine.key]: e.target.checked}})}
                        />
                        <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Zero-Miss Master Brain System */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333]">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">Zero-Miss Master Brain</h4>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Zero-Miss Auto Analysis</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.zeroMissAnalysisEnabled ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, zeroMissAnalysisEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Deep Data Intelligence</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.deepDataIntelligenceEnabled ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, deepDataIntelligenceEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Future Auto-Adapt System</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.futureAutoAdaptEnabled ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, futureAutoAdaptEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Human-Like Super Brain</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.humanLikeSuperBrainEnabled ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, humanLikeSuperBrainEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Zero Error + Max Accuracy</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.zeroErrorMaxAccuracyEnabled ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, zeroErrorMaxAccuracyEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>
              </div>

              {/* Advanced Intelligence */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333]">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">Advanced Intelligence</h4>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Auto Business Analysis Engine</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.autoAnalysisEnabled ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, autoAnalysisEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Visible to Customers</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.visibleToCustomers ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, visibleToCustomers: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Auto Speech System</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.autoSpeechEnabled ?? false}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, autoSpeechEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                {localSettings.novaAI?.autoSpeechEnabled && (
                  <div>
                    <label className="block text-xs text-gray-500 uppercase mb-2">Auto Speech Interval (Seconds)</label>
                    <input 
                      type="number"
                      value={localSettings.novaAI?.autoSpeechInterval || 30}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, autoSpeechInterval: parseInt(e.target.value)}})}
                      className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                      min="10"
                    />
                  </div>
                )}
              </div>

              {/* AI Profile & Media System */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333] md:col-span-2">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">AI Profile & Media System</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs text-gray-500 uppercase mb-2">AI Profile Image URL</label>
                    <input 
                      type="text"
                      value={localSettings.novaAI?.aiProfileImage || ''}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, aiProfileImage: e.target.value}})}
                      className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                      placeholder="https://example.com/ai-image.jpg"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-500 uppercase mb-2">AI Profile Video URL (MP4/GIF)</label>
                    <input 
                      type="text"
                      value={localSettings.novaAI?.aiProfileVideo || ''}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, aiProfileVideo: e.target.value}})}
                      className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                      placeholder="https://example.com/ai-video.mp4"
                    />
                  </div>
                </div>
              </div>

              {/* WhatsApp AI Agent */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333] md:col-span-2">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">WhatsApp AI Agent</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-white">Enable WhatsApp AI Agent</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        className="sr-only peer"
                        checked={localSettings.novaAI?.whatsappAiAgentEnabled ?? false}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, whatsappAiAgentEnabled: e.target.checked}})}
                      />
                      <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                    </label>
                  </div>

                  <div>
                    <label className="block text-xs text-gray-500 uppercase mb-2">WhatsApp Number (For Link/QR)</label>
                    <input 
                      type="text"
                      value={localSettings.novaAI?.whatsappNumber || ''}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, whatsappNumber: e.target.value}})}
                      className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                      placeholder="e.g. 919876543210"
                    />
                  </div>
                </div>

                {localSettings.novaAI?.whatsappAiAgentEnabled && (
                  <div className="space-y-4 mt-4 pt-4 border-t border-[#333]">
                    <div>
                      <label className="block text-xs text-gray-500 uppercase mb-2">WhatsApp Reply Mode</label>
                      <select 
                        value={localSettings.novaAI?.whatsappReplyMode || 'hybrid'}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, whatsappReplyMode: e.target.value as any}})}
                        className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                      >
                        <option value="ai">AI Reply (Fully Automated)</option>
                        <option value="manual">Manual Reply (Fixed Template)</option>
                        <option value="hybrid">Hybrid Reply (Template + AI Personalization)</option>
                      </select>
                    </div>

                    {(localSettings.novaAI?.whatsappReplyMode === 'manual' || localSettings.novaAI?.whatsappReplyMode === 'hybrid') && (
                      <div>
                        <label className="block text-xs text-gray-500 uppercase mb-2">Manual Reply Template</label>
                        <textarea
                          value={localSettings.novaAI?.whatsappManualReply || ''}
                          onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, whatsappManualReply: e.target.value}})}
                          className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                          rows={3}
                          placeholder="Enter your manual response template..."
                        />
                      </div>
                    )}
                  </div>
                )}

                {localSettings.novaAI?.whatsappNumber && (
                  <div className="mt-4 pt-4 border-t border-[#333]">
                    <label className="block text-xs text-gray-500 uppercase mb-2">WhatsApp Link & QR</label>
                    <div className="flex flex-col gap-4">
                      <div className="flex items-center gap-2">
                        <input 
                          type="text"
                          readOnly
                          value={`https://wa.me/${localSettings.novaAI.whatsappNumber}`}
                          className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-gray-400 outline-none"
                        />
                        <button 
                          onClick={() => {
                            navigator.clipboard.writeText(`https://wa.me/${localSettings.novaAI?.whatsappNumber}`);
                            alert('Link copied to clipboard!');
                          }}
                          className="bg-[var(--color-neon-green)] text-black px-4 py-2 rounded-lg font-bold hover:scale-105 transition-transform"
                        >
                          Copy
                        </button>
                      </div>
                      <div className="bg-white p-4 rounded-lg self-start">
                        <QRCodeSVG value={`https://wa.me/${localSettings.novaAI.whatsappNumber}`} size={128} />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Advanced Intelligence Settings */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333] md:col-span-2">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">Advanced Intelligence Settings</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between bg-[#222] p-4 rounded-lg border border-[#444]">
                    <div>
                      <span className="text-sm font-bold text-white block">Auto-Stable Mode</span>
                      <span className="text-xs text-gray-500">Auto-adapt to website changes</span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        className="sr-only peer"
                        checked={localSettings.novaAI?.autoStableModeEnabled ?? true}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, autoStableModeEnabled: e.target.checked}})}
                      />
                      <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between bg-[#222] p-4 rounded-lg border border-[#444]">
                    <div>
                      <span className="text-sm font-bold text-white block">Truth-First Mode</span>
                      <span className="text-xs text-gray-500">Strictly no fake answers</span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        className="sr-only peer"
                        checked={localSettings.novaAI?.truthFirstModeEnabled ?? true}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, truthFirstModeEnabled: e.target.checked}})}
                      />
                      <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between bg-[#222] p-4 rounded-lg border border-[#444]">
                    <div>
                      <span className="text-sm font-bold text-white block">Auto-Switch Mode</span>
                      <span className="text-xs text-gray-500">Fallback to manual if AI fails</span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        className="sr-only peer"
                        checked={localSettings.novaAI?.autoSwitchModeEnabled ?? true}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, autoSwitchModeEnabled: e.target.checked}})}
                      />
                      <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between bg-[#222] p-4 rounded-lg border border-[#444]">
                    <div>
                      <span className="text-sm font-bold text-white block">Cost-Saving Mode</span>
                      <span className="text-xs text-gray-500">Optimize API usage</span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        className="sr-only peer"
                        checked={localSettings.novaAI?.costSavingModeEnabled ?? false}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, costSavingModeEnabled: e.target.checked}})}
                      />
                      <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                    </label>
                  </div>

                  {/* Assistant Visibility */}
                  <div className="flex items-center justify-between bg-[#222] p-4 rounded-lg border border-[#444]">
                    <div>
                      <span className="text-sm font-bold text-white block">Assistant Visibility</span>
                      <span className="text-xs text-gray-500">Show/Hide Nova AI</span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        className="sr-only peer"
                        checked={localSettings.novaAI?.assistantVisible ?? true}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, assistantVisible: e.target.checked}})}
                      />
                      <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                    </label>
                  </div>

                  {/* Voice Mode */}
                  <div className="bg-[#222] p-4 rounded-lg border border-[#444] md:col-span-2">
                    <span className="text-sm font-bold text-white block mb-2">Voice Mode</span>
                    <div className="flex gap-2">
                      <button 
                        className={`flex-1 py-2 text-xs font-bold rounded-md ${localSettings.novaAI?.manualVoiceModeEnabled ? 'bg-[var(--color-neon-green)] text-black' : 'bg-[#333] text-white'}`}
                        onClick={() => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, manualVoiceModeEnabled: true, autoVoiceModeEnabled: false, hybridVoiceModeEnabled: false}})}
                      >Manual</button>
                      <button 
                        className={`flex-1 py-2 text-xs font-bold rounded-md ${localSettings.novaAI?.autoVoiceModeEnabled ? 'bg-[var(--color-neon-green)] text-black' : 'bg-[#333] text-white'}`}
                        onClick={() => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, manualVoiceModeEnabled: false, autoVoiceModeEnabled: true, hybridVoiceModeEnabled: false}})}
                      >Auto</button>
                      <button 
                        className={`flex-1 py-2 text-xs font-bold rounded-md ${localSettings.novaAI?.hybridVoiceModeEnabled ? 'bg-[var(--color-neon-green)] text-black' : 'bg-[#333] text-white'}`}
                        onClick={() => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, manualVoiceModeEnabled: false, autoVoiceModeEnabled: false, hybridVoiceModeEnabled: true}})}
                      >Hybrid</button>
                    </div>
                  </div>

                  {/* Voice Interval */}
                  <div className="bg-[#222] p-4 rounded-lg border border-[#444] md:col-span-2">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-bold text-white">Voice Interval (Seconds)</span>
                      <span className="text-xs text-[var(--color-neon-green)]">{localSettings.novaAI?.voiceInterval}s</span>
                    </div>
                    <input 
                      type="range" 
                      min="5" 
                      max="300" 
                      step="5"
                      value={localSettings.novaAI?.voiceInterval ?? 30}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, voiceInterval: Number(e.target.value)}})}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-[var(--color-neon-green)]"
                    />
                  </div>
                </div>
              </div>

              {/* AI Brain Update & Evolution System */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333] md:col-span-2">
                <div className="flex items-center justify-between border-b border-[#333] pb-4 mb-4">
                  <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider">Prompt Control Dashboard</h4>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-400 uppercase">AI Updates</span>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          className="sr-only peer"
                          checked={localSettings.novaAI?.aiUpdatesEnabled ?? true}
                          onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, aiUpdatesEnabled: e.target.checked}})}
                        />
                        <div className="w-9 h-5 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                      </label>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-400 uppercase">Safe Mode</span>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          className="sr-only peer"
                          checked={localSettings.novaAI?.safeModeEnabled ?? true}
                          onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, safeModeEnabled: e.target.checked}})}
                        />
                        <div className="w-9 h-5 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                      </label>
                    </div>
                    <select 
                      value={localSettings.novaAI?.updateMode || 'replace'}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, updateMode: e.target.value as any}})}
                      className="bg-[#222] border border-[#444] rounded-lg px-2 py-1 text-xs text-white focus:border-[var(--color-neon-green)] outline-none"
                    >
                      <option value="replace">Replace Mode</option>
                      <option value="merge">Merge Mode</option>
                      <option value="test">Test Mode</option>
                    </select>
                  </div>
                </div>
                
                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <label className="text-xs text-[var(--color-neon-green)] font-bold uppercase">Master Prompt (Core AI Personality)</label>
                      <PromptGeneratorButton onGenerate={() => generatePrompt('masterPrompt')} isLoading={isGenerating === 'masterPrompt'} />
                    </div>
                    <textarea
                      value={localSettings.novaAI?.masterPrompt || ''}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, masterPrompt: e.target.value}})}
                      className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none font-mono text-sm"
                      rows={4}
                      placeholder="You are NOVA AI..."
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <label className="text-xs text-gray-400 uppercase">Business Logic</label>
                        <PromptGeneratorButton onGenerate={() => generatePrompt('businessLogicPrompt')} isLoading={isGenerating === 'businessLogicPrompt'} />
                      </div>
                      <textarea
                        value={localSettings.novaAI?.businessLogicPrompt || ''}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, businessLogicPrompt: e.target.value}})}
                        className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none font-mono text-xs"
                        rows={3}
                        placeholder="Rules for handling business data..."
                      />
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <label className="text-xs text-gray-400 uppercase">Sales Strategy</label>
                        <PromptGeneratorButton onGenerate={() => generatePrompt('salesStrategyPrompt')} isLoading={isGenerating === 'salesStrategyPrompt'} />
                      </div>
                      <textarea
                        value={localSettings.novaAI?.salesStrategyPrompt || ''}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, salesStrategyPrompt: e.target.value}})}
                        className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none font-mono text-xs"
                        rows={3}
                        placeholder="Rules for upselling and combos..."
                      />
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <label className="text-xs text-gray-400 uppercase">WhatsApp AI Behavior</label>
                        <PromptGeneratorButton onGenerate={() => generatePrompt('whatsappBehaviorPrompt')} isLoading={isGenerating === 'whatsappBehaviorPrompt'} />
                      </div>
                      <textarea
                        value={localSettings.novaAI?.whatsappBehaviorPrompt || ''}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, whatsappBehaviorPrompt: e.target.value}})}
                        className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none font-mono text-xs"
                        rows={3}
                        placeholder="Rules for WhatsApp chat..."
                      />
                    </div>
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <label className="text-xs text-gray-400 uppercase">Voice & Cart Behavior</label>
                        <PromptGeneratorButton onGenerate={() => generatePrompt('voiceBehaviorPrompt')} isLoading={isGenerating === 'voiceBehaviorPrompt'} />
                      </div>
                      <textarea
                        value={localSettings.novaAI?.voiceBehaviorPrompt || ''}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, voiceBehaviorPrompt: e.target.value}})}
                        className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none font-mono text-xs"
                        rows={3}
                        placeholder="Rules for voice tone and cart additions..."
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Language Generation Settings */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333] md:col-span-2">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">Language Generation Settings</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { key: 'hindiEnglishScript', label: 'Hindi (English Script)' },
                    { key: 'hindiScript', label: 'Hindi (Devanagari Script)' },
                    { key: 'bengaliScript', label: 'Bengali (Bengali Script)' },
                    { key: 'english', label: 'English' }
                  ].map((lang) => (
                    <div key={lang.key} className="flex items-center justify-between bg-[#222] p-4 rounded-lg border border-[#444]">
                      <span className="text-sm font-bold text-white">{lang.label}</span>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          className="sr-only peer"
                          checked={localSettings.novaAI?.enabledLanguages?.[lang.key as keyof typeof localSettings.novaAI.enabledLanguages] ?? true}
                          onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, enabledLanguages: {...localSettings.novaAI?.enabledLanguages, [lang.key]: e.target.checked}}})}
                        />
                        <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Data Filter & Visibility Control */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333] md:col-span-2">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">Data Filter & Visibility Control</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between bg-[#222] p-4 rounded-lg border border-[#444]">
                    <span className="text-sm font-bold text-white">Show Prices</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        className="sr-only peer"
                        checked={localSettings.novaAI?.dataVisibility?.showPrice ?? true}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, dataVisibility: {...localSettings.novaAI?.dataVisibility, showPrice: e.target.checked}}})}
                      />
                      <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                    </label>
                  </div>
                  
                  <div className="flex items-center justify-between bg-[#222] p-4 rounded-lg border border-[#444]">
                    <span className="text-sm font-bold text-white">Show Offers</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        className="sr-only peer"
                        checked={localSettings.novaAI?.dataVisibility?.showOffers ?? true}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, dataVisibility: {...localSettings.novaAI?.dataVisibility, showOffers: e.target.checked}}})}
                      />
                      <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between bg-[#222] p-4 rounded-lg border border-[#444]">
                    <span className="text-sm font-bold text-white">Show Stock Status</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        className="sr-only peer"
                        checked={localSettings.novaAI?.dataVisibility?.showStock ?? true}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, dataVisibility: {...localSettings.novaAI?.dataVisibility, showStock: e.target.checked}}})}
                      />
                      <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between bg-[#222] p-4 rounded-lg border border-[#444]">
                    <span className="text-sm font-bold text-white">Show Special Items</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        className="sr-only peer"
                        checked={localSettings.novaAI?.dataVisibility?.showSpecialItems ?? true}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, dataVisibility: {...localSettings.novaAI?.dataVisibility, showSpecialItems: e.target.checked}}})}
                      />
                      <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                    </label>
                  </div>
                </div>
              </div>

              {/* Content Type Controls */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333] md:col-span-2">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">Content Type Controls</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {(['shayari', 'dialog', 'entertainment', 'funny', 'reaction', 'motionVibe', 'chutkule'] as const).map((key) => (
                    <div key={key} className="bg-[#222] p-4 rounded-lg border border-[#444] space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-white capitalize">{key}</span>
                        <PromptGeneratorButton onGenerate={() => generatePrompt(`${key}ManualText` as any)} isLoading={isGenerating === `${key}ManualText`} />
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input 
                            type="checkbox" 
                            className="sr-only peer"
                            checked={localSettings.novaAI?.[key]?.enabled ?? true}
                            onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, [key]: {...localSettings.novaAI?.[key], enabled: e.target.checked}}})}
                          />
                          <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                        </label>
                      </div>
                      <textarea
                        value={localSettings.novaAI?.[key]?.manualText || ''}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, [key]: {...localSettings.novaAI?.[key], manualText: e.target.value}}})}
                        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none text-sm"
                        placeholder={`Enter manual ${key} text...`}
                        rows={2}
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Core Settings */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333]">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">Core System</h4>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Enable Nova AI</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.isEnabled || false}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, isEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Founder AI Connection</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.isFounderAiEnabled ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, isFounderAiEnabled: e.target.checked})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Voice Output</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.voiceEnabled ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, voiceEnabled: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div>
                  <label className="block text-xs text-gray-500 uppercase mb-2">Voice Type</label>
                  <select 
                    value={localSettings.novaAI?.voiceType || 'female'}
                    onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, voiceType: e.target.value as any}})}
                    className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                  >
                    <option value="male">Male (Deep & Friendly)</option>
                    <option value="female">Female (Soft & Polite)</option>
                    <option value="young">Young (Energetic & Fun)</option>
                  </select>
                </div>
              </div>

              {/* Language & Wake Word */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333]">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">Interaction</h4>
                
                <div>
                  <label className="block text-xs text-gray-500 uppercase mb-2">Primary Language</label>
                  <select 
                    value={localSettings.novaAI?.language || 'hi'}
                    onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, language: e.target.value as any}})}
                    className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                  >
                    <option value="hi">Hindi (हिंदी)</option>
                    <option value="en">English</option>
                    <option value="bn">Bengali (বাংলা)</option>
                    <option value="ur">Urdu (اردو)</option>
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white">Auto Language Detection</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer"
                      checked={localSettings.novaAI?.autoLanguageDetection ?? true}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, autoLanguageDetection: e.target.checked}})}
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                  </label>
                </div>

                <div>
                  <label className="block text-xs text-gray-500 uppercase mb-2">Wake Word</label>
                  <input 
                    type="text"
                    value={localSettings.novaAI?.wakeWord || 'Hey Nova'}
                    onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, wakeWord: e.target.value}})}
                    className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                    placeholder="e.g. Hey Nova"
                  />
                </div>
              </div>

              {/* Entertainment & Mix Mode */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333] md:col-span-2">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">Behavior & Entertainment</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-white">Entertainment Mode (Jokes/Shayari)</span>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          className="sr-only peer"
                          checked={localSettings.novaAI?.entertainmentMode ?? true}
                          onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, entertainmentMode: e.target.checked}})}
                        />
                        <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                      </label>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-white">Mix Mode (Blend Styles)</span>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input 
                          type="checkbox" 
                          className="sr-only peer"
                          checked={localSettings.novaAI?.mixMode ?? true}
                          onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, mixMode: e.target.checked}})}
                        />
                        <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                      </label>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-gray-500 uppercase mb-2">Mix Intensity</label>
                    <select 
                      value={localSettings.novaAI?.mixIntensity || 'medium'}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, mixIntensity: e.target.value as any}})}
                      className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                    >
                      <option value="low">Low (Mostly Professional)</option>
                      <option value="medium">Medium (Balanced)</option>
                      <option value="high">High (Very Entertaining)</option>
                    </select>
                    <p className="text-[10px] text-gray-500 mt-2">Controls how often NOVA uses jokes, shayari, and funny reactions.</p>
                  </div>
                </div>
              </div>

              {/* WhatsApp Automation */}
              <div className="space-y-4 bg-[#1a1a1a] p-5 rounded-xl border border-[#333] md:col-span-2">
                <h4 className="text-[var(--color-neon-green)] font-bold uppercase tracking-wider mb-4 border-b border-[#333] pb-2">WhatsApp Automation</h4>
                
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-sm font-bold text-white block">Include AI Generated Message</span>
                      <span className="text-[10px] text-gray-500">NOVA will generate a personalized greeting or shayari based on the order.</span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        className="sr-only peer"
                        checked={localSettings.novaAI?.includeAiMessage ?? true}
                        onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, includeAiMessage: e.target.checked}})}
                      />
                      <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--color-neon-green)]"></div>
                    </label>
                  </div>

                  <div>
                    <label className="block text-xs text-gray-500 uppercase mb-2">WhatsApp Message Template</label>
                    <textarea 
                      value={localSettings.novaAI?.whatsappTemplate || ''}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, whatsappTemplate: e.target.value}})}
                      className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none min-h-[200px] font-mono text-sm"
                      placeholder="Enter template..."
                    />
                    <p className="text-[10px] text-gray-500 mt-2">Available variables: {'{{name}}'}, {'{{phone}}'}, {'{{address}}'}, {'{{mapsLink}}'}, {'{{orderId}}'}, {'{{paymentMethod}}'}, {'{{orderSummary}}'}, {'{{totalAmount}}'}</p>
                  </div>

                  <div>
                    <label className="block text-xs text-gray-500 uppercase mb-2">Custom Instructions (NOVA AI Learning)</label>
                    <textarea 
                      value={localSettings.novaAI?.customInstructions || ''}
                      onChange={(e) => setLocalSettings({...localSettings, novaAI: {...localSettings.novaAI, customInstructions: e.target.value}})}
                      className="w-full bg-[#222] border border-[#444] rounded-lg px-3 py-2 text-white focus:border-[var(--color-neon-green)] outline-none min-h-[150px] text-sm"
                      placeholder="Add specific instructions for NOVA AI to follow..."
                    />
                    <p className="text-[10px] text-gray-500 mt-2">These instructions will guide NOVA AI's behavior and knowledge.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <button 
              onClick={() => handleUpdateSettings(localSettings)}
              className="w-full bg-[var(--color-neon-green)] text-black font-black py-4 rounded-xl hover:bg-white transition-colors uppercase tracking-widest text-lg shadow-[0_0_20px_rgba(0,255,0,0.3)]"
            >
              Save NOVA AI Settings
            </button>
          </div>
        )}

        {activeSection === 'moments' && (
          <MomentsManagement />
        )}

        {activeSection === 'deliveryZones' && (
          <DeliveryZonesManagement />
        )}

        {activeSection === 'banners' && (
          <div>
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-3xl font-black uppercase">Banner Management</h3>
              <button 
                onClick={() => handleOpenBannerModal()}
                className="flex items-center gap-2 bg-[var(--color-neon-green)] text-black font-bold px-4 py-2 rounded-lg hover:bg-[#00cc00] transition-colors"
              >
                <Plus size={20} /> Add Banner
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {banners.map(banner => (
                <div key={banner.id} className="bg-[#111] border border-[#333] rounded-xl overflow-hidden group">
                  <div className="aspect-[21/9] relative">
                    {banner.imageUrl && <img src={banner.imageUrl} alt={banner.title} className="w-full h-full object-cover" />}
                    <div className="absolute top-2 right-2 flex gap-2">
                      <button onClick={() => handleOpenBannerModal(banner)} className="p-2 bg-black/50 text-white rounded-lg hover:bg-[var(--color-neon-green)] hover:text-black transition-colors">
                        <Edit2 size={16} />
                      </button>
                      <button onClick={() => handleDeleteBanner(banner.id)} className="p-2 bg-black/50 text-white rounded-lg hover:bg-red-500 transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                    <div className="absolute bottom-2 left-2 flex gap-2">
                      {banner.active ? (
                        <span className="bg-green-500/20 text-green-500 text-[10px] font-bold px-2 py-1 rounded border border-green-500/50 uppercase">Active</span>
                      ) : (
                        <span className="bg-red-500/20 text-red-500 text-[10px] font-bold px-2 py-1 rounded border border-red-500/50 uppercase">Inactive</span>
                      )}
                      <span className="bg-blue-500/20 text-blue-500 text-[10px] font-bold px-2 py-1 rounded border border-blue-500/50 uppercase">Order: {banner.order}</span>
                    </div>
                  </div>
                  <div className="p-4">
                    <h4 className="font-bold text-white mb-1">{banner.title}</h4>
                    {banner.link && <p className="text-xs text-gray-500 truncate">{banner.link}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeSection === 'cashback' && (
          <CashbackManagement />
        )}

        {activeSection === 'deliveryFee' && (
          <DeliveryFeeManagement />
        )}

        {activeSection === 'photostudio' && (
          <PhotoStudioManagement />
        )}

        {activeSection === 'stories' && (
          <div className="space-y-8">
            <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
              <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                <Film className="text-[var(--color-neon-green)]" size={20} />
                Story Section Settings
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Section Title</label>
                  <input 
                    type="text" 
                    value={localSettings.storySectionTitle}
                    onChange={(e) => setLocalSettings({ ...localSettings, storySectionTitle: e.target.value })}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Section Description</label>
                  <input 
                    type="text" 
                    value={localSettings.storySectionDescription}
                    onChange={(e) => setLocalSettings({ ...localSettings, storySectionDescription: e.target.value })}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center mb-8">
              <h3 className="text-3xl font-black uppercase tracking-tighter">Owner & Partner Stories</h3>
              <button 
                onClick={() => handleOpenStoryModal()}
                className="flex items-center gap-2 bg-[var(--color-neon-green)] text-black font-bold px-6 py-3 rounded-xl hover:bg-[#00cc00] transition-all hover:scale-105 shadow-[0_0_15px_rgba(0,255,0,0.3)]"
              >
                <Plus size={20} /> Add New Story
              </button>
            </div>

            {storyError && (
              <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-xl flex items-center justify-between mb-6">
                <p className="text-red-500 text-xs font-bold uppercase tracking-widest">{storyError}</p>
                <button onClick={() => setStoryError(null)}><X size={14} className="text-red-500" /></button>
              </div>
            )}
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
              {stories.map(story => (
                <div key={story.id} className="bg-[#111] border border-[#333] rounded-2xl overflow-hidden group hover:border-[var(--color-neon-green)] transition-all">
                  <div className="aspect-[9/16] relative bg-black">
                    {story.mediaType === 'video' ? (
                      <div className="w-full h-full relative">
                        {story.mediaUrl && <video src={story.mediaUrl} className="w-full h-full object-cover opacity-60" />}
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Play className="text-white opacity-40" size={32} />
                        </div>
                      </div>
                    ) : (
                      story.mediaUrl && <img src={story.mediaUrl} className="w-full h-full object-cover opacity-60" referrerPolicy="no-referrer" alt={story.title} />
                    )}
                    
                    <div className="absolute top-4 left-4 flex items-center gap-2">
                      <div className="w-10 h-10 rounded-full border-2 border-[var(--color-neon-green)] p-0.5 bg-black overflow-hidden shadow-[0_0_10px_rgba(0,255,0,0.5)]">
                        {story.logoUrl && <img src={story.logoUrl} className="w-full h-full rounded-full object-cover" referrerPolicy="no-referrer" alt="Logo" />}
                      </div>
                      <span className="text-xs font-black uppercase tracking-widest text-white drop-shadow-md">{story.title}</span>
                    </div>

                    <div className="absolute top-4 right-4 flex flex-col gap-2">
                      <button 
                        onClick={() => handleOpenStoryModal(story)} 
                        className="flex items-center gap-2 px-3 py-2 bg-black/80 text-white rounded-lg hover:bg-[var(--color-neon-green)] hover:text-black transition-colors backdrop-blur-md border border-white/10"
                      >
                        <Edit2 size={14} />
                        <span className="text-[10px] font-black uppercase tracking-widest">Edit</span>
                      </button>
                      <button 
                        onClick={() => handleDeleteStory(story.id)} 
                        className="flex items-center gap-2 px-3 py-2 bg-black/80 text-red-500 rounded-lg hover:bg-red-500 hover:text-white transition-colors backdrop-blur-md border border-white/10"
                      >
                        <Trash2 size={14} />
                        <span className="text-[10px] font-black uppercase tracking-widest">Delete</span>
                      </button>
                    </div>

                    <div className="absolute bottom-4 left-4 flex flex-wrap gap-2">
                      {story.active ? (
                        <span className="bg-green-500/20 text-green-500 text-[10px] font-black px-2 py-1 rounded border border-green-500/50 uppercase tracking-widest">Active</span>
                      ) : (
                        <span className="bg-red-500/20 text-red-500 text-[10px] font-black px-2 py-1 rounded border border-red-500/50 uppercase tracking-widest">Inactive</span>
                      )}
                      <span className="bg-blue-500/20 text-blue-500 text-[10px] font-black px-2 py-1 rounded border border-blue-500/50 uppercase tracking-widest">Order: {story.order}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {stories.length === 0 && (
              <div className="text-center py-20 bg-[#111] border border-dashed border-[#333] rounded-3xl">
                <TrendingUp size={48} className="mx-auto text-gray-700 mb-4" />
                <h4 className="text-xl font-bold text-gray-500 uppercase tracking-widest">No Stories Found</h4>
                <p className="text-gray-600 mt-2">Add your first partner or owner story to engage customers!</p>
              </div>
            )}
          </div>
        )}

        {activeSection === 'layouts' && (
          <LayoutManager 
            localSettings={localSettings} 
            setLocalSettings={setLocalSettings} 
            handleUpdateSettings={handleUpdateSettings} 
          />
        )}

        {activeSection === 'settings' && (
          <div>
            <h3 className="text-3xl font-black uppercase mb-8">Global Settings</h3>
            
            <AdminLogoUpload />

            <form onSubmit={handleSaveSettings} className="max-w-2xl space-y-6">
              
              {/* Appearance Settings */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-xl">
                <h4 className="text-xl font-bold mb-4 text-[var(--color-neon-green)]">Appearance</h4>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-bold">Theme Mode</p>
                    <p className="text-gray-400 text-sm">Switch between dark and light mode</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setLocalSettings({...localSettings, theme: localSettings.theme === 'dark' ? 'light' : 'dark'})}
                    className={`relative inline-flex h-8 w-16 items-center rounded-full transition-colors ${localSettings.theme === 'dark' ? 'bg-[var(--color-neon-green)]' : 'bg-gray-600'}`}
                  >
                    <span
                      className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${localSettings.theme === 'dark' ? 'translate-x-9' : 'translate-x-1'}`}
                    />
                  </button>
                </div>
              </div>

              {/* Minimum Order Settings */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-xl">
                <h4 className="text-xl font-bold mb-4 text-[var(--color-neon-green)]">Minimum Order Settings</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-white font-bold">Enable Minimum Order</p>
                      <p className="text-gray-400 text-sm">Require a minimum number of items per order</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setLocalSettings({...localSettings, isMinimumOrderEnabled: !localSettings.isMinimumOrderEnabled})}
                      className={`relative inline-flex h-8 w-16 items-center rounded-full transition-colors ${localSettings.isMinimumOrderEnabled ? 'bg-[var(--color-neon-green)]' : 'bg-gray-600'}`}
                    >
                      <span
                        className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${localSettings.isMinimumOrderEnabled ? 'translate-x-9' : 'translate-x-1'}`}
                      />
                    </button>
                  </div>
                  {localSettings.isMinimumOrderEnabled && (
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Minimum Items Required</label>
                      <input 
                        type="number" 
                        min="1"
                        value={localSettings.minimumOrderQuantity} 
                        onChange={e => setLocalSettings({...localSettings, minimumOrderQuantity: parseInt(e.target.value) || 1})} 
                        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Branding Settings */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-xl">
                <h4 className="text-xl font-bold mb-4 text-[var(--color-neon-green)]">Branding & Text</h4>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Logo Main Name</label>
                      <input type="text" value={localSettings.logoName} onChange={e => setLocalSettings({...localSettings, logoName: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. Gup Chup" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Logo Sub Name</label>
                      <input type="text" value={localSettings.logoSubName} onChange={e => setLocalSettings({...localSettings, logoSubName: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. Food Stool" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Logo Image URL (Optional)</label>
                    <input type="text" value={localSettings.logoImageUrl || ''} onChange={e => setLocalSettings({...localSettings, logoImageUrl: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="https://example.com/logo.png" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Hero Section Title</label>
                    <input type="text" value={localSettings.heroTitle} onChange={e => setLocalSettings({...localSettings, heroTitle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. I LOVE CHHOTO MOHODIPUR GRAM BASI" />
                  </div>
                  
                  {/* Hero Title Customization Controls */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 p-6 bg-black/40 rounded-xl border border-white/5">
                    <div className="col-span-full">
                      <h5 className="text-[10px] font-black uppercase tracking-[0.3em] text-[var(--color-neon-green)] mb-1">Advanced Layout</h5>
                      <p className="text-[14px] font-bold text-white uppercase tracking-tight">Hero Title Adjustment</p>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Font Size</label>
                        <span className="text-[10px] font-black text-[var(--color-neon-green)]">{localSettings.heroTitleFontSize || 100}%</span>
                      </div>
                      <input 
                        type="range" 
                        min="50" max="250" 
                        value={localSettings.heroTitleFontSize || 100} 
                        onChange={e => setLocalSettings({...localSettings, heroTitleFontSize: parseInt(e.target.value)})} 
                        className="w-full accent-[var(--color-neon-green)]" 
                      />
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Letter Spacing</label>
                        <span className="text-[10px] font-black text-[var(--color-neon-green)]">{localSettings.heroTitleLetterSpacing ?? -0.05}em</span>
                      </div>
                      <input 
                        type="range" 
                        min="-0.2" max="0.5" step="0.01" 
                        value={localSettings.heroTitleLetterSpacing ?? -0.05} 
                        onChange={e => setLocalSettings({...localSettings, heroTitleLetterSpacing: parseFloat(e.target.value)})} 
                        className="w-full accent-[var(--color-neon-green)]" 
                      />
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Title Y-Offset (Vertical)</label>
                        <span className="text-[10px] font-black text-[var(--color-neon-green)]">{localSettings.heroTitleYOffset || 0}px</span>
                      </div>
                      <input 
                        type="range" 
                        min="-200" max="200" 
                        value={localSettings.heroTitleYOffset || 0} 
                        onChange={e => setLocalSettings({...localSettings, heroTitleYOffset: parseInt(e.target.value)})} 
                        className="w-full accent-[var(--color-neon-green)]" 
                      />
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Lines Y-Offset (Vertical)</label>
                        <span className="text-[10px] font-black text-[var(--color-neon-green)]">{localSettings.heroLinesYOffset || 0}px</span>
                      </div>
                      <input 
                        type="range" 
                        min="-200" max="200" 
                        value={localSettings.heroLinesYOffset || 0} 
                        onChange={e => setLocalSettings({...localSettings, heroLinesYOffset: parseInt(e.target.value)})} 
                        className="w-full accent-[var(--color-neon-green)]" 
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Footer Brand Name</label>
                    <input type="text" value={localSettings.footerName} onChange={e => setLocalSettings({...localSettings, footerName: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. Food Cart Pro" />
                  </div>

                  {/* AI Assistant Social Media Promotion */}
                  <div className="bg-[#111] border border-[#333] p-6 rounded-xl mt-6">
                    <h4 className="text-xl font-bold mb-4 text-[var(--color-neon-green)]">AI Assistant Social Media Promotion</h4>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-white font-bold">Enable Social Media Promotion</p>
                          <p className="text-gray-400 text-sm">Nova AI will suggest customers visit your social media platforms.</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => setLocalSettings({...localSettings, isSocialMediaPromotionEnabled: !localSettings.isSocialMediaPromotionEnabled})}
                          className={`relative inline-flex h-8 w-16 items-center rounded-full transition-colors ${localSettings.isSocialMediaPromotionEnabled ? 'bg-[var(--color-neon-green)]' : 'bg-gray-600'}`}
                        >
                          <span
                            className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${localSettings.isSocialMediaPromotionEnabled ? 'translate-x-9' : 'translate-x-1'}`}
                          />
                        </button>
                      </div>
                      {localSettings.isSocialMediaPromotionEnabled && (
                        <div>
                          <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Promotion Message</label>
                          <textarea 
                            value={localSettings.socialMediaPromotionMessage} 
                            onChange={e => setLocalSettings({...localSettings, socialMediaPromotionMessage: e.target.value})} 
                            className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                            rows={3}
                            placeholder="e.g. Don't forget to follow us on Instagram, Facebook, YouTube, Twitter, and WhatsApp for the latest updates!"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Social Media Links */}
                  <div className="bg-[#111] border border-[#333] rounded-xl p-6 space-y-4">
                    <h4 className="text-sm font-black text-white uppercase tracking-widest flex items-center gap-2 mb-4">
                      <Instagram size={16} className="text-[var(--color-neon-green)]" />
                      Social Media Links
                    </h4>
                    
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Instagram URL</label>
                      <input type="url" value={localSettings.socialLinks?.instagram || ''} onChange={e => setLocalSettings({...localSettings, socialLinks: {...localSettings.socialLinks, instagram: e.target.value}})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="https://instagram.com/..." />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Facebook URL</label>
                      <input type="url" value={localSettings.socialLinks?.facebook || ''} onChange={e => setLocalSettings({...localSettings, socialLinks: {...localSettings.socialLinks, facebook: e.target.value}})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="https://facebook.com/..." />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">YouTube URL</label>
                      <input type="url" value={localSettings.socialLinks?.youtube || ''} onChange={e => setLocalSettings({...localSettings, socialLinks: {...localSettings.socialLinks, youtube: e.target.value}})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="https://youtube.com/..." />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Twitter / X URL</label>
                      <input type="url" value={localSettings.socialLinks?.twitter || ''} onChange={e => setLocalSettings({...localSettings, socialLinks: {...localSettings.socialLinks, twitter: e.target.value}})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="https://twitter.com/..." />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">WhatsApp URL</label>
                      <input type="url" value={localSettings.socialLinks?.whatsapp || ''} onChange={e => setLocalSettings({...localSettings, socialLinks: {...localSettings.socialLinks, whatsapp: e.target.value}})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="https://wa.me/..." />
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isBrandingVideoEnabled" checked={localSettings.isBrandingVideoEnabled} onChange={e => setLocalSettings({...localSettings, isBrandingVideoEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isBrandingVideoEnabled" className="text-sm font-bold text-white">Enable Branding Video</label>
                  </div>
                  {localSettings.isBrandingVideoEnabled && (
                    <MediaUploadInput 
                      label="Branding Media URL" 
                      value={localSettings.brandingVideoUrl || ''} 
                      onChange={val => setLocalSettings({...localSettings, brandingVideoUrl: val})} 
                    />
                  )}
                </div>
              </div>

              {/* Section Visibility Settings */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-xl">
                <h4 className="text-xl font-bold mb-4 text-[var(--color-neon-green)]">Section Visibility</h4>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isOffersEnabled" checked={localSettings.isOffersEnabled} onChange={e => setLocalSettings({...localSettings, isOffersEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isOffersEnabled" className="text-sm font-bold text-white">Enable Daily Offers Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isMenuEnabled" checked={localSettings.isMenuEnabled} onChange={e => setLocalSettings({...localSettings, isMenuEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isMenuEnabled" className="text-sm font-bold text-white">Enable Menu Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isInfluencerSectionEnabled" checked={localSettings.isInfluencerSectionEnabled} onChange={e => setLocalSettings({...localSettings, isInfluencerSectionEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isInfluencerSectionEnabled" className="text-sm font-bold text-white">Enable Influencer Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isReelsEnabled" checked={localSettings.isReelsEnabled} onChange={e => setLocalSettings({...localSettings, isReelsEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isReelsEnabled" className="text-sm font-bold text-white">Enable Daily Reels Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isSponsoredEnabled" checked={localSettings.isSponsoredEnabled} onChange={e => setLocalSettings({...localSettings, isSponsoredEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isSponsoredEnabled" className="text-sm font-bold text-white">Enable Sponsored Videos Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isCollaborationsEnabled" checked={localSettings.isCollaborationsEnabled} onChange={e => setLocalSettings({...localSettings, isCollaborationsEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isCollaborationsEnabled" className="text-sm font-bold text-white">Enable Collaborations Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isEventsSectionEnabled" checked={localSettings.isEventsSectionEnabled} onChange={e => setLocalSettings({...localSettings, isEventsSectionEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isEventsSectionEnabled" className="text-sm font-bold text-white">Enable Event Booking Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isEventsEnabled" checked={localSettings.isEventsEnabled} onChange={e => setLocalSettings({...localSettings, isEventsEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isEventsEnabled" className="text-sm font-bold text-white">Enable Special Events Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isCompetitionSectionEnabled" checked={localSettings.isCompetitionSectionEnabled} onChange={e => setLocalSettings({...localSettings, isCompetitionSectionEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isCompetitionSectionEnabled" className="text-sm font-bold text-white">Enable Competition Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isMomentsEnabled" checked={localSettings.isMomentsEnabled} onChange={e => setLocalSettings({...localSettings, isMomentsEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isMomentsEnabled" className="text-sm font-bold text-white">Enable Moments & Celebrations Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isNotificationSectionEnabled" checked={localSettings.isNotificationSectionEnabled} onChange={e => setLocalSettings({...localSettings, isNotificationSectionEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isNotificationSectionEnabled" className="text-sm font-bold text-white">Enable Notification Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isBannerEnabled" checked={localSettings.isBannerEnabled} onChange={e => setLocalSettings({...localSettings, isBannerEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isBannerEnabled" className="text-sm font-bold text-white">Enable Banner Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isStoriesEnabled" checked={localSettings.isStoriesEnabled} onChange={e => setLocalSettings({...localSettings, isStoriesEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isStoriesEnabled" className="text-sm font-bold text-white">Enable Partner Stories Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isFoundersEnabled" checked={localSettings.isFoundersEnabled} onChange={e => setLocalSettings({...localSettings, isFoundersEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isFoundersEnabled" className="text-sm font-bold text-white">Enable Founders & Partners Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isRiderListEnabled" checked={localSettings.isRiderListEnabled ?? true} onChange={e => setLocalSettings({...localSettings, isRiderListEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isRiderListEnabled" className="text-sm font-bold text-white">Enable Rider List Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isChickenStoreEnabled" checked={localSettings.isChickenStoreEnabled} onChange={e => setLocalSettings({...localSettings, isChickenStoreEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isChickenStoreEnabled" className="text-sm font-bold text-white">Enable Chicken Store Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isPanEnabled" checked={localSettings.isPanEnabled} onChange={e => setLocalSettings({...localSettings, isPanEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isPanEnabled" className="text-sm font-bold text-white">Enable Special Assam Pan Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isStaffEnabled" checked={localSettings.isStaffEnabled ?? true} onChange={e => setLocalSettings({...localSettings, isStaffEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isStaffEnabled" className="text-sm font-bold text-white">Enable Staff Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isDecorationEnabled" checked={localSettings.isDecorationEnabled ?? true} onChange={e => setLocalSettings({...localSettings, isDecorationEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isDecorationEnabled" className="text-sm font-bold text-white">Enable Decoration Services</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isDjSoundEnabled" checked={localSettings.isDjSoundEnabled ?? true} onChange={e => setLocalSettings({...localSettings, isDjSoundEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isDjSoundEnabled" className="text-sm font-bold text-white">Enable DJ Sound Services</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isReviewsEnabled" checked={localSettings.isReviewsEnabled ?? true} onChange={e => setLocalSettings({...localSettings, isReviewsEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isReviewsEnabled" className="text-sm font-bold text-white">Enable Reviews Section</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isDeliveryFeeEnabled" checked={localSettings.isDeliveryFeeEnabled ?? true} onChange={e => setLocalSettings({...localSettings, isDeliveryFeeEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isDeliveryFeeEnabled" className="text-sm font-bold text-white">Enable Delivery Fee System</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isDeliveryRestrictionEnabled" checked={localSettings.isDeliveryRestrictionEnabled ?? false} onChange={e => setLocalSettings({...localSettings, isDeliveryRestrictionEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isDeliveryRestrictionEnabled" className="text-sm font-bold text-white">Enable Delivery Restrictions (Distance/Zone)</label>
                  </div>
                </div>
              </div>

              {/* Share Button Settings */}
              <div className="bg-[#111] p-6 rounded-xl border border-[#333]">
                <h4 className="text-xl font-bold mb-4 text-[var(--color-neon-green)]">Share Button Settings</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isMenuShareEnabled" checked={localSettings.isMenuShareEnabled} onChange={e => setLocalSettings({...localSettings, isMenuShareEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isMenuShareEnabled" className="text-sm font-bold text-white">Menu Item Share</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isEventsShareEnabled" checked={localSettings.isEventsShareEnabled} onChange={e => setLocalSettings({...localSettings, isEventsShareEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isEventsShareEnabled" className="text-sm font-bold text-white">Events Share</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isOffersShareEnabled" checked={localSettings.isOffersShareEnabled} onChange={e => setLocalSettings({...localSettings, isOffersShareEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isOffersShareEnabled" className="text-sm font-bold text-white">Offers Share</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isMomentsShareEnabled" checked={localSettings.isMomentsShareEnabled} onChange={e => setLocalSettings({...localSettings, isMomentsShareEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isMomentsShareEnabled" className="text-sm font-bold text-white">Moments Share</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isBannersShareEnabled" checked={localSettings.isBannersShareEnabled} onChange={e => setLocalSettings({...localSettings, isBannersShareEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isBannersShareEnabled" className="text-sm font-bold text-white">Banners Share</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isInfluencersShareEnabled" checked={localSettings.isInfluencersShareEnabled} onChange={e => setLocalSettings({...localSettings, isInfluencersShareEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isInfluencersShareEnabled" className="text-sm font-bold text-white">Influencers Share</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isStaffShareEnabled" checked={localSettings.isStaffShareEnabled} onChange={e => setLocalSettings({...localSettings, isStaffShareEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isStaffShareEnabled" className="text-sm font-bold text-white">Staff Share</label>
                  </div>
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isFoodPageShareEnabled" checked={localSettings.isFoodPageShareEnabled} onChange={e => setLocalSettings({...localSettings, isFoodPageShareEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isFoodPageShareEnabled" className="text-sm font-bold text-white">Food Page Share</label>
                  </div>
                </div>
              </div>

              <div className="bg-[#111] p-6 rounded-xl border border-[#333]">
                <h4 className="text-xl font-bold mb-4 text-[var(--color-neon-green)]">Animation Settings</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="isAnimationsEnabled" checked={localSettings.isAnimationsEnabled ?? true} onChange={e => setLocalSettings({...localSettings, isAnimationsEnabled: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                    <label htmlFor="isAnimationsEnabled" className="text-sm font-bold text-white">Enable UI Animations & Motion Effects</label>
                  </div>
                  {(localSettings.isAnimationsEnabled ?? true) && (
                    <div className="mt-4">
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Animation Style</label>
                      <select 
                        value={localSettings.animationStyle || 'bouncy'} 
                        onChange={e => setLocalSettings({...localSettings, animationStyle: e.target.value as any})}
                        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                      >
                        <option value="subtle">Subtle & Smooth</option>
                        <option value="bouncy">Bouncy & Energetic</option>
                        <option value="energetic">Fast & Aggressive</option>
                      </select>
                    </div>
                  )}
                </div>
              </div>

              {/* Text Effects Settings */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-xl">
                <h4 className="text-xl font-bold mb-4 text-[var(--color-neon-green)]">Text Effects</h4>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <input 
                      type="checkbox" 
                      id="enableRgb"
                      checked={localSettings.enableRgbEffect ?? true} 
                      onChange={e => setLocalSettings({...localSettings, enableRgbEffect: e.target.checked})}
                      className="w-5 h-5 accent-[var(--color-neon-green)]"
                    />
                    <label htmlFor="enableRgb" className="text-sm font-bold text-white">Enable RGB Color Animation on Hero Title</label>
                  </div>
                  {(localSettings.enableRgbEffect ?? true) && (
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
                        Animation Speed: {localSettings.rgbAnimationSpeed ?? 3} seconds
                      </label>
                      <input 
                        type="range" 
                        min="1" max="10" step="0.5" 
                        value={localSettings.rgbAnimationSpeed ?? 3} 
                        onChange={e => setLocalSettings({...localSettings, rgbAnimationSpeed: parseFloat(e.target.value)})} 
                        className="w-full accent-[var(--color-neon-green)]" 
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Theme Colors */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-xl">
                <h4 className="text-xl font-bold mb-4 text-[var(--color-neon-green)]">Theme Settings</h4>
                <div className="space-y-6">
                  <div className="flex items-center gap-3">
                    <input 
                      type="checkbox" 
                      id="themeMode"
                      checked={localSettings.theme === 'light'} 
                      onChange={e => setLocalSettings({...localSettings, theme: e.target.checked ? 'light' : 'dark'})}
                      className="w-5 h-5 accent-[var(--color-neon-green)]"
                    />
                    <label htmlFor="themeMode" className="text-sm font-bold text-white">Enable Light Mode</label>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Neon Green</label>
                      <input type="color" value={localSettings.neonGreen} onChange={e => setLocalSettings({...localSettings, neonGreen: e.target.value})} className="w-full h-10 bg-[#1a1a1a] border border-[#333] rounded-lg cursor-pointer" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Neon Red</label>
                      <input type="color" value={localSettings.neonRed} onChange={e => setLocalSettings({...localSettings, neonRed: e.target.value})} className="w-full h-10 bg-[#1a1a1a] border border-[#333] rounded-lg cursor-pointer" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Category Management */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-xl">
                <h4 className="text-xl font-bold mb-4 text-[var(--color-neon-green)]">Menu Categories</h4>
                <div className="space-y-4">
                  <div className="flex flex-wrap gap-2">
                    {localSettings.categories?.map((cat, index) => (
                      <div key={`category-${cat}-${index}`} className="flex items-center gap-2 bg-[#1a1a1a] border border-[#333] px-3 py-1 rounded-full group">
                        <span className="text-sm text-white">{cat}</span>
                        <button 
                          type="button"
                          onClick={() => {
                            const newCats = localSettings.categories.filter((_, i) => i !== index);
                            setLocalSettings({...localSettings, categories: newCats});
                          }}
                          className="text-gray-500 hover:text-red-500 transition-colors"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      id="new-category-input"
                      placeholder="New category name..." 
                      className="flex-1 bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          const input = e.currentTarget;
                          const val = input.value.trim();
                          if (val && !localSettings.categories.includes(val)) {
                            setLocalSettings({
                              ...localSettings,
                              categories: [...localSettings.categories, val]
                            });
                            input.value = '';
                          }
                        }
                      }}
                    />
                    <button 
                      type="button"
                      onClick={() => {
                        const input = document.getElementById('new-category-input') as HTMLInputElement;
                        const val = input?.value.trim();
                        if (val && !localSettings.categories.includes(val)) {
                          setLocalSettings({
                            ...localSettings,
                            categories: [...localSettings.categories, val]
                          });
                          input.value = '';
                        }
                      }}
                      className="bg-white/5 hover:bg-white/10 text-white px-4 py-2 rounded-lg transition-colors font-bold"
                    >
                      Add
                    </button>
                  </div>
                  <p className="text-[10px] text-gray-500 italic">Press Enter or click Add to save a new category. These will appear in the Menu Item modal and on the website filters.</p>
                </div>
              </div>

              {/* Audio Settings */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-xl">
                <h4 className="text-xl font-bold mb-4 text-[var(--color-neon-green)]">Background Music</h4>
                <div className="space-y-4">
                  <div>
                    <MediaUploadInput 
                      label="Audio URL (MP3)" 
                      value={localSettings.bgMusicUrl} 
                      onChange={val => {
                        setLocalSettings({
                          ...localSettings, 
                          bgMusicUrl: val,
                        });
                      }} 
                      accept="audio/*"
                      buttonText="Upload Audio"
                      note="Max 1MB for direct upload"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Volume: {Math.round(localSettings.bgMusicVolume * 100)}%</label>
                    <input 
                      type="range" 
                      min="0" max="1" step="0.01" 
                      value={localSettings.bgMusicVolume} 
                      onChange={e => setLocalSettings({...localSettings, bgMusicVolume: parseFloat(e.target.value)})} 
                      className="w-full accent-[var(--color-neon-green)]" 
                    />
                  </div>
                </div>
              </div>

              {/* Video Settings */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-xl">
                <h4 className="text-xl font-bold mb-4 text-[var(--color-neon-green)]">Section Background Videos (MP4)</h4>
                <div className="space-y-4">
                  <div>
                    <MediaUploadInput 
                      label="Global UI Background Video (MP4/URL)" 
                      value={localSettings.globalBackgroundVideoUrl} 
                      onChange={val => {
                        setLocalSettings({
                          ...localSettings, 
                          globalBackgroundVideoUrl: val,
                        });
                      }} 
                    />
                    <p className="text-[10px] text-gray-500 mt-2">This video will play in the background of the entire website.</p>
                  </div>
                  <MediaUploadInput 
                    label="Hero Section" 
                    value={localSettings.heroVideoUrl || ''} 
                    onChange={val => setLocalSettings({...localSettings, heroVideoUrl: val})} 
                  />
                  <MediaUploadInput 
                    label="Daily Offers Section" 
                    value={localSettings.offersVideoUrl || ''} 
                    onChange={val => setLocalSettings({...localSettings, offersVideoUrl: val})} 
                  />
                  <MediaUploadInput 
                    label="Menu Section" 
                    value={localSettings.menuVideoUrl || ''} 
                    onChange={val => setLocalSettings({...localSettings, menuVideoUrl: val})} 
                  />
                  <MediaUploadInput 
                    label="Events Section" 
                    value={localSettings.eventsVideoUrl || ''} 
                    onChange={val => setLocalSettings({...localSettings, eventsVideoUrl: val})} 
                  />
                  <MediaUploadInput 
                    label="Sponsored Section" 
                    value={localSettings.sponsoredVideoUrl || ''} 
                    onChange={val => setLocalSettings({...localSettings, sponsoredVideoUrl: val})} 
                  />
                  <MediaUploadInput 
                    label="Footer Section" 
                    value={localSettings.footerVideoUrl || ''} 
                    onChange={val => setLocalSettings({...localSettings, footerVideoUrl: val})} 
                  />
                </div>
              </div>

              {/* Payment Settings */}
              <div className="bg-[#111] p-6 rounded-2xl border border-[#222] space-y-6">
                <h4 className="text-xl font-bold mb-4 text-[var(--color-neon-green)]">Payment & Tracking Settings</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">UPI ID</label>
                    <input type="text" value={localSettings.paymentSettings?.upiId || ''} onChange={e => setLocalSettings({...localSettings, paymentSettings: {...localSettings.paymentSettings, upiId: e.target.value}})} placeholder="e.g. example@upi" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" />
                  </div>
                  <MediaUploadInput label="QR Code URL" value={localSettings.paymentSettings?.qrCodeUrl || ''} onChange={val => setLocalSettings({...localSettings, paymentSettings: {...localSettings.paymentSettings, qrCodeUrl: val}})} />
                  <div className="flex items-center gap-4">
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Enable Order Tracking</label>
                    <input 
                      type="checkbox" 
                      checked={localSettings.enableOrderTracking || false} 
                      onChange={e => setLocalSettings({...localSettings, enableOrderTracking: e.target.checked})} 
                      className="w-5 h-5 accent-[var(--color-neon-green)]"
                    />
                  </div>
                  <div className="flex items-center gap-4">
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Enable Default Delivery Time</label>
                    <input 
                      type="checkbox" 
                      checked={localSettings.enableDefaultDeliveryTime || false} 
                      onChange={e => setLocalSettings({...localSettings, enableDefaultDeliveryTime: e.target.checked})} 
                      className="w-5 h-5 accent-[var(--color-neon-green)]"
                    />
                  </div>
                  {localSettings.enableDefaultDeliveryTime && (
                    <div className="md:col-span-2">
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Default Delivery Time</label>
                      <input type="text" value={localSettings.defaultDeliveryTime || ''} onChange={e => setLocalSettings({...localSettings, defaultDeliveryTime: e.target.value})} placeholder="e.g. 30-45 mins" className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" />
                    </div>
                  )}
                </div>
              </div>

              {/* Opening Hours & Contact Settings */}
              <div className="bg-[#111] border border-[#333] p-6 rounded-xl">
                <h4 className="text-xl font-bold mb-4 text-[var(--color-neon-green)]">Opening Hours & Contact</h4>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map((day) => (
                      <div key={day}>
                        <label className="block text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">{day}</label>
                        <input 
                          type="text" 
                          value={localSettings.openingHours[day] || ''} 
                          onChange={e => setLocalSettings({
                            ...localSettings, 
                            openingHours: { ...localSettings.openingHours, [day]: e.target.value }
                          })} 
                          className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none transition-all" 
                          placeholder="e.g. 4:00 PM - 10:00 PM or CLOSED" 
                        />
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">Owner Mobile</label>
                      <input 
                        type="text" 
                        value={localSettings.contactNumbers?.owner} 
                        onChange={e => setLocalSettings({
                          ...localSettings, 
                          contactNumbers: { ...localSettings.contactNumbers, owner: e.target.value }
                        })} 
                        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">Partner Mobile</label>
                      <input 
                        type="text" 
                        value={localSettings.contactNumbers?.partner} 
                        onChange={e => setLocalSettings({
                          ...localSettings, 
                          contactNumbers: { ...localSettings.contactNumbers, partner: e.target.value }
                        })} 
                        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">WhatsApp Number for Orders (with country code, e.g. 919735339454)</label>
                    <input 
                      type="text" 
                      value={localSettings.orderWhatsAppNumber} 
                      onChange={e => setLocalSettings({...localSettings, orderWhatsAppNumber: e.target.value})} 
                      className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">Address</label>
                    <textarea 
                      value={localSettings.address} 
                      onChange={e => setLocalSettings({...localSettings, address: e.target.value})} 
                      className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none h-20" 
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">Google Maps Link</label>
                    <input 
                      type="url" 
                      value={localSettings.locationLink} 
                      onChange={e => setLocalSettings({...localSettings, locationLink: e.target.value})} 
                      className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                    />
                  </div>
                </div>
              </div>

              {/* Founders / Owners Settings */}
              <div className="bg-[#111] border border-[#333] rounded-xl overflow-hidden mt-6">
                <div className="bg-[#1a1a1a] px-6 py-4 border-b border-[#333] flex items-center justify-between">
                  <h3 className="text-lg font-black text-white uppercase tracking-wider flex items-center gap-3">
                    <Users className="w-5 h-5 text-[var(--color-neon-green)]" />
                    Founders & Partners
                  </h3>
                </div>
                <div className="p-6 space-y-8">
                  {/* Layout Customization */}
                  <div className="space-y-4 border border-[#333] p-4 rounded-lg bg-[#0a0a0a]">
                    <h4 className="text-sm font-bold text-[var(--color-neon-green)] uppercase tracking-wider">Layout Customization</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Image Size (%)</label>
                        <input 
                          type="number" 
                          value={localSettings.founderImageSize || 100} 
                          onChange={e => setLocalSettings({...localSettings, founderImageSize: parseInt(e.target.value) || 100})} 
                          className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Spacing (px)</label>
                        <input 
                          type="number" 
                          value={localSettings.founderSpacing || 100} 
                          onChange={e => setLocalSettings({...localSettings, founderSpacing: parseInt(e.target.value) || 100})} 
                          className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Vertical Offset (px)</label>
                        <input 
                          type="number" 
                          value={localSettings.founderYOffset || 0} 
                          onChange={e => setLocalSettings({...localSettings, founderYOffset: parseInt(e.target.value) || 0})} 
                          className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Horizontal Offset (px)</label>
                        <input 
                          type="number" 
                          value={localSettings.founderXOffset || 0} 
                          onChange={e => setLocalSettings({...localSettings, founderXOffset: parseInt(e.target.value) || 0})} 
                          className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                        />
                      </div>
                    </div>
                  </div>

                  {/* Founder 1 */}
                  <div className="space-y-4 border border-[#333] p-4 rounded-lg bg-[#0a0a0a]">
                    <h4 className="text-sm font-bold text-[var(--color-neon-green)] uppercase tracking-wider">Founder 1 (Left)</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Name</label>
                        <input 
                          type="text" 
                          value={localSettings.founder1Name || ''} 
                          onChange={e => setLocalSettings({...localSettings, founder1Name: e.target.value})} 
                          className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Role</label>
                        <input 
                          type="text" 
                          value={localSettings.founder1Role || ''} 
                          onChange={e => setLocalSettings({...localSettings, founder1Role: e.target.value})} 
                          className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Image URL</label>
                      <input 
                        type="text" 
                        value={localSettings.founder1Image || ''} 
                        onChange={e => setLocalSettings({...localSettings, founder1Image: e.target.value})} 
                        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                        placeholder="https://example.com/image.jpg"
                      />
                    </div>
                    <div>
                      <MediaUploadInput 
                        label="Story Video URL (Optional)" 
                        value={localSettings.founder1Video || ''} 
                        onChange={val => {
                          setLocalSettings({
                            ...localSettings, 
                            founder1Video: val,
                          });
                        }} 
                      />
                      <p className="text-[10px] text-gray-500 mt-1">If provided, clicking their image will play this video like a story.</p>
                    </div>
                  </div>

                  {/* Founder 2 */}
                  <div className="space-y-4 border border-[#333] p-4 rounded-lg bg-[#0a0a0a]">
                    <h4 className="text-sm font-bold text-[var(--color-neon-red)] uppercase tracking-wider">Founder 2 (Right)</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Name</label>
                        <input 
                          type="text" 
                          value={localSettings.founder2Name || ''} 
                          onChange={e => setLocalSettings({...localSettings, founder2Name: e.target.value})} 
                          className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Role</label>
                        <input 
                          type="text" 
                          value={localSettings.founder2Role || ''} 
                          onChange={e => setLocalSettings({...localSettings, founder2Role: e.target.value})} 
                          className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Image URL</label>
                      <input 
                        type="text" 
                        value={localSettings.founder2Image || ''} 
                        onChange={e => setLocalSettings({...localSettings, founder2Image: e.target.value})} 
                        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                        placeholder="https://example.com/image.jpg"
                      />
                    </div>
                    <div>
                      <MediaUploadInput 
                        label="Story Video URL (Optional)" 
                        value={localSettings.founder2Video || ''} 
                        onChange={val => {
                          setLocalSettings({
                            ...localSettings, 
                            founder2Video: val,
                          });
                        }} 
                      />
                      <p className="text-[10px] text-gray-500 mt-1">If provided, clicking their image will play this video like a story.</p>
                    </div>
                  </div>
                </div>
              </div>

              <button type="submit" className="w-full bg-[var(--color-neon-green)] text-black font-bold px-6 py-4 rounded-xl hover:bg-[#00cc00] transition-colors text-lg shadow-[0_0_15px_rgba(0,255,0,0.3)]">
                Save All Settings
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Menu Item Modal */}
      {isMenuModalOpen && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-[#111] border border-[#333] rounded-2xl w-full max-w-md overflow-hidden">
            <div className="p-6 border-b border-[#333] flex justify-between items-center">
              <h3 className="text-xl font-bold">{editingItem ? 'Edit Menu Item' : 'Add Menu Item'}</h3>
              <button onClick={() => setIsMenuModalOpen(false)} className="text-gray-400 hover:text-white">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSaveMenuItem} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">Name</label>
                <input required type="text" value={menuForm.name} onChange={e => setMenuForm({...menuForm, name: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. Samosa" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">Price (₹)</label>
                  <input required type="number" value={menuForm.price} onChange={e => setMenuForm({...menuForm, price: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. 20" />
                </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">Category</label>
                    <select value={menuForm.category} onChange={e => setMenuForm({...menuForm, category: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none">
                      {localSettings.categories?.map((cat, index) => (
                        <option key={`category-option-${cat}-${index}`} value={cat}>{cat}</option>
                      ))}
                      <option value="Other">Other</option>
                    </select>
                  </div>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">Shayari / Description</label>
                <textarea value={menuForm.shayari} onChange={e => setMenuForm({...menuForm, shayari: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none min-h-[80px]" placeholder="Add a catchy shayari..." />
              </div>
              <div className="space-y-4">
                <MediaUploadInput 
                  label="Image URL (Required)" 
                  value={menuForm.imageUrl} 
                  onChange={val => setMenuForm({...menuForm, imageUrl: val})} 
                  accept="image/*"
                  buttonText="Upload Image"
                />
                
                <div className="p-4 bg-[#1a1a1a] rounded-xl border border-[#333]">
                  <div className="flex items-center gap-3 mb-4">
                    <input 
                      type="checkbox" 
                      id="videoEnabled"
                      checked={menuForm.isVideoEnabled} 
                      onChange={e => setMenuForm({...menuForm, isVideoEnabled: e.target.checked})}
                      className="w-5 h-5 accent-[var(--color-neon-green)]"
                    />
                    <label htmlFor="videoEnabled" className="text-sm font-bold text-white">Enable Video for this item</label>
                  </div>
                  
                  {menuForm.isVideoEnabled && (
                    <MediaUploadInput 
                      label="Video URL (MP4)" 
                      value={menuForm.videoUrl} 
                      onChange={val => setMenuForm({...menuForm, videoUrl: val})} 
                      accept="video/mp4"
                      buttonText="Upload Video"
                    />
                  )}
                </div>
              </div>
              
              <div className="flex items-center gap-3 pt-2">
                <input 
                  type="checkbox" 
                  id="isCustomizable"
                  checked={menuForm.isCustomizable} 
                  onChange={e => setMenuForm({...menuForm, isCustomizable: e.target.checked})}
                  className="w-5 h-5 accent-[var(--color-neon-green)]"
                />
                <label htmlFor="isCustomizable" className="text-sm font-bold text-white">Enable Customization</label>
              </div>

              {menuForm.isCustomizable && (
                <div className="space-y-4 p-4 bg-[#1a1a1a] rounded-xl border border-[#333]">
                  <div>
                    <label className="block text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">Available Toppings (Comma separated)</label>
                    <input 
                      type="text" 
                      value={menuForm.availableToppings} 
                      onChange={e => setMenuForm({...menuForm, availableToppings: e.target.value})} 
                      className="w-full bg-[#0a0a0a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                      placeholder="e.g. Cheese, Onion, Paneer" 
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">Spice Levels (Comma separated)</label>
                    <input 
                      type="text" 
                      value={menuForm.availableSpiceLevels} 
                      onChange={e => setMenuForm({...menuForm, availableSpiceLevels: e.target.value})} 
                      className="w-full bg-[#0a0a0a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                      placeholder="e.g. Mild, Medium, Hot" 
                    />
                  </div>
                </div>
              )}
              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => setIsMenuModalOpen(false)} className="flex-1 bg-[#222] text-white font-bold py-3 rounded-xl hover:bg-[#333] transition-colors">Cancel</button>
                <button type="submit" className="flex-1 bg-[var(--color-neon-green)] text-black font-bold py-3 rounded-xl hover:bg-[#00cc00] transition-colors">Save Item</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Offer Modal */}
      {isOfferModalOpen && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-[#111] border border-[#333] rounded-2xl w-full max-w-md overflow-hidden">
            <div className="p-6 border-b border-[#333] flex justify-between items-center">
              <h3 className="text-xl font-bold">{editingOffer ? 'Edit Offer' : 'Add Offer'}</h3>
              <div className="flex items-center gap-4">
                <button 
                  type="button" 
                  onClick={generateOfferWithAI} 
                  disabled={isGeneratingOffer}
                  className="flex items-center gap-2 text-xs bg-purple-500/20 text-purple-400 px-3 py-1.5 rounded-lg hover:bg-purple-500/30 transition-colors disabled:opacity-50"
                >
                  {isGeneratingOffer ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
                  Auto AI
                </button>
                <button onClick={() => setIsOfferModalOpen(false)} className="text-gray-400 hover:text-white">
                  <X size={24} />
                </button>
              </div>
            </div>
            <form onSubmit={handleSaveOffer} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Title</label>
                <input required type="text" value={offerForm.title} onChange={e => setOfferForm({...offerForm, title: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. Weekend Special Combo" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Description</label>
                <textarea required value={offerForm.description} onChange={e => setOfferForm({...offerForm, description: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none min-h-[80px]" placeholder="Details about the offer..." />
              </div>
              <div>
                <MediaUploadInput 
                  label="Image URL" 
                  value={offerForm.imageUrl} 
                  onChange={val => {
                    setOfferForm({
                      ...offerForm, 
                      imageUrl: val,
                    });
                  }} 
                />
              </div>
              <div>
                <MediaUploadInput 
                  label="Video URL (Optional)" 
                  value={offerForm.videoUrl} 
                  onChange={val => {
                    setOfferForm({
                      ...offerForm, 
                      videoUrl: val,
                    });
                  }} 
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Offer Price (₹)</label>
                  <input required type="number" value={offerForm.price} onChange={e => setOfferForm({...offerForm, price: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. 199" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Original Price (₹)</label>
                  <input type="number" value={offerForm.originalPrice} onChange={e => setOfferForm({...offerForm, originalPrice: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. 299" />
                </div>
              </div>
              <div className="flex items-center gap-3 pt-2">
                <input 
                  type="checkbox" 
                  id="offerActive"
                  checked={offerForm.active} 
                  onChange={e => setOfferForm({...offerForm, active: e.target.checked})}
                  className="w-5 h-5 accent-[var(--color-neon-green)]"
                />
                <label htmlFor="offerActive" className="text-sm font-bold text-white">Offer is Active</label>
              </div>
              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => setIsOfferModalOpen(false)} className="flex-1 bg-[#222] text-white font-bold py-3 rounded-xl hover:bg-[#333] transition-colors">Cancel</button>
                <button type="submit" className="flex-1 bg-[var(--color-neon-green)] text-black font-bold py-3 rounded-xl hover:bg-[#00cc00] transition-colors">Save Offer</button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Staff Modal */}
      {isStaffModalOpen && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#111] border border-[#333] rounded-2xl w-full max-w-md overflow-hidden my-8">
            <div className="p-6 border-b border-[#333] flex justify-between items-center bg-[#1a1a1a] sticky top-0 z-10">
              <h3 className="text-xl font-bold">{editingStaff ? 'Edit Staff' : 'Add Staff'}</h3>
              <button onClick={() => setIsStaffModalOpen(false)} className="text-gray-400 hover:text-white">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSaveStaff} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Name</label>
                <input required type="text" value={staffForm.name} onChange={e => setStaffForm({...staffForm, name: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. John Doe" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Mobile Number</label>
                  <input required type="tel" value={staffForm.mobile} onChange={e => setStaffForm({...staffForm, mobile: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. 9876543210" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Category</label>
                  <select value={staffForm.category} onChange={e => setStaffForm({...staffForm, category: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none">
                    <option value="Chef">Chef</option>
                    <option value="Waiter">Waiter</option>
                    <option value="Manager">Manager</option>
                    <option value="Delivery">Delivery</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Experience</label>
                <input type="text" value={staffForm.experience} onChange={e => setStaffForm({...staffForm, experience: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. 5 Years" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Address</label>
                <input type="text" value={staffForm.address} onChange={e => setStaffForm({...staffForm, address: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. 123 Main St, City" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Remark / Bio</label>
                <textarea value={staffForm.remark} onChange={e => setStaffForm({...staffForm, remark: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none min-h-[80px]" placeholder="Any special skills or notes..." />
              </div>
              <div>
                <MediaUploadInput 
                  label="Image URL" 
                  value={staffForm.imageUrl} 
                  onChange={val => {
                    setStaffForm({
                      ...staffForm, 
                      imageUrl: val,
                    });
                  }} 
                />
              </div>
              <div>
                <MediaUploadInput 
                  label="Story Video URL (Optional)" 
                  value={staffForm.videoUrl} 
                  onChange={val => {
                    setStaffForm({
                      ...staffForm, 
                      videoUrl: val,
                    });
                  }} 
                />
              </div>
              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => setIsStaffModalOpen(false)} className="flex-1 bg-[#222] text-white font-bold py-3 rounded-xl hover:bg-[#333] transition-colors">Cancel</button>
                <button type="submit" className="flex-1 bg-[var(--color-neon-green)] text-black font-bold py-3 rounded-xl hover:bg-[#00cc00] transition-colors">Save Staff</button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Reel Modal */}
      {isReelModalOpen && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-[#111] border border-[#333] rounded-2xl w-full max-w-md overflow-hidden">
            <div className="p-6 border-b border-[#333] flex justify-between items-center">
              <h3 className="text-xl font-bold">{editingReel ? 'Edit Reel' : 'Add Reel'}</h3>
              <button onClick={() => setIsReelModalOpen(false)} className="text-gray-400 hover:text-white">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSaveReel} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto custom-scrollbar">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Title</label>
                <input required type="text" value={reelForm.title} onChange={e => setReelForm({...reelForm, title: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. Making of Special Samosa" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Media Type</label>
                  <select value={reelForm.mediaType} onChange={e => setReelForm({...reelForm, mediaType: e.target.value as any})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none">
                    <option value="video">Video (.mp4)</option>
                    <option value="gif">GIF</option>
                    <option value="image">Image</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Social Link</label>
                  <input type="url" value={reelForm.socialLink} onChange={e => setReelForm({...reelForm, socialLink: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="Instagram/FB link" />
                </div>
              </div>
              <MediaUploadInput 
                label="Media URL" 
                value={reelForm.videoUrl} 
                onChange={val => {
                  setReelForm({
                    ...reelForm, 
                    videoUrl: val,
                  });
                }} 
              />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <MediaUploadInput 
                    label="Logo URL" 
                    value={reelForm.logoUrl} 
                    onChange={val => {
                      setReelForm({
                        ...reelForm, 
                        logoUrl: val,
                      });
                    }} 
                  />
                </div>
                <div>
                  <MediaUploadInput 
                    label="Music URL" 
                    value={reelForm.musicUrl} 
                    onChange={val => {
                      setReelForm({
                        ...reelForm, 
                        musicUrl: val,
                      });
                    }} 
                    accept="audio/*"
                    buttonText="Upload Audio"
                    note="Max 1MB for direct upload"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Quote / Caption</label>
                <textarea value={reelForm.quote} onChange={e => setReelForm({...reelForm, quote: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none min-h-[80px]" placeholder="Add a catchy quote..." />
              </div>
              <div className="flex items-center gap-3 pt-2">
                <input 
                  type="checkbox" 
                  id="reelActive"
                  checked={reelForm.active} 
                  onChange={e => setReelForm({...reelForm, active: e.target.checked})}
                  className="w-5 h-5 accent-[var(--color-neon-green)]"
                />
                <label htmlFor="reelActive" className="text-sm font-bold text-white">Reel is Active</label>
              </div>
              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => setIsReelModalOpen(false)} className="flex-1 bg-[#222] text-white font-bold py-3 rounded-xl hover:bg-[#333] transition-colors">Cancel</button>
                <button type="submit" className="flex-1 bg-[var(--color-neon-green)] text-black font-bold py-3 rounded-xl hover:bg-[#00cc00] transition-colors">Save Reel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Influencer Modal */}
      {isInfluencerModalOpen && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-[#111] border border-[#333] rounded-2xl w-full max-w-md overflow-hidden">
            <div className="p-6 border-b border-[#333] flex justify-between items-center">
              <h3 className="text-xl font-bold">{editingInfluencer ? 'Edit Influencer' : 'Add Influencer'}</h3>
              <button onClick={() => setIsInfluencerModalOpen(false)} className="text-gray-400 hover:text-white">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSaveInfluencer} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Name</label>
                  <input required type="text" value={influencerForm.name} onChange={e => setInfluencerForm({...influencerForm, name: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. Foodie Explorer" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Instagram Handle</label>
                  <input type="text" value={influencerForm.instagramHandle} onChange={e => setInfluencerForm({...influencerForm, instagramHandle: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. @foodie_explorer" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Media Type</label>
                  <select value={influencerForm.mediaType} onChange={e => setInfluencerForm({...influencerForm, mediaType: e.target.value as any})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none">
                    <option value="video">Video (.mp4)</option>
                    <option value="gif">GIF</option>
                    <option value="image">Image</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Social Link</label>
                  <input type="url" value={influencerForm.socialLink} onChange={e => setInfluencerForm({...influencerForm, socialLink: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="Social profile link" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Quote / Review</label>
                <textarea value={influencerForm.quote} onChange={e => setInfluencerForm({...influencerForm, quote: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none min-h-[80px]" placeholder="What they said about us..." />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <MediaUploadInput 
                    label="Profile Image URL" 
                    value={influencerForm.imageUrl} 
                    onChange={val => {
                      setInfluencerForm({
                        ...influencerForm, 
                        imageUrl: val,
                      });
                    }} 
                  />
                </div>
                <div>
                  <MediaUploadInput 
                    label="Logo URL" 
                    value={influencerForm.logoUrl} 
                    onChange={val => {
                      setInfluencerForm({
                        ...influencerForm, 
                        logoUrl: val,
                      });
                    }} 
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <MediaUploadInput 
                    label="Media URL (Video/GIF/Img)" 
                    value={influencerForm.videoUrl} 
                    onChange={val => {
                      setInfluencerForm({
                        ...influencerForm, 
                        videoUrl: val,
                      });
                    }} 
                  />
                </div>
                <div>
                  <MediaUploadInput 
                    label="Music URL" 
                    value={influencerForm.musicUrl} 
                    onChange={val => {
                      setInfluencerForm({
                        ...influencerForm, 
                        musicUrl: val,
                      });
                    }} 
                    accept="audio/*"
                    buttonText="Upload Audio"
                    note="Max 1MB for direct upload"
                  />
                </div>
              </div>
              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => setIsInfluencerModalOpen(false)} className="flex-1 bg-[#222] text-white font-bold py-3 rounded-xl hover:bg-[#333] transition-colors">Cancel</button>
                <button type="submit" className="flex-1 bg-[var(--color-neon-green)] text-black font-bold py-3 rounded-xl hover:bg-[#00cc00] transition-colors">Save Influencer</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Sponsored Video Modal */}
      {isSponsoredModalOpen && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-[#111] border border-[#333] rounded-2xl w-full max-w-md overflow-hidden">
            <div className="p-6 border-b border-[#333] flex justify-between items-center">
              <h3 className="text-xl font-bold">{editingSponsored ? 'Edit Sponsored Video' : 'Add Sponsored Video'}</h3>
              <button onClick={() => setIsSponsoredModalOpen(false)} className="text-gray-400 hover:text-white">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSaveSponsored} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Title</label>
                  <input required type="text" value={sponsoredForm.title} onChange={e => setSponsoredForm({...sponsoredForm, title: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. Summer Refreshers" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Sponsor Name</label>
                  <input type="text" value={sponsoredForm.sponsorName} onChange={e => setSponsoredForm({...sponsoredForm, sponsorName: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. Coca-Cola" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Media Type</label>
                  <select value={sponsoredForm.mediaType} onChange={e => setSponsoredForm({...sponsoredForm, mediaType: e.target.value as any})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none">
                    <option value="video">Video (.mp4)</option>
                    <option value="gif">GIF</option>
                    <option value="image">Image</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Social Link</label>
                  <input type="url" value={sponsoredForm.socialLink} onChange={e => setSponsoredForm({...sponsoredForm, socialLink: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="Sponsor link" />
                </div>
              </div>
              <MediaUploadInput 
                label="Media URL" 
                value={sponsoredForm.videoUrl} 
                onChange={val => {
                  setSponsoredForm({
                    ...sponsoredForm, 
                    videoUrl: val,
                  });
                }} 
              />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <MediaUploadInput 
                    label="Logo URL" 
                    value={sponsoredForm.logoUrl} 
                    onChange={val => {
                      setSponsoredForm({
                        ...sponsoredForm, 
                        logoUrl: val,
                      });
                    }} 
                  />
                </div>
                <div>
                  <MediaUploadInput 
                    label="Music URL" 
                    value={sponsoredForm.musicUrl} 
                    onChange={val => {
                      setSponsoredForm({
                        ...sponsoredForm, 
                        musicUrl: val,
                      });
                    }} 
                    accept="audio/*"
                    buttonText="Upload Audio"
                    note="Max 1MB for direct upload"
                  />
                </div>
              </div>
              <MediaUploadInput 
                label="Zip File URL (Optional)" 
                value={sponsoredForm.zipUrl} 
                onChange={val => setSponsoredForm({...sponsoredForm, zipUrl: val})} 
                accept="application/zip"
                buttonText="Upload Zip (.zip)"
              />
              <div className="flex items-center gap-3 pt-2">
                <input 
                  type="checkbox" 
                  id="sponsoredActive"
                  checked={sponsoredForm.active} 
                  onChange={e => setSponsoredForm({...sponsoredForm, active: e.target.checked})}
                  className="w-5 h-5 accent-[var(--color-neon-green)]"
                />
                <label htmlFor="sponsoredActive" className="text-sm font-bold text-white">Video is Active</label>
              </div>
              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => setIsSponsoredModalOpen(false)} className="flex-1 bg-[#222] text-white font-bold py-3 rounded-xl hover:bg-[#333] transition-colors">Cancel</button>
                <button type="submit" className="flex-1 bg-[var(--color-neon-green)] text-black font-bold py-3 rounded-xl hover:bg-[#00cc00] transition-colors">Save Video</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Collaboration Modal */}
      {isCollaborationModalOpen && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-[#111] border border-[#333] rounded-2xl w-full max-w-2xl overflow-hidden">
            <div className="p-6 border-b border-[#333] flex justify-between items-center">
              <h3 className="text-xl font-bold">{editingCollaboration ? 'Edit Collaboration' : 'Add Collaboration'}</h3>
              <button onClick={() => setIsCollaborationModalOpen(false)} className="text-gray-400 hover:text-white">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSaveCollaboration} className="p-6 space-y-4 max-h-[85vh] overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Brand Name</label>
                  <input required type="text" value={collaborationForm.brandName} onChange={e => setCollaborationForm({...collaborationForm, brandName: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. Local Food Festival" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Media Type</label>
                  <select value={collaborationForm.mediaType} onChange={e => setCollaborationForm({...collaborationForm, mediaType: e.target.value as any})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none">
                    <option value="video">Video (.mp4)</option>
                    <option value="gif">GIF</option>
                    <option value="image">Image</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Mobile Number</label>
                  <input type="text" value={collaborationForm.mobile} onChange={e => setCollaborationForm({...collaborationForm, mobile: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. +91 9876543210" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Experience</label>
                  <input type="text" value={collaborationForm.experience} onChange={e => setCollaborationForm({...collaborationForm, experience: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. 5 Years in Food Industry" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Address</label>
                  <input type="text" value={collaborationForm.address} onChange={e => setCollaborationForm({...collaborationForm, address: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. Mumbai, India" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Hobby</label>
                  <input type="text" value={collaborationForm.hobby} onChange={e => setCollaborationForm({...collaborationForm, hobby: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. Cooking, Traveling" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Description</label>
                <textarea required value={collaborationForm.description} onChange={e => setCollaborationForm({...collaborationForm, description: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none min-h-[80px]" placeholder="Details about the collaboration..." />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Remark / Story</label>
                <textarea value={collaborationForm.remark} onChange={e => setCollaborationForm({...collaborationForm, remark: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none min-h-[80px]" placeholder="Any special remarks or story..." />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <MediaUploadInput 
                  label="Image URL" 
                  value={collaborationForm.imageUrl} 
                  onChange={val => setCollaborationForm({...collaborationForm, imageUrl: val})} 
                />
                <MediaUploadInput 
                  label="Logo URL" 
                  value={collaborationForm.logoUrl} 
                  onChange={val => setCollaborationForm({...collaborationForm, logoUrl: val})} 
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <MediaUploadInput 
                    label="Media URL (Direct link or Upload)" 
                    value={collaborationForm.videoUrl} 
                    onChange={val => setCollaborationForm({...collaborationForm, videoUrl: val})} 
                  />
                  {collaborationForm.videoUrl && (
                    <div className="mt-2 rounded-lg overflow-hidden border border-[#333] aspect-video bg-black relative">
                      {collaborationForm.mediaType === 'video' ? (
                        <video src={collaborationForm.videoUrl || undefined} className="w-full h-full object-cover" />
                      ) : (
                        <img src={collaborationForm.videoUrl || undefined} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      )}
                      <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[8px] font-bold text-white uppercase">
                        Preview
                      </div>
                    </div>
                  )}
                </div>
                <MediaUploadInput 
                  label="Music URL" 
                  value={collaborationForm.musicUrl} 
                  onChange={val => setCollaborationForm({...collaborationForm, musicUrl: val})} 
                  accept="audio/*"
                  buttonText="Upload Audio"
                  note="Max 1MB"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Instagram URL</label>
                  <input type="url" value={collaborationForm.instagram} onChange={e => setCollaborationForm({...collaborationForm, instagram: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="https://instagram.com/..." />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Facebook URL</label>
                  <input type="url" value={collaborationForm.facebook} onChange={e => setCollaborationForm({...collaborationForm, facebook: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="https://facebook.com/..." />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">YouTube URL</label>
                  <input type="url" value={collaborationForm.youtube} onChange={e => setCollaborationForm({...collaborationForm, youtube: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="https://youtube.com/..." />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Twitter URL</label>
                  <input type="url" value={collaborationForm.twitter} onChange={e => setCollaborationForm({...collaborationForm, twitter: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="https://twitter.com/..." />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">General Social Link</label>
                <input type="url" value={collaborationForm.socialLink} onChange={e => setCollaborationForm({...collaborationForm, socialLink: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="https://..." />
              </div>

              <MediaUploadInput 
                label="Zip File URL (Optional)" 
                value={collaborationForm.zipUrl} 
                onChange={val => setCollaborationForm({...collaborationForm, zipUrl: val})} 
                accept="application/zip"
                buttonText="Upload Zip (.zip)"
              />

              <div className="flex items-center gap-3 pt-2">
                <input 
                  type="checkbox" 
                  id="collaborationActive"
                  checked={collaborationForm.active} 
                  onChange={e => setCollaborationForm({...collaborationForm, active: e.target.checked})}
                  className="w-5 h-5 accent-[var(--color-neon-green)]"
                />
                <label htmlFor="collaborationActive" className="text-sm font-bold text-white">Collaboration is Active</label>
              </div>
              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => setIsCollaborationModalOpen(false)} className="flex-1 bg-[#222] text-white font-bold py-3 rounded-xl hover:bg-[#333] transition-colors">Cancel</button>
                <button type="submit" className="flex-1 bg-[var(--color-neon-green)] text-black font-bold py-3 rounded-xl hover:bg-[#00cc00] transition-colors">Save Collaboration</button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Chicken Store Modal */}
      {isChickenModalOpen && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-[#111] border border-[#333] rounded-2xl w-full max-w-2xl overflow-hidden">
            <div className="p-6 border-b border-[#333] flex justify-between items-center">
              <h3 className="text-xl font-bold">{editingChicken ? 'Edit Chicken Item' : 'Add Chicken Item'}</h3>
              <button onClick={() => setIsChickenModalOpen(false)} className="text-gray-400 hover:text-white">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSaveChicken} className="p-6 space-y-4 max-h-[85vh] overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Item Name</label>
                  <input required type="text" value={chickenForm.name} onChange={e => setChickenForm({...chickenForm, name: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. Fresh Broiler Chicken" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Category</label>
                  <select value={chickenForm.category} onChange={e => setChickenForm({...chickenForm, category: e.target.value as any})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none">
                    <option value="Broiler Chicken">Broiler Chicken</option>
                    <option value="Desi Chicken">Desi Chicken</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Quality Description</label>
                  <input type="text" value={chickenForm.quality} onChange={e => setChickenForm({...chickenForm, quality: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. Farm Fresh, Organic" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Tasty Remark</label>
                  <input type="text" value={chickenForm.remark} onChange={e => setChickenForm({...chickenForm, remark: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" placeholder="e.g. Juicy & Tender" />
                </div>
              </div>

              <div className="space-y-4">
                <MediaUploadInput 
                  label="Image URL (Required)" 
                  value={chickenForm.imageUrl} 
                  onChange={val => setChickenForm({...chickenForm, imageUrl: val})} 
                  accept="image/*"
                  buttonText="Upload Image"
                />
                
                <div className="p-4 bg-[#1a1a1a] rounded-xl border border-[#333]">
                  <div className="flex items-center gap-3 mb-4">
                    <input 
                      type="checkbox" 
                      id="chickenVideoEnabled"
                      checked={chickenForm.isVideoEnabled} 
                      onChange={e => setChickenForm({...chickenForm, isVideoEnabled: e.target.checked})}
                      className="w-5 h-5 accent-[var(--color-neon-green)]"
                    />
                    <label htmlFor="chickenVideoEnabled" className="text-sm font-bold text-white">Enable Video for this item</label>
                  </div>
                  
                  {chickenForm.isVideoEnabled && (
                    <MediaUploadInput 
                      label="Video URL (MP4)" 
                      value={chickenForm.videoUrl} 
                      onChange={val => setChickenForm({...chickenForm, videoUrl: val})} 
                      accept="video/mp4"
                      buttonText="Upload Video"
                    />
                  )}
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider">Rates & Weights</label>
                  <button 
                    type="button" 
                    onClick={() => setChickenForm({...chickenForm, rates: [...chickenForm.rates, { id: crypto.randomUUID(), weight: '', price: 0 }]})}
                    className="text-[var(--color-neon-green)] text-xs font-bold hover:underline"
                  >
                    + Add Rate
                  </button>
                </div>
                {chickenForm.rates.map((rate, index) => (
                  <div key={rate.id || `rate-${index}`} className="flex gap-3 items-end">
                    <div className="flex-1">
                      <label className="block text-[10px] text-gray-500 uppercase mb-1">Weight</label>
                      <input 
                        type="text" 
                        value={rate.weight} 
                        onChange={e => {
                          const newRates = [...chickenForm.rates];
                          newRates[index].weight = e.target.value;
                          setChickenForm({...chickenForm, rates: newRates});
                        }}
                        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-3 py-2 text-sm text-white focus:border-[var(--color-neon-green)] outline-none" 
                        placeholder="e.g. 1kg" 
                      />
                    </div>
                    <div className="flex-1">
                      <label className="block text-[10px] text-gray-500 uppercase mb-1">Price (₹)</label>
                      <input 
                        type="number" 
                        value={rate.price} 
                        onChange={e => {
                          const newRates = [...chickenForm.rates];
                          newRates[index].price = Number(e.target.value);
                          setChickenForm({...chickenForm, rates: newRates});
                        }}
                        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-3 py-2 text-sm text-white focus:border-[var(--color-neon-green)] outline-none" 
                        placeholder="e.g. 100" 
                      />
                    </div>
                    {chickenForm.rates.length > 1 && (
                      <button 
                        type="button" 
                        onClick={() => {
                          const newRates = chickenForm.rates.filter((_, i) => i !== index);
                          setChickenForm({...chickenForm, rates: newRates});
                        }}
                        className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    )}
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div className="flex items-center gap-3">
                  <input 
                    type="checkbox" 
                    id="chickenActive"
                    checked={chickenForm.active} 
                    onChange={e => setChickenForm({...chickenForm, active: e.target.checked})}
                    className="w-5 h-5 accent-[var(--color-neon-green)]"
                  />
                  <label htmlFor="chickenActive" className="text-sm font-bold text-white">Item is Active</label>
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Display Order</label>
                  <input type="number" value={chickenForm.order} onChange={e => setChickenForm({...chickenForm, order: Number(e.target.value)})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" />
                </div>
              </div>

              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => setIsChickenModalOpen(false)} className="flex-1 bg-[#222] text-white font-bold py-3 rounded-xl hover:bg-[#333] transition-colors">Cancel</button>
                <button type="submit" className="flex-1 bg-[var(--color-neon-green)] text-black font-bold py-3 rounded-xl hover:bg-[#00cc00] transition-colors">Save Chicken Item</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Story Modal */}
      {isStoryModalOpen && (
        <div className="fixed inset-0 z-[150] bg-black/90 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-[#111] border border-[#333] rounded-2xl w-full max-w-lg overflow-hidden">
            <div className="p-6 border-b border-[#333] flex justify-between items-center">
              <h3 className="text-xl font-black uppercase">{editingStory ? 'Edit Story' : 'Add New Story'}</h3>
              <button onClick={() => setIsStoryModalOpen(false)} className="text-gray-400 hover:text-white">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSaveStory} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Title (e.g., Owner, Partner Name)</label>
                <input 
                  type="text" 
                  required
                  value={storyForm.title}
                  onChange={(e) => setStoryForm({ ...storyForm, title: e.target.value })}
                  className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                />
              </div>
              <div>
                <MediaUploadInput 
                  label="Logo URL (Circle Image)" 
                  value={storyForm.logoUrl} 
                  onChange={val => setStoryForm({ ...storyForm, logoUrl: val })} 
                  accept="image/*"
                  buttonText="Upload Image"
                />
                {storyForm.logoUrl && (
                  <div className="mt-2 w-10 h-10 rounded-full border border-[#333] overflow-hidden">
                    <img src={storyForm.logoUrl || undefined} className="w-full h-full object-cover" alt="Preview" />
                  </div>
                )}
              </div>
              <MediaUploadInput 
                label="Story Media URL (Video or Image)" 
                value={storyForm.mediaUrl} 
                onChange={val => {
                  setStoryForm({
                    ...storyForm, 
                    mediaUrl: val,
                    // Note: We can't easily infer mediaType from just the URL string here, 
                    // so we rely on the user to select the correct type below if it's a URL.
                    // If it's a data URL from an upload, we could potentially parse it, but 
                    // keeping it simple for now and letting the select handle it.
                  });
                }} 
              />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Media Type</label>
                  <select 
                    value={storyForm.mediaType}
                    onChange={(e) => setStoryForm({ ...storyForm, mediaType: e.target.value as 'video' | 'image' })}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                  >
                    <option value="video">Video (MP4)</option>
                    <option value="image">Image / GIF</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Display Order</label>
                  <input 
                    type="number" 
                    value={storyForm.order}
                    onChange={(e) => setStoryForm({ ...storyForm, order: Number(e.target.value) })}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <input 
                  type="checkbox" 
                  id="story-active"
                  checked={storyForm.active}
                  onChange={(e) => setStoryForm({ ...storyForm, active: e.target.checked })}
                  className="w-4 h-4 accent-[var(--color-neon-green)]" 
                />
                <label htmlFor="story-active" className="text-sm font-bold text-gray-300">Active / Visible</label>
              </div>
              <div className="flex gap-3 pt-4">
                <button 
                  type="button"
                  onClick={() => setIsStoryModalOpen(false)}
                  className="flex-1 bg-[#222] text-white font-bold py-3 rounded-xl hover:bg-[#333] transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="flex-1 bg-[var(--color-neon-green)] text-black font-bold py-3 rounded-xl hover:bg-[#00cc00] transition-colors"
                >
                  {editingStory ? 'Update Story' : 'Create Story'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {isCroppingOpen && (
        <div className="fixed inset-0 bg-black z-[200] flex flex-col items-center justify-center p-4">
          <div className="relative w-full h-[60vh] bg-black">
            <Cropper
              image={bannerForm.imageUrl}
              crop={bannerForm.crop}
              zoom={bannerForm.zoom}
              aspect={bannerForm.aspect}
              onCropChange={onCropChange}
              onCropComplete={onCropComplete}
              onZoomChange={onZoomChange}
            />
          </div>
          <div className="mt-4 flex gap-4">
            <button
              onClick={() => setIsCroppingOpen(false)}
              className="bg-white text-black px-6 py-2 rounded-full font-bold"
            >
              Done
            </button>
          </div>
        </div>
      )}
      {isBannerModalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-[#111] border border-[#333] rounded-2xl w-full max-w-lg overflow-hidden">
            <div className="p-6 border-b border-[#333] flex justify-between items-center">
              <h3 className="text-xl font-black uppercase tracking-widest text-[var(--color-neon-green)]">
                {editingBanner ? 'Edit Banner' : 'Add New Banner'}
              </h3>
              <button onClick={() => setIsBannerModalOpen(false)} className="text-gray-400 hover:text-white">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSaveBanner} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Banner Title</label>
                <input 
                  type="text" 
                  required
                  value={bannerForm.title}
                  onChange={e => setBannerForm({...bannerForm, title: e.target.value})}
                  className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                  placeholder="e.g. Summer Special Offer" 
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Media Type</label>
                <select 
                  value={bannerForm.mediaType}
                  onChange={e => setBannerForm({...bannerForm, mediaType: e.target.value as 'image' | 'video' | 'gif'})}
                  className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                >
                  <option value="image">Image</option>
                  <option value="video">Video (.mp4)</option>
                  <option value="gif">GIF</option>
                </select>
              </div>
              <MediaUploadInput 
                label="Media URL" 
                value={bannerForm.mediaType === 'image' ? bannerForm.imageUrl : bannerForm.videoUrl} 
                onChange={val => {
                  if (bannerForm.mediaType === 'image') {
                    setBannerForm({...bannerForm, imageUrl: val});
                    // Note: If it's a direct upload, we might want to trigger cropping here.
                    // For simplicity, we'll let the user open cropping manually if needed, 
                    // or we could add a callback to MediaUploadInput for when a file is uploaded.
                    // Since MediaUploadInput doesn't expose whether it was an upload or paste,
                    // we'll just set the URL. The user can still crop if they want.
                  } else {
                    setBannerForm({...bannerForm, videoUrl: val});
                  }
                }} 
              />
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Link URL (Optional)</label>
                <input 
                  type="url" 
                  value={bannerForm.link}
                  onChange={e => setBannerForm({...bannerForm, link: e.target.value})}
                  className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                  placeholder="https://example.com/promo" 
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Display Order</label>
                  <input 
                    type="number" 
                    value={bannerForm.order}
                    onChange={e => setBannerForm({...bannerForm, order: parseInt(e.target.value)})}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                  />
                </div>
                <div className="flex items-end pb-2">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={bannerForm.active}
                      onChange={e => setBannerForm({...bannerForm, active: e.target.checked})}
                      className="w-5 h-5 accent-[var(--color-neon-green)]" 
                    />
                    <span className="text-sm font-bold text-white">Active</span>
                  </label>
                </div>
              </div>
              <div className="flex gap-3 pt-4">
                <button 
                  type="button"
                  onClick={() => setIsBannerModalOpen(false)}
                  className="flex-1 bg-[#222] text-white font-bold py-3 rounded-xl hover:bg-[#333] transition-colors border border-[#444]"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="flex-1 bg-[var(--color-neon-green)] text-black font-bold py-3 rounded-xl hover:bg-[#00cc00] transition-colors"
                >
                  Save Banner
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
