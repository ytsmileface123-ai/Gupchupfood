import React, { useState, useEffect } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { motion } from 'framer-motion';
import { MapPin, Truck, CheckCircle2, Clock, AlertCircle, Utensils, Package, User, XCircle } from 'lucide-react';

interface OrderTrackingProps {
  orderId: string;
}

const STATUSES = ['Pending', 'Confirmed', 'Preparing', 'Out for Delivery', 'Completed'];

const OrderTracking: React.FC<OrderTrackingProps> = ({ orderId }) => {
  const [order, setOrder] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const orderDoc = doc(db, 'orders', orderId);
    const unsubscribe = onSnapshot(orderDoc, (doc) => {
      if (doc.exists()) {
        setOrder({ id: doc.id, ...doc.data() });
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [orderId]);

  const handleCopy = () => {
    navigator.clipboard.writeText(orderId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) return <div className="text-white p-4 text-center">Loading order details...</div>;
  if (!order) return <div className="text-white p-4 text-center">Order not found.</div>;

  const currentStatusIndex = STATUSES.indexOf(order.status);
  const isDelayed = order.status === 'delayed';
  const isCancelled = order.status === 'Cancelled';

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-black/90 backdrop-blur-2xl p-8 rounded-[2rem] border border-white/10 shadow-2xl text-white space-y-8 relative overflow-hidden"
    >
      {/* Luxury Accent */}
      <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[var(--color-neon-green)] to-transparent opacity-50 ${isCancelled ? 'via-red-500' : isDelayed ? 'via-yellow-500' : ''}`} />

      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-3xl font-black uppercase tracking-tighter text-white">Order Tracking</h3>
          <div className="flex items-center gap-2 mt-1">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-[0.2em]">Order ID: {order.id.slice(-8)}</p>
            <button 
              onClick={handleCopy}
              className={`text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded border transition-all ${copied ? 'bg-[var(--color-neon-green)] text-black border-[var(--color-neon-green)]' : 'border-white/10 text-gray-500 hover:border-white/20 hover:text-white'}`}
            >
              {copied ? 'Copied!' : 'Copy'}
            </button>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs font-bold text-gray-500 uppercase tracking-[0.2em]">Total</p>
          <p className="text-3xl font-black text-[var(--color-neon-green)] tracking-tighter">₹{order.totalAmount}</p>
        </div>
      </div>

      {isCancelled ? (
        <div className="bg-red-500/10 border border-red-500/20 p-6 rounded-3xl flex items-center gap-4 text-red-500">
          <XCircle size={32} />
          <div>
            <h4 className="font-black uppercase tracking-widest text-sm">Order Cancelled</h4>
            <p className="text-xs opacity-70">This order has been cancelled. Please contact support for more information.</p>
          </div>
        </div>
      ) : (
        <>
          {/* Progress Bar */}
          <div className="relative pt-6 pb-2">
            <div className="flex justify-between mb-6">
              {STATUSES.map((status, index) => {
                const isActive = index <= currentStatusIndex;
                const isCurrent = index === currentStatusIndex;
                return (
                  <div key={status} className={`flex flex-col items-center ${isActive ? 'text-[var(--color-neon-green)]' : 'text-gray-700'}`}>
                    <motion.div 
                      initial={false}
                      animate={{ 
                        scale: isCurrent ? 1.2 : 1,
                        backgroundColor: isActive ? 'var(--color-neon-green)' : 'black'
                      }}
                      className={`w-5 h-5 rounded-full border-2 ${isActive ? 'border-[var(--color-neon-green)]' : 'border-gray-700'}`} 
                    />
                    <span className={`text-[10px] font-black uppercase mt-3 tracking-widest ${isActive ? 'text-white' : 'text-gray-600'}`}>
                      {status.replace('_', ' ')}
                    </span>
                  </div>
                );
              })}
            </div>
            <div className="h-3 bg-gray-900 rounded-full overflow-hidden border border-white/5">
              <motion.div 
                className={`h-full bg-gradient-to-r from-[var(--color-neon-green)] to-emerald-500 shadow-[0_0_15px_rgba(0,255,0,0.5)] ${isDelayed ? 'from-yellow-500 to-orange-500 shadow-[0_0_15px_rgba(234,179,8,0.5)]' : ''}`}
                initial={{ width: '0%' }}
                animate={{ width: `${(currentStatusIndex / (STATUSES.length - 1)) * 100}%` }}
                transition={{ duration: 0.5, ease: "easeInOut" }}
              />
            </div>
            {isDelayed && (
              <div className="mt-4 flex items-center gap-2 text-yellow-500 bg-yellow-500/10 p-3 rounded-xl border border-yellow-500/20">
                <AlertCircle size={16} />
                <span className="text-[10px] font-black uppercase tracking-widest">Order is slightly delayed. We're working on it!</span>
              </div>
            )}
          </div>
        </>
      )}

      {/* Order Summary */}
      <div className="bg-white/[0.03] p-6 rounded-3xl border border-white/[0.05]">
        <h4 className="text-xs font-black text-gray-400 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
          <Package size={16} /> Order Summary
        </h4>
        <div className="space-y-3">
          {order.items.map((item: any, idx: number) => (
            <div key={`tracking-item-${item.cartItemId || item.id || idx}-${idx}`} className="border-b border-white/[0.05] pb-3 last:border-0 last:pb-0">
              <div className="flex justify-between text-sm font-bold mb-1">
                <span className="text-gray-300">{item.name} <span className="text-gray-600">x{item.quantity}</span></span>
                <span className="text-white">₹{item.price * item.quantity}</span>
              </div>
              {item.customizations && (
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest pl-2 border-l border-white/10">
                  {item.customizations.spiceLevel} {item.customizations.toppings?.length ? `• ${item.customizations.toppings.join(', ')}` : ''}
                </p>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Estimated Time & Remarks */}
      {(order.estimatedDeliveryTime || order.adminRemark) && (
        <div className="bg-white/[0.03] p-6 rounded-3xl border border-white/[0.05] grid grid-cols-2 gap-4">
          {order.estimatedDeliveryTime && (
            <div>
              <h4 className="text-xs font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Estimated Time</h4>
              <p className="text-sm font-bold text-white">{order.estimatedDeliveryTime}</p>
            </div>
          )}
          {order.adminRemark && (
            <div>
              <h4 className="text-xs font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Admin Remark</h4>
              <p className="text-sm font-bold text-white">{order.adminRemark}</p>
            </div>
          )}
        </div>
      )}

      {/* Status History */}
      <div className="bg-white/[0.03] p-6 rounded-3xl border border-white/[0.05]">
        <h4 className="text-xs font-black text-gray-400 uppercase tracking-[0.2em] mb-6 flex items-center gap-2">
          <Clock size={16} /> Status History
        </h4>
        <div className="relative pl-6 space-y-6">
          {/* Vertical Line */}
          <div className="absolute left-[11px] top-2 bottom-2 w-0.5 bg-white/10" />
          
          {STATUSES.map((status, idx) => {
            const timestamp = order.statusTimestamps?.[status];
            if (!timestamp) return null;
            const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
            
            return (
              <div key={`tracking-status-${idx}`} className="relative flex items-start gap-4">
                {/* Dot */}
                <div className="absolute -left-[25px] top-1 w-5 h-5 rounded-full bg-[var(--color-neon-green)] border-4 border-black" />
                
                <div className="flex-1 flex justify-between items-center">
                  <span className="text-white font-bold text-sm capitalize">{status.replace('_', ' ')}</span>
                  <span className="text-gray-500 text-xs font-mono">
                    {date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Rider Info */}
      {order.riderId && (
        <div className="bg-gradient-to-br from-white/[0.05] to-transparent p-6 rounded-3xl border border-white/[0.05] flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-white/[0.05] flex items-center justify-center border border-white/[0.1]">
              <User size={24} className="text-[var(--color-neon-green)]" />
            </div>
            <div>
              <p className="text-xs font-black uppercase tracking-[0.2em] text-gray-400">Your Rider</p>
              <p className="text-sm font-bold text-white">ID: {order.riderId.slice(-4)}</p>
            </div>
          </div>
          {order.liveLocation && (
            <a href={order.liveLocation} target="_blank" rel="noopener noreferrer" className="bg-[var(--color-neon-green)] text-black px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-2 hover:bg-white transition-colors">
              <MapPin size={16} /> Track
            </a>
          )}
        </div>
      )}
    </motion.div>
  );
};

export default OrderTracking;
