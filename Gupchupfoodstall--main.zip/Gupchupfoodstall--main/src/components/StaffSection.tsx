import React, { useEffect, useState } from 'react';
import { collection, query, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { motion, useMotionValue, useTransform, useSpring, AnimatePresence } from 'framer-motion';
import { MapPin, Phone, Star, Award, Play, X, Volume2, VolumeX } from 'lucide-react';
import { useStore } from '../store/useStore';
import StorySection from './StorySection';
import ShareButton from './ShareButton';

const TiltCard = ({ staff, onClick, settings }: { staff: any, onClick: () => void, settings: any }) => {
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x);
  const mouseYSpring = useSpring(y);

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["15deg", "-15deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-15deg", "15deg"]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onClick={onClick}
      style={{
        rotateY,
        rotateX,
        transformStyle: "preserve-3d",
      }}
      className="relative w-full aspect-[9/16] rounded-3xl bg-[#0a0a0a] border border-white/10 overflow-hidden cursor-pointer group"
      id={`staff-${staff.id}`}
    >
      {/* Background Image or Video */}
      <div className="absolute inset-0 overflow-hidden">
        {staff.videoUrl ? (
          <video 
            src={staff.videoUrl}
            muted
            loop
            autoPlay
            playsInline
            poster={staff.imageUrl}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
          />
        ) : (
          <img 
            src={staff.imageUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(staff.name)}&background=random`}
            alt={staff.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
      </div>

      <div className="absolute top-4 right-4 z-30">
        {settings.isStaffShareEnabled && (
          <ShareButton 
            title={`Staff: ${staff.name}`}
            text={`Check out our amazing staff member: ${staff.name}!`}
            url={`${window.location.origin}/#staff-${staff.id}`}
            iconSize={12}
          />
        )}
      </div>

      {/* Play Icon Overlay if it has video */}
      {staff.videoUrl && (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-all duration-500 hover:scale-110 z-20">
          <Play size={32} fill="currentColor" />
        </div>
      )}

      {/* Content at the bottom */}
      <div
        style={{
          transform: "translateZ(50px)",
          transformStyle: "preserve-3d",
        }}
        className="absolute inset-x-0 bottom-0 p-6 flex flex-col items-start text-left z-20"
      >
        <motion.span 
          style={{ transform: "translateZ(40px)" }}
          className="px-3 py-1 rounded-full bg-[var(--color-neon-green)]/20 text-[var(--color-neon-green)] border border-[var(--color-neon-green)]/30 font-bold text-[10px] tracking-widest uppercase mb-3 backdrop-blur-md"
        >
          {staff.category}
        </motion.span>
        
        <motion.h3 
          style={{ transform: "translateZ(60px)" }}
          className="text-2xl font-black text-white uppercase tracking-wider mb-1"
        >
          {staff.name}
        </motion.h3>

        <motion.div 
          style={{ transform: "translateZ(30px)" }}
          className="w-full space-y-1.5 text-xs text-gray-300 mt-2"
        >
          {staff.experience && (
            <div className="flex items-center gap-2">
              <Award size={14} className="text-[var(--color-neon-green)]" />
              <span>{staff.experience} Experience</span>
            </div>
          )}
          {staff.mobile && (
            <div className="flex items-center gap-2">
              <Phone size={14} className="text-[var(--color-neon-green)]" />
              <span>{staff.mobile}</span>
            </div>
          )}
          {staff.address && (
            <div className="flex items-center gap-2">
              <MapPin size={14} className="text-[var(--color-neon-green)]" />
              <span className="truncate">{staff.address}</span>
            </div>
          )}
        </motion.div>

        {staff.remark && (
          <motion.p 
            style={{ transform: "translateZ(20px)" }}
            className="mt-3 text-xs text-gray-400 italic line-clamp-2"
          >
            "{staff.remark}"
          </motion.p>
        )}
      </div>

      {/* Glow Effect */}
      <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-[var(--color-neon-green)]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
    </motion.div>
  );
};

export default function StaffSection({ stories, isStoriesEnabled }: { stories?: any[], isStoriesEnabled?: boolean }) {
  const [staffList, setStaffList] = useState<any[]>([]);
  const [selectedStaff, setSelectedStaff] = useState<any | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const { settings } = useStore();

  useEffect(() => {
    const qStaff = query(collection(db, 'staff'));
    const unsubscribe = onSnapshot(qStaff, (snapshot) => {
      const staffData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setStaffList(staffData);
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    let timer: any;
    if (selectedStaff && selectedStaff.videoUrl) {
      setProgress(0);
      timer = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            setSelectedStaff(null);
            return 0;
          }
          return prev + 1;
        });
      }, 150); // 15 seconds per story
    }
    return () => clearInterval(timer);
  }, [selectedStaff]);

  if (staffList.length === 0) return null;

  return (
    <section className="py-24 bg-black/30 backdrop-blur-md relative overflow-hidden perspective-1000">
      {/* Background Elements */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-[var(--color-neon-green)]/5 rounded-full blur-[120px] pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-24"
        >
          {isStoriesEnabled && stories && stories.length > 0 && (
            <div className="mb-12">
              <StorySection stories={stories} hideTitle={true} />
            </div>
          )}
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="w-16 h-px bg-gradient-to-r from-[var(--color-neon-green)] to-transparent"></div>
            <span className="text-[var(--color-neon-green)] font-black uppercase tracking-[0.5em] text-xs">The Visionaries</span>
          </div>
          <h2 className="text-6xl md:text-9xl font-black text-white uppercase tracking-tighter leading-[0.8] mb-8">
            Owner & <span className="text-gradient">Partner</span>
          </h2>
          <p className="text-gray-400 text-lg md:text-2xl font-medium max-w-3xl mx-auto leading-relaxed">
            The passionate individuals behind your favorite street food experience, dedicated to culinary excellence.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 perspective-1000">
          {staffList.map((staff, index) => (
            <motion.div
              key={staff.id}
              initial={{ opacity: 0, z: -100, rotateX: 20 }}
              whileInView={{ opacity: 1, z: 0, rotateX: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.2, type: "spring" }}
            >
              <TiltCard staff={staff} settings={settings} onClick={() => {
                if (staff.videoUrl) {
                  setSelectedStaff(staff);
                }
              }} />
            </motion.div>
          ))}
        </div>
      </div>

      {/* Story Modal for Staff Video */}
      <AnimatePresence>
        {selectedStaff && selectedStaff.videoUrl && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-black/80 flex items-center justify-center p-4"
            onClick={() => setSelectedStaff(null)}
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="relative w-full max-w-sm aspect-[9/16] bg-black rounded-3xl overflow-hidden shadow-2xl flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Progress Bar */}
              <div className="absolute top-4 left-4 right-4 flex gap-1 z-30">
                <div className="h-1 flex-1 bg-white/20 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-white transition-all duration-100 ease-linear"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>

              {/* Header */}
              <div className="absolute top-8 left-4 right-4 flex items-center justify-between z-30">
                <div className="flex items-center gap-2">
                  <img 
                    src={selectedStaff.imageUrl || undefined} 
                    className="w-10 h-10 rounded-full border-2 border-[var(--color-neon-green)] object-cover" 
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex flex-col">
                    <span className="text-white font-bold text-sm drop-shadow-md leading-tight">
                      {selectedStaff.name}
                    </span>
                    <span className="text-[var(--color-neon-green)] text-xs font-bold uppercase tracking-wider drop-shadow-md">
                      {selectedStaff.category}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <button onClick={() => setIsMuted(!isMuted)} className="text-white drop-shadow-md hover:scale-110 transition-transform">
                    {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
                  </button>
                  <button onClick={() => setSelectedStaff(null)} className="text-white drop-shadow-md hover:scale-110 transition-transform">
                    <X size={28} />
                  </button>
                </div>
              </div>

              {/* Media */}
              <div className="flex-1 relative overflow-hidden bg-black">
                <video 
                  src={selectedStaff.videoUrl || undefined}
                  className="w-full h-full object-contain"
                  autoPlay
                  muted={isMuted}
                  playsInline
                  onEnded={() => setSelectedStaff(null)}
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
