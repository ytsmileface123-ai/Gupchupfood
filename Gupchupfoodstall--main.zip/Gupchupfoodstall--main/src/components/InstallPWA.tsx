import React, { useState, useEffect } from 'react';
import { Download, Share, PlusSquare, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const InstallPWA: React.FC = () => {
  const [supportsPWA, setSupportsPWA] = useState(false);
  const [promptInstall, setPromptInstall] = useState<any>(null);
  const [showFallback, setShowFallback] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    // Check if already installed
    const checkStandalone = () => {
      const isStand = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone;
      setIsStandalone(isStand);
    };
    
    checkStandalone();
    window.matchMedia('(display-mode: standalone)').addEventListener('change', checkStandalone);

    const handler = (e: Event) => {
      e.preventDefault();
      setSupportsPWA(true);
      setPromptInstall(e);
    };
    
    window.addEventListener('beforeinstallprompt', handler);
    
    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
      window.matchMedia('(display-mode: standalone)').removeEventListener('change', checkStandalone);
    };
  }, []);

  const onClick = (evt: React.MouseEvent<HTMLButtonElement>) => {
    evt.preventDefault();
    if (promptInstall) {
      promptInstall.prompt();
      promptInstall.userChoice.then((choiceResult: { outcome: string }) => {
        if (choiceResult.outcome === 'accepted') {
          console.log('User accepted the install prompt');
        } else {
          console.log('User dismissed the install prompt');
        }
        setSupportsPWA(false);
      });
    } else {
      // Show fallback instructions
      setShowFallback(true);
    }
  };

  if (isStandalone) return null;

  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;

  return (
    <>
      <button
        onClick={onClick}
        className="hidden md:flex items-center gap-2 bg-[var(--color-neon-green)] text-black px-4 py-2 rounded-full font-black text-[10px] uppercase tracking-[0.2em] hover:scale-105 transition-transform shadow-[0_0_15px_rgba(0,255,0,0.3)]"
      >
        <Download size={14} />
        <span className="hidden lg:inline">Install App</span>
      </button>

      {/* Mobile version - just icon to save space */}
      <button
        onClick={onClick}
        className="md:hidden flex items-center justify-center w-9 h-9 bg-[var(--color-neon-green)] text-black rounded-full hover:scale-105 transition-transform shadow-[0_0_15px_rgba(0,255,0,0.3)]"
      >
        <Download size={16} />
      </button>

      <AnimatePresence>
        {showFallback && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
            onClick={() => setShowFallback(false)}
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-[#111] border border-[#333] rounded-3xl p-6 max-w-sm w-full shadow-2xl relative"
              onClick={e => e.stopPropagation()}
            >
              <button 
                onClick={() => setShowFallback(false)}
                className="absolute top-4 right-4 text-gray-400 hover:text-white"
              >
                <X size={24} />
              </button>
              
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-[var(--color-neon-green)]/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Download size={32} className="text-[var(--color-neon-green)]" />
                </div>
                <h3 className="text-xl font-black text-white uppercase tracking-wider mb-2">Install App</h3>
                <p className="text-gray-400 text-sm">Install our app on your device for the best experience.</p>
              </div>

              {isIOS ? (
                <div className="space-y-4 bg-white/5 p-4 rounded-2xl border border-white/10">
                  <div className="flex items-center gap-3 text-white">
                    <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center shrink-0">1</div>
                    <p className="text-sm">Tap the <Share size={16} className="inline mx-1" /> <b>Share</b> button at the bottom of your screen.</p>
                  </div>
                  <div className="flex items-center gap-3 text-white">
                    <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center shrink-0">2</div>
                    <p className="text-sm">Scroll down and tap <PlusSquare size={16} className="inline mx-1" /> <b>Add to Home Screen</b>.</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4 bg-white/5 p-4 rounded-2xl border border-white/10">
                  <div className="flex items-center gap-3 text-white">
                    <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center shrink-0">1</div>
                    <p className="text-sm">Tap the <b>Menu</b> (three dots) at the top right of your browser.</p>
                  </div>
                  <div className="flex items-center gap-3 text-white">
                    <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center shrink-0">2</div>
                    <p className="text-sm">Tap <b>Install app</b> or <b>Add to Home screen</b>.</p>
                  </div>
                </div>
              )}
              
              <button 
                onClick={() => setShowFallback(false)}
                className="w-full mt-6 bg-white/10 hover:bg-white/20 text-white font-bold py-3 rounded-xl transition-colors"
              >
                Got it
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
