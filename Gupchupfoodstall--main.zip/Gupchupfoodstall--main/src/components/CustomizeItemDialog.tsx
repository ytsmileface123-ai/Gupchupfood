import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Flame, Plus, Check } from 'lucide-react';
import { CartItem } from '../store/useStore';

interface CustomizeItemDialogProps {
  item: CartItem;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (customizations: { spiceLevel: string; toppings: string[] }) => void;
  availableToppings?: string;
  availableSpiceLevels?: string;
}

export default function CustomizeItemDialog({ 
  item, 
  isOpen, 
  onClose, 
  onConfirm,
  availableToppings = '',
  availableSpiceLevels = ''
}: CustomizeItemDialogProps) {
  const spiceOptions = availableSpiceLevels.split(',').map(s => s.trim()).filter(s => s !== '');
  const toppingOptions = availableToppings.split(',').map(t => t.trim()).filter(t => t !== '');

  const [spiceLevel, setSpiceLevel] = useState(spiceOptions[0] || 'Medium');
  const [toppings, setToppings] = useState<string[]>([]);

  const toggleTopping = (topping: string) => {
    setToppings(prev => prev.includes(topping) ? prev.filter(t => t !== topping) : [...prev, topping]);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-xl p-4"
          onClick={onClose}
        >
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="glass-panel border-white/10 rounded-[2.5rem] w-full max-w-md p-8 md:p-10 relative overflow-hidden shadow-2xl"
            onClick={e => e.stopPropagation()}
          >
            {/* Background Glow */}
            <div className="absolute -top-24 -right-24 w-48 h-48 bg-[var(--color-neon-green)]/10 rounded-full blur-[60px] pointer-events-none"></div>

            <div className="flex justify-between items-center mb-8 relative z-10">
              <div>
                <h3 className="text-3xl font-black text-white uppercase tracking-tighter leading-none italic">Customize</h3>
                <p className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mt-1">{item.name}</p>
              </div>
              <motion.button 
                whileHover={{ scale: 1.1, rotate: 90 }}
                whileTap={{ scale: 0.9 }}
                onClick={onClose} 
                className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-white hover:text-black transition-all"
              >
                <X size={20} />
              </motion.button>
            </div>

            <div className="space-y-8 relative z-10">
              {spiceOptions.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <Flame size={14} className="text-[var(--color-neon-red)]" />
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em]">Spice Level</label>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    {spiceOptions.map((level, index) => (
                      <motion.button 
                        key={`${level}-${index}`}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setSpiceLevel(level)}
                        className={`py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all duration-500 border ${
                          spiceLevel === level 
                            ? 'bg-[var(--color-neon-green)] text-black border-[var(--color-neon-green)] shadow-[0_0_20px_rgba(255,183,3,0.2)]' 
                            : 'bg-white/5 text-white border-white/5 hover:bg-white/10'
                        }`}
                      >
                        {level}
                      </motion.button>
                    ))}
                  </div>
                </div>
              )}

              {toppingOptions.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <Plus size={14} className="text-[var(--color-neon-green)]" />
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em]">Add Toppings</label>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {toppingOptions.map((topping, index) => (
                      <motion.button 
                        key={`${topping}-${index}`}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => toggleTopping(topping)}
                        className={`py-3 px-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all duration-500 border flex items-center justify-between ${
                          toppings.includes(topping) 
                            ? 'bg-white/10 text-[var(--color-neon-green)] border-[var(--color-neon-green)]/40' 
                            : 'bg-white/5 text-white border-white/5 hover:bg-white/10'
                        }`}
                      >
                        {topping}
                        {toppings.includes(topping) && <Check size={12} />}
                      </motion.button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <motion.button 
              whileHover={{ scale: 1.02, y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => {
                onConfirm({ spiceLevel, toppings });
                onClose();
              }}
              className="w-full mt-10 bg-[var(--color-neon-green)] text-black font-black uppercase tracking-[0.2em] py-5 rounded-2xl hover:bg-white transition-all duration-500 shadow-xl"
            >
              Add to Cart
            </motion.button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
