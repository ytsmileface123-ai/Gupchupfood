import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { doc, onSnapshot, updateDoc, collection, addDoc, deleteDoc, query, orderBy, limit, serverTimestamp, arrayUnion, arrayRemove, getDocs } from 'firebase/firestore';
import { Plus, Trash2, RefreshCw, ToggleLeft, ToggleRight, Sparkles, MapPin, User, Utensils, Edit2, Check, X, Clock } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

const SettingInput = ({ value, onChange, type = "text", className, placeholder }: any) => {
  const [localValue, setLocalValue] = useState(value);

  useEffect(() => {
    setLocalValue(value);
  }, [value]);

  if (type === 'textarea') {
    return (
      <textarea
        value={localValue}
        onChange={(e) => setLocalValue(e.target.value)}
        onBlur={() => onChange(localValue)}
        className={className}
        placeholder={placeholder}
      />
    );
  }

  return (
    <input
      type={type}
      value={localValue}
      onChange={(e) => setLocalValue(e.target.value)}
      onBlur={() => onChange(type === 'number' ? Number(localValue) : localValue)}
      className={className}
      placeholder={placeholder}
    />
  );
};

const CashbackManagement: React.FC = () => {
  const [settings, setSettings] = useState<any>(null);
  const [wins, setWins] = useState<any[]>([]);
  const [newWin, setNewWin] = useState({ customerName: '', amount: '' });
  const [newLocation, setNewLocation] = useState('');
  const [newName, setNewName] = useState('');
  const [newFood, setNewFood] = useState('');
  const [editingItem, setEditingItem] = useState<{ field: string, index: number, value: string } | null>(null);
  const [editingWin, setEditingWin] = useState<{ id: string, customerName: string, amount: string } | null>(null);
  const [isClearingWins, setIsClearingWins] = useState(false);
  const [isResettingToday, setIsResettingToday] = useState(false);

  useEffect(() => {
    const unsubscribeSettings = onSnapshot(doc(db, 'cashbackSettings', 'global'), (snapshot) => {
      if (snapshot.exists()) {
        setSettings(snapshot.data());
      }
    });

    const qWins = query(collection(db, 'cashbackWins'), orderBy('timestamp', 'desc'), limit(50));
    const unsubscribeWins = onSnapshot(qWins, (snapshot) => {
      setWins(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    return () => {
      unsubscribeSettings();
      unsubscribeWins();
    };
  }, []);

  const handleUpdateSettings = async (updates: any) => {
    try {
      await updateDoc(doc(db, 'cashbackSettings', 'global'), updates);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'cashbackSettings/global');
    }
  };

  const handleAddCustomItem = async (field: string, value: string, setter: (v: string) => void) => {
    if (!value.trim()) return;
    try {
      await updateDoc(doc(db, 'cashbackSettings', 'global'), {
        [field]: arrayUnion(value.trim())
      });
      setter('');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'cashbackSettings/global');
    }
  };

  const handleRemoveCustomItem = async (field: string, value: string) => {
    try {
      await updateDoc(doc(db, 'cashbackSettings', 'global'), {
        [field]: arrayRemove(value)
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'cashbackSettings/global');
    }
  };

  const handleUpdateCustomItem = async () => {
    if (!editingItem || !editingItem.value.trim()) return;
    try {
      const currentList = [...(settings[editingItem.field] || [])];
      currentList[editingItem.index] = editingItem.value.trim();
      await updateDoc(doc(db, 'cashbackSettings', 'global'), {
        [editingItem.field]: currentList
      });
      setEditingItem(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'cashbackSettings/global');
    }
  };

  const handleAddWin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWin.customerName || !newWin.amount) return;
    
    try {
      await addDoc(collection(db, 'cashbackWins'), {
        customerName: newWin.customerName,
        amount: Number(newWin.amount),
        timestamp: serverTimestamp()
      });
      
      // Also update total cashback today
      if (settings) {
        await updateDoc(doc(db, 'cashbackSettings', 'global'), {
          totalCashbackToday: (settings.totalCashbackToday || 0) + Number(newWin.amount)
        });
      }
      
      setNewWin({ customerName: '', amount: '' });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'cashbackWins');
    }
  };

  const handleUpdateWin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingWin) return;
    try {
      await updateDoc(doc(db, 'cashbackWins', editingWin.id), {
        customerName: editingWin.customerName,
        amount: Number(editingWin.amount)
      });
      setEditingWin(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `cashbackWins/${editingWin.id}`);
    }
  };

  const handleDeleteWin = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'cashbackWins', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `cashbackWins/${id}`);
    }
  };

  const handleClearAllWins = async () => {
    if (!isClearingWins) {
      setIsClearingWins(true);
      setTimeout(() => setIsClearingWins(false), 3000);
      return;
    }
    
    try {
      const snapshot = await getDocs(collection(db, 'cashbackWins'));
      const deletePromises = snapshot.docs.map(docRef => deleteDoc(docRef.ref));
      await Promise.all(deletePromises);
      setIsClearingWins(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'cashbackWins');
    }
  };

  const handleManualReset = async () => {
    if (!isResettingToday) {
      setIsResettingToday(true);
      setTimeout(() => setIsResettingToday(false), 3000);
      return;
    }
    
    try {
      await updateDoc(doc(db, 'cashbackSettings', 'global'), {
        totalCashbackToday: 0,
        lastResetDate: new Date().toISOString().split('T')[0]
      });
      setIsResettingToday(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'cashbackSettings/global');
    }
  };

  if (!settings) return <div className="p-8 text-center text-gray-500">Loading settings...</div>;

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h3 className="text-3xl font-black uppercase tracking-tighter">Cashback Rewards</h3>
        <button 
          onClick={handleManualReset}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl border font-bold text-sm transition-all ${isResettingToday ? 'bg-yellow-500/10 border-yellow-500/50 text-yellow-500' : 'bg-red-500/10 border-red-500/20 text-red-500 hover:bg-red-500/20'}`}
        >
          <RefreshCw size={18} className={isResettingToday ? 'animate-spin' : ''} />
          {isResettingToday ? 'Click Again to Confirm Reset' : 'Manual Reset Today'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Settings Panel */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
            <h4 className="text-lg font-bold mb-6 flex items-center gap-2">
              <Sparkles className="text-purple-400" size={20} />
              Display Settings
            </h4>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-black/40 rounded-xl border border-white/5">
                <div>
                  <p className="font-bold text-sm">Enable Dashboard</p>
                  <p className="text-[10px] text-gray-500">Show/hide on website</p>
                </div>
                <button 
                  onClick={() => handleUpdateSettings({ isEnabled: !settings.isEnabled })}
                  className={`p-2 rounded-lg transition-colors ${settings.isEnabled ? 'text-[var(--color-neon-green)]' : 'text-gray-600'}`}
                >
                  {settings.isEnabled ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}
                </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-black/40 rounded-xl border border-white/5">
                <div>
                  <p className="font-bold text-sm">Auto Daily Reset</p>
                  <p className="text-[10px] text-gray-500">Reset at midnight</p>
                </div>
                <button 
                  onClick={() => handleUpdateSettings({ autoReset: !settings.autoReset })}
                  className={`p-2 rounded-lg transition-colors ${settings.autoReset ? 'text-[var(--color-neon-green)]' : 'text-gray-600'}`}
                >
                  {settings.autoReset ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}
                </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-black/40 rounded-xl border border-white/5">
                <div>
                  <p className="font-bold text-sm">Auto Increment</p>
                  <p className="text-[10px] text-gray-500">Increase amount automatically</p>
                </div>
                <button 
                  onClick={() => handleUpdateSettings({ isAutoIncrementEnabled: !settings.isAutoIncrementEnabled })}
                  className={`p-2 rounded-lg transition-colors ${settings.isAutoIncrementEnabled ? 'text-[var(--color-neon-green)]' : 'text-gray-600'}`}
                >
                  {settings.isAutoIncrementEnabled ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}
                </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-black/40 rounded-xl border border-white/5">
                <div>
                  <p className="font-bold text-sm">AI Mode (Gemini)</p>
                  <p className="text-[10px] text-gray-500">Generate realistic names with AI</p>
                </div>
                <button 
                  onClick={() => handleUpdateSettings({ isAiModeEnabled: !settings.isAiModeEnabled })}
                  className={`p-2 rounded-lg transition-colors ${settings.isAiModeEnabled ? 'text-[var(--color-neon-green)]' : 'text-gray-600'}`}
                >
                  {settings.isAiModeEnabled ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}
                </button>
              </div>

              <div className="p-4 bg-black/40 rounded-xl border border-white/5 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-bold text-sm flex items-center gap-2">
                      <Clock size={16} className="text-blue-400" />
                      Auto-Schedule (Open/Close)
                    </p>
                    <p className="text-[10px] text-gray-500">Only count during business hours</p>
                  </div>
                  <button 
                    onClick={() => handleUpdateSettings({ isScheduleEnabled: !settings.isScheduleEnabled })}
                    className={`p-2 rounded-lg transition-colors ${settings.isScheduleEnabled ? 'text-[var(--color-neon-green)]' : 'text-gray-600'}`}
                  >
                    {settings.isScheduleEnabled ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}
                  </button>
                </div>

                {settings.isScheduleEnabled && (
                  <div className="grid grid-cols-2 gap-4 pt-2 border-t border-white/5">
                    <div>
                      <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Open Time</label>
                      <SettingInput 
                        type="time" 
                        value={settings.openTime || "09:00"}
                        onChange={(val: string) => handleUpdateSettings({ openTime: val })}
                        className="w-full bg-black border border-[#333] rounded-lg px-3 py-1.5 text-xs text-white focus:border-blue-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Close Time</label>
                      <SettingInput 
                        type="time" 
                        value={settings.closeTime || "22:00"}
                        onChange={(val: string) => handleUpdateSettings({ closeTime: val })}
                        className="w-full bg-black border border-[#333] rounded-lg px-3 py-1.5 text-xs text-white focus:border-blue-500 outline-none"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Max Auto Amount (₹)</label>
                <SettingInput 
                  type="number" 
                  value={settings.autoIncrementMaxAmount || 50000}
                  onChange={(val: number) => handleUpdateSettings({ autoIncrementMaxAmount: val })}
                  className="w-full bg-black border border-[#333] rounded-lg px-4 py-2 text-white focus:border-purple-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Update Speed (Seconds)</label>
                <SettingInput 
                  type="number" 
                  value={settings.autoIncrementSpeed || 10}
                  onChange={(val: number) => handleUpdateSettings({ autoIncrementSpeed: val })}
                  className="w-full bg-black border border-[#333] rounded-lg px-4 py-2 text-white focus:border-purple-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Min Step (₹)</label>
                  <SettingInput 
                    type="number" 
                    value={settings.autoIncrementMinStep || 5}
                    onChange={(val: number) => handleUpdateSettings({ autoIncrementMinStep: val })}
                    className="w-full bg-black border border-[#333] rounded-lg px-4 py-2 text-white focus:border-purple-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Max Step (₹)</label>
                  <SettingInput 
                    type="number" 
                    value={settings.autoIncrementMaxStep || 50}
                    onChange={(val: number) => handleUpdateSettings({ autoIncrementMaxStep: val })}
                    className="w-full bg-black border border-[#333] rounded-lg px-4 py-2 text-white focus:border-purple-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Manual Total Amount</label>
                <div className="flex gap-2">
                  <SettingInput 
                    type="number" 
                    value={settings.totalCashbackToday}
                    onChange={(val: number) => handleUpdateSettings({ totalCashbackToday: val })}
                    className="flex-1 bg-black border border-[#333] rounded-lg px-4 py-2 text-white focus:border-purple-500 outline-none"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Custom Lists Panel */}
        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Custom Locations */}
            <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
              <h4 className="text-lg font-bold mb-6 flex items-center gap-2">
                <MapPin className="text-blue-400" size={20} />
                Custom Addresses
              </h4>
              <div className="flex gap-2 mb-4">
                <input 
                  type="text" 
                  value={newLocation}
                  onChange={(e) => setNewLocation(e.target.value)}
                  placeholder="e.g. Bandra, Mumbai"
                  className="flex-1 bg-black border border-[#333] rounded-lg px-4 py-2 text-white focus:border-blue-500 outline-none text-sm"
                />
                <button 
                  onClick={() => handleAddCustomItem('customLocations', newLocation, setNewLocation)}
                  className="bg-blue-500 text-white p-2 rounded-lg hover:bg-blue-600 transition-colors"
                >
                  <Plus size={20} />
                </button>
              </div>
              <div className="flex flex-wrap gap-2 max-h-[200px] overflow-y-auto pr-2 custom-scrollbar">
                {settings.customLocations?.map((loc: string, i: number) => (
                  <span key={`cb-tag-${i}`} className="flex items-center gap-2 bg-blue-500/10 text-blue-400 border border-blue-500/20 px-3 py-1 rounded-full text-xs font-bold">
                    {editingItem?.field === 'customLocations' && editingItem?.index === i ? (
                      <div className="flex items-center gap-1">
                        <input 
                          type="text" 
                          value={editingItem.value}
                          onChange={(e) => setEditingItem({ ...editingItem, value: e.target.value })}
                          className="bg-black border border-blue-500/50 rounded px-1 py-0.5 text-white outline-none w-24"
                          autoFocus
                        />
                        <button onClick={handleUpdateCustomItem} className="text-green-500 hover:text-green-400">
                          <Check size={12} />
                        </button>
                        <button onClick={() => setEditingItem(null)} className="text-red-500 hover:text-red-400">
                          <X size={12} />
                        </button>
                      </div>
                    ) : (
                      <>
                        {loc}
                        <div className="flex items-center gap-1">
                          <button onClick={() => setEditingItem({ field: 'customLocations', index: i, value: loc })} className="hover:text-white">
                            <Edit2 size={10} />
                          </button>
                          <button onClick={() => handleRemoveCustomItem('customLocations', loc)} className="hover:text-red-500">
                            <Trash2 size={10} />
                          </button>
                        </div>
                      </>
                    )}
                  </span>
                ))}
                {(!settings.customLocations || settings.customLocations.length === 0) && (
                  <p className="text-gray-600 text-xs italic">Using default locations</p>
                )}
              </div>
            </div>

            {/* Custom Names */}
            <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
              <h4 className="text-lg font-bold mb-6 flex items-center gap-2">
                <User className="text-green-400" size={20} />
                Custom Names
              </h4>
              <div className="flex gap-2 mb-4">
                <input 
                  type="text" 
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. ASHUTOSH"
                  className="flex-1 bg-black border border-[#333] rounded-lg px-4 py-2 text-white focus:border-green-500 outline-none text-sm"
                />
                <button 
                  onClick={() => handleAddCustomItem('customNames', newName, setNewName)}
                  className="bg-green-500 text-white p-2 rounded-lg hover:bg-green-600 transition-colors"
                >
                  <Plus size={20} />
                </button>
              </div>
              <div className="flex flex-wrap gap-2 max-h-[200px] overflow-y-auto pr-2 custom-scrollbar">
                {settings.customNames?.map((name: string, i: number) => (
                  <span key={`cb-tag-${i}`} className="flex items-center gap-2 bg-green-500/10 text-green-400 border border-green-500/20 px-3 py-1 rounded-full text-xs font-bold">
                    {editingItem?.field === 'customNames' && editingItem?.index === i ? (
                      <div className="flex items-center gap-1">
                        <input 
                          type="text" 
                          value={editingItem.value}
                          onChange={(e) => setEditingItem({ ...editingItem, value: e.target.value })}
                          className="bg-black border border-green-500/50 rounded px-1 py-0.5 text-white outline-none w-24"
                          autoFocus
                        />
                        <button onClick={handleUpdateCustomItem} className="text-green-500 hover:text-green-400">
                          <Check size={12} />
                        </button>
                        <button onClick={() => setEditingItem(null)} className="text-red-500 hover:text-red-400">
                          <X size={12} />
                        </button>
                      </div>
                    ) : (
                      <>
                        {name}
                        <div className="flex items-center gap-1">
                          <button onClick={() => setEditingItem({ field: 'customNames', index: i, value: name })} className="hover:text-white">
                            <Edit2 size={10} />
                          </button>
                          <button onClick={() => handleRemoveCustomItem('customNames', name)} className="hover:text-red-500">
                            <Trash2 size={10} />
                          </button>
                        </div>
                      </>
                    )}
                  </span>
                ))}
                {(!settings.customNames || settings.customNames.length === 0) && (
                  <p className="text-gray-600 text-xs italic">Using default names</p>
                )}
              </div>
            </div>

            {/* Custom Foods */}
            <div className="bg-[#111] border border-[#333] p-6 rounded-2xl md:col-span-2">
              <h4 className="text-lg font-bold mb-6 flex items-center gap-2">
                <Utensils className="text-orange-400" size={20} />
                Custom Food Items
              </h4>
              <div className="flex gap-2 mb-4">
                <input 
                  type="text" 
                  value={newFood}
                  onChange={(e) => setNewFood(e.target.value)}
                  placeholder="e.g. Special Gupchup"
                  className="flex-1 bg-black border border-[#333] rounded-lg px-4 py-2 text-white focus:border-orange-500 outline-none text-sm"
                />
                <button 
                  onClick={() => handleAddCustomItem('customFoods', newFood, setNewFood)}
                  className="bg-orange-500 text-white p-2 rounded-lg hover:bg-orange-600 transition-colors"
                >
                  <Plus size={20} />
                </button>
              </div>
              <div className="flex flex-wrap gap-2 max-h-[200px] overflow-y-auto pr-2 custom-scrollbar">
                {settings.customFoods?.map((food: string, i: number) => (
                  <span key={`cb-tag-${i}`} className="flex items-center gap-2 bg-orange-500/10 text-orange-400 border border-orange-500/20 px-3 py-1 rounded-full text-xs font-bold">
                    {editingItem?.field === 'customFoods' && editingItem?.index === i ? (
                      <div className="flex items-center gap-1">
                        <input 
                          type="text" 
                          value={editingItem.value}
                          onChange={(e) => setEditingItem({ ...editingItem, value: e.target.value })}
                          className="bg-black border border-orange-500/50 rounded px-1 py-0.5 text-white outline-none w-32"
                          autoFocus
                        />
                        <button onClick={handleUpdateCustomItem} className="text-green-500 hover:text-green-400">
                          <Check size={12} />
                        </button>
                        <button onClick={() => setEditingItem(null)} className="text-red-500 hover:text-red-400">
                          <X size={12} />
                        </button>
                      </div>
                    ) : (
                      <>
                        {food}
                        <div className="flex items-center gap-1">
                          <button onClick={() => setEditingItem({ field: 'customFoods', index: i, value: food })} className="hover:text-white">
                            <Edit2 size={10} />
                          </button>
                          <button onClick={() => handleRemoveCustomItem('customFoods', food)} className="hover:text-red-500">
                            <Trash2 size={10} />
                          </button>
                        </div>
                      </>
                    )}
                  </span>
                ))}
                {(!settings.customFoods || settings.customFoods.length === 0) && (
                  <p className="text-gray-600 text-xs italic">Using default foods</p>
                )}
              </div>
            </div>
          </div>

          <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
            <h4 className="text-lg font-bold mb-6 flex items-center gap-2">
              <Plus className="text-[var(--color-neon-green)]" size={20} />
              Add New Cashback Win
            </h4>
            
            <form onSubmit={handleAddWin} className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-1">
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Customer Name</label>
                <input 
                  type="text" 
                  value={newWin.customerName}
                  onChange={(e) => setNewWin({ ...newWin, customerName: e.target.value })}
                  placeholder="e.g. ASHUTOSH"
                  className="w-full bg-black border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                />
              </div>
              <div className="md:col-span-1">
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Amount (₹)</label>
                <input 
                  type="number" 
                  value={newWin.amount}
                  onChange={(e) => setNewWin({ ...newWin, amount: e.target.value })}
                  placeholder="e.g. 250"
                  className="w-full bg-black border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                />
              </div>
              <div className="md:col-span-1 flex items-end">
                <button 
                  type="submit"
                  className="w-full bg-[var(--color-neon-green)] text-black font-black py-2 rounded-lg hover:bg-[#00cc00] transition-all flex items-center justify-center gap-2"
                >
                  <Plus size={18} /> Add Record
                </button>
              </div>
            </form>
          </div>

          {/* Recent Wins List */}
          <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
            <div className="flex justify-between items-center mb-6">
              <h4 className="text-lg font-bold">Recent Wins</h4>
              <button 
                onClick={handleClearAllWins}
                className={`text-[10px] font-black uppercase tracking-widest hover:underline transition-colors ${isClearingWins ? 'text-yellow-500' : 'text-red-500'}`}
              >
                {isClearingWins ? 'Click Again to Confirm Clear' : 'Clear All Wins'}
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="text-[10px] font-black text-gray-500 uppercase tracking-widest border-b border-[#222]">
                    <th className="pb-4">Customer</th>
                    <th className="pb-4">Amount</th>
                    <th className="pb-4">Time</th>
                    <th className="pb-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#222]">
                  {wins.map((win) => (
                    <tr key={win.id} className="group hover:bg-white/[0.02]">
                      <td className="py-4 font-bold">
                        {editingWin?.id === win.id ? (
                          <input 
                            type="text" 
                            value={editingWin.customerName}
                            onChange={(e) => setEditingWin({ ...editingWin, customerName: e.target.value })}
                            className="bg-black border border-purple-500/50 rounded px-2 py-1 text-white outline-none w-full max-w-[150px]"
                            autoFocus
                          />
                        ) : (
                          win.customerName
                        )}
                      </td>
                      <td className="py-4 text-purple-400 font-black">
                        {editingWin?.id === win.id ? (
                          <input 
                            type="number" 
                            value={editingWin.amount}
                            onChange={(e) => setEditingWin({ ...editingWin, amount: e.target.value })}
                            className="bg-black border border-purple-500/50 rounded px-2 py-1 text-white outline-none w-24"
                          />
                        ) : (
                          `₹${win.amount}`
                        )}
                      </td>
                      <td className="py-4 text-xs text-gray-500">
                        {win.timestamp?.toDate ? win.timestamp.toDate().toLocaleString() : 'Just now'}
                      </td>
                      <td className="py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {editingWin?.id === win.id ? (
                            <>
                              <button 
                                onClick={handleUpdateWin}
                                className="p-2 text-green-500 hover:bg-green-500/10 rounded-lg transition-colors"
                              >
                                <Check size={16} />
                              </button>
                              <button 
                                onClick={() => setEditingWin(null)}
                                className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors"
                              >
                                <X size={16} />
                              </button>
                            </>
                          ) : (
                            <>
                              <button 
                                onClick={() => setEditingWin({ id: win.id, customerName: win.customerName, amount: win.amount?.toString() || '' })}
                                className="p-2 text-gray-600 hover:text-purple-400 transition-colors"
                              >
                                <Edit2 size={16} />
                              </button>
                              <button 
                                onClick={() => handleDeleteWin(win.id)}
                                className="p-2 text-gray-600 hover:text-red-500 transition-colors"
                              >
                                <Trash2 size={16} />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                  {wins.length === 0 && (
                    <tr>
                      <td colSpan={4} className="py-8 text-center text-gray-600 italic">No records found</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CashbackManagement;
