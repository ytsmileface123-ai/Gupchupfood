import React, { useState } from 'react';
import { Trash2, Edit2, CheckCircle, XCircle, Star, Plus, X } from 'lucide-react';
import { useStore, Review } from '../store/useStore';

export default function ReviewManagement() {
  const { reviews, deleteReview, approveReview, rejectReview, highlightReview } = useStore();
  const [error, setError] = useState<string | null>(null);

  const handleDelete = async (id: string) => {
    try {
      await deleteReview(id);
    } catch (err) {
      setError("Failed to delete review.");
    }
  };

  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-xl flex items-center justify-between">
          <p className="text-red-500 text-xs font-bold uppercase tracking-widest">{error}</p>
          <button onClick={() => setError(null)}><X size={14} className="text-red-500" /></button>
        </div>
      )}
      <h3 className="text-2xl font-black uppercase tracking-tighter">Review Management</h3>
      <div className="bg-[#111] border border-[#333] rounded-2xl overflow-hidden">
        <table className="w-full text-left text-sm text-gray-400">
          <thead className="bg-[#222] text-white uppercase text-xs font-bold">
            <tr>
              <th className="px-6 py-4">Customer</th>
              <th className="px-6 py-4">Review</th>
              <th className="px-6 py-4">Rating</th>
              <th className="px-6 py-4">Status</th>
              <th className="px-6 py-4">Actions</th>
            </tr>
          </thead>
          <tbody>
            {reviews.map(review => (
              <tr key={review.id} className="border-b border-[#333] hover:bg-[#1a1a1a]">
                <td className="px-6 py-4 text-white font-bold">{review.customerName}</td>
                <td className="px-6 py-4">{review.reviewText.substring(0, 50)}...</td>
                <td className="px-6 py-4 flex items-center gap-1">
                  {review.rating} <Star size={14} className="text-[var(--color-neon-green)]" />
                </td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase ${review.approved ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'}`}>
                    {review.approved ? 'Approved' : 'Pending'}
                  </span>
                </td>
                <td className="px-6 py-4 flex items-center gap-2">
                  <button onClick={() => approveReview(review.id)} className="text-green-500 hover:text-green-400"><CheckCircle size={18} /></button>
                  <button onClick={() => rejectReview(review.id)} className="text-red-500 hover:text-red-400"><XCircle size={18} /></button>
                  <button onClick={() => highlightReview(review.id)} className={review.highlighted ? "text-yellow-500" : "text-gray-500"}><Star size={18} /></button>
                  <button onClick={() => handleDelete(review.id)} className="text-red-500 hover:text-red-400"><Trash2 size={18} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
