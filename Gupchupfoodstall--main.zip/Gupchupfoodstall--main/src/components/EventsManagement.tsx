import React, { useState, useEffect } from 'react';
import { db, storage } from '../firebase';
import { collection, addDoc, updateDoc, deleteDoc, doc, onSnapshot, query, orderBy } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { Calendar, Trash2, Plus, Check, X, Image as ImageIcon, Video, Music, Link as LinkIcon, Save, Edit2, MapPin, Clock, Tag } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';
import { motion, AnimatePresence } from 'framer-motion';

const MediaUploadInput = ({ 
  label, 
  value, 
  onChange, 
  onError,
  placeholder = "https://...",
  accept = "video/mp4,image/*,image/gif",
  buttonText = "Upload Media",
  note = ""
}: { 
  label: string, 
  value: string, 
  onChange: (val: string) => void, 
  onError?: (err: string) => void,
  placeholder?: string,
  accept?: string,
  buttonText?: string,
  note?: string
}) => {
  const [isUploading, setIsUploading] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setIsUploading(true);
    try {
      const storageRef = ref(storage, `events/${Date.now()}_${file.name}`);
      const snapshot = await uploadBytes(storageRef, file);
      const url = await getDownloadURL(snapshot.ref);
      onChange(url);
    } catch (err) {
      if (onError) onError("Failed to upload file.");
      console.error(err);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-2">
      <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">{label}</label>
      <div className="flex flex-col gap-2">
        <input 
          type="url" 
          value={value || ''} 
          onChange={e => onChange(e.target.value)} 
          className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-2 text-sm text-white focus:border-[var(--color-neon-green)] outline-none transition-all" 
          placeholder={placeholder} 
        />
        <div className="flex items-center gap-3">
          <label className="bg-white/5 hover:bg-white/10 text-white text-[9px] font-black py-1.5 px-3 rounded-md cursor-pointer transition-all border border-white/10 uppercase tracking-wider">
            {isUploading ? "Uploading..." : buttonText}
            <input 
              type="file" 
              accept={accept} 
              className="hidden" 
              onChange={handleFileChange}
              disabled={isUploading}
            />
          </label>
          {note && <span className="text-[8px] text-gray-500 italic">{note}</span>}
        </div>
      </div>
    </div>
  );
};

export default function EventsManagement() {
  const [events, setEvents] = useState<any[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({ 
    title: '', 
    description: '', 
    date: '', 
    location: '',
    imageUrl: '', 
    videoUrl: '',
    musicUrl: '',
    couponCode: '',
    discountAmount: 0,
    expiryDate: '',
    mediaType: 'image',
    active: true,
    order: 0
  });

  useEffect(() => {
    const q = query(collection(db, 'events'), orderBy('order', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setEvents(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'events');
    });

    return () => unsubscribe();
  }, []);

  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const data = { ...form, order: Number(form.order) };
      if (editingId) {
        await updateDoc(doc(db, 'events', editingId), data);
      } else {
        await addDoc(collection(db, 'events'), data);
      }
      setIsAdding(false);
      setEditingId(null);
      setForm({ title: '', description: '', date: '', location: '', imageUrl: '', videoUrl: '', musicUrl: '', couponCode: '', discountAmount: 0, expiryDate: '', mediaType: 'image', active: true, order: events.length });
    } catch (error: any) {
      if (error.message?.includes('exceeds the maximum allowed size')) {
        setError("The event data is too large (max 1MB). This usually happens when uploading a large image or video. Please use a direct URL link instead of uploading the file.");
      } else {
        setError("Failed to save event. Please try again.");
      }
      handleFirestoreError(error, editingId ? OperationType.UPDATE : OperationType.CREATE, editingId ? `events/${editingId}` : 'events');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'events', id));
      setShowDeleteConfirm(null);
    } catch (error) {
      setError("Failed to delete event.");
      handleFirestoreError(error, OperationType.DELETE, `events/${id}`);
    }
  };

  const handleEdit = (event: any) => {
    setEditingId(event.id);
    setForm({
      title: event.title || '',
      description: event.description || '',
      date: event.date || '',
      location: event.location || '',
      imageUrl: event.imageUrl || '',
      videoUrl: event.videoUrl || '',
      musicUrl: event.musicUrl || '',
      couponCode: event.couponCode || '',
      discountAmount: event.discountAmount || 0,
      expiryDate: event.expiryDate || '',
      mediaType: event.mediaType || 'image',
      active: event.active ?? true,
      order: event.order || 0
    });
    setIsAdding(true);
  };

  return (
    <div className="space-y-8">
      {error && (
        <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-xl flex items-center justify-between">
          <p className="text-red-500 text-xs font-bold uppercase tracking-widest">{error}</p>
          <button onClick={() => setError(null)}><X size={14} className="text-red-500" /></button>
        </div>
      )}

      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-3xl font-black uppercase text-white">Events <span className="text-gray-600">Management</span></h3>
          <p className="text-gray-500 text-xs mt-1 uppercase tracking-widest">Manage upcoming special events and festivals</p>
        </div>
        <button 
          onClick={() => {
            setIsAdding(true);
            setEditingId(null);
            setForm({ title: '', description: '', date: '', location: '', imageUrl: '', videoUrl: '', musicUrl: '', couponCode: '', discountAmount: 0, expiryDate: '', mediaType: 'image', active: true, order: events.length });
          }}
          className="flex items-center gap-2 bg-[var(--color-neon-green)] text-black font-black px-6 py-3 rounded-xl hover:scale-105 transition-all active:scale-95 shadow-[0_0_20px_rgba(0,255,0,0.2)]"
        >
          <Plus size={20} />
          ADD EVENT
        </button>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="bg-[#111] border border-white/10 p-8 rounded-[2rem] shadow-2xl relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-[var(--color-neon-green)]/5 blur-3xl rounded-full"></div>
            
            <div className="flex justify-between items-center mb-8 relative z-10">
              <h4 className="text-xl font-black uppercase text-white tracking-tight">
                {editingId ? 'Edit Event' : 'Create New Event'}
              </h4>
              <button onClick={() => setIsAdding(false)} className="p-2 hover:bg-white/5 rounded-full transition-colors">
                <X size={20} className="text-gray-500" />
              </button>
            </div>

            <form onSubmit={handleSave} className="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10">
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Event Title</label>
                  <input 
                    type="text" 
                    required
                    value={form.title} 
                    onChange={e => setForm({...form, title: e.target.value})} 
                    className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all" 
                    placeholder="e.g., Street Food Festival"
                  />
                </div>

                <div className="space-y-2">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Description</label>
                  <textarea 
                    rows={4}
                    value={form.description} 
                    onChange={e => setForm({...form, description: e.target.value})} 
                    className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all resize-none" 
                    placeholder="Describe the event details..."
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Date & Time</label>
                    <div className="relative">
                      <Calendar size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                      <input 
                        type="text" 
                        required
                        value={form.date} 
                        onChange={e => setForm({...form, date: e.target.value})} 
                        className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg pl-10 pr-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all" 
                        placeholder="Sunday, 5 PM"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Location</label>
                    <div className="relative">
                      <MapPin size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                      <input 
                        type="text" 
                        value={form.location} 
                        onChange={e => setForm({...form, location: e.target.value})} 
                        className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg pl-10 pr-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all" 
                        placeholder="Main Square"
                      />
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Coupon Code</label>
                    <div className="relative">
                      <Tag size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                      <input 
                        type="text" 
                        value={form.couponCode} 
                        onChange={e => setForm({...form, couponCode: e.target.value.toUpperCase()})} 
                        className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg pl-10 pr-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all" 
                        placeholder="e.g., FESTIVAL50"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Discount (%)</label>
                    <input 
                      type="number" 
                      min="0"
                      max="100"
                      value={form.discountAmount} 
                      onChange={e => setForm({...form, discountAmount: parseInt(e.target.value) || 0})} 
                      className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all" 
                      placeholder="e.g., 20"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Coupon Expiry Date</label>
                  <input 
                    type="date" 
                    value={form.expiryDate} 
                    onChange={e => setForm({...form, expiryDate: e.target.value})} 
                    className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all" 
                  />
                </div>
              </div>

              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Media Type</label>
                    <select 
                      value={form.mediaType} 
                      onChange={e => setForm({...form, mediaType: e.target.value})} 
                      className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all"
                    >
                      <option value="image">Image</option>
                      <option value="video">Video</option>
                      <option value="gif">GIF</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Display Order</label>
                    <input 
                      type="number" 
                      value={form.order} 
                      onChange={e => setForm({...form, order: parseInt(e.target.value)})} 
                      className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all" 
                    />
                  </div>
                </div>

                <MediaUploadInput 
                  label="Image URL" 
                  value={form.imageUrl} 
                  onChange={val => setForm({...form, imageUrl: val})} 
                  onError={setError}
                  placeholder="Event poster or photo URL"
                />

                <MediaUploadInput 
                  label="Video URL (Optional)" 
                  value={form.videoUrl} 
                  onChange={val => setForm({...form, videoUrl: val})} 
                  onError={setError}
                  placeholder="Background video URL"
                  accept="video/mp4"
                />

                <MediaUploadInput 
                  label="Music URL or ZIP (Optional)" 
                  value={form.musicUrl} 
                  onChange={val => setForm({...form, musicUrl: val})} 
                  onError={setError}
                  placeholder="Background music URL or ZIP link"
                  accept="audio/*,.zip"
                  buttonText="Upload MP3/ZIP"
                  note="Max 700KB for upload. Use URL for larger files."
                />

                <div className="flex items-center gap-4 p-4 bg-black/40 rounded-xl border border-white/5">
                  <input 
                    type="checkbox" 
                    id="eventActive"
                    checked={form.active} 
                    onChange={e => setForm({...form, active: e.target.checked})} 
                    className="w-5 h-5 accent-[var(--color-neon-green)] rounded"
                  />
                  <label htmlFor="eventActive" className="text-sm font-bold text-gray-300">Active & Visible to Customers</label>
                </div>

                <div className="flex gap-4 pt-4">
                  <button 
                    type="submit" 
                    className="flex-1 bg-[var(--color-neon-green)] text-black font-black py-4 rounded-xl hover:scale-[1.02] transition-all active:scale-[0.98] shadow-lg"
                  >
                    {editingId ? 'UPDATE EVENT' : 'CREATE EVENT'}
                  </button>
                  <button 
                    type="button"
                    onClick={() => setIsAdding(false)}
                    className="px-8 bg-white/5 text-white font-black py-4 rounded-xl hover:bg-white/10 transition-all"
                  >
                    CANCEL
                  </button>
                </div>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {events.map(event => (
          <motion.div 
            layout
            key={event.id} 
            className={`group relative bg-[#111] border ${event.active ? 'border-white/10' : 'border-red-500/20'} rounded-3xl overflow-hidden hover:border-[var(--color-neon-green)]/50 transition-all duration-500`}
          >
            <div className="aspect-[16/9] relative overflow-hidden">
              <img 
                src={event.imageUrl || 'https://picsum.photos/seed/event/800/450'} 
                alt={event.title} 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent"></div>
              
              {!event.active && (
                <div className="absolute top-4 left-4 bg-red-500 text-white text-[8px] font-black px-2 py-1 rounded uppercase tracking-tighter">
                  Inactive
                </div>
              )}
              
              <div className="absolute bottom-4 left-4 right-4">
                <h4 className="text-lg font-black text-white uppercase truncate">{event.title}</h4>
                <div className="flex items-center gap-3 mt-1">
                  <div className="flex items-center gap-1 text-[10px] text-gray-400">
                    <Calendar size={10} className="text-[var(--color-neon-green)]" />
                    {event.date}
                  </div>
                  <div className="flex items-center gap-1 text-[10px] text-gray-400">
                    <MapPin size={10} className="text-[var(--color-neon-red)]" />
                    {event.location}
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6">
              <p className="text-gray-400 text-xs line-clamp-2 mb-6 h-8">{event.description}</p>
              
              <div className="flex items-center justify-between pt-4 border-t border-white/5">
                <div className="text-[10px] font-black text-gray-600 uppercase tracking-widest">
                  Order: {event.order}
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => handleEdit(event)}
                    className="p-2 bg-white/5 hover:bg-[var(--color-neon-green)] hover:text-black rounded-lg transition-all"
                  >
                    <Edit2 size={16} />
                  </button>
                  <button 
                    onClick={() => setShowDeleteConfirm(event.id)}
                    className="p-2 bg-white/5 hover:bg-red-500 hover:text-white rounded-lg transition-all"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            </div>

            <AnimatePresence>
              {showDeleteConfirm === event.id && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-6 text-center"
                >
                  <div className="space-y-4">
                    <p className="text-white font-black uppercase tracking-widest text-sm">Delete this event?</p>
                    <div className="flex gap-3">
                      <button 
                        onClick={() => handleDelete(event.id)}
                        className="bg-red-500 text-white font-black px-4 py-2 rounded-lg text-[10px] uppercase tracking-widest"
                      >
                        Confirm
                      </button>
                      <button 
                        onClick={() => setShowDeleteConfirm(null)}
                        className="bg-white/10 text-white font-black px-4 py-2 rounded-lg text-[10px] uppercase tracking-widest"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
        
        {events.length === 0 && !isAdding && (
          <div className="col-span-full py-20 text-center bg-white/[0.02] border border-dashed border-white/10 rounded-[2rem]">
            <Calendar size={48} className="mx-auto text-gray-700 mb-4" />
            <p className="text-gray-500 font-bold uppercase tracking-widest text-sm">No events found</p>
            <button 
              onClick={() => setIsAdding(true)}
              className="mt-4 text-[var(--color-neon-green)] font-black text-xs uppercase tracking-widest hover:underline"
            >
              Add your first event
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
