import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { auth, db } from '../firebase';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';

export const AuthPage: React.FC = () => {
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    setError('');
    setLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      // Check if user exists in Firestore
      const userRef = doc(db, 'users', user.uid);
      const userDoc = await getDoc(userRef);
      
      if (!userDoc.exists()) {
        // Auto create account
        const role = user.email?.toLowerCase() === 'gupchupfoodstall@gmail.com' ? 'admin' : 'customer';
        await setDoc(userRef, {
          email: user.email,
          name: user.displayName || '',
          photoURL: user.photoURL || '',
          mobile: '',
          address: '',
          location: null,
          role,
          createdAt: new Date()
        });
      }
      
      // Navigate to dashboard
      navigate('/dashboard');
    } catch (error: any) {
      console.error('Auth error:', error);
      setError(`Authentication failed: ${error.message || 'Please try again.'}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#111] p-4">
      <div className="bg-[#1a1a1a] p-8 rounded-2xl border border-[#333] w-full max-w-md text-center">
        <div className="w-20 h-20 bg-[var(--color-neon-green)] rounded-full flex items-center justify-center mx-auto mb-6 shadow-[0_0_30px_rgba(57,255,20,0.3)]">
          <span className="text-black font-black text-3xl">GC</span>
        </div>
        <h2 className="text-3xl font-black text-white mb-2 uppercase tracking-tight">
          Welcome Back
        </h2>
        <p className="text-gray-400 mb-8 text-sm">Sign in to manage your orders and profile</p>

        {error && (
          <div className="bg-red-500/10 border border-red-500/50 text-red-500 p-3 rounded-lg text-sm mb-6">
            {error}
          </div>
        )}

        <button 
          onClick={handleGoogleLogin}
          disabled={loading}
          className="w-full bg-white text-black font-bold py-3 px-4 rounded-xl hover:bg-gray-100 disabled:opacity-50 transition-all flex items-center justify-center gap-3 shadow-lg"
        >
          {loading ? (
            <Loader2 className="animate-spin" size={20} />
          ) : (
            <>
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
              </svg>
              Continue with Google
            </>
          )}
        </button>
        
        <div className="mt-8 flex flex-col gap-4">
          <Link to="/admin-login" className="text-gray-500 text-sm hover:text-[var(--color-neon-green)] transition-colors">
            Admin Panel Login
          </Link>
          <Link to="/" className="flex items-center justify-center gap-2 text-gray-500 text-sm hover:text-white transition-colors">
            <ArrowLeft size={14} /> Back to Website
          </Link>
        </div>
      </div>
    </div>
  );
};

