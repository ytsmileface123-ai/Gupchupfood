import React, { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useTransform, useSpring, AnimatePresence } from 'framer-motion';
import { useStore } from '../store/useStore';
import { ArrowRight, MapPin, Play, X } from 'lucide-react';

export default function Hero() {
  const { settings } = useStore();
  const { scrollY } = useScroll();
  const [isInView, setIsInView] = useState(true); // Default true since it's at the top
  const heroRef = useRef<HTMLElement>(null);
  
  // Smooth scroll value for more premium feel
  const smoothY = useSpring(scrollY, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsInView(entry.isIntersecting);
      },
      { threshold: 0.1 }
    );

    if (heroRef.current) {
      observer.observe(heroRef.current);
    }

    return () => {
      if (heroRef.current) {
        observer.unobserve(heroRef.current);
      }
    };
  }, []);

  const y1 = useTransform(smoothY, [0, 500], [0, 200]);
  const y2 = useTransform(smoothY, [0, 500], [0, -150]);
  const opacity = useTransform(smoothY, [0, 400], [1, 0]);
  const scale = useTransform(smoothY, [0, 500], [1, 1.15]);
  const [activeVideo, setActiveVideo] = useState<string | null>(null);
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
      console.error(`Element with id ${id} not found.`);
    }
  };

  const founders = [
    {
      name: settings.founder1Name,
      role: settings.founder1Role,
      image: settings.founder1Image,
      video: settings.founder1Video,
      accent: 'cyan',
      color: 'text-cyan-400',
      glow: 'shadow-cyan-500/20'
    },
    {
      name: settings.founder2Name,
      role: settings.founder2Role,
      image: settings.founder2Image,
      video: settings.founder2Video,
      accent: 'green',
      color: 'text-green-400',
      glow: 'shadow-green-500/20'
    }
  ];

  return (
    <section ref={heroRef} className="relative w-full min-h-screen flex flex-col items-center justify-center bg-transparent py-20 overflow-hidden">
      {/* Background Video with Parallax */}
      <motion.div style={{ y: y1, opacity, scale }} className="absolute inset-0 z-0">
        {settings.heroVideoUrl && isInView && (
          <video
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-cover opacity-40 mix-blend-screen"
            src={settings.heroVideoUrl || undefined}
          />
        )}
        {settings.isBrandingVideoEnabled && settings.brandingVideoUrl && isInView && (
          <video
            autoPlay
            loop
            muted
            playsInline
            className="absolute inset-0 w-full h-full object-cover opacity-20 mix-blend-overlay pointer-events-none"
            src={settings.brandingVideoUrl || undefined}
          />
        )}
      </motion.div>
      
      {/* Dynamic Overlay Gradients */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-transparent to-[#050505] z-[1]"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(0,255,0,0.15),transparent_70%)] z-[1]"></div>
      <div className="absolute inset-0 bg-[conic-gradient(from_0deg_at_50%_50%,rgba(0,255,0,0.05),transparent_50%)] animate-spin-slow opacity-30 z-[1]"></div>

      {/* Content with inverse parallax */}
      <motion.div 
        style={{ y: y2 }}
        className="relative z-10 text-center px-4 max-w-7xl mx-auto flex flex-col items-center justify-center gap-y-8 md:gap-y-12 w-full"
      >
        
        <div className="flex flex-col items-center gap-y-8 md:gap-y-12 w-full max-w-4xl mx-auto shrink-0">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1.8, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-6xl px-4 flex flex-col items-center mx-auto"
          >
            {/* Founders Grid - Left & Right Layout */}
            <div 
              className="flex flex-row items-start justify-center w-full mb-8 md:mb-12"
              style={{ 
                gap: `clamp(10px, 5vw, ${settings.founderSpacing || 100}px)`,
                marginTop: `${settings.founderYOffset || 0}px`,
                marginLeft: `${settings.founderXOffset || 0}px`
              }}
            >
              {founders.map((founder, index) => (
                <motion.div
                  key={`founder-${founder.name}-${index}`}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.5, delay: index * 0.2, ease: [0.16, 1, 0.3, 1] }}
                  whileHover={{ y: -15, scale: 1.02 }}
                  className="relative group w-1/2 md:w-auto max-w-sm flex flex-col items-center"
                >
                  <div className="relative flex flex-col items-center w-full">
                    {/* Circular Profile Image with Glassmorphism & Glow */}
                    <div 
                      className={`relative rounded-full p-1 md:p-2 bg-white/5 border border-white/10 overflow-hidden shadow-[0_0_60px_rgba(0,0,0,0.9)] transition-all duration-700 group-hover:${founder.glow} ${founder.video ? 'cursor-pointer' : ''}`}
                      onClick={() => founder.video && setActiveVideo(founder.video)}
                      style={{ 
                        width: `calc(clamp(6rem, 20vw, 12rem) * ${(settings.founderImageSize || 100) / 100})`,
                        height: `calc(clamp(6rem, 20vw, 12rem) * ${(settings.founderImageSize || 100) / 100})`
                      }}
                    >
                      <div className={`absolute inset-0 rounded-full border-2 border-white/5 group-hover:border-${founder.accent}-500/40 transition-colors duration-700 z-10`}></div>
                      <img 
                        src={founder.image} 
                        alt={founder.name} 
                        className="w-full h-full rounded-full object-cover transition-all duration-1000 grayscale-[0.2] group-hover:grayscale-0 scale-110 group-hover:scale-100"
                        referrerPolicy="no-referrer"
                      />
                      {founder.video && (
                        <div className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-20">
                          <Play className="w-8 h-8 md:w-12 md:h-12 text-white fill-white animate-pulse" />
                        </div>
                      )}
                    </div>

                    {/* Name & Role Badge - Glassmorphism */}
                    <div className="mt-6 md:mt-10 bg-black/60 backdrop-blur-2xl border border-white/10 px-2 md:px-12 py-3 md:py-5 rounded-2xl md:rounded-full flex flex-col md:flex-row items-center justify-center gap-1 md:gap-6 shadow-2xl group-hover:border-purple-500/40 transition-all duration-500 text-center w-full md:w-auto md:whitespace-nowrap">
                      <span className="text-[10px] md:text-base font-black uppercase tracking-[0.1em] md:tracking-[0.3em] text-white leading-tight">
                        {founder.name}
                      </span>
                      <span className={`text-[8px] md:text-xs font-black uppercase tracking-[0.1em] md:tracking-[0.3em] ${founder.color} leading-tight`}>
                        {founder.role}
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            <h1 
              className={`w-full max-w-full font-black uppercase tracking-tighter leading-[1] md:leading-[0.95] select-none ${settings.enableRgbEffect !== false ? 'text-rgb-animate' : 'text-gradient'} drop-shadow-[0_0_30px_rgba(255,255,255,0.1)] text-center break-words mx-auto px-4`}
              style={{
                fontSize: `calc(clamp(1.5rem, 10vw, 8rem) * ${(settings.heroTitleFontSize || 100) / 100})`,
                transform: `translateY(${settings.heroTitleYOffset || 0}px)`,
                letterSpacing: `${settings.heroTitleLetterSpacing ?? -0.05}em`,
                animationDuration: settings.enableRgbEffect !== false ? `${settings.rgbAnimationSpeed || 3}s` : undefined
              }}
            >
              {settings.heroTitle}
            </h1>
            <div 
              className="mt-6 md:mt-10 flex items-center justify-center gap-4 md:gap-8 w-full max-w-4xl"
              style={{ transform: `translateY(${settings.heroLinesYOffset || 0}px)` }}
            >
              <div className="h-px flex-1 bg-gradient-to-r from-transparent via-[var(--color-neon-green)] to-transparent opacity-40"></div>
              <span className="text-[10px] md:text-sm font-black uppercase tracking-[0.4em] md:tracking-[0.6em] text-white/50 whitespace-nowrap">Authentic Street Flavors</span>
              <div className="h-px flex-1 bg-gradient-to-l from-transparent via-[var(--color-neon-green)] to-transparent opacity-40"></div>
            </div>
          </motion.div>

          <motion.div
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 1.5, delay: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="relative group max-w-3xl w-full px-4"
          >
            <div className="relative glass-panel p-6 md:p-10 rounded-[2rem] md:rounded-[3rem] shadow-2xl overflow-hidden group-hover:border-white/20 transition-all duration-700 text-center">
              <p className="text-gray-300 text-sm md:text-xl italic font-medium leading-relaxed tracking-wide">
                "Mera Sapna hai ki Logo ko Apne Hato se Khana Banake Khilau isse Mere Dilko Shukun Milta hy our achchha lagta hyy, To Ayiye Mere bhai Our Bhehno Ayiye Our apna Pyar dikhayiye ❤️"
              </p>
            </div>
          </motion.div>

          <motion.div 
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 1.5, delay: 0.9, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col items-center gap-6 w-full px-4"
          >
            <div className="flex flex-col sm:flex-row justify-center items-center gap-4 w-full max-w-2xl">
              <button 
                onClick={() => scrollToSection('location-section')}
                className="group relative glass-panel text-white font-black uppercase tracking-[0.3em] py-4 px-10 rounded-full hover:bg-white/10 transition-all duration-700 flex items-center justify-center gap-3 text-[10px] md:text-xs border border-white/10 w-full sm:w-64"
              >
                <MapPin size={16} className="text-[var(--color-neon-green)]" />
                Find Us
              </button>

              <button 
                onClick={() => scrollToSection('menu-section')}
                className="group relative bg-[var(--color-neon-green)] text-black font-black uppercase tracking-[0.3em] py-4 px-10 rounded-full overflow-hidden transition-all hover:scale-105 active:scale-95 shadow-lg w-full sm:w-64"
              >
                <span className="relative flex items-center justify-center gap-3 text-[10px] md:text-xs">
                  Explore Menu <ArrowRight size={16} />
                </span>
              </button>
            </div>

            <motion.div 
              whileHover={{ scale: 1.02 }}
              onClick={() => document.getElementById('riders-section')?.scrollIntoView({ behavior: 'smooth' })}
              className="flex items-center gap-3 px-5 py-2.5 glass-panel rounded-full group hover:border-[var(--color-neon-green)]/50 transition-all cursor-pointer border border-white/5"
            >
              <div className="flex -space-x-3">
                {[1, 2, 3].map((i) => (
                  <div key={`hero-dot-${i}`} className="w-7 h-7 rounded-full border-2 border-black bg-gray-900 overflow-hidden">
                    <img src={`https://picsum.photos/seed/rider${i}/100/100`} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" />
                  </div>
                ))}
              </div>
              <div className="text-center">
                <div className="text-[8px] font-black text-[var(--color-neon-green)] uppercase tracking-wider">Fast Delivery</div>
                <div className="text-[10px] font-bold text-white uppercase tracking-tight opacity-80">By Our Riders</div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-[9px] font-black uppercase tracking-[0.3em] text-white/30">Scroll Down</span>
        <div className="w-px h-12 bg-gradient-to-b from-white/30 to-transparent"></div>
      </motion.div>

      {/* Video Modal */}
      <AnimatePresence>
        {activeVideo && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-sm p-4"
            onClick={() => setActiveVideo(null)}
          >
            <button 
              className="absolute top-6 right-6 text-white hover:text-[var(--color-neon-green)] transition-colors z-10"
              onClick={() => setActiveVideo(null)}
            >
              <X size={32} />
            </button>
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-lg aspect-[9/16] bg-black rounded-2xl overflow-hidden border border-white/10 shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <video 
                src={activeVideo || undefined} 
                autoPlay 
                controls 
                className="w-full h-full object-cover"
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
