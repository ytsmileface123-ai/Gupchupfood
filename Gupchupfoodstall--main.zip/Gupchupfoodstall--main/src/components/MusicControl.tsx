import React, { useState, useRef, useEffect } from 'react';
import { Volume2, VolumeX, Settings2 } from 'lucide-react';
import { useStore } from '../store/useStore';
import { motion, AnimatePresence } from 'framer-motion';

export const MusicControl: React.FC = () => {
  const { settings, setSettings } = useStore();
  const [isExpanded, setIsExpanded] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const pressTimer = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = settings.bgMusicVolume;
      if (settings.bgMusicUrl) {
        audioRef.current.play().catch(e => console.log("Autoplay prevented"));
      }
    }
  }, [settings.bgMusicVolume, settings.bgMusicUrl]);

  const toggleMute = () => {
    setSettings({ ...settings, bgMusicVolume: settings.bgMusicVolume === 0 ? 0.5 : 0 });
  };

  const handlePressStart = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    setIsExpanded(false); // Reset expanded state
    pressTimer.current = setTimeout(() => {
      setIsExpanded(true);
      pressTimer.current = null; // Mark as hold triggered
    }, 500); // 500ms hold
  };

  const handlePressEnd = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    if (pressTimer.current) {
      // It was a short click
      clearTimeout(pressTimer.current);
      pressTimer.current = null;
      toggleMute();
    } else {
      // It was a hold, do nothing
      pressTimer.current = null;
    }
  };

  return (
    <div className="fixed bottom-12 left-4 z-[90] flex flex-col items-start gap-2">
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.9 }}
            className="bg-black/80 backdrop-blur-xl border border-white/10 p-4 rounded-2xl shadow-2xl mb-2"
          >
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={settings.bgMusicVolume}
              onChange={(e) => setSettings({ ...settings, bgMusicVolume: parseFloat(e.target.value) })}
              className="w-24 accent-[var(--color-neon-green)]"
            />
            <button 
              onClick={() => setIsExpanded(false)}
              className="block w-full text-[10px] text-gray-400 mt-2 uppercase"
            >
              Close
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onMouseDown={handlePressStart}
        onMouseUp={handlePressEnd}
        onTouchStart={handlePressStart}
        onTouchEnd={handlePressEnd}
        className="p-4 bg-black/60 backdrop-blur-md border border-white/10 rounded-full text-[var(--color-neon-green)] hover:bg-white/10 transition-all shadow-lg"
      >
        {settings.bgMusicVolume === 0 ? <VolumeX size={24} /> : <Volume2 size={24} />}
      </button>

      {settings.bgMusicUrl && (
        <audio ref={audioRef} src={settings.bgMusicUrl} loop />
      )}
    </div>
  );
};
