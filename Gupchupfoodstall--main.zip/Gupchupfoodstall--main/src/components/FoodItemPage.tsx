import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, ShoppingBag, Flame, Plus, Check, Share2 } from 'lucide-react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { useStore, CartItem } from '../store/useStore';
import { motion } from 'framer-motion';
import ShareButton from './ShareButton';

export default function FoodItemPage() {
  const { id } = useParams<{ id: string }>();
  const [item, setItem] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const { addToCart, settings } = useStore(state => ({
    addToCart: state.addToCart,
    settings: state.settings
  }));
  
  const [spiceLevel, setSpiceLevel] = useState('Medium');
  const [toppings, setToppings] = useState<string[]>([]);

  useEffect(() => {
    if (!id) return;
    const itemDoc = doc(db, 'menuItems', id);
    const unsubscribe = onSnapshot(itemDoc, (doc) => {
      if (doc.exists()) {
        const data = doc.data();
        setItem({ id: doc.id, ...data });
        
        // Set default spice level if available
        if (data.availableSpiceLevels) {
          const options = data.availableSpiceLevels.split(',').map((s: string) => s.trim()).filter((s: string) => s !== '');
          if (options.length > 0) setSpiceLevel(options[0]);
        }
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[var(--color-neon-green)] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-400 uppercase tracking-widest text-xs font-black">Loading Deliciousness...</p>
        </div>
      </div>
    );
  }

  if (!item) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Item not found</h2>
          <Link to="/" className="text-[var(--color-neon-green)] underline">Back to Menu</Link>
        </div>
      </div>
    );
  }

  const spiceOptions = item.availableSpiceLevels ? item.availableSpiceLevels.split(',').map((s: string) => s.trim()).filter((s: string) => s !== '') : [];
  const toppingOptions = item.availableToppings ? item.availableToppings.split(',').map((t: string) => t.trim()).filter((t: string) => t !== '') : [];

  const handleAddToCart = () => {
    const cartItem: CartItem = {
      id: item.id,
      cartItemId: item.id,
      name: item.name,
      price: item.price,
      imageUrl: item.imageUrl,
      quantity: 1,
      customizations: item.isCustomizable ? { spiceLevel, toppings } : undefined
    };
    addToCart(cartItem);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 text-gray-400 hover:text-white group">
            <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" /> 
            <span className="text-xs font-black uppercase tracking-widest">Back to Menu</span>
          </Link>
          
          {settings.isFoodPageShareEnabled && (
            <ShareButton 
              title={item.name}
              text={`Check out this delicious ${item.name}!`}
              url={window.location.href}
            />
          )}
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative aspect-square rounded-[3rem] overflow-hidden border border-white/10 shadow-2xl"
          >
            <img 
              src={item.imageUrl || `https://picsum.photos/seed/${item.name}/800/800`} 
              alt={item.name} 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col"
          >
            <div className="mb-8">
              <span className="px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 mb-4 inline-block">
                {item.category}
              </span>
              <h1 className="text-5xl md:text-7xl font-black uppercase tracking-tighter mb-4 leading-none italic">{item.name}</h1>
              <div className="flex items-baseline gap-2">
                <span className="text-xl font-bold text-gray-500">₹</span>
                <span className="text-5xl font-black text-[var(--color-neon-green)] tracking-tighter">{item.price}</span>
              </div>
            </div>

            <p className="text-gray-400 mb-10 text-lg leading-relaxed italic border-l-4 border-[var(--color-neon-red)] pl-6">
              "{item.shayari}"
            </p>

            {item.isCustomizable && (
              <div className="space-y-8 mb-10">
                {spiceOptions.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <Flame size={16} className="text-[var(--color-neon-red)]" />
                      <label className="text-xs font-black text-gray-400 uppercase tracking-[0.3em]">Spice Level</label>
                    </div>
                    <div className="grid grid-cols-3 gap-3">
                      {spiceOptions.map((level: string, index: number) => (
                        <button 
                          key={`${level}-${index}`}
                          onClick={() => setSpiceLevel(level)}
                          className={`py-4 rounded-2xl text-xs font-black uppercase tracking-widest transition-all border ${
                            spiceLevel === level 
                              ? 'bg-[var(--color-neon-green)] text-black border-[var(--color-neon-green)] shadow-[0_0_20px_rgba(255,183,3,0.2)]' 
                              : 'bg-white/5 text-white border-white/5 hover:bg-white/10'
                          }`}
                        >
                          {level}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {toppingOptions.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <Plus size={16} className="text-[var(--color-neon-green)]" />
                      <label className="text-xs font-black text-gray-400 uppercase tracking-[0.3em]">Add Toppings</label>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      {toppingOptions.map((topping: string, index: number) => (
                        <button 
                          key={`${topping}-${index}`}
                          onClick={() => setToppings(prev => prev.includes(topping) ? prev.filter(t => t !== topping) : [...prev, topping])}
                          className={`py-4 px-6 rounded-2xl text-xs font-black uppercase tracking-widest transition-all border flex items-center justify-between ${
                            toppings.includes(topping) 
                              ? 'bg-white/10 text-[var(--color-neon-green)] border-[var(--color-neon-green)]/40' 
                              : 'bg-white/5 text-white border-white/5 hover:bg-white/10'
                          }`}
                        >
                          {topping}
                          {toppings.includes(topping) && <Check size={14} />}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
            
            <div className="flex gap-4">
              <motion.button 
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleAddToCart}
                className="flex-1 bg-[var(--color-neon-green)] text-black font-black uppercase tracking-[0.2em] py-5 rounded-2xl hover:bg-white transition-all duration-500 shadow-xl flex items-center justify-center gap-3"
              >
                <ShoppingBag size={20} /> Add to Cart
              </motion.button>
              
              {item.arEnabled && item.modelURL && (
                <button className="bg-white/5 border border-white/10 text-white font-black uppercase tracking-[0.2em] px-8 py-5 rounded-2xl hover:bg-white/10 transition-all">
                  View in AR
                </button>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
