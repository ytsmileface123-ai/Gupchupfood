import React, { useMemo, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, Legend } from 'recharts';
import { Package, DollarSign, TrendingUp, Calendar, RefreshCw, CheckCircle, Clock, XCircle, Trash2 } from 'lucide-react';
import { doc, deleteDoc } from 'firebase/firestore';
import { db } from '../firebase';

interface Order {
  id: string;
  status: string;
  totalAmount: number;
  createdAt: any;
  paymentMethod: string;
}

interface AnalyticsDashboardProps {
  orders: Order[];
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

export default function AnalyticsDashboard({ orders }: AnalyticsDashboardProps) {
  const [filter, setFilter] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('monthly');

  const stats = useMemo(() => {
    const completed = orders.filter(o => o.status === 'Completed').length;
    const pending = orders.filter(o => o.status === 'Pending').length;
    const processing = orders.filter(o => o.status === 'Processing').length;
    const cancelled = orders.filter(o => o.status === 'Cancelled').length;

    const totalRevenue = orders.reduce((sum, o) => sum + (o.totalAmount || 0), 0);
    
    const paymentMethods = orders.reduce((acc: any, o) => {
      acc[o.paymentMethod || 'Unknown'] = (acc[o.paymentMethod || 'Unknown'] || 0) + 1;
      return acc;
    }, {});

    return { completed, pending, processing, cancelled, totalRevenue, paymentMethods };
  }, [orders]);

  const pieData = Object.entries(stats.paymentMethods).map(([name, value]) => ({ name, value }));

  const [showConfirm, setShowConfirm] = useState(false);
  const [isResetting, setIsResetting] = useState(false);

  const handleReset = async () => {
    setIsResetting(true);
    try {
      for (const order of orders) {
        await deleteDoc(doc(db, 'orders', order.id));
      }
      setShowConfirm(false);
    } catch (error) {
      console.error('Error resetting data:', error);
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <div className="p-6 space-y-6 bg-[#0a0a0a] text-white min-h-screen">
      {showConfirm && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
          <div className="bg-[#111] p-6 rounded-xl border border-[#333] max-w-sm w-full">
            <h3 className="text-lg font-bold mb-4">Are you sure?</h3>
            <p className="text-gray-400 mb-6">This action cannot be undone.</p>
            <div className="flex gap-4">
              <button onClick={() => setShowConfirm(false)} className="flex-1 bg-[#222] py-2 rounded-lg">Cancel</button>
              <button onClick={handleReset} disabled={isResetting} className="flex-1 bg-red-600 py-2 rounded-lg font-bold">
                {isResetting ? 'Resetting...' : 'Confirm'}
              </button>
            </div>
          </div>
        </div>
      )}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Analytics Dashboard</h2>
        <div className="flex gap-2">
          <button onClick={() => window.location.reload()} className="bg-[#222] p-2 rounded-lg hover:bg-[#333]"><RefreshCw size={20} /></button>
          <button onClick={() => setShowConfirm(true)} className="bg-red-900/20 text-red-500 p-2 rounded-lg hover:bg-red-900/40"><Trash2 size={20} /></button>
          <select 
            value={filter} 
            onChange={(e) => setFilter(e.target.value as any)}
            className="bg-[#222] border border-[#333] p-2 rounded-lg"
          >
            <option value="daily">Daily</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
            <option value="yearly">Yearly</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Completed" value={stats.completed} icon={<CheckCircle className="text-green-500" />} />
        <StatCard title="Total Pending" value={stats.pending} icon={<Clock className="text-yellow-500" />} />
        <StatCard title="Total Processing" value={stats.processing} icon={<Package className="text-blue-500" />} />
        <StatCard title="Total Cancelled" value={stats.cancelled} icon={<XCircle className="text-red-500" />} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#111] p-6 rounded-xl border border-[#333]">
          <h3 className="text-lg font-bold mb-4">Revenue Growth</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={orders.slice(-10)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="createdAt" stroke="#666" />
              <YAxis stroke="#666" />
              <Tooltip contentStyle={{ backgroundColor: '#222', border: 'none' }} />
              <Line type="monotone" dataKey="totalAmount" stroke="#8884d8" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-[#111] p-6 rounded-xl border border-[#333]">
          <h3 className="text-lg font-bold mb-4">Payment Methods</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                {pieData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon }: { title: string, value: number, icon: React.ReactNode }) {
  return (
    <div className="bg-[#111] p-6 rounded-xl border border-[#333] flex items-center gap-4">
      <div className="p-3 bg-[#222] rounded-full">{icon}</div>
      <div>
        <p className="text-gray-400 text-sm">{title}</p>
        <p className="text-2xl font-bold">{value}</p>
      </div>
    </div>
  );
}
