import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { db } from '../firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { User, MapPin, Star, Heart, Info, Phone, Video, Music, FileArchive, X, Play, Pause } from 'lucide-react';
import { useStore } from '../store/useStore';

export default function RiderList() {
  const [riders, setRiders] = useState<any[]>([]);
  const [selectedRider, setSelectedRider] = useState<any | null>(null);
  const { settings } = useStore();

  useEffect(() => {
    const q = query(collection(db, 'riders'), where('isVisible', '==', true));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setRiders(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return unsubscribe;
  }, []);

  return (
    <div id="riders-section" className="py-16 bg-black text-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] font-black text-[var(--color-neon-green)] uppercase tracking-[0.3em] mb-4"
          >
            <MapPin size={14} /> Fast Delivery Service
          </motion.div>
          <h2 className="text-4xl md:text-6xl font-black mb-4 font-display uppercase tracking-tighter leading-none">
            {settings.riderSectionTitle.split(' ').map((word, i, arr) => (
              <span key={`rider-part-${i}`} className={i === arr.length - 1 ? "text-[var(--color-neon-green)]" : ""}>
                {word}{' '}
              </span>
            ))}
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg font-medium">
            {settings.riderSectionDescription}
            <span className="block mt-2 text-white font-bold uppercase text-sm tracking-widest">
              Your order will be delivered by our professional rider boys.
            </span>
          </p>
        </div>

        {riders.length === 0 ? (
          <div className="text-center py-20">
            <User className="w-16 h-16 text-gray-700 mx-auto mb-4" />
            <p className="text-xl text-gray-500">No riders available at the moment.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {riders.map(rider => (
              <RiderCard key={rider.id} rider={rider} onClick={() => setSelectedRider(rider)} />
            ))}
          </div>
        )}
      </div>

      {selectedRider && (
        <RiderModal rider={selectedRider} onClose={() => setSelectedRider(null)} />
      )}
    </div>
  );
}

function RiderCard({ rider, onClick }: { rider: any, onClick: () => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);

  return (
    <div 
      onClick={onClick}
      className="group relative bg-gray-900 rounded-2xl overflow-hidden border border-gray-800 hover:border-[var(--color-neon-green)] transition-all duration-500 cursor-pointer shadow-2xl hover:shadow-[0_0_30px_rgba(255,183,3,0.15)]"
    >
      <div className="aspect-[4/5] relative overflow-hidden bg-gray-950">
        {rider.storyVideoUrl ? (
          <video 
            ref={videoRef}
            src={rider.storyVideoUrl} 
            className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity duration-500 group-hover:scale-105"
            muted 
            loop 
            playsInline
            onMouseEnter={() => videoRef.current?.play()}
            onMouseLeave={() => {
              if (videoRef.current) {
                videoRef.current.pause();
                videoRef.current.currentTime = 0;
              }
            }}
          />
        ) : rider.imageUrl ? (
          <img 
            src={rider.imageUrl} 
            alt={rider.name} 
            className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-all duration-500 group-hover:scale-105" 
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gray-900">
            <User className="w-20 h-20 text-gray-800" />
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-80" />

        <div className="absolute top-4 left-4 z-10">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-black/60 backdrop-blur-md rounded-full border border-white/10">
            <div className="w-2 h-2 bg-[var(--color-neon-green)] rounded-full animate-pulse"></div>
            <span className="text-[10px] font-black text-white uppercase tracking-widest">Verified Rider</span>
          </div>
        </div>

        <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
          {rider.videoUrl && <div className="p-2 bg-black/50 backdrop-blur-md rounded-full text-white"><Video className="w-4 h-4" /></div>}
          {rider.musicUrl && <div className="p-2 bg-black/50 backdrop-blur-md rounded-full text-white"><Music className="w-4 h-4" /></div>}
          {rider.zipFileUrl && <div className="p-2 bg-black/50 backdrop-blur-md rounded-full text-white"><FileArchive className="w-4 h-4" /></div>}
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-6 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
          <div className="inline-block px-3 py-1 bg-[var(--color-neon-green)] text-black text-xs font-bold uppercase tracking-wider rounded-full mb-3">
            {rider.category || 'Rider'}
          </div>
          <h3 className="text-2xl font-bold text-white mb-1">{rider.name}</h3>
          
          <div className="flex items-center text-gray-300 text-sm mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
            <MapPin className="w-4 h-4 mr-1 text-[var(--color-neon-green)]" />
            <span className="truncate">{rider.address || 'Local Area'}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function RiderModal({ rider, onClose }: { rider: any, onClose: () => void }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  const toggleAudio = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <div className="absolute inset-0 bg-black/90 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative w-full max-w-5xl bg-gray-900 rounded-2xl overflow-hidden shadow-2xl border border-gray-800 flex flex-col md:flex-row max-h-[90vh]">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 bg-black/50 hover:bg-black text-white rounded-full backdrop-blur-md transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Media Section */}
        <div className="w-full md:w-1/2 bg-black relative flex-shrink-0">
          {rider.videoUrl ? (
            <video 
              src={rider.videoUrl} 
              controls 
              autoPlay 
              className="w-full h-full object-contain max-h-[50vh] md:max-h-none"
            />
          ) : rider.storyVideoUrl ? (
            <video 
              src={rider.storyVideoUrl} 
              controls 
              autoPlay 
              loop
              className="w-full h-full object-contain max-h-[50vh] md:max-h-none"
            />
          ) : rider.imageUrl ? (
            <img 
              src={rider.imageUrl} 
              alt={rider.name} 
              className="w-full h-full object-cover max-h-[50vh] md:max-h-none"
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="w-full h-full min-h-[300px] flex items-center justify-center">
              <User className="w-32 h-32 text-gray-800" />
            </div>
          )}

          {rider.musicUrl && (
            <div className="absolute bottom-4 left-4 right-4 p-4 bg-black/60 backdrop-blur-md rounded-xl border border-gray-700 flex items-center justify-between">
              <div className="flex items-center">
                <Music className="w-5 h-5 text-[var(--color-neon-green)] mr-3" />
                <div>
                  <p className="text-sm font-bold text-white">Theme Music</p>
                  <p className="text-xs text-gray-400">Playing in background</p>
                </div>
              </div>
              <button 
                onClick={toggleAudio}
                className="w-10 h-10 flex items-center justify-center bg-[var(--color-neon-green)] text-black rounded-full hover:scale-105 transition-transform"
              >
                {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-1" />}
              </button>
              <audio ref={audioRef} src={rider.musicUrl} loop autoPlay onPlay={() => setIsPlaying(true)} onPause={() => setIsPlaying(false)} />
            </div>
          )}
        </div>

        {/* Details Section */}
        <div className="w-full md:w-1/2 p-8 overflow-y-auto">
          <div className="inline-block px-3 py-1 bg-[var(--color-neon-green)]/20 text-[var(--color-neon-green)] text-xs font-bold uppercase tracking-wider rounded-full mb-4 border border-[var(--color-neon-green)]/30">
            {rider.category || 'Standard Rider'}
          </div>
          
          <h2 className="text-4xl font-bold text-white mb-6">{rider.name}</h2>

          <div className="space-y-6">
            {rider.remark && (
              <div>
                <h4 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2 flex items-center">
                  <Info className="w-4 h-4 mr-2" /> Bio
                </h4>
                <p className="text-gray-300 leading-relaxed">{rider.remark}</p>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {rider.experience && (
                <div>
                  <h4 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2 flex items-center">
                    <Star className="w-4 h-4 mr-2" /> Experience
                  </h4>
                  <p className="text-white font-medium">{rider.experience}</p>
                </div>
              )}
              
              {rider.hobby && (
                <div>
                  <h4 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2 flex items-center">
                    <Heart className="w-4 h-4 mr-2" /> Hobbies
                  </h4>
                  <p className="text-white font-medium">{rider.hobby}</p>
                </div>
              )}

              {rider.mobile && (
                <div>
                  <h4 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2 flex items-center">
                    <Phone className="w-4 h-4 mr-2" /> Contact
                  </h4>
                  <p className="text-white font-medium">{rider.mobile}</p>
                </div>
              )}

              {rider.address && (
                <div>
                  <h4 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-2 flex items-center">
                    <MapPin className="w-4 h-4 mr-2" /> Location
                  </h4>
                  <p className="text-white font-medium">{rider.address}</p>
                </div>
              )}
            </div>

            {rider.zipFileUrl && (
              <div className="pt-6 border-t border-gray-800">
                <h4 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-4">Downloads</h4>
                <a 
                  href={rider.zipFileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center px-6 py-3 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-xl text-white font-medium transition-colors"
                >
                  <FileArchive className="w-5 h-5 mr-3 text-[var(--color-neon-green)]" />
                  Download Rider Assets (ZIP)
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
