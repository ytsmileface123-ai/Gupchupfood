import React, { useState, useEffect, useRef } from 'react';
import { motion, useSpring, useTransform, animate, AnimatePresence } from 'framer-motion';
import { doc, onSnapshot, collection, query, orderBy, limit, setDoc, getDoc, updateDoc, addDoc, runTransaction } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';
import { db, auth } from '../firebase';
import { ArrowRight, Trophy, Sparkles, User, CheckCircle } from 'lucide-react';
import CashbackTicker from './CashbackTicker';
import { GoogleGenAI, Type } from "@google/genai";

interface CashbackSettings {
  totalCashbackToday: number;
  targetCashback: number;
  isEnabled: boolean;
  lastResetDate: string;
  autoReset: boolean;
  isAutoIncrementEnabled?: boolean;
  isAiModeEnabled?: boolean;
  autoIncrementMaxAmount?: number;
  autoIncrementSpeed?: number;
  autoIncrementMinStep?: number;
  autoIncrementMaxStep?: number;
  lastAutoIncrementTime?: string;
  customLocations?: string[];
  customNames?: string[];
  customFoods?: string[];
  isScheduleEnabled?: boolean;
  openTime?: string;
  closeTime?: string;
}

interface WinEvent {
  name: string;
  location: string;
  amount: number;
  foodItem: string;
}

const RANDOM_NAMES = [
  'Ashutosh', 'Suresh', 'Priya', 'Rahul', 'Anjali', 'Vikram', 'Neha', 'Amit', 'Sneha', 'Rohan',
  'Deepak', 'Kavita', 'Manish', 'Pooja', 'Sanjay', 'Meena', 'Rajesh', 'Sunita', 'Arjun', 'Shweta',
  'Vivek', 'Divya', 'Karan', 'Ritu', 'Abhishek', 'Swati', 'Nitin', 'Preeti', 'Manoj', 'Jyoti'
];

const RANDOM_LOCATIONS = ['Mumbai', 'Delhi', 'Bangalore', 'Hyderabad', 'Ahmedabad', 'Chennai', 'Kolkata', 'Surat', 'Pune', 'Jaipur'];
const RANDOM_FOODS = ['Gupchup', 'Pani Puri', 'Dahi Puri', 'Sev Puri', 'Aloo Tikki', 'Samosa', 'Vada Pav', 'Pav Bhaji'];

const CashbackDashboard: React.FC = () => {
  const [settings, setSettings] = useState<CashbackSettings | null>(null);
  const [displayValue, setDisplayValue] = useState(0);
  const [latestWinner, setLatestWinner] = useState<any>(null);
  const [aiEvents, setAiEvents] = useState<WinEvent[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const aiRef = useRef<any>(null);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      setIsAdmin(!!user);
    });

    const unsubscribe = onSnapshot(doc(db, 'cashbackSettings', 'global'), async (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data() as CashbackSettings;
        setSettings(data);
        
        // Auto-reset check
        const today = new Date().toISOString().split('T')[0];
        if (data.autoReset && data.lastResetDate !== today) {
          try {
            await runTransaction(db, async (transaction) => {
              const settingsDocRef = doc(db, 'cashbackSettings', 'global');
              const settingsDoc = await transaction.get(settingsDocRef);
              if (!settingsDoc.exists()) return;
              
              const currentData = settingsDoc.data();
              if (currentData.lastResetDate !== today) {
                transaction.update(settingsDocRef, {
                  totalCashbackToday: 0,
                  targetCashback: 0,
                  lastResetDate: today
                });
              }
            });
          } catch (error) {
            console.error("Auto-reset transaction failed:", error);
          }
        }
      } else {
        // Initialize if not exists
        const today = new Date().toISOString().split('T')[0];
        try {
          await setDoc(doc(db, 'cashbackSettings', 'global'), {
            totalCashbackToday: 0,
            targetCashback: 0,
            isEnabled: true,
            lastResetDate: today,
            autoReset: true,
            isAutoIncrementEnabled: true,
            isAiModeEnabled: true,
            autoIncrementMaxAmount: 50000,
            autoIncrementSpeed: 10,
            autoIncrementMinStep: 5,
            autoIncrementMaxStep: 50,
            lastAutoIncrementTime: new Date().toISOString()
          });
        } catch (error) {
          console.error("Initial settings creation failed:", error);
        }
      }
    });

    // Listen for latest winner
    const qWins = query(collection(db, 'cashbackWins'), orderBy('timestamp', 'desc'), limit(1));
    const unsubscribeWins = onSnapshot(qWins, (snapshot) => {
      if (!snapshot.empty) {
        const win = snapshot.docs[0].data();
        setLatestWinner({ id: snapshot.docs[0].id, ...win });
        
        // Clear notification after 5 seconds
        setTimeout(() => {
          setLatestWinner(null);
        }, 5000);
      }
    });

    return () => {
      unsubscribe();
      unsubscribeWins();
      unsubscribeAuth();
    };
  }, []);

  // AI Win Event Generation
  const isGeneratingRef = useRef<boolean>(false);
  useEffect(() => {
    if (!settings?.isAiModeEnabled || !settings?.isEnabled || aiEvents.length > 5) return;

    const generateEvents = async () => {
      if (isGeneratingRef.current) return;
      try {
        isGeneratingRef.current = true;
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: "Generate 20 realistic Indian food stall win events. Each event should have a common Indian name, a major Indian city, a cashback amount between 5 and 100, and a popular street food item. Return as a JSON array of objects with keys: name, location, amount, foodItem.",
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  location: { type: Type.STRING },
                  amount: { type: Type.NUMBER },
                  foodItem: { type: Type.STRING }
                },
                required: ["name", "location", "amount", "foodItem"]
              }
            }
          }
        });
        
        const events = JSON.parse(response.text);
        if (events && events.length > 0) {
          setAiEvents(prev => [...prev, ...events]);
        }
      } catch (error) {
        console.error("AI Win Event generation failed:", error);
      } finally {
        isGeneratingRef.current = false;
      }
    };

    generateEvents();
  }, [settings?.isAiModeEnabled, settings?.isEnabled, aiEvents.length]);

  // Auto-increment logic
  const lastWriteTimeRef = useRef<number>(0);
  const isWritingRef = useRef<boolean>(false);

  useEffect(() => {
    if (!settings || !settings.isAutoIncrementEnabled || !settings.isEnabled || !isAdmin) return;

    const interval = setInterval(async () => {
      // Prevent background tabs from writing
      if (document.visibilityState !== 'visible') return;
      
      // Prevent concurrent writes from the same client
      if (isWritingRef.current) return;
      
      const now = Date.now();
      const speedMs = (settings.autoIncrementSpeed || 10) * 1000;
      
      // 1. Local Guard: Prevent this specific client from writing too often
      // Use a larger jitter (0-3s) to stagger clients
      const jitter = Math.random() * 3000;
      if (now - lastWriteTimeRef.current < (speedMs + jitter)) return;

      // 2. Global Guard: Check if ANY client has written recently
      const lastGlobalWrite = settings.lastAutoIncrementTime ? new Date(settings.lastAutoIncrementTime).getTime() : 0;
      if (now - lastGlobalWrite < speedMs * 0.9) return;

      // Check schedule if enabled
      if (settings.isScheduleEnabled && settings.openTime && settings.closeTime) {
        const currentTime = `${new Date().getHours().toString().padStart(2, '0')}:${new Date().getMinutes().toString().padStart(2, '0')}`;
        if (currentTime < settings.openTime || currentTime > settings.closeTime) return;
      }

      const currentAmount = settings.totalCashbackToday;
      const maxAmount = settings.autoIncrementMaxAmount || 50000;
      
      if (currentAmount < maxAmount) {
        try {
          isWritingRef.current = true;
          lastWriteTimeRef.current = now;
          
          let winEvent: WinEvent;
          if (settings.isAiModeEnabled && aiEvents.length > 0) {
            winEvent = aiEvents[0];
            setAiEvents(prev => prev.slice(1));
          } else {
            const nameList = (settings.customNames && settings.customNames.length > 0) ? settings.customNames : RANDOM_NAMES;
            const locationList = (settings.customLocations && settings.customLocations.length > 0) ? settings.customLocations : RANDOM_LOCATIONS;
            const foodList = (settings.customFoods && settings.customFoods.length > 0) ? settings.customFoods : RANDOM_FOODS;

            winEvent = {
              name: nameList[Math.floor(Math.random() * nameList.length)],
              location: locationList[Math.floor(Math.random() * locationList.length)],
              amount: Math.floor(Math.random() * ((settings.autoIncrementMaxStep || 50) - (settings.autoIncrementMinStep || 5) + 1)) + (settings.autoIncrementMinStep || 5),
              foodItem: foodList[Math.floor(Math.random() * foodList.length)]
            };
          }

          // Use a transaction to ensure only one client updates at a time
          await runTransaction(db, async (transaction) => {
            const settingsDocRef = doc(db, 'cashbackSettings', 'global');
            const settingsDoc = await transaction.get(settingsDocRef);
            
            if (!settingsDoc.exists()) {
              throw "Settings doc does not exist!";
            }
            
            const data = settingsDoc.data();
            const lastGlobalWrite = data.lastAutoIncrementTime ? new Date(data.lastAutoIncrementTime).getTime() : 0;
            const nowTime = Date.now();
            
            // If someone else wrote recently, abort
            if (nowTime - lastGlobalWrite < speedMs * 0.9) {
              return;
            }
            
            const currentAmount = data.totalCashbackToday || 0;
            const maxAmount = data.autoIncrementMaxAmount || 50000;
            
            if (currentAmount < maxAmount) {
              const newAmount = Math.min(currentAmount + winEvent.amount, maxAmount);
              
              // Update total cashback and time
              transaction.update(settingsDocRef, {
                totalCashbackToday: newAmount,
                lastAutoIncrementTime: new Date().toISOString()
              });

              // Add a random win record to the ticker
              const winRef = doc(collection(db, 'cashbackWins'));
              transaction.set(winRef, {
                customerName: winEvent.name,
                location: winEvent.location,
                foodItem: winEvent.foodItem,
                amount: winEvent.amount,
                timestamp: new Date().toISOString(),
                isFake: true
              });
            }
          });
        } catch (error: any) {
          const errorMessage = error?.message || String(error);
          if (!errorMessage.includes('Connection failed') && !errorMessage.includes('offline')) {
            console.error("Auto-increment write failed:", error);
          }
        } finally {
          isWritingRef.current = false;
        }
      }
    }, 5000); // Check every 5 seconds

    return () => clearInterval(interval);
  }, [settings?.isAutoIncrementEnabled, settings?.isEnabled, settings?.lastAutoIncrementTime, aiEvents.length, isAdmin]);

  useEffect(() => {
    if (settings) {
      const controls = animate(displayValue, settings.totalCashbackToday, {
        duration: 2,
        ease: "easeOut",
        onUpdate: (value) => setDisplayValue(Math.floor(value))
      });
      return () => controls.stop();
    }
  }, [settings?.totalCashbackToday]);

  const isStallOpen = () => {
    if (!settings?.isScheduleEnabled || !settings?.openTime || !settings?.closeTime) return true;
    const now = new Date();
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    return currentTime >= settings.openTime && currentTime <= settings.closeTime;
  };

  if (!settings || !settings.isEnabled) return null;

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-12">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-[2.5rem] bg-black border border-white/10 p-8 md:p-12 shadow-[0_0_50px_rgba(0,0,0,0.8)]"
      >
        {/* Background Gradient Glow */}
        <div className="absolute -top-24 -left-24 w-64 h-64 bg-purple-600/20 rounded-full blur-[100px]" />
        <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-pink-600/20 rounded-full blur-[100px]" />
        
        <div className="relative z-10 flex flex-col items-center text-center">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] font-black text-purple-400 uppercase tracking-[0.3em] mb-8"
          >
            <Sparkles size={14} /> Cashback Disbursed Today
          </motion.div>

          <h2 className="text-6xl md:text-8xl font-black tracking-tighter mb-4 flex items-center justify-center gap-2">
            <span className="text-white opacity-50">₹</span>
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-[length:200%_auto] animate-gradient">
              {displayValue.toLocaleString('en-IN')}
            </span>
          </h2>

          <div className="flex flex-col items-center gap-2 mb-12">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full animate-pulse shadow-[0_0_8px] ${isStallOpen() ? 'bg-[var(--color-neon-green)] shadow-[var(--color-neon-green)]' : 'bg-red-500 shadow-red-500'}`} />
              <span className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">
                {isStallOpen() ? 'Live Rewards Active' : 'Rewards Paused'}
              </span>
            </div>
            {settings.isScheduleEnabled && (
              <div className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest border ${isStallOpen() ? 'bg-green-500/10 text-green-500 border-green-500/20' : 'bg-red-500/10 text-red-500 border-red-500/20'}`}>
                {isStallOpen() ? `Stall Open (Closes at ${settings.closeTime})` : `Stall Closed (Opens at ${settings.openTime})`}
              </div>
            )}
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="group relative w-full max-w-md bg-white text-black font-black py-6 px-8 rounded-2xl flex items-center justify-center gap-4 text-xl overflow-hidden transition-all hover:bg-gray-100"
          >
            Pay bills to earn cashback
            <ArrowRight className="group-hover:translate-x-2 transition-transform" />
          </motion.button>
        </div>

        {/* Live Winner Notification */}
        <AnimatePresence>
          {latestWinner && (
            <motion.div
              initial={{ opacity: 0, y: 50, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute bottom-8 left-1/2 -translate-x-1/2 z-50 w-[90%] max-w-sm"
            >
              <div className="bg-black/80 backdrop-blur-xl border border-white/20 p-4 rounded-2xl shadow-2xl flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center text-white shrink-0">
                  <User size={24} />
                </div>
                <div className="flex-1 min-w-0 text-left">
                  <div className="flex items-center gap-2">
                    <p className="font-black text-white truncate">{latestWinner.customerName}</p>
                    <CheckCircle size={14} className="text-[var(--color-neon-green)] shrink-0" />
                  </div>
                  <p className="text-[10px] text-gray-400 leading-tight">
                    From <span className="text-white">{latestWinner.location || 'Mumbai'}</span> just ordered <span className="text-white">{latestWinner.foodItem || 'Gupchup'}</span> & won <span className="text-purple-400 font-bold">₹{latestWinner.amount}</span>!
                  </p>
                </div>
                <motion.div 
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="text-yellow-400"
                >
                  <Trophy size={20} />
                </motion.div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Ticker Section */}
      <div className="mt-4">
        <CashbackTicker />
      </div>
    </div>
  );
};

export default CashbackDashboard;
