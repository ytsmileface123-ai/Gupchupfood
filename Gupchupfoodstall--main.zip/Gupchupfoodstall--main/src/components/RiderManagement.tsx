import React, { useState, useEffect } from 'react';
import { db, storage } from '../firebase';
import { collection, addDoc, updateDoc, deleteDoc, doc, onSnapshot, query } from 'firebase/firestore';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { Plus, Trash2, Eye, EyeOff, Image as ImageIcon, Video, Music, FileArchive, Film, User, Phone, MapPin, Star, Heart, Info, Tag, Upload } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

export default function RiderManagement() {
  const [riders, setRiders] = useState<any[]>([]);
  const [newRider, setNewRider] = useState({ 
    name: '', mobile: '', address: '', remark: '', experience: '', hobby: '', category: '', 
    imageUrl: '', videoUrl: '', musicUrl: '', storyVideoUrl: '', zipFileUrl: '', isVisible: false 
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});

  useEffect(() => {
    const q = query(collection(db, 'riders'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setRiders(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return unsubscribe;
  }, []);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const storageRef = ref(storage, `riders/${Date.now()}_${file.name}`);
      const uploadTask = uploadBytesResumable(storageRef, file);

      uploadTask.on('state_changed', 
        (snapshot) => {
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          setUploadProgress(prev => ({ ...prev, [field]: progress }));
        }, 
        (error) => {
          console.error("Upload error:", error);
          setUploadProgress(prev => ({ ...prev, [field]: 0 }));
        }, 
        async () => {
          const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
          setNewRider(prev => ({ ...prev, [field]: downloadURL }));
          setUploadProgress(prev => ({ ...prev, [field]: 0 }));
        }
      );
    } catch (error) {
      console.error("Upload error:", error);
    }
  };

  const saveRider = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRider.name) return;
    setIsSubmitting(true);
    try {
      if (editingId) {
        await updateDoc(doc(db, 'riders', editingId), {
          ...newRider,
          updatedAt: new Date().toISOString()
        });
      } else {
        await addDoc(collection(db, 'riders'), {
          ...newRider,
          createdAt: new Date().toISOString()
        });
      }
      cancelEdit();
    } catch (error) {
      handleFirestoreError(error, editingId ? OperationType.UPDATE : OperationType.CREATE, editingId ? `riders/${editingId}` : 'riders');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEdit = (rider: any) => {
    setEditingId(rider.id);
    setNewRider({
      name: rider.name || '',
      mobile: rider.mobile || '',
      address: rider.address || '',
      remark: rider.remark || '',
      experience: rider.experience || '',
      hobby: rider.hobby || '',
      category: rider.category || '',
      imageUrl: rider.imageUrl || '',
      videoUrl: rider.videoUrl || '',
      musicUrl: rider.musicUrl || '',
      storyVideoUrl: rider.storyVideoUrl || '',
      zipFileUrl: rider.zipFileUrl || '',
      isVisible: rider.isVisible || false
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setNewRider({ 
      name: '', mobile: '', address: '', remark: '', experience: '', hobby: '', category: '', 
      imageUrl: '', videoUrl: '', musicUrl: '', storyVideoUrl: '', zipFileUrl: '', isVisible: false 
    });
  };

  const toggleVisibility = async (id: string, isVisible: boolean) => {
    try {
      await updateDoc(doc(db, 'riders', id), { isVisible: !isVisible });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `riders/${id}`);
    }
  };

  const deleteRider = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this rider?')) {
      try {
        await deleteDoc(doc(db, 'riders', id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `riders/${id}`);
      }
    }
  };

  const renderMediaInput = (field: string, icon: React.ReactNode, placeholder: string, accept: string) => (
    <div className="space-y-2">
      <div className="relative">
        <div className="absolute left-3 top-3 text-gray-500">{icon}</div>
        <input 
          placeholder={`${placeholder} URL`} 
          value={(newRider as any)[field]} 
          onChange={e => setNewRider({...newRider, [field]: e.target.value})} 
          className="w-full pl-10 pr-4 py-2.5 bg-gray-900 border border-gray-700 rounded-lg focus:ring-2 focus:ring-[var(--color-neon-green)] focus:border-transparent outline-none transition-all" 
        />
      </div>
      <div className="flex items-center space-x-2">
        <label className="flex-1 flex items-center justify-center px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg cursor-pointer hover:bg-gray-700 transition-colors text-sm text-gray-300">
          <Upload className="w-4 h-4 mr-2" />
          Upload {placeholder.split(' ')[0]}
          <input type="file" accept={accept} className="hidden" onChange={(e) => handleFileUpload(e, field)} />
        </label>
        {uploadProgress[field] > 0 && uploadProgress[field] < 100 && (
          <div className="text-xs text-[var(--color-neon-green)] font-mono">
            {Math.round(uploadProgress[field])}%
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="p-6 bg-gray-900 text-white rounded-2xl border border-gray-800 shadow-xl">
      <div className="flex items-center justify-between mb-8 border-b border-gray-800 pb-4">
        <div>
          <h2 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-[var(--color-neon-green)] to-green-400">Rider Management</h2>
          <p className="text-gray-400 mt-1">Add and manage delivery personnel profiles</p>
        </div>
        <div className="bg-gray-800 p-3 rounded-xl flex items-center space-x-3">
          <User className="w-6 h-6 text-[var(--color-neon-green)]" />
          <span className="font-bold text-xl">{riders.length}</span>
        </div>
      </div>

      <form onSubmit={saveRider} className="bg-gray-800/50 p-6 rounded-xl border border-gray-700 mb-8 space-y-6">
        <h3 className="text-xl font-semibold mb-4 flex items-center">
          {editingId ? <ImageIcon className="w-5 h-5 mr-2 text-[var(--color-neon-green)]" /> : <Plus className="w-5 h-5 mr-2 text-[var(--color-neon-green)]" />}
          {editingId ? 'Edit Rider Profile' : 'Add New Rider'}
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Basic Info */}
          <div className="space-y-4">
            <h4 className="text-sm font-medium text-gray-400 uppercase tracking-wider border-b border-gray-700 pb-2">Basic Info</h4>
            <div className="relative">
              <User className="absolute left-3 top-3 w-5 h-5 text-gray-500" />
              <input required placeholder="Full Name *" value={newRider.name} onChange={e => setNewRider({...newRider, name: e.target.value})} className="w-full pl-10 pr-4 py-2.5 bg-gray-900 border border-gray-700 rounded-lg focus:ring-2 focus:ring-[var(--color-neon-green)] focus:border-transparent outline-none transition-all" />
            </div>
            <div className="relative">
              <Phone className="absolute left-3 top-3 w-5 h-5 text-gray-500" />
              <input placeholder="Mobile Number" value={newRider.mobile} onChange={e => setNewRider({...newRider, mobile: e.target.value})} className="w-full pl-10 pr-4 py-2.5 bg-gray-900 border border-gray-700 rounded-lg focus:ring-2 focus:ring-[var(--color-neon-green)] focus:border-transparent outline-none transition-all" />
            </div>
            <div className="relative">
              <MapPin className="absolute left-3 top-3 w-5 h-5 text-gray-500" />
              <input placeholder="Address" value={newRider.address} onChange={e => setNewRider({...newRider, address: e.target.value})} className="w-full pl-10 pr-4 py-2.5 bg-gray-900 border border-gray-700 rounded-lg focus:ring-2 focus:ring-[var(--color-neon-green)] focus:border-transparent outline-none transition-all" />
            </div>
            <div className="relative">
              <Tag className="absolute left-3 top-3 w-5 h-5 text-gray-500" />
              <input placeholder="Category (e.g., Premium, Standard)" value={newRider.category} onChange={e => setNewRider({...newRider, category: e.target.value})} className="w-full pl-10 pr-4 py-2.5 bg-gray-900 border border-gray-700 rounded-lg focus:ring-2 focus:ring-[var(--color-neon-green)] focus:border-transparent outline-none transition-all" />
            </div>
          </div>

          {/* Details */}
          <div className="space-y-4">
            <h4 className="text-sm font-medium text-gray-400 uppercase tracking-wider border-b border-gray-700 pb-2">Details</h4>
            <div className="relative">
              <Star className="absolute left-3 top-3 w-5 h-5 text-gray-500" />
              <input placeholder="Experience (e.g., 2 Years)" value={newRider.experience} onChange={e => setNewRider({...newRider, experience: e.target.value})} className="w-full pl-10 pr-4 py-2.5 bg-gray-900 border border-gray-700 rounded-lg focus:ring-2 focus:ring-[var(--color-neon-green)] focus:border-transparent outline-none transition-all" />
            </div>
            <div className="relative">
              <Heart className="absolute left-3 top-3 w-5 h-5 text-gray-500" />
              <input placeholder="Hobby" value={newRider.hobby} onChange={e => setNewRider({...newRider, hobby: e.target.value})} className="w-full pl-10 pr-4 py-2.5 bg-gray-900 border border-gray-700 rounded-lg focus:ring-2 focus:ring-[var(--color-neon-green)] focus:border-transparent outline-none transition-all" />
            </div>
            <div className="relative">
              <Info className="absolute left-3 top-3 w-5 h-5 text-gray-500" />
              <input placeholder="Remark / Bio" value={newRider.remark} onChange={e => setNewRider({...newRider, remark: e.target.value})} className="w-full pl-10 pr-4 py-2.5 bg-gray-900 border border-gray-700 rounded-lg focus:ring-2 focus:ring-[var(--color-neon-green)] focus:border-transparent outline-none transition-all" />
            </div>
          </div>

          {/* Media URLs */}
          <div className="space-y-4">
            <h4 className="text-sm font-medium text-gray-400 uppercase tracking-wider border-b border-gray-700 pb-2">Media Uploads & URLs</h4>
            {renderMediaInput('imageUrl', <ImageIcon className="w-5 h-5" />, 'Profile Image / GIF', 'image/*')}
            {renderMediaInput('storyVideoUrl', <Film className="w-5 h-5" />, 'Story Video (Vertical)', 'video/mp4,video/quicktime')}
            {renderMediaInput('videoUrl', <Video className="w-5 h-5" />, 'Full Video (MP4)', 'video/mp4,video/quicktime')}
            {renderMediaInput('musicUrl', <Music className="w-5 h-5" />, 'Background Music', 'audio/*')}
            {renderMediaInput('zipFileUrl', <FileArchive className="w-5 h-5" />, 'ZIP File (Assets)', '.zip,.rar,.7z')}
          </div>
        </div>

        <div className="pt-4 border-t border-gray-700 flex justify-end gap-3">
          {editingId && (
            <button 
              type="button" 
              onClick={cancelEdit}
              className="px-6 py-3 bg-gray-700 text-white font-bold rounded-lg hover:bg-gray-600 transition-colors"
            >
              Cancel
            </button>
          )}
          <button 
            type="submit" 
            disabled={isSubmitting || !newRider.name || Object.values(uploadProgress).some(p => p > 0 && p < 100)}
            className="flex items-center px-6 py-3 bg-[var(--color-neon-green)] text-black font-bold rounded-lg hover:bg-green-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Saving...' : editingId ? 'Update Rider Profile' : <><Plus className="w-5 h-5 mr-2" /> Add Rider Profile</>}
          </button>
        </div>
      </form>


      <div className="space-y-4">
        <h3 className="text-xl font-semibold mb-4">Current Riders</h3>
        {riders.length === 0 ? (
          <div className="text-center py-12 bg-gray-800/30 rounded-xl border border-gray-800 border-dashed">
            <User className="w-12 h-12 text-gray-600 mx-auto mb-3" />
            <p className="text-gray-400">No riders added yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {riders.map(rider => (
              <div key={rider.id} className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden flex flex-col">
                <div className="h-32 relative bg-gray-900">
                  {rider.storyVideoUrl ? (
                    <video src={rider.storyVideoUrl} autoPlay loop muted playsInline className="w-full h-full object-cover opacity-60" />
                  ) : rider.imageUrl ? (
                    <img src={rider.imageUrl} alt={rider.name} className="w-full h-full object-cover opacity-60" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center"><User className="w-12 h-12 text-gray-700" /></div>
                  )}
                  <div className="absolute top-2 right-2 flex space-x-1">
                    {rider.videoUrl && <div className="p-1.5 bg-black/60 backdrop-blur-sm rounded-md"><Video className="w-3 h-3 text-blue-400" /></div>}
                    {rider.musicUrl && <div className="p-1.5 bg-black/60 backdrop-blur-sm rounded-md"><Music className="w-3 h-3 text-pink-400" /></div>}
                    {rider.zipFileUrl && <div className="p-1.5 bg-black/60 backdrop-blur-sm rounded-md"><FileArchive className="w-3 h-3 text-yellow-400" /></div>}
                  </div>
                </div>
                
                <div className="p-4 flex-1 flex flex-col">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-bold text-lg">{rider.name}</h4>
                      <p className="text-xs text-[var(--color-neon-green)] uppercase tracking-wider">{rider.category || 'Standard'}</p>
                    </div>
                  </div>
                  
                  <div className="text-sm text-gray-400 space-y-1 mb-4 flex-1">
                    {rider.mobile && <p className="flex items-center"><Phone className="w-3 h-3 mr-2" /> {rider.mobile}</p>}
                    {rider.address && <p className="flex items-center"><MapPin className="w-3 h-3 mr-2" /> {rider.address}</p>}
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-gray-700">
                    <div className="flex gap-2">
                      <button 
                        onClick={() => toggleVisibility(rider.id, rider.isVisible)} 
                        className={`flex items-center px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${rider.isVisible ? 'bg-blue-500/20 text-blue-400 hover:bg-blue-500/30' : 'bg-gray-700 text-gray-400 hover:bg-gray-600'}`}
                      >
                        {rider.isVisible ? <><Eye className="w-4 h-4 mr-1.5" /> Visible</> : <><EyeOff className="w-4 h-4 mr-1.5" /> Hidden</>}
                      </button>
                      <button 
                        onClick={() => handleEdit(rider)} 
                        className="flex items-center px-3 py-1.5 bg-gray-700 text-gray-300 rounded-lg text-sm font-medium hover:bg-gray-600 transition-colors"
                      >
                        Edit
                      </button>
                    </div>
                    <button 
                      onClick={() => deleteRider(rider.id)} 
                      className="p-1.5 text-red-400 hover:bg-red-500/20 rounded-lg transition-colors"
                      title="Delete Rider"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

