import React from 'react';
import { useStore } from '../store/useStore';
import { Settings, Clock, ToggleLeft, ToggleRight, AlertCircle, ShoppingBag } from 'lucide-react';

export const AdminStallControl: React.FC = () => {
  const { settings, setSettings } = useStore();
  const { stallControl } = settings;

  const updateStallControl = (updates: Partial<typeof stallControl>) => {
    setSettings({ stallControl: { ...stallControl, ...updates } });
  };

  return (
    <div className="p-6 bg-gray-900 rounded-xl border border-gray-800 text-white shadow-lg">
      <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
        <Settings className="w-6 h-6 text-green-500" />
        Smart Stall Control
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Main Toggles */}
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-800 rounded-lg">
            <span className="font-medium">System Enabled</span>
            <button onClick={() => updateStallControl({ enabled: !stallControl.enabled })}>
              {stallControl.enabled ? <ToggleRight className="w-8 h-8 text-green-500" /> : <ToggleLeft className="w-8 h-8 text-gray-500" />}
            </button>
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-800 rounded-lg">
            <span className="font-medium">Pre-Order Enabled</span>
            <button onClick={() => updateStallControl({ preOrderEnabled: !stallControl.preOrderEnabled })}>
              {stallControl.preOrderEnabled ? <ToggleRight className="w-8 h-8 text-green-500" /> : <ToggleLeft className="w-8 h-8 text-gray-500" />}
            </button>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-800 rounded-lg">
            <span className="font-medium">Mode: {stallControl.mode.toUpperCase()}</span>
            <button 
              className="px-4 py-2 bg-gray-700 rounded-md hover:bg-gray-600"
              onClick={() => updateStallControl({ mode: stallControl.mode === 'auto' ? 'manual' : 'auto' })}
            >
              Switch Mode
            </button>
          </div>
        </div>

        {/* Status Controls */}
        <div className="space-y-4">
          <div className="flex gap-2">
            <button 
              className={`flex-1 py-3 rounded-lg font-bold ${stallControl.status === 'open' ? 'bg-green-600' : 'bg-gray-700'}`}
              onClick={() => updateStallControl({ status: 'open' })}
            >
              Open Now
            </button>
            <button 
              className={`flex-1 py-3 rounded-lg font-bold ${stallControl.status === 'closed' ? 'bg-red-600' : 'bg-gray-700'}`}
              onClick={() => updateStallControl({ status: 'closed' })}
            >
              Close Now
            </button>
            <button 
              className={`flex-1 py-3 rounded-lg font-bold ${stallControl.status === 'busy' ? 'bg-yellow-600' : 'bg-gray-700'}`}
              onClick={() => updateStallControl({ status: 'busy' })}
            >
              Busy Mode
            </button>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium">Open Message</label>
            <input 
              type="text"
              value={stallControl.openMessage}
              onChange={(e) => updateStallControl({ openMessage: e.target.value })}
              className="w-full p-2 bg-gray-800 rounded-md border border-gray-700"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Closed Message</label>
            <input 
              type="text"
              value={stallControl.closedMessage}
              onChange={(e) => updateStallControl({ closedMessage: e.target.value })}
              className="w-full p-2 bg-gray-800 rounded-md border border-gray-700"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
