import React from 'react';
import { motion } from 'motion/react';

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

interface CartProps {
  cartItems: CartItem[];
  onRemoveFromCart: (id: string) => void;
}

export default function Cart({ cartItems, onRemoveFromCart }: CartProps) {
  const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <motion.div
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      className="bg-white p-6 rounded-2xl shadow-2xl border border-gray-100"
    >
      <h2 className="text-2xl font-bold mb-4">Your Cart</h2>
      {cartItems.length === 0 ? (
        <p className="text-gray-500">Your cart is empty.</p>
      ) : (
        <>
          {cartItems.map((item) => (
            <div key={item.id} className="flex justify-between items-center mb-4">
              <div>
                <h3 className="font-semibold">{item.name}</h3>
                <p className="text-sm text-gray-600">₹{item.price} x {item.quantity}</p>
              </div>
              <button
                onClick={() => onRemoveFromCart(item.id)}
                className="text-red-500 hover:text-red-700"
              >
                Remove
              </button>
            </div>
          ))}
          <div className="border-t pt-4 mt-4">
            <div className="flex justify-between font-bold text-xl">
              <span>Total:</span>
              <span>₹{total}</span>
            </div>
            <button className="w-full bg-green-600 text-white py-3 rounded-full mt-4 font-bold hover:bg-green-700 transition">
              Checkout
            </button>
          </div>
        </>
      )}
    </motion.div>
  );
}
