import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus } from 'lucide-react';
import { useStore, CartItem } from '../store/useStore';
import CustomizeItemDialog from './CustomizeItemDialog';
import ARViewerDialog from './ARViewerDialog';
import ShareButton from './ShareButton';

interface MenuCardProps {
  item: CartItem & { 
    category: string; 
    shayari?: string; 
    videoUrl?: string; 
    isVideoEnabled?: boolean; 
    isCustomizable?: boolean;
    availableToppings?: string;
    availableSpiceLevels?: string;
    modelURL?: string;
    is3DEnabled?: boolean;
    arEnabled?: boolean;
  };
}

export default function MenuCard({ item }: MenuCardProps) {
  const [isMuted, setIsMuted] = useState(true);
  const [isCustomizeOpen, setIsCustomizeOpen] = useState(false);
  const [isAROpen, setIsAROpen] = useState(false);
  const [isInView, setIsInView] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const addToCart = useStore(state => state.addToCart);
  const settings = useStore(state => state.settings);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsInView(entry.isIntersecting);
      },
      { threshold: 0.1 }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => {
      if (cardRef.current) {
        observer.unobserve(cardRef.current);
      }
    };
  }, []);

  const handleAddToCart = (customizations?: { spiceLevel: string; toppings: string[] }) => {
    const cartItem: CartItem = {
      ...item,
      customizations: customizations || { spiceLevel: 'Medium', toppings: [] }
    };
    
    addToCart(cartItem);
    if (isCustomizeOpen) setIsCustomizeOpen(false);
  };

  return (
    <>
      <motion.div 
        ref={cardRef}
        whileHover={{ y: -12, scale: 1.03 }}
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="h-full flex flex-col glass-panel rounded-[3rem] overflow-hidden group relative shadow-2xl transition-all duration-700 hover:shadow-[0_30px_60px_rgba(255,183,3,0.15)] border border-white/5 hover:border-[var(--color-neon-green)]/30 bg-black/40 backdrop-blur-md"
      >
        {/* Image/Video Container */}
        <div className="relative h-80 w-full overflow-hidden shrink-0">
          {/* Animated Glow on Hover */}
          <div className="absolute -inset-4 bg-gradient-to-r from-[var(--color-neon-green)]/20 to-transparent rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-1000"></div>

          {/* Share & Mute Buttons */}
          <div className="absolute top-6 right-6 z-30 flex flex-col gap-3">
            {settings.isMenuShareEnabled && (
              <ShareButton 
                title={item.name}
                text={`Check out this delicious ${item.name}!`}
                url={`${window.location.origin}/menu/${item.id}`}
              />
            )}
            {item.isVideoEnabled && item.videoUrl && (
              <motion.button 
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setIsMuted(!isMuted)}
                className="p-3.5 bg-black/60 backdrop-blur-2xl text-white rounded-full text-sm border border-white/10 hover:border-[var(--color-neon-green)]/40 transition-all shadow-2xl flex items-center justify-center"
              >
                {isMuted ? <span className="opacity-60">🔇</span> : <span className="text-[var(--color-neon-green)]">🔊</span>}
              </motion.button>
            )}
          </div>

          {item.isVideoEnabled && item.videoUrl ? (
            <div className="relative w-full h-full">
              {isInView ? (
                <video 
                  src={item.videoUrl || undefined}
                  className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity duration-1000"
                  autoPlay
                  loop
                  muted={isMuted}
                  playsInline
                  disablePictureInPicture
                  controlsList="nodownload"
                  poster={item.imageUrl || undefined}
                />
              ) : (
                <img 
                  src={item.imageUrl || `https://picsum.photos/seed/${item.name}/400/300`} 
                  alt={item.name}
                  className="w-full h-full object-cover opacity-80"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              )}
            </div>
          ) : (
            <img 
              src={item.imageUrl || `https://picsum.photos/seed/${item.name}/400/300`} 
              alt={item.name}
              className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-all duration-1000 group-hover:scale-110"
              referrerPolicy="no-referrer"
              loading="lazy"
            />
          )}
          
          {/* Overlay Gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent opacity-90"></div>
          
          {/* AR Button */}
          {item.arEnabled && item.modelURL && (
            <motion.button 
              whileHover={{ scale: 1.05, x: 5 }}
              onClick={() => setIsAROpen(true)}
              className="absolute top-6 left-6 bg-white/10 backdrop-blur-2xl text-white text-[10px] font-black uppercase tracking-[0.3em] px-5 py-2.5 rounded-full border border-white/20 hover:bg-[var(--color-neon-green)] hover:text-black transition-all z-20 shadow-2xl"
            >
              View in AR
            </motion.button>
          )}

          {/* Price Tag */}
          <div className="absolute bottom-8 left-10 z-20">
            <span className="text-[10px] text-[var(--color-neon-green)] font-black uppercase tracking-[0.4em] block mb-1.5 opacity-80">Premium Quality</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-lg font-bold text-white/40 tracking-tighter">₹</span>
              <span className="text-5xl font-black text-white tracking-tighter drop-shadow-[0_0_20px_rgba(255,255,255,0.3)]">{item.price}</span>
            </div>
          </div>

          {/* Add Button */}
          <motion.button 
            whileHover={{ scale: 1.1, rotate: 90 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => {
              if (item.isCustomizable) {
                setIsCustomizeOpen(true);
              } else {
                handleAddToCart();
              }
            }}
            className="absolute bottom-8 right-10 bg-[var(--color-neon-green)] text-black p-6 rounded-full shadow-[0_0_40px_rgba(255,183,3,0.4)] z-20 hover:bg-white transition-all duration-700"
          >
            <Plus size={32} strokeWidth={4} />
          </motion.button>
        </div>

        {/* Content Container */}
        <div className="p-10 relative bg-gradient-to-b from-transparent to-black/20 flex-1 flex flex-col">
          <div className="absolute top-0 left-10 w-16 h-1 bg-gradient-to-r from-[var(--color-neon-green)] to-transparent opacity-60"></div>
          
          <a href={`/menu/${item.id}`} className="block mb-5">
            <h3 className="text-4xl font-black text-white group-hover:text-[var(--color-neon-green)] transition-all duration-700 uppercase tracking-tighter leading-none italic">
              {item.name}
            </h3>
          </a>
          
          <div className="flex items-center gap-4 mb-4">
            <span className="px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">
              {item.category}
            </span>
            {item.isCustomizable && (
              <span className="px-4 py-1.5 rounded-full bg-[var(--color-neon-green)]/10 border border-[var(--color-neon-green)]/20 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--color-neon-green)]">
                Customizable
              </span>
            )}
          </div>

          {/* Shayari / Lalach Effect */}
          {item.shayari && (
            <div className="relative group/shayari mt-auto">
              <div className="absolute -left-5 top-0 bottom-0 w-1 bg-gradient-to-b from-[var(--color-neon-red)] to-transparent opacity-40 group-hover/shayari:opacity-100 transition-opacity duration-700"></div>
              <p className="text-base text-gray-400 italic font-medium leading-relaxed tracking-wide pl-3 group-hover/shayari:text-gray-200 transition-colors duration-700">
                "{item.shayari}"
              </p>
            </div>
          )}
        </div>
      </motion.div>

      <CustomizeItemDialog 
        item={item} 
        isOpen={isCustomizeOpen} 
        onClose={() => setIsCustomizeOpen(false)} 
        onConfirm={handleAddToCart}
        availableToppings={item.availableToppings}
        availableSpiceLevels={item.availableSpiceLevels}
      />

      {item.modelURL && (
        <ARViewerDialog
          isOpen={isAROpen}
          onClose={() => setIsAROpen(false)}
          modelURL={item.modelURL}
          itemName={item.name}
        />
      )}
    </>
  );
}