import React from 'react';
import { useStore, SectionConfig } from '../store/useStore';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

export default function SectionManagement() {
  const { settings, setSettings } = useStore();

  const toggleSection = async (sectionId: string, field: keyof SectionConfig) => {
    const newSettings = {
      ...settings,
      sections: {
        ...settings.sections,
        [sectionId]: {
          ...settings.sections[sectionId],
          [field]: !settings.sections[sectionId][field]
        }
      }
    };
    
    try {
      await setDoc(doc(db, 'settings', 'global'), newSettings);
      setSettings(newSettings);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'settings/global');
    }
  };

  return (
    <div className="p-6 bg-[#111] border border-[#333] rounded-2xl">
      <h2 className="text-white font-bold text-xl mb-6">Section Intelligence Engine</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {Object.entries(settings.sections || {}).map(([id, config]) => (
          <div key={id} className="p-4 bg-[#1a1a1a] border border-[#333] rounded-lg">
            <h3 className="text-white font-bold capitalize mb-3">{id.replace(/([A-Z])/g, ' $1')}</h3>
            <div className="flex flex-wrap gap-2">
              <button 
                onClick={() => toggleSection(id, 'enabled')}
                className={`px-3 py-1 text-xs font-bold rounded ${config.enabled ? 'bg-[var(--color-neon-green)] text-black' : 'bg-[#333] text-gray-400'}`}
              >
                Enabled
              </button>
              <button 
                onClick={() => toggleSection(id, 'aiAccess')}
                className={`px-3 py-1 text-xs font-bold rounded ${config.aiAccess ? 'bg-[var(--color-neon-green)] text-black' : 'bg-[#333] text-gray-400'}`}
              >
                AI Access
              </button>
              <button 
                onClick={() => toggleSection(id, 'customerVisibility')}
                className={`px-3 py-1 text-xs font-bold rounded ${config.customerVisibility ? 'bg-[var(--color-neon-green)] text-black' : 'bg-[#333] text-gray-400'}`}
              >
                Visible
              </button>
              <button 
                onClick={() => toggleSection(id, 'dataAnalysis')}
                className={`px-3 py-1 text-xs font-bold rounded ${config.dataAnalysis ? 'bg-[var(--color-neon-green)] text-black' : 'bg-[#333] text-gray-400'}`}
              >
                Analysis
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
