import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Instagram } from 'lucide-react';
import { useStore } from '../store/useStore';
import ShareButton from './ShareButton';

interface Influencer {
  id: string;
  name: string;
  instagramHandle?: string;
  imageUrl: string;
}

export default function FeaturedInfluencers({ influencers }: { influencers: Influencer[] }) {
  const { settings } = useStore();
  if (!influencers || influencers.length === 0) return null;

  return (
    <section className="py-40 px-4 relative overflow-hidden bg-transparent border-t border-white/5">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[var(--color-neon-green)]/5 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="mb-24 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex items-center justify-center gap-4 mb-6"
          >
            <div className="w-12 h-px bg-[var(--color-neon-green)]"></div>
            <span className="text-[var(--color-neon-green)] font-black uppercase tracking-[0.5em] text-[10px]">The Community</span>
            <div className="w-12 h-px bg-[var(--color-neon-green)]"></div>
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-8xl font-black uppercase text-white tracking-tighter leading-none italic"
          >
            Featured <span className="text-white/20">Vibers</span>
          </motion.h2>
        </div>
        
        <div className="flex gap-10 overflow-x-auto pb-12 no-scrollbar snap-x">
          {influencers.map((influencer, index) => (
            <motion.div 
              key={influencer.id} 
              id={`influencer-${influencer.id}`}
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -20 }}
              className="min-w-[280px] md:min-w-[320px] glass-panel rounded-[3rem] p-10 border-white/10 flex flex-col items-center text-center group hover:bg-white/10 transition-all duration-700 snap-center relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-b from-[var(--color-neon-green)]/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
              
              <div className="absolute top-6 right-6 z-30">
                {settings.isInfluencersShareEnabled && (
                  <ShareButton 
                    title={`Influencer: ${influencer.name}`}
                    text={`Check out this influencer: ${influencer.name}!`}
                    url={`${window.location.origin}/#influencer-${influencer.id}`}
                    iconSize={12}
                  />
                )}
              </div>

              <div className="relative mb-8">
                <div className="absolute -inset-4 bg-[var(--color-neon-green)]/20 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
                <img 
                  src={influencer.imageUrl || `https://picsum.photos/seed/${influencer.id}/200/200`} 
                  alt={influencer.name} 
                  className="w-32 h-32 rounded-full border-4 border-white/10 group-hover:border-[var(--color-neon-green)] transition-all duration-700 object-cover relative z-10 shadow-2xl" 
                  referrerPolicy="no-referrer" 
                />
              </div>

              <h4 className="text-2xl font-black text-white mb-4 uppercase tracking-tight italic group-hover:text-[var(--color-neon-green)] transition-colors relative z-10">
                {influencer.name}
              </h4>
              
              <motion.a 
                href={influencer.instagramHandle ? `https://instagram.com/${influencer.instagramHandle.replace('@', '')}` : '#'} 
                target="_blank" 
                rel="noopener noreferrer" 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="flex items-center gap-3 px-6 py-3 rounded-full bg-white/5 border border-white/10 text-[10px] font-black text-white/60 uppercase tracking-[0.3em] hover:bg-[var(--color-neon-green)] hover:text-black hover:border-[var(--color-neon-green)] transition-all duration-500 relative z-10"
              >
                <Instagram size={14} />
                {influencer.instagramHandle || 'Connect'}
                <ExternalLink size={12} className="opacity-40" />
              </motion.a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
