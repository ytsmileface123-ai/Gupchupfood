import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { db } from '../firebase';
import { collection, query, orderBy, limit, onSnapshot, doc } from 'firebase/firestore';

interface CashbackWin {
  id: string;
  customerName: string;
  location?: string;
  foodItem?: string;
  amount: number;
  timestamp: any;
}

const CashbackTicker: React.FC = () => {
  const [wins, setWins] = useState<CashbackWin[]>([]);
  const [settings, setSettings] = useState<any>(null);

  useEffect(() => {
    const unsubscribeSettings = onSnapshot(doc(db, 'cashbackSettings', 'global'), (snapshot) => {
      if (snapshot.exists()) {
        setSettings(snapshot.data());
      }
    });

    const q = query(collection(db, 'cashbackWins'), orderBy('timestamp', 'desc'), limit(10));
    const unsubscribeWins = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CashbackWin));
      setWins(data);
    });

    return () => {
      unsubscribeSettings();
      unsubscribeWins();
    };
  }, []);

  const isStallOpen = () => {
    if (!settings?.isScheduleEnabled || !settings?.openTime || !settings?.closeTime) return true;
    const now = new Date();
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    return currentTime >= settings.openTime && currentTime <= settings.closeTime;
  };

  if (settings && !settings.isEnabled) return null;

  if (!isStallOpen()) {
    return (
      <div className="w-full overflow-hidden bg-red-950/20 backdrop-blur-md border-t border-red-500/10 py-3">
        <div className="flex justify-center items-center gap-4 text-[10px] font-black uppercase tracking-[0.3em] text-red-400/60">
          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
          Stall Currently Closed • Rewards Paused • Opens at {settings?.openTime}
          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
        </div>
      </div>
    );
  }

  if (wins.length === 0) {
    // Mock data if empty
    const mockWins = [
      { id: '1', customerName: 'ASHUTOSH', location: 'Mumbai', foodItem: 'Gupchup', amount: 250 },
      { id: '2', customerName: 'SURESH', location: 'Delhi', foodItem: 'Pani Puri', amount: 15 },
      { id: '3', customerName: 'PRIYA', location: 'Bangalore', foodItem: 'Dahi Puri', amount: 120 },
      { id: '4', customerName: 'RAHUL', location: 'Pune', foodItem: 'Vada Pav', amount: 45 },
    ];
    
    return (
      <div className="w-full overflow-hidden bg-black/50 backdrop-blur-md border-t border-white/5 py-3">
        <div className="flex whitespace-nowrap animate-marquee">
          {[...mockWins, ...mockWins].map((win, i) => (
            <div key={`${win.id}-${i}`} className="flex items-center gap-2 mx-8 text-[10px] font-bold uppercase tracking-widest text-gray-400">
              <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
              <span className="text-white">{win.customerName}</span>
              <span className="text-gray-600">from</span>
              <span className="text-gray-300">{win.location}</span>
              <span className="text-gray-600">ordered</span>
              <span className="text-gray-300">{win.foodItem}</span>
              <span className="text-gray-600">& won</span>
              <span className="text-purple-400">₹{win.amount}</span>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="w-full overflow-hidden bg-black/50 backdrop-blur-md border-t border-white/5 py-3">
      <div className="flex whitespace-nowrap animate-marquee">
        {[...wins, ...wins].map((win, i) => (
          <div key={`${win.id}-${i}`} className="flex items-center gap-2 mx-8 text-[10px] font-bold uppercase tracking-widest text-gray-400">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
            <span className="text-white">{win.customerName}</span>
            {win.location && (
              <>
                <span className="text-gray-600">from</span>
                <span className="text-gray-300">{win.location}</span>
              </>
            )}
            {win.foodItem && (
              <>
                <span className="text-gray-600">ordered</span>
                <span className="text-gray-300">{win.foodItem}</span>
              </>
            )}
            <span className="text-gray-600">& won</span>
            <span className="text-purple-400">₹{win.amount}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CashbackTicker;
