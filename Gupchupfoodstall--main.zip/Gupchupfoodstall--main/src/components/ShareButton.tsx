import React from 'react';
import { Share2, Copy, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface ShareButtonProps {
  title: string;
  text: string;
  url: string;
  className?: string;
  iconSize?: number;
}

export default function ShareButton({ title, text, url, className = "", iconSize = 18 }: ShareButtonProps) {
  const [copied, setCopied] = React.useState(false);

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title,
          text,
          url,
        });
      } catch (error) {
        if ((error as Error).name !== 'AbortError') {
          console.error('Error sharing:', error);
        }
      }
    } else {
      // Fallback: Copy to clipboard
      try {
        await navigator.clipboard.writeText(url);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (err) {
        console.error('Failed to copy: ', err);
      }
    }
  };

  return (
    <div className={`relative ${className}`}>
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={handleShare}
        className="p-2.5 bg-white/5 hover:bg-white/10 rounded-full border border-white/10 text-white transition-all shadow-xl group/share flex items-center justify-center"
        title="Share"
      >
        {copied ? (
          <Check size={iconSize} className="text-[var(--color-neon-green)]" />
        ) : (
          <Share2 size={iconSize} className="group-hover/share:text-[var(--color-neon-green)] transition-colors" />
        )}
      </motion.button>
      
      <AnimatePresence>
        {copied && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1 bg-[var(--color-neon-green)] text-black text-[10px] font-black uppercase tracking-widest rounded-md whitespace-nowrap z-50 pointer-events-none"
          >
            Link Copied!
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
