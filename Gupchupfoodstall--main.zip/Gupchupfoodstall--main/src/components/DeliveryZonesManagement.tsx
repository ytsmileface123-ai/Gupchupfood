import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { Plus, Trash2, Edit2, MapPin, ShieldAlert, ShieldCheck } from 'lucide-react';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

export default function DeliveryZonesManagement() {
  const { settings, setSettings } = useStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingZoneId, setEditingZoneId] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    country: 'India',
    state: '',
    district: '',
    city: '',
    active: true
  });

  const persistSettings = async (newSettings: any) => {
    try {
      const updatedSettings = { ...settings, ...newSettings };
      await setDoc(doc(db, 'settings', 'global'), updatedSettings);
      setSettings(newSettings);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'settings/global');
    }
  };

  const handleOpenModal = (zone?: any) => {
    if (zone) {
      setEditingZoneId(zone.id);
      setFormData({
        country: zone.country,
        state: zone.state,
        district: zone.district,
        city: zone.city,
        active: zone.active
      });
    } else {
      setEditingZoneId(null);
      setFormData({
        country: 'India',
        state: '',
        district: '',
        city: '',
        active: true
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const currentZones = settings.deliveryZones || [];
    const currentFees = settings.deliveryFeeByLocation || [];
    
    if (editingZoneId) {
      const updatedZones = currentZones.map(zone => 
        zone.id === editingZoneId ? { ...formData, id: editingZoneId } : zone
      );
      // Update location name in deliveryFeeByLocation if it exists
      const updatedFees = currentFees.map(fee => 
        fee.id === editingZoneId ? { ...fee, location: `${formData.city}, ${formData.district}` } : fee
      );
      await persistSettings({ deliveryZones: updatedZones, deliveryFeeByLocation: updatedFees });
    } else {
      const newId = Date.now().toString() + Math.random().toString(36).substring(7);
      const newZone = { ...formData, id: newId };
      const newFee = { id: newId, location: `${formData.city}, ${formData.district}`, fee: 0 };
      await persistSettings({ 
        deliveryZones: [...currentZones, newZone],
        deliveryFeeByLocation: [...currentFees, newFee]
      });
    }
    setIsModalOpen(false);
  };

  const handleDelete = async (id: string) => {
    const currentZones = settings.deliveryZones || [];
    const currentFees = settings.deliveryFeeByLocation || [];
    await persistSettings({ 
      deliveryZones: currentZones.filter(z => z.id !== id),
      deliveryFeeByLocation: currentFees.filter(f => f.id !== id)
    });
  };

  const toggleRestriction = async () => {
    await persistSettings({ isDeliveryRestrictionEnabled: !settings.isDeliveryRestrictionEnabled });
  };

  const toggleZoneActive = async (id: string) => {
    const currentZones = settings.deliveryZones || [];
    const updatedZones = currentZones.map(zone => 
      zone.id === id ? { ...zone, active: !zone.active } : zone
    );
    await persistSettings({ deliveryZones: updatedZones });
  };

  return (
    <div className="space-y-8">
      {/* Header & Master Toggle */}
      <div className="bg-[#111] border border-[#333] rounded-2xl p-6 md:p-8 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-[var(--color-neon-green)] to-transparent"></div>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <h3 className="text-2xl font-black uppercase text-white tracking-tighter flex items-center gap-3">
              <MapPin className="text-[var(--color-neon-green)]" /> Delivery Restriction System
            </h3>
            <p className="text-gray-400 text-sm mt-2 max-w-2xl">
              Control exactly where you accept orders. If enabled, customers outside your defined active zones will be blocked from placing orders.
            </p>
          </div>
          
          <div className="flex items-center gap-4 bg-black/50 p-4 rounded-xl border border-white/5">
            <div className="flex flex-col">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">System Status</span>
              <span className={`text-sm font-black uppercase ${settings.isDeliveryRestrictionEnabled ? 'text-[var(--color-neon-green)]' : 'text-red-500'}`}>
                {settings.isDeliveryRestrictionEnabled ? 'Strict Mode (Active)' : 'All Areas Allowed'}
              </span>
            </div>
            <button 
              onClick={toggleRestriction}
              className={`relative inline-flex h-8 w-14 items-center rounded-full transition-colors ${settings.isDeliveryRestrictionEnabled ? 'bg-[var(--color-neon-green)]' : 'bg-gray-600'}`}
            >
              <span className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${settings.isDeliveryRestrictionEnabled ? 'translate-x-7' : 'translate-x-1'}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Zones List */}
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h4 className="text-lg font-bold text-white uppercase tracking-widest">Allowed Delivery Zones</h4>
          <button 
            onClick={() => handleOpenModal()}
            className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2 transition-colors border border-white/10 text-sm"
          >
            <Plus size={16} /> Add New Area
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {(settings.deliveryZones || []).map((zone, index) => (
            <div key={zone.id || `zone-${index}`} className={`bg-[#111] border ${zone.active ? 'border-[var(--color-neon-green)]/30' : 'border-[#333] opacity-60'} rounded-xl p-5 relative group transition-all`}>
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-2">
                  {zone.active ? (
                    <ShieldCheck size={18} className="text-[var(--color-neon-green)]" />
                  ) : (
                    <ShieldAlert size={18} className="text-gray-500" />
                  )}
                  <span className={`text-xs font-black uppercase tracking-widest ${zone.active ? 'text-[var(--color-neon-green)]' : 'text-gray-500'}`}>
                    {zone.active ? 'Delivery Allowed' : 'Currently Blocked'}
                  </span>
                </div>
                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => handleOpenModal(zone)} className="text-blue-400 hover:text-blue-300"><Edit2 size={16} /></button>
                  <button onClick={() => handleDelete(zone.id)} className="text-red-500 hover:text-red-400"><Trash2 size={16} /></button>
                </div>
              </div>
              
              <div className="space-y-1">
                <h5 className="text-xl font-black text-white uppercase">{zone.city}</h5>
                <p className="text-sm text-gray-400">{zone.district}, {zone.state}</p>
                <p className="text-xs text-gray-600">{zone.country}</p>
              </div>

              <div className="mt-4 pt-4 border-t border-[#222] flex justify-between items-center">
                <span className="text-xs text-gray-500 font-medium">Toggle Area</span>
                <button 
                  onClick={() => toggleZoneActive(zone.id)}
                  className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${zone.active ? 'bg-[var(--color-neon-green)]' : 'bg-gray-600'}`}
                >
                  <span className={`inline-block h-3 w-3 transform rounded-full bg-white transition-transform ${zone.active ? 'translate-x-5' : 'translate-x-1'}`} />
                </button>
              </div>
            </div>
          ))}

          {(!settings.deliveryZones || settings.deliveryZones.length === 0) && (
            <div className="col-span-full py-12 text-center bg-[#111] border border-[#333] border-dashed rounded-xl">
              <MapPin className="mx-auto mb-3 text-gray-600" size={32} />
              <p className="text-gray-400 font-medium">No delivery zones defined.</p>
              <p className="text-xs text-gray-500 mt-1">If restriction is enabled, no orders will be accepted.</p>
            </div>
          )}
        </div>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-[#111] border border-[#333] rounded-2xl w-full max-w-md">
            <div className="p-6 border-b border-[#333]">
              <h3 className="text-xl font-black uppercase text-white">{editingZoneId ? 'Edit Delivery Area' : 'Add Delivery Area'}</h3>
            </div>
            <form onSubmit={handleSave} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">City / Village / Local Area *</label>
                <input 
                  required
                  type="text" 
                  value={formData.city} 
                  onChange={e => setFormData({...formData, city: e.target.value})} 
                  className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none" 
                  placeholder="e.g., Mohodipur, Malda Town" 
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">District *</label>
                <input 
                  required
                  type="text" 
                  value={formData.district} 
                  onChange={e => setFormData({...formData, district: e.target.value})} 
                  className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none" 
                  placeholder="e.g., Malda" 
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">State *</label>
                  <input 
                    required
                    type="text" 
                    value={formData.state} 
                    onChange={e => setFormData({...formData, state: e.target.value})} 
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none" 
                    placeholder="e.g., West Bengal" 
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Country</label>
                  <input 
                    required
                    type="text" 
                    value={formData.country} 
                    onChange={e => setFormData({...formData, country: e.target.value})} 
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none" 
                  />
                </div>
              </div>
              
              <div className="flex items-center gap-3 pt-4 border-t border-[#333] mt-6">
                <input 
                  type="checkbox" 
                  id="zoneActive" 
                  checked={formData.active} 
                  onChange={e => setFormData({...formData, active: e.target.checked})} 
                  className="w-5 h-5 accent-[var(--color-neon-green)]" 
                />
                <label htmlFor="zoneActive" className="text-sm text-white font-bold cursor-pointer">Active (Allow Delivery)</label>
              </div>

              <div className="flex gap-4 pt-6">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 bg-[#222] text-white font-bold py-3 rounded-lg hover:bg-[#333] transition-colors">Cancel</button>
                <button type="submit" className="flex-1 bg-[var(--color-neon-green)] text-black font-bold py-3 rounded-lg hover:bg-white transition-colors">Save Area</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
