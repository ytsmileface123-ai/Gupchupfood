import React from 'react';
import { Users, Star, TrendingUp, Award } from 'lucide-react';
import { Review } from '../../store/useStore';

interface TrustAnalyticsProps {
  reviews: Review[];
}

export default function TrustAnalytics({ reviews }: TrustAnalyticsProps) {
  const approvedReviews = reviews.filter(r => r.approved);
  const totalReviews = approvedReviews.length;
  const averageRating = totalReviews > 0 
    ? (approvedReviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews).toFixed(1) 
    : 0;
  
  const topReview = approvedReviews.reduce((prev, current) => 
    (prev.rating > current.rating) ? prev : current, approvedReviews[0]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
      <div className="bg-[#111] border border-[#333] p-6 rounded-2xl flex items-center gap-4">
        <div className="p-4 bg-[var(--color-neon-green)]/10 rounded-full text-[var(--color-neon-green)]">
          <Users size={24} />
        </div>
        <div>
          <p className="text-gray-400 text-sm">Customers Supported</p>
          <h3 className="text-2xl font-black text-white">{totalReviews * 12}</h3>
        </div>
      </div>
      <div className="bg-[#111] border border-[#333] p-6 rounded-2xl flex items-center gap-4">
        <div className="p-4 bg-[var(--color-neon-green)]/10 rounded-full text-[var(--color-neon-green)]">
          <Star size={24} />
        </div>
        <div>
          <p className="text-gray-400 text-sm">Average Rating</p>
          <h3 className="text-2xl font-black text-white">{averageRating}</h3>
        </div>
      </div>
      <div className="bg-[#111] border border-[#333] p-6 rounded-2xl flex items-center gap-4">
        <div className="p-4 bg-[var(--color-neon-green)]/10 rounded-full text-[var(--color-neon-green)]">
          <Award size={24} />
        </div>
        <div>
          <p className="text-gray-400 text-sm">Total Reviews</p>
          <h3 className="text-2xl font-black text-white">{totalReviews}</h3>
        </div>
      </div>
    </div>
  );
}
