import React from 'react';
import { Star, ExternalLink } from 'lucide-react';
import { Review } from '../../store/useStore';

interface ReviewCardProps {
  review: Review;
}

export default function ReviewCard({ review }: ReviewCardProps) {
  return (
    <div className="bg-[#111] border border-[#333] p-6 rounded-2xl shadow-lg hover:border-[var(--color-neon-green)] transition-all duration-300">
      <div className="flex items-center gap-4 mb-4">
        {review.customerImageUrl ? (
          <img src={review.customerImageUrl} alt={review.customerName} className="w-12 h-12 rounded-full object-cover" referrerPolicy="no-referrer" />
        ) : (
          <div className="w-12 h-12 rounded-full bg-gray-800 flex items-center justify-center text-gray-500 font-bold">
            {review.customerName.charAt(0).toUpperCase()}
          </div>
        )}
        <div>
          <h4 className="text-white font-bold">{review.customerName}</h4>
          <div className="flex gap-0.5">
            {[...Array(5)].map((_, i) => (
              <Star 
                key={i} 
                size={14} 
                className={i < review.rating ? "text-[var(--color-neon-green)] fill-[var(--color-neon-green)]" : "text-gray-600"} 
              />
            ))}
          </div>
        </div>
        {review.customerUrl && (
          <a href={review.customerUrl} target="_blank" rel="noopener noreferrer" className="ml-auto text-gray-500 hover:text-white">
            <ExternalLink size={16} />
          </a>
        )}
      </div>
      <p className="text-gray-300 text-sm mb-4">{review.reviewText}</p>
      {review.imageUrl && (
        <img src={review.imageUrl} alt="Review" className="w-full h-40 object-cover rounded-lg" referrerPolicy="no-referrer" />
      )}
    </div>
  );
}
