import React, { useState } from 'react';
import { Star, Upload } from 'lucide-react';
import { useStore } from '../../store/useStore';

export default function ReviewForm() {
  const { addReview } = useStore();
  const [customerName, setCustomerName] = useState('');
  const [reviewText, setReviewText] = useState('');
  const [rating, setRating] = useState(5);
  const [imageUrl, setImageUrl] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addReview({
      customerName,
      reviewText,
      rating,
      imageUrl,
      approved: false,
      highlighted: false
    });
    setCustomerName('');
    setReviewText('');
    setRating(5);
    setImageUrl('');
  };

  return (
    <form onSubmit={handleSubmit} className="bg-[#111] border border-[#333] p-8 rounded-3xl mt-12">
      <h3 className="text-2xl font-black text-white mb-6">Leave a Review</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <input 
          type="text" 
          placeholder="Your Name" 
          value={customerName}
          onChange={e => setCustomerName(e.target.value)}
          className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none"
          required
        />
        <div className="flex items-center gap-2">
          {[1, 2, 3, 4, 5].map((star) => (
            <Star 
              key={star} 
              size={24} 
              className={`cursor-pointer ${star <= rating ? "text-[var(--color-neon-green)] fill-[var(--color-neon-green)]" : "text-gray-600"}`}
              onClick={() => setRating(star)}
            />
          ))}
        </div>
      </div>
      <textarea 
        placeholder="Your Review" 
        value={reviewText}
        onChange={e => setReviewText(e.target.value)}
        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none mt-6 h-32"
        required
      />
      <input 
        type="url" 
        placeholder="Image URL (optional)" 
        value={imageUrl}
        onChange={e => setImageUrl(e.target.value)}
        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none mt-6"
      />
      <button 
        type="submit" 
        className="w-full bg-[var(--color-neon-green)] text-black font-bold py-4 rounded-xl mt-6 hover:bg-[#00cc00] transition-colors"
      >
        Submit Review
      </button>
    </form>
  );
}
