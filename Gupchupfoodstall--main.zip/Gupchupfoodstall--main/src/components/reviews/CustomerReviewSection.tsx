import React from 'react';
import { useStore } from '../../store/useStore';
import ReviewCard from './ReviewCard';
import TrustAnalytics from './TrustAnalytics';
import ReviewForm from './ReviewForm';

export default function CustomerReviewSection() {
  const { settings, reviews } = useStore();

  if (!settings.isReviewsEnabled) return null;

  const approvedReviews = reviews.filter(r => r.approved);

  return (
    <section className="py-20 px-6 bg-black">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-black text-white text-center mb-4 uppercase tracking-tighter">
          {settings.reviewsSectionTitle}
        </h2>
        <p className="text-gray-400 text-center mb-12">{settings.reviewsSectionSubtitle}</p>
        
        <TrustAnalytics reviews={reviews} />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {approvedReviews.map(review => (
            <ReviewCard key={review.id} review={review} />
          ))}
        </div>
        
        <ReviewForm />
      </div>
    </section>
  );
}
