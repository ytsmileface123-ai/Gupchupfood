import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { db } from '../firebase';
import { collection, query, where, onSnapshot, doc, updateDoc, getDoc, setDoc } from 'firebase/firestore';
import { Navigate, Link } from 'react-router-dom';
import { Loader2, Package, User, LogOut, ChevronRight, RotateCcw, ShieldCheck, MapPin, Phone, Edit2, Save, ArrowLeft, Clock, CheckCircle2, XCircle, Truck, ChefHat, MessageCircle, Camera } from 'lucide-react';
import { auth, storage } from '../firebase';
import { signOut } from 'firebase/auth';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { useStore } from '../store/useStore';

export const CustomerDashboard: React.FC = () => {
  const { user, role, loading } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [ordersLoading, setOrdersLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);
  const [profileData, setProfileData] = useState<any>(null);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [profileLoading, setProfileLoading] = useState(true);
  const [savingProfile, setSavingProfile] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);

  const isAdminEmail = user?.email?.toLowerCase() === 'gupchupfoodstall@gmail.com';

  useEffect(() => {
    if (user) {
      // Fetch Orders
      const q = query(collection(db, 'orders'), where('userId', '==', user.uid));
      const unsubscribeOrders = onSnapshot(q, (snapshot) => {
        const fetchedOrders = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        // Sort by createdAt descending
        fetchedOrders.sort((a: any, b: any) => {
          const dateA = a.createdAt?.toDate() || new Date(0);
          const dateB = b.createdAt?.toDate() || new Date(0);
          return dateB.getTime() - dateA.getTime();
        });
        setOrders(fetchedOrders);
        setOrdersLoading(false);
      });

      // Fetch Profile
      const userRef = doc(db, 'users', user.uid);
      const unsubscribeProfile = onSnapshot(userRef, (docSnap) => {
        if (docSnap.exists()) {
          setProfileData(docSnap.data());
        }
        setProfileLoading(false);
      });

      return () => {
        unsubscribeOrders();
        unsubscribeProfile();
      };
    } else if (!loading) {
      setProfileLoading(false);
      setOrdersLoading(false);
    }
  }, [user, loading]);

  const handleSaveProfile = async () => {
    if (!user) {
      console.error("User is null");
      return;
    }
    setSavingProfile(true);
    try {
      console.log("Saving profile for user:", user);
      console.log("User UID:", user.uid);

      const dataToSave = {
        name: profileData?.name || '',
        mobile: profileData?.mobile || '',
        address: profileData?.address || '',
        location: profileData?.location || null
      };

      console.log("Data being saved:", dataToSave);

      const userRef = doc(db, 'users', user.uid);
      await setDoc(userRef, dataToSave, { merge: true });
      
      setIsEditingProfile(false);
    } catch (error) {
      console.error("Error saving profile:", error);
      alert("Failed to save profile.");
    } finally {
      setSavingProfile(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    if (!file.type.startsWith('image/')) {
      alert('Please select an image file');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('Image size should be less than 5MB');
      return;
    }

    setUploadingImage(true);
    try {
      const storageRef = ref(storage, `profiles/${user.uid}/${Date.now()}_${file.name}`);
      await uploadBytes(storageRef, file);
      const downloadURL = await getDownloadURL(storageRef);
      
      setProfileData((prev: any) => ({ ...prev, photoURL: downloadURL }));
      const userRef = doc(db, 'users', user.uid);
      await setDoc(userRef, { photoURL: downloadURL }, { merge: true });
      
    } catch (error) {
      console.error("Error uploading image:", error);
      alert("Failed to upload image. Please try again.");
    } finally {
      setUploadingImage(false);
    }
  };

  const handleGetLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setProfileData({
            ...profileData,
            location: {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            }
          });
        },
        (error) => {
          console.error("Error getting location:", error);
          alert("Could not get your location. Please allow location access.");
        }
      );
    } else {
      alert("Geolocation is not supported by this browser.");
    }
  };

  const handleReorder = (order: any) => {
    order.items.forEach((item: any) => {
      useStore.getState().addToCart({
        ...item,
        cartItemId: Math.random().toString(36).substring(7),
      });
    });
    alert('Items added to cart!');
  };
  
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Pending': return <Clock className="text-yellow-500" />;
      case 'Confirmed': return <CheckCircle2 className="text-blue-500" />;
      case 'Preparing': return <ChefHat className="text-orange-500" />;
      case 'Out for Delivery': return <Truck className="text-purple-500" />;
      case 'Completed': return <CheckCircle2 className="text-green-500" />;
      case 'Cancelled': return <XCircle className="text-red-500" />;
      default: return <Clock className="text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending': return 'bg-yellow-500/20 text-yellow-500 border-yellow-500/50';
      case 'Confirmed': return 'bg-blue-500/20 text-blue-500 border-blue-500/50';
      case 'Preparing': return 'bg-orange-500/20 text-orange-500 border-orange-500/50';
      case 'Out for Delivery': return 'bg-purple-500/20 text-purple-500 border-purple-500/50';
      case 'Completed': return 'bg-green-500/20 text-green-500 border-green-500/50';
      case 'Cancelled': return 'bg-red-500/20 text-red-500 border-red-500/50';
      default: return 'bg-gray-500/20 text-gray-500 border-gray-500/50';
    }
  };

  if (loading || profileLoading) return <div className="min-h-screen flex items-center justify-center text-white bg-[#111]"><Loader2 className="animate-spin" /></div>;
  if (!user) return <Navigate to="/auth" />;
  if (role === 'admin') return <Navigate to="/admin" />;

  return (
    <div className="min-h-screen bg-[#111] text-white pb-24">
      {/* Header */}
      <div className="bg-[#1a1a1a] border-b border-[#333] sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-black uppercase tracking-tight">My Dashboard</h1>
          <div className="flex items-center gap-4">
            {isAdminEmail && (
              <Link 
                to="/admin-login" 
                className="hidden md:flex items-center gap-2 bg-[var(--color-neon-green)] text-black px-4 py-2 rounded-lg font-bold hover:scale-105 transition-transform"
              >
                <ShieldCheck size={18} /> Admin Panel
              </Link>
            )}
            <button onClick={() => signOut(auth)} className="flex items-center gap-2 text-red-500 hover:text-red-400 font-bold bg-red-500/10 px-4 py-2 rounded-lg">
              <LogOut size={18} /> <span className="hidden md:inline">Logout</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-6 mt-6">
        {/* Welcome & Profile Section */}
        <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-[#333] relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-[var(--color-neon-green)] opacity-5 blur-[100px] rounded-full pointer-events-none"></div>
          
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center gap-4">
              <div className="relative w-16 h-16 rounded-full bg-[#222] border-2 border-[var(--color-neon-green)] overflow-hidden group shrink-0">
                {profileData?.photoURL ? (
                  <img src={profileData.photoURL} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <User className="w-full h-full p-4 text-gray-400" />
                )}
                
                {/* Image Upload Overlay */}
                <label className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 cursor-pointer transition-opacity">
                  {uploadingImage ? (
                    <Loader2 size={20} className="animate-spin text-white" />
                  ) : (
                    <Camera size={20} className="text-white" />
                  )}
                  <input 
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={handleImageUpload}
                    disabled={uploadingImage}
                  />
                </label>
              </div>
              <div>
                <h2 className="text-2xl font-bold">Welcome, {profileData?.name || 'Guest'}!</h2>
                <p className="text-gray-400">{profileData?.email}</p>
              </div>
            </div>
            <button 
              onClick={() => isEditingProfile ? handleSaveProfile() : setIsEditingProfile(true)}
              disabled={savingProfile}
              className="flex items-center gap-2 bg-[#222] hover:bg-[#333] text-white px-4 py-2 rounded-lg transition-colors border border-[#444]"
            >
              {savingProfile ? <Loader2 size={16} className="animate-spin" /> : isEditingProfile ? <Save size={16} /> : <Edit2 size={16} />}
              <span className="hidden sm:inline">{isEditingProfile ? 'Save Profile' : 'Edit Profile'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-2">
                <User size={14} /> Full Name
              </label>
              {isEditingProfile ? (
                <input 
                  type="text" 
                  value={profileData?.name || ''} 
                  onChange={e => setProfileData({...profileData, name: e.target.value})}
                  className="w-full bg-[#222] border border-[#444] rounded-lg px-4 py-2 text-white outline-none focus:border-[var(--color-neon-green)]"
                />
              ) : (
                <p className="font-medium bg-[#222] px-4 py-2 rounded-lg border border-transparent">{profileData?.name || 'Not set'}</p>
              )}
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-2">
                <Phone size={14} /> Mobile Number
              </label>
              {isEditingProfile ? (
                <input 
                  type="tel" 
                  value={profileData?.mobile || ''} 
                  onChange={e => setProfileData({...profileData, mobile: e.target.value})}
                  className="w-full bg-[#222] border border-[#444] rounded-lg px-4 py-2 text-white outline-none focus:border-[var(--color-neon-green)]"
                  placeholder="e.g. 9876543210"
                />
              ) : (
                <p className="font-medium bg-[#222] px-4 py-2 rounded-lg border border-transparent">{profileData?.mobile || 'Not set'}</p>
              )}
            </div>
            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-2">
                <MapPin size={14} /> Delivery Address
              </label>
              {isEditingProfile ? (
                <div className="space-y-2">
                  <textarea 
                    value={profileData?.address || ''} 
                    onChange={e => setProfileData({...profileData, address: e.target.value})}
                    className="w-full bg-[#222] border border-[#444] rounded-lg px-4 py-2 text-white outline-none focus:border-[var(--color-neon-green)] min-h-[80px]"
                    placeholder="Enter your full delivery address"
                  />
                  <div className="flex items-center justify-between bg-[#222] p-3 rounded-lg border border-[#444]">
                    <div className="text-sm text-gray-400">
                      {profileData?.location ? (
                        <span className="text-[var(--color-neon-green)] flex items-center gap-1"><CheckCircle2 size={14}/> Location captured</span>
                      ) : (
                        "No live location captured"
                      )}
                    </div>
                    <button 
                      type="button"
                      onClick={handleGetLocation}
                      className="text-sm bg-[#333] hover:bg-[#444] px-3 py-1.5 rounded-md transition-colors flex items-center gap-2"
                    >
                      <MapPin size={14} /> Auto Detect Location
                    </button>
                  </div>
                </div>
              ) : (
                <p className="font-medium bg-[#222] px-4 py-2 rounded-lg border border-transparent min-h-[40px]">
                  {profileData?.address || 'Not set'}
                  {profileData?.location && <span className="block text-xs text-[var(--color-neon-green)] mt-1">📍 Live location saved</span>}
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Order History Section */}
        <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-[#333]">
          <h2 className="text-xl font-bold mb-6 flex items-center gap-2"><Package className="text-[var(--color-neon-green)]" /> Order History</h2>
          
          {ordersLoading ? (
            <div className="flex justify-center py-12"><Loader2 className="animate-spin text-[var(--color-neon-green)]" size={32} /></div>
          ) : orders.length === 0 ? (
            <div className="text-center py-12 bg-[#222] rounded-xl border border-[#333] border-dashed">
              <Package className="mx-auto mb-4 text-gray-600" size={48} />
              <p className="text-gray-400 mb-4">You haven't placed any orders yet.</p>
              <Link to="/" className="inline-block bg-[var(--color-neon-green)] text-black font-bold px-6 py-2 rounded-lg">
                Start Ordering
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map(order => (
                <div key={order.id} className="bg-[#222] border border-[#333] rounded-xl overflow-hidden transition-all hover:border-[#444]">
                  <div 
                    className="p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 cursor-pointer"
                    onClick={() => setSelectedOrder(order)}
                  >
                    <div>
                      <div className="flex items-center gap-3 mb-1">
                        <p className="font-bold text-lg">Order #{order.id.slice(-6).toUpperCase()}</p>
                        <span className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center gap-1 ${getStatusColor(order.status || 'Pending')}`}>
                          {getStatusIcon(order.status || 'Pending')}
                          {order.status || 'Pending'}
                        </span>
                      </div>
                      <p className="text-sm text-gray-400">
                        {order.createdAt ? new Date(order.createdAt.toDate()).toLocaleString() : 'Just now'}
                      </p>
                    </div>
                    
                    <div className="flex items-center justify-between w-full sm:w-auto gap-4">
                      <div className="text-left sm:text-right">
                        <p className="text-xs text-gray-500 uppercase tracking-wider">Total</p>
                        <p className="font-black text-xl text-[var(--color-neon-green)]">₹{order.totalAmount}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button 
                          onClick={(e) => { e.stopPropagation(); handleReorder(order); }} 
                          className="p-2 bg-[#333] hover:bg-[#444] rounded-lg transition-colors"
                          title="Reorder"
                        >
                          <RotateCcw size={18} />
                        </button>
                        <button className="p-2 bg-[#333] hover:bg-[#444] rounded-lg transition-colors">
                          <ChevronRight size={18} />
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  {/* Quick Timeline Preview if Active */}
                  {['Pending', 'Confirmed', 'Preparing', 'Out for Delivery'].includes(order.status) && (
                    <div className="px-4 pb-4 pt-2 border-t border-[#333] bg-[#1a1a1a]/50">
                      <div className="flex items-center justify-between text-xs font-medium text-gray-400">
                        <span className={order.status === 'Pending' ? 'text-yellow-500' : 'text-green-500'}>Placed</span>
                        <div className={`flex-1 h-0.5 mx-2 ${['Confirmed', 'Preparing', 'Out for Delivery', 'Completed'].includes(order.status) ? 'bg-green-500' : 'bg-[#333]'}`}></div>
                        <span className={['Preparing', 'Out for Delivery', 'Completed'].includes(order.status) ? 'text-green-500' : order.status === 'Confirmed' ? 'text-blue-500' : ''}>Preparing</span>
                        <div className={`flex-1 h-0.5 mx-2 ${['Out for Delivery', 'Completed'].includes(order.status) ? 'bg-green-500' : 'bg-[#333]'}`}></div>
                        <span className={order.status === 'Out for Delivery' ? 'text-purple-500' : order.status === 'Completed' ? 'text-green-500' : ''}>Delivery</span>
                      </div>
                      {order.estimatedDeliveryTime && (
                        <p className="text-center text-xs mt-2 text-[var(--color-neon-green)]">
                          Estimated Delivery: {order.estimatedDeliveryTime}
                        </p>
                      )}
                      {order.adminRemark && (
                        <div className="mt-2 bg-blue-500/10 border border-blue-500/20 rounded p-2 text-xs text-blue-300 flex items-start gap-2">
                          <MessageCircle size={14} className="shrink-0 mt-0.5" />
                          <p><strong>Update:</strong> {order.adminRemark}</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Fixed Back to Website Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black via-black/80 to-transparent z-40">
        <div className="max-w-4xl mx-auto">
          <Link to="/" className="w-full bg-[#222] hover:bg-[#333] border border-[#444] text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 transition-all shadow-xl">
            <ArrowLeft size={20} /> Back to Website
          </Link>
        </div>
      </div>

      {/* Order Details Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/90 flex items-center justify-center p-4 z-50 backdrop-blur-sm overflow-y-auto">
          <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-[#333] w-full max-w-lg my-8 relative">
            <button 
              onClick={() => setSelectedOrder(null)} 
              className="absolute top-4 right-4 text-gray-400 hover:text-white bg-[#222] p-2 rounded-full"
            >
              <XCircle size={24} />
            </button>
            
            <div className="mb-6 pr-10">
              <h2 className="text-2xl font-black uppercase tracking-tight">Order #{selectedOrder.id.slice(-6).toUpperCase()}</h2>
              <p className="text-gray-400 text-sm">
                {selectedOrder.createdAt ? new Date(selectedOrder.createdAt.toDate()).toLocaleString() : 'Just now'}
              </p>
            </div>

            {/* Status Banner */}
            <div className={`p-4 rounded-xl mb-6 border flex items-center gap-3 ${getStatusColor(selectedOrder.status || 'Pending')}`}>
              {getStatusIcon(selectedOrder.status || 'Pending')}
              <div>
                <p className="font-bold text-lg">{selectedOrder.status || 'Pending'}</p>
                {selectedOrder.estimatedDeliveryTime && (
                  <p className="text-sm opacity-80">Est. Delivery: {selectedOrder.estimatedDeliveryTime}</p>
                )}
              </div>
            </div>

            {/* Admin Remark */}
            {selectedOrder.adminRemark && (
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 mb-6">
                <h4 className="text-xs font-bold text-blue-400 uppercase tracking-wider mb-1">Message from Restaurant</h4>
                <p className="text-blue-100 text-sm">{selectedOrder.adminRemark}</p>
              </div>
            )}

            <div className="space-y-4 mb-6">
              <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider border-b border-[#333] pb-2">Items</h3>
              {selectedOrder.items.map((item: any, idx: number) => (
                <div key={idx} className="flex justify-between items-center bg-[#222] p-3 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded bg-[#333] overflow-hidden">
                      {item.imageUrl ? (
                        <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                      ) : (
                        <Package className="w-full h-full p-2 text-gray-500" />
                      )}
                    </div>
                    <div>
                      <p className="font-bold">{item.name}</p>
                      <p className="text-xs text-gray-400">Qty: {item.quantity}</p>
                    </div>
                  </div>
                  <span className="font-bold">₹{item.price * item.quantity}</span>
                </div>
              ))}
            </div>

            <div className="border-t border-[#333] pt-4 mb-6">
              <div className="flex justify-between items-center mb-2 text-gray-400">
                <span>Subtotal</span>
                <span>₹{selectedOrder.totalAmount}</span>
              </div>
              <div className="flex justify-between items-center text-xl font-black text-[var(--color-neon-green)]">
                <span>Total</span>
                <span>₹{selectedOrder.totalAmount}</span>
              </div>
            </div>

            <div className="flex gap-4">
              <button 
                onClick={() => { handleReorder(selectedOrder); setSelectedOrder(null); }} 
                className="flex-1 bg-[var(--color-neon-green)] text-black font-bold py-3 rounded-xl flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
              >
                <RotateCcw size={18} /> Reorder
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

