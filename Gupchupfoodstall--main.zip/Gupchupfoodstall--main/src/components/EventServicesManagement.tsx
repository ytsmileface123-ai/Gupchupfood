import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, addDoc, updateDoc, deleteDoc, doc, onSnapshot, query, orderBy, setDoc } from 'firebase/firestore';
import { Calendar, Trash2, Plus, Check, X, Image as ImageIcon, Video, Music, Link as LinkIcon, Save, Edit2, MapPin, Clock, Tag, User, Phone, MessageCircle, Star, Sparkles, XCircle } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';
import { motion, AnimatePresence } from 'framer-motion';
import { useStore, EventOwnerProfile } from '../store/useStore';

const MediaUploadInput = ({ 
  label, 
  value, 
  onChange, 
  onError,
  placeholder = "https://...",
  accept = "video/mp4,image/*,image/gif",
  buttonText = "Upload Media",
  note = ""
}: { 
  label: string, 
  value: string, 
  onChange: (val: string) => void, 
  onError?: (err: string) => void,
  placeholder?: string,
  accept?: string,
  buttonText?: string,
  note?: string
}) => (
  <div className="space-y-2">
    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">{label}</label>
    <div className="flex flex-col gap-2">
      <input 
        type="url" 
        value={value || ''} 
        onChange={e => onChange(e.target.value)} 
        className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-2 text-sm text-white focus:border-[var(--color-neon-green)] outline-none transition-all" 
        placeholder={placeholder} 
      />
      <div className="flex items-center gap-3">
        <label className="bg-white/5 hover:bg-white/10 text-white text-[9px] font-black py-1.5 px-3 rounded-md cursor-pointer transition-all border border-white/10 uppercase tracking-wider">
          {buttonText}
          <input 
            type="file" 
            accept={accept} 
            className="hidden" 
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                if (file.size > 700 * 1024) {
                  const msg = "File is too large (max 700KB for direct upload). Please use a URL link for larger files.";
                  if (onError) onError(msg);
                  else console.error(msg);
                  return;
                }
                const reader = new FileReader();
                reader.onload = (event) => {
                  onChange(event.target?.result as string);
                };
                reader.readAsDataURL(file);
              }
            }}
          />
        </label>
        {note && <span className="text-[8px] text-gray-500 italic">{note}</span>}
      </div>
    </div>
  </div>
);

export default function EventServicesManagement() {
  const { eventOwnerProfile, updateEventOwnerProfile } = useStore();
  const [services, setServices] = useState<any[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'services' | 'profile'>('services');
  const [error, setError] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  const [form, setForm] = useState({ 
    title: '', 
    category: 'Decoration',
    eventTypes: [] as string[],
    description: '', 
    mediaUrls: [''],
    mediaType: 'image' as 'image' | 'video' | 'gif',
    priceRange: '',
    active: true,
    order: 0
  });

  const [profileForm, setProfileForm] = useState<EventOwnerProfile>(eventOwnerProfile);

  useEffect(() => {
    const q = query(collection(db, 'eventServices'), orderBy('order', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      console.log("onSnapshot called, snapshot size:", snapshot.size);
      setServices(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      console.error("Error in onSnapshot:", error);
      handleFirestoreError(error, OperationType.LIST, 'eventServices');
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const unsubscribe = onSnapshot(doc(db, 'settings', 'eventOwnerProfile'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data() as EventOwnerProfile;
        setProfileForm(data);
        updateEventOwnerProfile(data);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'settings/eventOwnerProfile');
    });

    return () => unsubscribe();
  }, []);

  const handleSaveService = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    console.log("Saving service...", { editingId, form });
    try {
      const data = { ...form, order: Number(form.order), mediaUrls: form.mediaUrls.filter(url => url.trim() !== '') };
      console.log("Data to save:", data);
      if (editingId) {
        await updateDoc(doc(db, 'eventServices', editingId), data);
        console.log("Service updated successfully.");
      } else {
        await addDoc(collection(db, 'eventServices'), data);
        console.log("Service added successfully.");
      }
      setIsAdding(false);
      setEditingId(null);
      setForm({ title: '', category: 'Decoration', eventTypes: [], description: '', mediaUrls: [''], mediaType: 'image', priceRange: '', active: true, order: services.length });
    } catch (error: any) {
      console.error("Error saving service:", error);
      if (error.message?.includes('exceeds the maximum allowed size')) {
        setError("The data is too large (max 1MB). Please use a direct URL link instead of uploading the file.");
      } else {
        setError("Failed to save service. Please try again.");
      }
      handleFirestoreError(error, editingId ? OperationType.UPDATE : OperationType.CREATE, editingId ? `eventServices/${editingId}` : 'eventServices');
    }
  };

  const handleDeleteService = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'eventServices', id));
      setShowDeleteConfirm(null);
    } catch (error) {
      setError("Failed to delete service.");
      handleFirestoreError(error, OperationType.DELETE, `eventServices/${id}`);
    }
  };

  const handleEditService = (service: any) => {
    setEditingId(service.id);
    setForm({
      title: service.title || '',
      category: service.category || 'Decoration',
      eventTypes: service.eventTypes || [],
      description: service.description || '',
      mediaUrls: service.mediaUrls?.length ? service.mediaUrls : [''],
      mediaType: service.mediaType || 'image',
      priceRange: service.priceRange || '',
      active: service.active ?? true,
      order: service.order || 0
    });
    setIsAdding(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await setDoc(doc(db, 'settings', 'eventOwnerProfile'), profileForm);
      updateEventOwnerProfile(profileForm);
      alert("Profile saved successfully!");
    } catch (error: any) {
      if (error.message?.includes('exceeds the maximum allowed size')) {
        setError("The image is too large (max 1MB). Please use a direct URL link instead.");
      } else {
        setError("Failed to save profile. Please try again.");
      }
      handleFirestoreError(error, OperationType.WRITE, 'settings/eventOwnerProfile');
    }
  };

  const toggleEventType = (type: string) => {
    setForm(prev => ({
      ...prev,
      eventTypes: prev.eventTypes.includes(type) 
        ? prev.eventTypes.filter(t => t !== type)
        : [...prev.eventTypes, type]
    }));
  };

  const addMediaUrl = () => {
    setForm(prev => ({ ...prev, mediaUrls: [...prev.mediaUrls, ''] }));
  };

  const updateMediaUrl = (index: number, url: string) => {
    const newUrls = [...form.mediaUrls];
    newUrls[index] = url;
    setForm(prev => ({ ...prev, mediaUrls: newUrls }));
  };

  const removeMediaUrl = (index: number) => {
    setForm(prev => ({ ...prev, mediaUrls: prev.mediaUrls.filter((_, i) => i !== index) }));
  };

  const eventTypeOptions = ['Wedding', 'Birthday', 'New Year Party', 'Corporate Events', 'Private Functions', 'Festival Events'];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black text-white uppercase tracking-tighter">Event Booking</h2>
          <p className="text-gray-400">Manage Decoration & DJ Sound Services</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 border-b border-white/10 pb-4">
        <button
          onClick={() => setActiveTab('services')}
          className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${activeTab === 'services' ? 'bg-[#d4af37] text-black' : 'bg-white/5 text-gray-400 hover:bg-white/10'}`}
        >
          Services
        </button>
        <button
          onClick={() => setActiveTab('profile')}
          className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${activeTab === 'profile' ? 'bg-[#d4af37] text-black' : 'bg-white/5 text-gray-400 hover:bg-white/10'}`}
        >
          Owner Profile
        </button>
      </div>

      {error && (
        <div className="bg-red-500/20 border border-red-500/50 text-red-200 p-4 rounded-xl flex items-start gap-3">
          <XCircle className="shrink-0 mt-0.5" size={18} />
          <p className="text-sm">{error}</p>
        </div>
      )}

      {activeTab === 'profile' && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-[#111] border border-[#333] rounded-2xl p-6 md:p-8"
        >
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
            <User className="text-[#d4af37]" /> Owner Profile Details
          </h3>
          <form onSubmit={handleSaveProfile} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Full Name</label>
                <input type="text" value={profileForm.name} onChange={e => setProfileForm({...profileForm, name: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" required />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Experience (e.g., 10+ Years)</label>
                <input type="text" value={profileForm.experience} onChange={e => setProfileForm({...profileForm, experience: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" required />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Phone Number</label>
                <input type="text" value={profileForm.phone} onChange={e => setProfileForm({...profileForm, phone: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" required />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-2">WhatsApp Number</label>
                <input type="text" value={profileForm.whatsapp} onChange={e => setProfileForm({...profileForm, whatsapp: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" required />
              </div>
              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Business Address</label>
                <input type="text" value={profileForm.address} onChange={e => setProfileForm({...profileForm, address: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" required />
              </div>
              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Special Skills / Hobby</label>
                <input type="text" value={profileForm.skills} onChange={e => setProfileForm({...profileForm, skills: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" placeholder="e.g., Event Planning, Sound Engineering" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Customer Remark / Review Highlight</label>
                <textarea value={profileForm.remark} onChange={e => setProfileForm({...profileForm, remark: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white h-24" placeholder="e.g., Making your special moments unforgettable." />
              </div>
              <div className="md:col-span-2">
                <MediaUploadInput 
                  label="Profile Image" 
                  value={profileForm.imageUrl} 
                  onChange={val => setProfileForm({...profileForm, imageUrl: val})} 
                  onError={setError}
                  accept="image/*"
                />
              </div>
              <div className="md:col-span-2 flex items-center gap-3">
                <input type="checkbox" id="isVerified" checked={profileForm.isVerified} onChange={e => setProfileForm({...profileForm, isVerified: e.target.checked})} className="w-5 h-5 accent-[#d4af37]" />
                <label htmlFor="isVerified" className="text-sm font-bold text-white">Show Verified Business Badge</label>
              </div>
            </div>
            <button type="submit" className="w-full py-4 bg-[#d4af37] text-black font-black rounded-xl hover:bg-[#f3e5ab] transition-colors flex items-center justify-center gap-2">
              <Save size={20} /> Save Profile
            </button>
          </form>
        </motion.div>
      )}

      {activeTab === 'services' && (
        <>
          {!isAdding ? (
            <button 
              onClick={() => {
                setIsAdding(true);
                setEditingId(null);
                setForm({ title: '', category: 'Decoration', eventTypes: [], description: '', mediaUrls: [''], mediaType: 'image', priceRange: '', active: true, order: services.length });
              }}
              className="w-full py-4 bg-white/5 border border-white/10 rounded-2xl text-white font-bold hover:bg-white/10 transition-colors flex items-center justify-center gap-2"
            >
              <Plus size={20} /> Add New Service
            </button>
          ) : (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-[#111] border border-[#333] rounded-2xl p-6 md:p-8"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white">{editingId ? 'Edit Service' : 'Add New Service'}</h3>
                <button onClick={() => setIsAdding(false)} className="p-2 text-gray-400 hover:text-white bg-white/5 rounded-full">
                  <X size={20} />
                </button>
              </div>

              <form onSubmit={handleSaveService} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Service Title</label>
                    <input type="text" value={form.title} onChange={e => setForm({...form, title: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" required />
                  </div>
                  
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Category</label>
                    <select value={form.category} onChange={e => setForm({...form, category: e.target.value as any})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white">
                      <option value="Decoration">Decoration Services</option>
                      <option value="DJ Sound">DJ Sound Services</option>
                    </select>
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Event Types (Select multiple)</label>
                    <div className="flex flex-wrap gap-2">
                      {eventTypeOptions.map(type => (
                        <button
                          key={type}
                          type="button"
                          onClick={() => toggleEventType(type)}
                          className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all border ${
                            form.eventTypes.includes(type) 
                              ? 'bg-[#d4af37] text-black border-[#d4af37]' 
                              : 'bg-white/5 text-gray-400 border-white/10 hover:border-white/30'
                          }`}
                        >
                          {type}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Description</label>
                    <textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white h-24" required />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Price Range (Optional)</label>
                    <input type="text" value={form.priceRange} onChange={e => setForm({...form, priceRange: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" placeholder="e.g., ₹15,000 - ₹50,000" />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Media Type</label>
                    <select value={form.mediaType} onChange={e => setForm({...form, mediaType: e.target.value as any})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white">
                      <option value="image">Image Slider</option>
                      <option value="video">Video (Reels Style)</option>
                      <option value="gif">GIF Animation</option>
                    </select>
                  </div>

                  <div className="md:col-span-2 space-y-4">
                    <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Media URLs</label>
                    {form.mediaUrls.map((url, index) => (
                      <div key={index} className="flex gap-2 items-start">
                        <div className="flex-1">
                          <MediaUploadInput 
                            label={`Media ${index + 1}`} 
                            value={url} 
                            onChange={val => updateMediaUrl(index, val)} 
                            onError={setError}
                            accept={form.mediaType === 'video' ? "video/mp4" : "image/*,image/gif"}
                          />
                        </div>
                        {form.mediaUrls.length > 1 && (
                          <button type="button" onClick={() => removeMediaUrl(index)} className="p-2 mt-6 bg-red-500/20 text-red-500 rounded-lg hover:bg-red-500/30">
                            <Trash2 size={16} />
                          </button>
                        )}
                      </div>
                    ))}
                    <button type="button" onClick={addMediaUrl} className="text-sm text-[#d4af37] font-bold flex items-center gap-1 hover:underline">
                      <Plus size={14} /> Add Another Media
                    </button>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Display Order</label>
                    <input type="number" value={form.order} onChange={e => setForm({...form, order: Number(e.target.value)})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" />
                  </div>

                  <div className="flex items-center gap-3">
                    <input type="checkbox" id="active" checked={form.active} onChange={e => setForm({...form, active: e.target.checked})} className="w-5 h-5 accent-[#d4af37]" />
                    <label htmlFor="active" className="text-sm font-bold text-white">Active (Visible to customers)</label>
                  </div>
                </div>

                <button type="submit" className="w-full py-4 bg-[#d4af37] text-black font-black rounded-xl hover:bg-[#f3e5ab] transition-colors flex items-center justify-center gap-2">
                  <Save size={20} /> {editingId ? 'Update Service' : 'Save Service'}
                </button>
              </form>
            </motion.div>
          )}

          {/* List of Services */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
            <AnimatePresence>
              {services.map((service) => (
                <motion.div 
                  key={service.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className={`bg-[#111] border rounded-2xl overflow-hidden flex flex-col ${service.active ? 'border-[#333]' : 'border-red-500/30 opacity-70'}`}
                >
                  <div className="relative h-48 bg-[#0a0a0a]">
                    {service.mediaUrls?.[0] ? (
                      service.mediaType === 'video' ? (
                        <video src={service.mediaUrls[0]} className="w-full h-full object-cover" muted loop playsInline />
                      ) : (
                        <img src={service.mediaUrls[0]} alt={service.title} className="w-full h-full object-cover" />
                      )
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-gray-600">
                        <ImageIcon size={32} />
                      </div>
                    )}
                    <div className="absolute top-2 right-2 flex gap-2">
                      <button onClick={() => handleEditService(service)} className="p-2 bg-black/50 backdrop-blur-md text-white rounded-lg hover:bg-[#d4af37] hover:text-black transition-colors">
                        <Edit2 size={16} />
                      </button>
                      <button onClick={() => setShowDeleteConfirm(service.id)} className="p-2 bg-black/50 backdrop-blur-md text-red-500 rounded-lg hover:bg-red-500 hover:text-white transition-colors">
                        <Trash2 size={16} />
                      </button>
                    </div>
                    <div className="absolute top-2 left-2">
                      <span className="px-2 py-1 bg-black/60 backdrop-blur-md text-white text-[10px] font-bold rounded border border-white/10">
                        {service.category}
                      </span>
                    </div>
                  </div>
                  
                  <div className="p-4 flex-1 flex flex-col">
                    <h4 className="text-lg font-bold text-white mb-1">{service.title}</h4>
                    <p className="text-xs text-gray-400 mb-3 line-clamp-2">{service.description}</p>
                    
                    <div className="flex flex-wrap gap-1 mb-3">
                      {service.eventTypes?.map((type: string, index: number) => (
                        <span key={`${service.id}-${type}-${index}`} className="text-[9px] px-1.5 py-0.5 bg-white/5 rounded text-gray-300">
                          {type}
                        </span>
                      ))}
                    </div>

                    <div className="mt-auto flex items-center justify-between text-xs">
                      <span className="text-[#d4af37] font-bold">{service.priceRange || 'Price on request'}</span>
                      <span className="text-gray-500">Order: {service.order}</span>
                    </div>
                  </div>

                  {showDeleteConfirm === service.id && (
                    <div className="absolute inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center p-6 z-20">
                      <div className="text-center">
                        <Trash2 className="mx-auto text-red-500 mb-4" size={32} />
                        <h4 className="text-white font-bold mb-2">Delete Service?</h4>
                        <p className="text-sm text-gray-400 mb-6">This action cannot be undone.</p>
                        <div className="flex gap-3 justify-center">
                          <button onClick={() => setShowDeleteConfirm(null)} className="px-4 py-2 bg-white/10 text-white rounded-lg text-sm font-bold hover:bg-white/20">Cancel</button>
                          <button onClick={() => handleDeleteService(service.id)} className="px-4 py-2 bg-red-500 text-white rounded-lg text-sm font-bold hover:bg-red-600">Delete</button>
                        </div>
                      </div>
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </>
      )}
    </div>
  );
}
