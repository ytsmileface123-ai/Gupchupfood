import React from 'react';
import { motion } from 'framer-motion';
import { Clock, Sparkles, Calendar } from 'lucide-react';
import { useStore } from '../store/useStore';

const DAYS_ORDER = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export default function OpeningHoursSection() {
  const { settings } = useStore();
  
  const today = new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(new Date());

  const sortedHours = DAYS_ORDER.map(day => ({
    day,
    time: settings.openingHours[day] || 'CLOSED'
  }));

  return (
    <section className="py-24 px-4 relative overflow-hidden">
      {/* Luxury Background Elements */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-gradient-to-b from-pink-500/5 via-transparent to-transparent pointer-events-none" />
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-purple-500/10 rounded-full blur-[120px] animate-pulse" />
      <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-blue-500/10 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '2s' }} />

      <div className="max-w-4xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/[0.03] border border-white/10 text-[10px] font-black text-pink-400 uppercase tracking-[0.4em] mb-6">
            <Clock size={14} className="animate-pulse" />
            Time to Indulge
          </div>
          <h2 className="text-5xl md:text-7xl font-black tracking-tighter uppercase italic leading-none mb-6">
            {settings.openingHoursSectionTitle?.split(' ')[0] || 'Opening'} <br />
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-pink-500 via-white to-purple-500">
              {settings.openingHoursSectionTitle?.split(' ').slice(1).join(' ') || 'Hours'}
            </span>
          </h2>
          <p className="text-gray-400 text-sm md:text-lg max-w-lg mx-auto font-medium opacity-60">
            Visit us during our operational hours for the most authentic street food experience in a luxury setting.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {sortedHours.map(({ day, time }, index) => {
            const isToday = day === today;
            const isClosed = time === 'CLOSED';

            return (
              <motion.div
                key={day}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={`relative group p-6 rounded-[2.5rem] border transition-all duration-500 ${
                  isToday 
                    ? 'bg-white/[0.05] border-pink-500/50 shadow-[0_20px_50px_rgba(236,72,153,0.15)]' 
                    : 'bg-white/[0.02] border-white/5 hover:border-white/20'
                }`}
              >
                {isToday && (
                  <div className="absolute -top-3 -right-3 bg-pink-500 text-white text-[9px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-lg animate-bounce">
                    Today
                  </div>
                )}
                
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-colors ${
                      isToday ? 'bg-pink-500/20 text-pink-500' : 'bg-white/5 text-gray-500 group-hover:text-white'
                    }`}>
                      <Calendar size={18} />
                    </div>
                    <div>
                      <h5 className={`text-lg font-black uppercase tracking-tight ${isToday ? 'text-white' : 'text-gray-400'}`}>
                        {day}
                      </h5>
                      {isToday && (
                        <p className="text-[9px] font-black text-pink-500/60 uppercase tracking-widest">Live Status</p>
                      )}
                    </div>
                  </div>

                  <div className="text-right">
                    <span className={`inline-block px-5 py-2 rounded-2xl text-[10px] font-black tracking-[0.2em] uppercase transition-all ${
                      isClosed 
                        ? 'bg-red-500/10 text-red-500 border border-red-500/20' 
                        : isToday
                          ? 'bg-pink-500 text-white shadow-[0_10px_20px_rgba(236,72,153,0.3)]'
                          : 'bg-white/5 text-gray-300 border border-white/10'
                    }`}>
                      {time}
                    </span>
                  </div>
                </div>

                {/* Decorative Sparkle for Today */}
                {isToday && !isClosed && (
                  <div className="absolute bottom-4 right-4 text-pink-500/20">
                    <Sparkles size={24} />
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          className="mt-16 p-8 rounded-[3rem] bg-gradient-to-r from-pink-600/10 to-purple-600/10 border border-white/5 text-center"
        >
          <p className="text-gray-400 text-xs font-bold uppercase tracking-[0.3em] mb-2">Special Note</p>
          <p className="text-white text-sm font-medium italic opacity-80">
            "We are committed to serving you the best flavors. Hours may vary on public holidays."
          </p>
        </motion.div>
      </div>
    </section>
  );
}
