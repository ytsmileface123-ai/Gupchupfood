import React from 'react';

interface ConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({ isOpen, onClose, onConfirm, title, message }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[1000]">
      <div className="bg-[#111] p-6 rounded-xl border border-[#333] max-w-sm w-full">
        <h3 className="text-lg font-bold mb-4">{title}</h3>
        <p className="text-gray-400 mb-6">{message}</p>
        <div className="flex gap-4">
          <button onClick={onClose} className="flex-1 bg-[#222] py-2 rounded-lg">Cancel</button>
          <button onClick={() => { onConfirm(); onClose(); }} className="flex-1 bg-red-600 py-2 rounded-lg font-bold">Confirm</button>
        </div>
      </div>
    </div>
  );
};
