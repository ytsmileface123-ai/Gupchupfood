import React, { useState, useEffect, useRef } from 'react';
import { db } from '../firebase';
import { collection, query, onSnapshot, where, doc } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';
import { Bell, ArrowRight, Volume2, VolumeX, Sparkles, ChevronLeft, ChevronRight, Info, Calendar, Tag } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function NotificationSection() {
  const [notifications, setNotifications] = useState<any[]>([]);
  const [sectionSettings, setSectionSettings] = useState<any>({
    title: 'Exclusive',
    subtitle: 'Notices',
    rotationSpeed: 10,
    isEnabled: true
  });
  const [activeIndex, setActiveIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(true);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Fetch global section settings
    const unsubscribeSettings = onSnapshot(doc(db, 'notificationSettings', 'global'), (snapshot) => {
      if (snapshot.exists()) {
        setSectionSettings(snapshot.data());
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'notificationSettings/global');
    });

    const q = query(
      collection(db, 'notifications'), 
      where('isActive', '==', true)
    );
    const unsubscribeNotifs = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      const sortedData = data.sort((a: any, b: any) => (a.order || 0) - (b.order || 0));
      setNotifications(sortedData);
      setIsLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'notifications');
    });

    return () => {
      unsubscribeSettings();
      unsubscribeNotifs();
    };
  }, []);

  useEffect(() => {
    if (notifications.length > 0 && notifications[activeIndex]?.musicUrl) {
      if (audioRef.current) {
        audioRef.current.src = notifications[activeIndex].musicUrl;
        if (!isMuted) {
          audioRef.current.play().catch(e => console.log("Audio play blocked"));
        }
      }
    } else if (audioRef.current) {
      audioRef.current.pause();
    }
  }, [activeIndex, notifications, isMuted]);

  if (isLoading) return null;
  if (!sectionSettings.isEnabled) return null;
  if (notifications.length === 0) return null;

  const current = notifications[activeIndex];

  const nextSlide = () => setActiveIndex((prev) => (prev + 1) % notifications.length);
  const prevSlide = () => setActiveIndex((prev) => (prev - 1 + notifications.length) % notifications.length);

  return (
    <section className="relative py-20 px-4 overflow-hidden bg-[#020202]">
      {/* Luxury Mesh Gradient Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-pink-500/10 rounded-full blur-[150px] animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-purple-500/10 rounded-full blur-[150px] animate-pulse" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.03)_0%,transparent_70%)]" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row items-end justify-between mb-12 gap-8">
          <div className="max-w-2xl">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              className="flex items-center gap-4 mb-6"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-pink-500 rounded-full blur-md animate-pulse opacity-50" />
                <div className="relative w-3 h-3 bg-pink-500 rounded-full border-2 border-white/30" />
              </div>
              <span className="text-[10px] font-black text-pink-500 uppercase tracking-[0.5em] italic">Intelligence Hub</span>
            </motion.div>
            
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="text-5xl md:text-8xl font-black uppercase tracking-tighter leading-[0.85] italic"
            >
              {sectionSettings.title} <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-white/50 to-white/10">
                {sectionSettings.subtitle}
              </span>
            </motion.h2>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 bg-white/5 backdrop-blur-2xl border border-white/10 p-1.5 rounded-full shadow-2xl">
              <button 
                onClick={prevSlide}
                className="p-3 rounded-full hover:bg-white/10 text-white/40 hover:text-white transition-all active:scale-90"
              >
                <ChevronLeft size={20} />
              </button>
              <div className="px-4 text-[10px] font-black text-white uppercase tracking-[0.2em] flex items-center gap-2">
                <span className="text-pink-500">{activeIndex + 1}</span>
                <div className="w-8 h-[1px] bg-white/20" />
                <span className="opacity-40">{notifications.length}</span>
              </div>
              <button 
                onClick={nextSlide}
                className="p-3 rounded-full hover:bg-white/10 text-white/40 hover:text-white transition-all active:scale-90"
              >
                <ChevronRight size={20} />
              </button>
            </div>

            {current?.musicUrl && (
              <button 
                onClick={() => setIsMuted(!isMuted)}
                className={`p-4 rounded-full border transition-all duration-700 ${
                  !isMuted 
                    ? 'bg-pink-500 border-pink-400 text-white shadow-[0_0_30px_rgba(236,72,153,0.5)] scale-110' 
                    : 'bg-white/5 border-white/10 text-white/40 hover:text-white hover:bg-white/10'
                }`}
              >
                {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} className="animate-pulse" />}
              </button>
            )}
          </div>
        </div>

        {/* Main Content Area */}
        <AnimatePresence mode="wait">
          <motion.div 
            key={current.id}
            initial={{ opacity: 0, scale: 0.95, filter: 'blur(10px)' }}
            animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
            exit={{ opacity: 0, scale: 1.05, filter: 'blur(10px)' }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="relative group"
          >
            {/* Glass Card */}
            <div className="relative bg-gradient-to-br from-white/[0.05] to-transparent backdrop-blur-[100px] border border-white/10 rounded-[4rem] overflow-hidden shadow-[0_50px_100px_rgba(0,0,0,0.8)]">
              
              <div className="flex flex-col lg:flex-row min-h-[500px]">
                {/* Media Section */}
                <div className="w-full lg:w-[60%] relative overflow-hidden bg-black aspect-video lg:aspect-auto">
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={current.mediaUrl}
                      initial={{ opacity: 0, scale: 1.1 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 1.2 }}
                      className="absolute inset-0"
                    >
                      {current.mediaType === 'video' ? (
                        <video 
                          src={current.mediaUrl} 
                          autoPlay 
                          loop 
                          muted 
                          playsInline 
                          className="w-full h-full object-contain group-hover:scale-105 transition-all duration-[2s]"
                        />
                      ) : (
                        <img 
                          src={current.mediaUrl || current.imageUrl || "https://picsum.photos/seed/notif/1200/800"} 
                          alt={current.title} 
                          className="w-full h-full object-contain group-hover:scale-105 transition-all duration-[2s]"
                          referrerPolicy="no-referrer"
                        />
                      )}
                    </motion.div>
                  </AnimatePresence>

                  {/* Overlays */}
                  <div className="absolute inset-0 bg-gradient-to-r from-black via-black/20 to-transparent hidden lg:block" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent lg:hidden" />
                  
                  {/* Floating Badges */}
                  <div className="absolute top-10 left-10 flex flex-col gap-3">
                    <motion.div 
                      initial={{ x: -20, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      transition={{ delay: 0.4 }}
                      className="px-6 py-2 rounded-full bg-pink-500 text-white text-[10px] font-black uppercase tracking-[0.3em] shadow-[0_10px_30px_rgba(236,72,153,0.4)] flex items-center gap-2.5"
                    >
                      <Sparkles size={14} />
                      {current.type || 'Notice'}
                    </motion.div>
                    
                    {current.musicUrl && (
                      <motion.div 
                        initial={{ x: -20, opacity: 0 }}
                        animate={{ x: 0, opacity: 1 }}
                        transition={{ delay: 0.5 }}
                        className="px-6 py-2 rounded-full bg-white/10 backdrop-blur-xl border border-white/20 text-white text-[10px] font-black uppercase tracking-[0.3em] flex items-center gap-2.5"
                      >
                        <Volume2 size={14} className="animate-pulse text-pink-400" />
                        Audio Active
                      </motion.div>
                    )}
                  </div>
                </div>

                {/* Content Section */}
                <div className="flex-1 p-12 md:p-20 flex flex-col justify-center relative">
                  {/* Decorative Elements */}
                  <div className="absolute top-0 right-0 p-12 opacity-[0.02] pointer-events-none">
                    <Bell size={250} />
                  </div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="space-y-8 relative z-10"
                  >
                    <div className="space-y-4">
                      <div className="flex items-center gap-4 text-pink-500 font-black text-[10px] uppercase tracking-[0.4em]">
                        <div className="w-10 h-[2px] bg-pink-500 shadow-[0_0_10px_rgba(236,72,153,0.8)]" />
                        Exclusive Update
                      </div>
                      <h3 className="text-5xl md:text-7xl font-black text-white uppercase tracking-tighter leading-[0.9] italic drop-shadow-2xl">
                        {current.title}
                      </h3>
                    </div>

                    <p className="text-gray-400 text-lg md:text-xl font-medium leading-relaxed max-w-lg opacity-80 border-l-2 border-white/10 pl-6">
                      {current.description}
                    </p>

                    <div className="grid grid-cols-2 gap-8 py-8 border-y border-white/5">
                      <div className="space-y-2">
                        <p className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em]">Category</p>
                        <div className="flex items-center gap-3 text-white font-black text-base uppercase tracking-tight italic">
                          <div className="p-1.5 bg-pink-500/10 rounded-lg">
                            <Tag size={14} className="text-pink-500" />
                          </div>
                          {current.type || 'General'}
                        </div>
                      </div>
                      <div className="space-y-2">
                        <p className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em]">Priority</p>
                        <div className="flex items-center gap-3 text-white font-black text-base uppercase tracking-tight italic">
                          <div className="p-1.5 bg-pink-500/10 rounded-lg">
                            <Info size={14} className="text-pink-500" />
                          </div>
                          High Priority
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-6 pt-4">
                      {current.link && (
                        <a 
                          href={current.link} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="group/btn relative px-10 py-5 bg-white text-black rounded-2xl text-[11px] font-black uppercase tracking-[0.2em] overflow-hidden transition-all hover:scale-105 active:scale-95 shadow-[0_20px_40px_rgba(255,255,255,0.1)]"
                        >
                          <div className="absolute inset-0 bg-gradient-to-r from-pink-500 to-purple-500 opacity-0 group-hover/btn:opacity-100 transition-opacity duration-700" />
                          <span className="relative z-10 group-hover/btn:text-white transition-colors flex items-center gap-3">
                            Take Action <ArrowRight size={18} className="group-hover/btn:translate-x-1 transition-transform" />
                          </span>
                        </a>
                      )}
                      
                      <button 
                        onClick={nextSlide}
                        className="px-10 py-5 rounded-2xl bg-white/5 border border-white/10 text-white text-[11px] font-black uppercase tracking-[0.2em] hover:bg-white/10 transition-all flex items-center gap-3 active:scale-95"
                      >
                        Next Update <ChevronRight size={18} />
                      </button>
                    </div>
                  </motion.div>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="absolute bottom-0 left-0 w-full h-1 bg-white/5">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: '100%' }}
                  key={activeIndex}
                  transition={{ duration: sectionSettings.rotationSpeed || 10, ease: "linear" }}
                  onAnimationComplete={nextSlide}
                  className="h-full bg-gradient-to-r from-pink-500 via-purple-500 to-pink-500 shadow-[0_0_15px_rgba(236,72,153,0.5)]"
                />
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Audio Element */}
        <audio ref={audioRef} loop muted={isMuted} className="hidden" />
      </div>
    </section>
  );
}
