import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, ExternalLink } from 'lucide-react';
import { useStore } from '../store/useStore';

export default function GetDirectionsSection() {
  const { settings } = useStore();

  return (
    <section id="location-section" className="py-20 px-4 bg-black/40 backdrop-blur-lg overflow-hidden scroll-mt-20">
      <div className="max-w-4xl mx-auto relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="bg-[#0a0a0a] border border-[var(--color-neon-green)]/20 rounded-[2rem] p-8 md:p-12 shadow-2xl"
        >
          <div className="flex flex-col items-center gap-8 text-center">
            <div className="w-20 h-20 bg-[var(--color-neon-green)]/10 rounded-2xl flex items-center justify-center border border-[var(--color-neon-green)]/30 shadow-[0_0_20px_rgba(255,183,3,0.1)]">
              <MapPin className="text-[var(--color-neon-green)]" size={40} />
            </div>
            <div>
              <h3 className="text-3xl md:text-4xl font-black text-white mb-4 uppercase tracking-tight leading-tight">
                {settings.address}
              </h3>
              <p className="text-[var(--color-neon-green)] text-sm font-bold uppercase tracking-[0.2em] opacity-60">
                TREE MOHINI, WEST BENGAL
              </p>
            </div>
            <a 
              href={settings.locationLink}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[var(--color-neon-green)] text-black font-black uppercase tracking-widest px-10 py-5 rounded-full flex items-center gap-3 hover:scale-105 transition-transform shadow-[0_0_30px_rgba(255,183,3,0.2)] text-lg"
            >
              {settings.locationSectionTitle || 'Get Directions'} <ExternalLink size={20} />
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
