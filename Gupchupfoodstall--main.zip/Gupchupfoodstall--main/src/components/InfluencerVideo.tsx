import React, { useState, useRef, useEffect } from 'react';
import { Volume2, VolumeX, ExternalLink, Music, Play, Pause } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface InfluencerVideoProps {
  videoUrl: string;
  influencerName: string;
  influencerImage: string;
  caption: string;
  logoUrl?: string;
  socialLink?: string;
  musicUrl?: string;
  mediaType?: 'video' | 'gif' | 'image';
  zipUrl?: string;
  noModal?: boolean;
  isModal?: boolean;
  children?: React.ReactNode;
  showMuteButton?: boolean;
}

export default function InfluencerVideo({ 
  videoUrl, 
  influencerName, 
  influencerImage, 
  caption,
  logoUrl,
  socialLink,
  musicUrl,
  mediaType = 'video',
  zipUrl,
  noModal = false,
  isModal = false,
  children,
  showMuteButton = false
}: InfluencerVideoProps) {
  const [isMuted, setIsMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(true);
  const [showControls, setShowControls] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [isInView, setIsInView] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const thumbVideoRef = useRef<HTMLVideoElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    console.log("InfluencerVideo: videoUrl =", videoUrl, "mediaType =", mediaType, "isInView =", isInView, "isModal =", isModal);
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsInView(entry.isIntersecting);
      },
      { threshold: 0.1 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => {
      if (containerRef.current) {
        observer.unobserve(containerRef.current);
      }
    };
  }, [videoUrl, mediaType, isInView, isModal]);

  useEffect(() => {
    const video = videoRef.current;
    if (video && isFullScreen) {
      if (isPlaying) {
        video.play().catch(() => setIsPlaying(false));
      } else {
        video.pause();
      }
    }
    
    if (audioRef.current && isFullScreen) {
      audioRef.current.muted = isMuted;
      if (isPlaying) {
        audioRef.current.play().catch(() => {});
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying, isMuted, isFullScreen]);

  // Ensure thumbnail video always plays
  useEffect(() => {
    if (thumbVideoRef.current && !isFullScreen) {
      thumbVideoRef.current.play().catch(() => {});
    }
  }, [isFullScreen]);

  const togglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsPlaying(!isPlaying);
  };

  const openFullScreen = () => {
    setIsFullScreen(true);
    setIsMuted(false);
  };

  const closeFullScreen = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFullScreen(false);
    setIsMuted(true);
  };

  const ReelContent = ({ isModal = false }: { isModal?: boolean }) => (
    <>
      {/* Media Content */}
      <div className="absolute inset-0 flex items-center justify-center" onClick={isModal ? togglePlay : openFullScreen}>
        {mediaType === 'video' ? (
          isInView || isModal ? (
            <video 
              key={videoUrl}
              ref={isModal ? videoRef : thumbVideoRef}
              src={videoUrl || undefined} 
              className="w-full h-full object-cover"
              loop 
              muted={isModal ? (isMuted || !!musicUrl) : true}
              playsInline 
              autoPlay 
              disablePictureInPicture
              controlsList="nodownload"
            />
          ) : (
            <div className="w-full h-full bg-black/40 animate-pulse" />
          )
        ) : mediaType === 'gif' || mediaType === 'image' ? (
          <img 
            src={videoUrl || undefined} 
            alt={influencerName} 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        ) : null}
      </div>

      {/* Zip Download Button (Optional) */}
      {zipUrl && isModal && (
        <div className="absolute top-20 right-4 z-40">
          <a 
            href={zipUrl} 
            download 
            target="_blank" 
            rel="noopener noreferrer"
            className="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white text-[10px] font-bold px-3 py-2 rounded-lg border border-white/10 flex items-center gap-2 transition-all"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
            Assets (.zip)
          </a>
        </div>
      )}

      {/* Background Music (Optional) */}
      {musicUrl && (
        <audio ref={isModal ? audioRef : null} src={musicUrl || undefined} loop />
      )}

      {/* Overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-black/20 pointer-events-none"></div>

      {/* Top Controls */}
      <div className="absolute top-4 right-4 flex flex-col gap-2 z-20">
        {isModal && (
          <button 
            onClick={closeFullScreen}
            className="bg-black/40 backdrop-blur-md text-white p-2.5 rounded-full hover:bg-black/60 transition-all border border-white/10 mb-4"
          >
            <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
          </button>
        )}
        {socialLink && (
          <a 
            href={socialLink} 
            target="_blank" 
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="bg-[var(--color-neon-green)] text-black p-2.5 rounded-full hover:scale-110 transition-all shadow-lg"
          >
            <ExternalLink size={18} />
          </a>
        )}
      </div>

      {/* Mute Button */}
      {showMuteButton && (
        <button 
          onClick={(e) => { e.stopPropagation(); setIsMuted(!isMuted); }}
          className="absolute top-6 left-6 z-30 bg-black/40 backdrop-blur-md text-white p-2.5 rounded-full hover:bg-black/60 transition-all border border-white/10"
        >
          {isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
        </button>
      )}

      {/* Right Sidebar Actions (Reels Style) */}
      <div className={`absolute right-2 ${isModal ? 'bottom-32' : 'bottom-24'} flex flex-col items-center gap-5 z-30`}>
        <div className="flex flex-col items-center gap-1">
          <button className="text-white hover:scale-110 transition-transform">
            <svg viewBox="0 0 24 24" className="w-7 h-7 fill-white"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
          </button>
          <span className="text-[10px] font-bold text-white drop-shadow-md">1.2K</span>
        </div>
        <div className="flex flex-col items-center gap-1">
          <button className="text-white hover:scale-110 transition-transform">
            <svg viewBox="0 0 24 24" className="w-7 h-7 fill-white"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
          </button>
          <span className="text-[10px] font-bold text-white drop-shadow-md">84</span>
        </div>
        <div className="flex flex-col items-center gap-1">
          <button className="text-white hover:scale-110 transition-transform">
            <svg viewBox="0 0 24 24" className="w-7 h-7 fill-white"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
          </button>
          <span className="text-[10px] font-bold text-white drop-shadow-md">Share</span>
        </div>
        <div className="w-7 h-7 rounded-md border-2 border-white/50 overflow-hidden animate-spin-slow">
          <img src={influencerImage || undefined} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
        </div>
      </div>

      {/* Center Play/Pause Indicator */}
      <AnimatePresence>
        {!isPlaying && isModal && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.5 }}
            className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none"
          >
            <div className="bg-black/40 backdrop-blur-md p-6 rounded-full border border-white/20">
              <Play size={40} className="text-white fill-white ml-1" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Bottom Content (Reels Style) */}
      <div className={`absolute bottom-0 left-0 right-0 p-5 ${isModal ? 'pb-10' : ''} pr-12 z-20`}>
        <div className="flex items-center gap-3 mb-3">
          <div className="relative">
            <img 
              src={logoUrl || influencerImage || undefined} 
              alt={influencerName} 
              className="w-11 h-11 rounded-full border-2 border-[var(--color-neon-green)] object-cover shadow-lg" 
              referrerPolicy="no-referrer"
            />
            {mediaType === 'video' && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/20 rounded-full">
                <Play size={14} className="text-white fill-white opacity-80" />
              </div>
            )}
            {logoUrl && influencerImage && (
              <img 
                src={influencerImage || undefined} 
                className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full border border-black object-cover" 
                referrerPolicy="no-referrer"
              />
            )}
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-black text-white drop-shadow-md flex items-center gap-1">
              {influencerName}
              <span className="w-3 h-3 bg-blue-500 rounded-full flex items-center justify-center">
                <svg viewBox="0 0 24 24" className="w-2 h-2 text-white fill-current"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
              </span>
            </span>
            <span className="text-[10px] text-[var(--color-neon-green)] font-bold uppercase tracking-tighter opacity-80">Original Audio</span>
          </div>
          <button className="ml-auto bg-white/10 hover:bg-white/20 backdrop-blur-md text-white text-[10px] font-bold px-3 py-1 rounded-md border border-white/10 transition-colors">
            Follow
          </button>
        </div>

        <p className="text-xs text-gray-200 line-clamp-3 mb-4 leading-relaxed drop-shadow-md">
          {caption}
        </p>

        {children}

        {/* Music Ticker */}
        <div className="flex items-center gap-2 overflow-hidden">
          <Music size={12} className="text-white animate-pulse shrink-0" />
          <div className="flex whitespace-nowrap animate-marquee">
            <span className="text-[10px] text-white font-medium mr-8 uppercase tracking-widest">
              {influencerName} • Original Sound • {new Date().toLocaleDateString()}
            </span>
            <span className="text-[10px] text-white font-medium mr-8 uppercase tracking-widest">
              {influencerName} • Original Sound • {new Date().toLocaleDateString()}
            </span>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="absolute bottom-0 left-0 h-0.5 bg-white/20 w-full">
        <motion.div 
          className="h-full bg-[var(--color-neon-green)] shadow-[0_0_10px_var(--color-neon-green)]"
          initial={{ width: "0%" }}
          animate={{ width: isPlaying ? "100%" : "0%" }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
        />
      </div>
    </>
  );

  return (
    <>
      <div 
        ref={containerRef}
        className="relative aspect-[9/16] rounded-2xl overflow-hidden border border-white/10 group bg-black shadow-2xl cursor-pointer"
        onMouseEnter={() => setShowControls(true)}
        onMouseLeave={() => setShowControls(false)}
      >
        <ReelContent isModal={isModal} />
      </div>

      {/* Full Screen Modal */}
      {!noModal && (
        <AnimatePresence>
          {isFullScreen && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-4"
              onClick={closeFullScreen}
            >
              <motion.div 
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                className="relative w-full max-w-sm aspect-[9/16] bg-black rounded-3xl overflow-hidden shadow-2xl"
                onClick={(e) => e.stopPropagation()}
              >
                <ReelContent isModal={true} />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      )}
    </>
  );
}
