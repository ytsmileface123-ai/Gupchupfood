import React, { useState, useEffect, useRef } from 'react';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { motion, AnimatePresence, useScroll, useTransform } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useStore } from '../store/useStore';
import ShareButton from './ShareButton';

interface Banner {
  id: string;
  imageUrl: string;
  videoUrl?: string;
  mediaType: 'image' | 'video' | 'gif';
  title: string;
  link?: string;
  active: boolean;
  order: number;
}

function BannerContent({ banners, settings }: { banners: Banner[], settings: any }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isInView, setIsInView] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["-15%", "15%"]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsInView(entry.isIntersecting);
      },
      { threshold: 0.1 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => {
      if (containerRef.current) {
        observer.unobserve(containerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (banners.length <= 1) return;

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % banners.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [banners.length]);

  const nextBanner = () => {
    setCurrentIndex((prev) => (prev + 1) % banners.length);
  };

  const prevBanner = () => {
    setCurrentIndex((prev) => (prev - 1 + banners.length) % banners.length);
  };

  const banner = banners[currentIndex];

  return (
    <section ref={containerRef} className="relative w-full overflow-hidden bg-transparent pt-24 pb-12 md:pt-32 md:pb-20">
      <div className="max-w-[1600px] mx-auto px-4 md:px-10">
        <div className="relative aspect-[16/9] md:aspect-[21/8] rounded-[3rem] overflow-hidden border border-white/10 shadow-[0_0_100px_rgba(0,0,0,0.5)] group">
          <AnimatePresence mode="wait">
            <motion.div
              key={banner.id}
              initial={{ opacity: 0, scale: 1.1, rotate: 2 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              exit={{ opacity: 0, scale: 0.9, rotate: -2 }}
              transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
              className="absolute inset-0 overflow-hidden"
            >
              {banner.mediaType === 'video' ? (
                isInView ? (
                  <motion.video
                    style={{ y, scale: 1.4 }}
                    src={banner.videoUrl || undefined}
                    autoPlay
                    loop
                    muted
                    playsInline
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-black/40 animate-pulse" />
                )
              ) : (
                <motion.img
                  style={{ y, scale: 1.4 }}
                  src={banner.imageUrl || undefined}
                  alt={banner.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              )}
              
              {/* Editorial Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent"></div>
              <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-transparent to-transparent"></div>
              
              <div className="absolute top-8 left-8 z-30">
                {settings.isBannersShareEnabled && (
                  <ShareButton 
                    title={banner.title}
                    text={`Check out this: ${banner.title}!`}
                    url={banner.link || window.location.origin}
                  />
                )}
              </div>

              <div className="absolute inset-0 flex flex-col justify-end p-8 md:p-24">
                <motion.div
                  initial={{ x: -100, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.4, duration: 1, ease: [0.16, 1, 0.3, 1] }}
                  className="max-w-4xl"
                >
                  <h2 className="text-4xl md:text-8xl lg:text-9xl font-black text-white uppercase tracking-tighter leading-[0.85] italic mb-10 transform -skew-x-6">
                    {banner.title}
                  </h2>
                </motion.div>
              </div>
            </motion.div>
          </AnimatePresence>

          {banners.length > 1 && (
            <>
              <div className="absolute right-8 top-1/2 -translate-y-1/2 flex flex-col gap-4 z-20">
                <button
                  onClick={prevBanner}
                  className="p-5 rounded-full glass-panel text-white border border-white/10 hover:bg-[var(--color-neon-green)] hover:text-black transition-all duration-500 hover:scale-110"
                >
                  <ChevronLeft size={24} />
                </button>
                <button
                  onClick={nextBanner}
                  className="p-5 rounded-full glass-panel text-white border border-white/10 hover:bg-[var(--color-neon-green)] hover:text-black transition-all duration-500 hover:scale-110"
                >
                  <ChevronRight size={24} />
                </button>
              </div>
              
              {/* Progress Dots */}
              <div className="absolute bottom-10 right-10 flex gap-3 z-20">
                {banners.map((_, idx) => (
                  <button
                    key={`banner-dot-${idx}`}
                    onClick={() => setCurrentIndex(idx)}
                    className={`h-1 rounded-full transition-all duration-700 ${idx === currentIndex ? 'bg-[var(--color-neon-green)] w-12' : 'bg-white/20 w-4 hover:bg-white/40'}`}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  );
}

export default function BannerSection() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const { settings } = useStore();

  useEffect(() => {
    const q = query(
      collection(db, 'banners'),
      orderBy('order', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const bannerData = snapshot.docs
          .map(doc => ({
            id: doc.id,
            ...doc.data()
          }))
          .filter((b: any) => b.active) as Banner[];
        setBanners(bannerData);
      } else {
        setBanners([
          {
            id: 'mock1',
            imageUrl: 'https://images.unsplash.com/photo-1555244162-803834f87a33?auto=format&fit=crop&q=80&w=1920',
            mediaType: 'image',
            title: 'Experience the Taste',
            link: '#',
            active: true,
            order: 1
          },
          {
            id: 'mock2',
            imageUrl: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&q=80&w=1920',
            mediaType: 'image',
            title: 'Delicious Street Food',
            link: '#',
            active: true,
            order: 2
          }
        ]);
      }
    });

    return () => unsubscribe();
  }, []);

  if (!settings.isBannerEnabled || banners.length === 0) return null;

  return <BannerContent banners={banners} settings={settings} />;
}
