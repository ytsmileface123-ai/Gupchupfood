import React from 'react';
import { useStore } from '../store/useStore';
import { Clock, AlertCircle, ShoppingBag, Coffee, Store } from 'lucide-react';
import { motion } from 'framer-motion';

export const StallStatusBadge: React.FC = () => {
  const { getStallStatus } = useStore();
  const { status, message } = getStallStatus();
  
  const getStatusConfig = () => {
    switch (status) {
      case 'open': 
        return { 
          color: 'bg-emerald-500', 
          icon: <ShoppingBag size={14} />,
          label: 'Open Now'
        };
      case 'closed': 
        return { 
          color: 'bg-red-500', 
          icon: <Clock size={14} />,
          label: 'Closed'
        };
      case 'busy': 
        return { 
          color: 'bg-amber-500', 
          icon: <AlertCircle size={14} />,
          label: 'Busy'
        };
      default: 
        return { 
          color: 'bg-gray-500', 
          icon: <Store size={14} />,
          label: 'Status'
        };
    }
  };

  const config = getStatusConfig();

  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`fixed top-20 left-4 z-50 flex items-center gap-2 px-4 py-2 rounded-full text-white font-black shadow-2xl text-[10px] uppercase tracking-[0.2em] ${config.color} backdrop-blur-md`}
    >
      <div className="animate-pulse">
        {config.icon}
      </div>
      <span>{message || config.label}</span>
    </motion.div>
  );
};
