import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Box, Smartphone } from 'lucide-react';

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'model-viewer': any;
    }
  }
}

interface ARViewerDialogProps {
  isOpen: boolean;
  onClose: () => void;
  modelURL: string;
  itemName: string;
}

export default function ARViewerDialog({ isOpen, onClose, modelURL, itemName }: ARViewerDialogProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-2xl p-4 md:p-8"
          onClick={onClose}
        >
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="glass-panel border-white/10 rounded-[3rem] w-full max-w-5xl h-[85vh] p-8 md:p-12 relative flex flex-col overflow-hidden shadow-[0_0_100px_rgba(255,183,3,0.1)]"
            onClick={e => e.stopPropagation()}
          >
            {/* Background Glow */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-[var(--color-neon-green)]/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>

            <div className="flex justify-between items-center mb-8 relative z-10">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-[var(--color-neon-green)]/10 border border-[var(--color-neon-green)]/20 flex items-center justify-center text-[var(--color-neon-green)]">
                  <Box size={24} />
                </div>
                <div>
                  <h3 className="text-2xl md:text-4xl font-black text-white uppercase tracking-tighter leading-none">
                    3D <span className="text-[var(--color-neon-green)]">Experience</span>
                  </h3>
                  <p className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mt-1">{itemName}</p>
                </div>
              </div>
              <motion.button 
                whileHover={{ scale: 1.1, rotate: 90 }}
                whileTap={{ scale: 0.9 }}
                onClick={onClose} 
                className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-white hover:text-black transition-all"
              >
                <X size={24} />
              </motion.button>
            </div>

            <div className="flex-1 w-full h-full relative rounded-[2rem] overflow-hidden bg-black/40 border border-white/5 group">
              {/* @ts-ignore */}
              <model-viewer
                src={modelURL || undefined}
                alt={`3D model of ${itemName}`}
                ar
                ar-modes="webxr scene-viewer quick-look"
                camera-controls
                auto-rotate
                shadow-intensity="1"
                environment-image="neutral"
                exposure="1"
                className="w-full h-full"
              />
              
              <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-4 px-6 py-3 rounded-full bg-black/60 backdrop-blur-xl border border-white/10 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <Smartphone size={16} className="text-[var(--color-neon-green)]" />
                <span className="text-[10px] font-black text-white uppercase tracking-widest whitespace-nowrap">Scan with your phone for AR</span>
              </div>
            </div>
            
            <div className="mt-8 flex items-center justify-center gap-8 opacity-40">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
                <span className="text-[8px] font-black text-white uppercase tracking-widest">Rotate 360°</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
                <span className="text-[8px] font-black text-white uppercase tracking-widest">Zoom In/Out</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-white"></div>
                <span className="text-[8px] font-black text-white uppercase tracking-widest">View in Space</span>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
