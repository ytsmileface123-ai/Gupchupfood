import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from '../store/useStore';
import { Play, X } from 'lucide-react';

export default function FounderSection() {
  const { settings } = useStore();
  const [activeVideo, setActiveVideo] = useState<string | null>(null);

  const founders = [
    {
      name: settings.founder1Name,
      role: settings.founder1Role,
      image: settings.founder1Image,
      video: settings.founder1Video,
      accent: 'cyan',
      color: 'text-cyan-400',
      glow: 'shadow-cyan-500/20'
    },
    {
      name: settings.founder2Name,
      role: settings.founder2Role,
      image: settings.founder2Image,
      video: settings.founder2Video,
      accent: 'green',
      color: 'text-green-400',
      glow: 'shadow-green-500/20'
    }
  ];

  return (
    <section className="py-24 md:py-40 px-4 relative overflow-hidden bg-black">
      {/* Background Decorative Elements */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_20%_30%,rgba(168,85,247,0.05),transparent_50%)]"></div>
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_80%_70%,rgba(59,130,246,0.05),transparent_50%)]"></div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-20 md:mb-32">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="inline-block"
          >
            <div className="flex items-center justify-center gap-6 mb-4">
              <div className="w-12 h-px bg-gradient-to-r from-transparent to-white/20"></div>
              <h2 className="text-xs md:text-sm font-black uppercase tracking-[1em] text-white/40 ml-[1em] whitespace-nowrap">
                Founders
              </h2>
              <div className="w-12 h-px bg-gradient-to-l from-transparent to-white/20"></div>
            </div>
            <div className="h-1 w-32 bg-gradient-to-r from-transparent via-purple-500 to-transparent mx-auto"></div>
          </motion.div>
        </div>

        {/* Founders Grid - Left & Right Layout */}
        <div 
          className="flex flex-row items-start justify-center w-full"
          style={{ 
            gap: `clamp(10px, 5vw, ${settings.founderSpacing || 100}px)`,
            marginTop: `${settings.founderYOffset || 0}px`,
            marginLeft: `${settings.founderXOffset || 0}px`
          }}
        >
          {founders.map((founder, index) => (
            <motion.div
              key={`founder-${founder.name}-${index}`}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1.5, delay: index * 0.2, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -15, scale: 1.02 }}
              className="relative group w-1/2 md:w-auto max-w-sm flex flex-col items-center"
            >
              <div className="relative flex flex-col items-center w-full">
                {/* Circular Profile Image with Glassmorphism & Glow */}
                <div 
                  className={`relative rounded-full p-1 md:p-2 bg-white/5 border border-white/10 overflow-hidden shadow-[0_0_60px_rgba(0,0,0,0.9)] transition-all duration-700 group-hover:${founder.glow} ${founder.video ? 'cursor-pointer' : ''}`}
                  onClick={() => founder.video && setActiveVideo(founder.video)}
                  style={{ 
                    width: `calc(clamp(6rem, 20vw, 12rem) * ${(settings.founderImageSize || 100) / 100})`,
                    height: `calc(clamp(6rem, 20vw, 12rem) * ${(settings.founderImageSize || 100) / 100})`
                  }}
                >
                  <div className={`absolute inset-0 rounded-full border-2 border-white/5 group-hover:border-${founder.accent}-500/40 transition-colors duration-700 z-10`}></div>
                  <img 
                    src={founder.image} 
                    alt={founder.name} 
                    className="w-full h-full rounded-full object-cover transition-all duration-1000 grayscale-[0.2] group-hover:grayscale-0 scale-110 group-hover:scale-100"
                    referrerPolicy="no-referrer"
                  />
                  {founder.video && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-20">
                      <Play className="w-8 h-8 md:w-12 md:h-12 text-white fill-white animate-pulse" />
                    </div>
                  )}
                </div>

                {/* Name & Role Badge - Glassmorphism */}
                <div className="mt-6 md:mt-10 bg-black/60 backdrop-blur-2xl border border-white/10 px-2 md:px-12 py-3 md:py-5 rounded-2xl md:rounded-full flex flex-col md:flex-row items-center justify-center gap-1 md:gap-6 shadow-2xl group-hover:border-purple-500/40 transition-all duration-500 text-center w-full md:w-auto md:whitespace-nowrap">
                  <span className="text-[10px] md:text-base font-black uppercase tracking-[0.1em] md:tracking-[0.3em] text-white leading-tight">
                    {founder.name}
                  </span>
                  <span className={`text-[8px] md:text-xs font-black uppercase tracking-[0.1em] md:tracking-[0.3em] ${founder.color} leading-tight`}>
                    {founder.role}
                  </span>
                </div>

                {/* Quote / Bio */}
                <p className="mt-4 md:mt-8 text-gray-400 text-[10px] md:text-base italic font-medium leading-relaxed text-center max-w-[150px] md:max-w-xs opacity-80 md:opacity-60 group-hover:opacity-100 transition-opacity duration-500">
                  "Bringing authentic street flavors with a premium futuristic touch to your neighborhood."
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Video Modal */}
      <AnimatePresence>
        {activeVideo && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-2xl"
            onClick={() => setActiveVideo(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-lg aspect-[9/16] bg-black rounded-3xl overflow-hidden border border-white/10 shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <button 
                onClick={() => setActiveVideo(null)}
                className="absolute top-6 right-6 z-10 w-12 h-12 rounded-full bg-black/50 backdrop-blur-md border border-white/10 flex items-center justify-center text-white hover:bg-white hover:text-black transition-all"
              >
                <X size={24} />
              </button>
              <video 
                src={activeVideo} 
                className="w-full h-full object-cover"
                autoPlay 
                loop
                playsInline
                controls
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
