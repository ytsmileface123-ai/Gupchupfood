import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { ShoppingCart, Menu as MenuIcon, ShieldCheck, Globe, LogIn, Bell, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { motion } from 'framer-motion';
import { InstallPWA } from './InstallPWA';

export default function Navbar() {
  const cart = useStore(state => state.cart);
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const { language, setLanguage, toggleCart, settings } = useStore();
  const { user, role, loading } = useAuth();
  const [isOpen, setIsOpen] = useState(true);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Logic to check if open/closed based on settings.openingHours
  useEffect(() => {
    const checkStatus = () => {
      const now = new Date();
      const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      const currentDay = days[now.getDay()];
      const hours = settings.openingHours[currentDay];

      if (!hours || hours === 'CLOSED') {
        setIsOpen(false);
        return;
      }

      // Simple parse for "4:00 PM - 10:00 PM"
      try {
        const [start, end] = hours.split(' - ');
        const parseTime = (timeStr: string) => {
          const [time, modifier] = timeStr.split(' ');
          let [h, m] = time.split(':').map(Number);
          if (modifier === 'PM' && h < 12) h += 12;
          if (modifier === 'AM' && h === 12) h = 0;
          const d = new Date();
          d.setHours(h, m, 0);
          return d;
        };

        const startTime = parseTime(start);
        const endTime = parseTime(end);
        setIsOpen(now >= startTime && now <= endTime);
      } catch (e) {
        setIsOpen(true); // Fallback
      }
    };

    checkStatus();
    const interval = setInterval(checkStatus, 60000);
    return () => clearInterval(interval);
  }, [settings.openingHours]);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-[100] px-4 md:px-10 py-2 flex justify-between items-center transition-all duration-700 ${isScrolled ? 'bg-black/60 backdrop-blur-2xl border-b border-white/5 py-2' : 'bg-transparent py-3'}`}>
      {/* Left: Logo & Status */}
      <div className="flex items-center gap-6">
        <Link to="/" className="flex items-center gap-3 group relative">
          <div className="relative">
            <div className="absolute -inset-2 bg-gradient-to-r from-[var(--color-neon-green)] to-emerald-500 rounded-full blur-xl opacity-0 group-hover:opacity-40 transition-all duration-700"></div>
            <motion.img 
              whileHover={{ scale: 1.1, rotate: 5 }}
              src={settings.logoImageUrl || "https://picsum.photos/seed/gupchup/100/100"} 
              alt="Logo" 
              className="relative w-10 h-10 md:w-12 md:h-12 rounded-full border border-white/10 shadow-2xl object-cover z-10"
              referrerPolicy="no-referrer"
            />
            <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-[var(--color-neon-green)] rounded-full border-2 border-black z-20 animate-pulse"></div>
          </div>
          <div className="flex flex-col">
            <h1 className="text-xl md:text-2xl font-black leading-none tracking-tighter uppercase italic text-gradient">
              {settings.logoName}
            </h1>
            <p className="text-[9px] text-[var(--color-neon-green)] font-black tracking-[0.3em] uppercase opacity-60 mt-0.5">
              {settings.logoSubName}
            </p>
            {/* Status Badge */}
            <motion.div 
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex items-center gap-1.5 mt-1.5 text-[8px] font-black uppercase tracking-[0.1em] ${isOpen ? 'text-emerald-400' : 'text-red-400'}`}
            >
              <div className="relative flex items-center justify-center">
                <span className={`absolute w-2 h-2 rounded-full animate-ping opacity-40 ${isOpen ? 'bg-emerald-500' : 'bg-red-500'}`}></span>
                <span className={`relative w-1.5 h-1.5 rounded-full ${isOpen ? 'bg-emerald-500' : 'bg-red-500'}`}></span>
              </div>
              {isOpen ? 'Open Now' : 'Closed'}
            </motion.div>
          </div>
        </Link>
      </div>
      
      {/* Right: Actions */}
      <div className="flex items-center gap-3 md:gap-8">
        <InstallPWA />
        {/* Language Selector */}
        <div className="hidden lg:flex items-center gap-3 bg-white/[0.03] hover:bg-white/[0.08] rounded-full px-5 py-2.5 text-[10px] font-black border border-white/5 transition-all cursor-pointer group glass-panel-hover overflow-hidden relative">
          <div className="absolute inset-0 bg-gradient-to-r from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
          <Globe size={14} className="text-[var(--color-neon-green)] group-hover:rotate-45 transition-transform duration-700 relative z-10" />
          <select 
            value={language} 
            onChange={(e) => setLanguage(e.target.value as any)}
            className="bg-transparent outline-none text-white cursor-pointer uppercase tracking-widest font-bold relative z-10"
          >
            <option value="en" className="bg-black">English</option>
            <option value="hi" className="bg-black">Hindi</option>
            <option value="bn" className="bg-black">Bengali</option>
          </select>
        </div>

        {/* Cart */}
        <motion.div 
          whileHover={{ scale: 1.1, y: -2 }}
          whileTap={{ scale: 0.9 }}
          id="cart-icon" 
          className="relative p-3.5 bg-white/[0.03] hover:bg-white/[0.08] rounded-full border border-white/5 cursor-pointer transition-all group glass-panel-hover" 
          onClick={toggleCart}
        >
          <ShoppingCart className="text-gray-300 group-hover:text-[var(--color-neon-green)] transition-colors" size={22} />
          {cartCount > 0 && (
            <motion.span 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute -top-1 -right-1 bg-[var(--color-neon-red)] text-white text-[10px] font-black rounded-full w-6 h-6 flex items-center justify-center shadow-[0_0_25px_rgba(255,0,0,0.8)] border-2 border-black"
            >
              {cartCount}
            </motion.span>
          )}
        </motion.div>

        {/* Auth/Dashboard/Admin Button */}
        {loading ? null : user ? (
          role === 'admin' ? (
            <Link 
              to="/admin" 
              className="group relative overflow-hidden bg-[var(--color-neon-green)] text-black text-[10px] font-black uppercase tracking-[0.2em] px-6 py-2 rounded-full transition-all duration-700 hover:shadow-[0_0_40px_rgba(0,255,0,0.5)] hover:scale-105 active:scale-95 flex items-center gap-2"
            >
              <ShieldCheck size={16} className="relative z-10" />
              <span className="hidden sm:inline relative z-10">Admin</span>
            </Link>
          ) : (
            <Link 
              to="/dashboard" 
              className="group relative overflow-hidden bg-white/10 text-white text-[10px] font-black uppercase tracking-[0.2em] px-6 py-2 rounded-full transition-all duration-700 hover:bg-white/20 hover:scale-105 active:scale-95 flex items-center gap-2"
            >
              <User size={16} className="relative z-10" />
              <span className="hidden sm:inline relative z-10">Dashboard</span>
            </Link>
          )
        ) : (
          <Link 
            to="/auth" 
            className="group relative overflow-hidden bg-white/5 text-white text-[10px] font-black uppercase tracking-[0.2em] px-6 py-2 rounded-full transition-all duration-700 hover:bg-white/10 hover:scale-105 active:scale-95 flex items-center gap-2 border border-white/10"
          >
            <LogIn size={16} className="relative z-10" />
            <span className="hidden sm:inline relative z-10">Login</span>
          </Link>
        )}
      </div>
    </nav>
  );
}
