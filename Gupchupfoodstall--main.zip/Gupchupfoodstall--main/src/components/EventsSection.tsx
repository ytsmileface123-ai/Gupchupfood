import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Phone, MessageCircle, MapPin, CheckCircle, Star, Calendar, Music, Sparkles, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { useStore } from '../store/useStore';

export default function EventsSection() {
  const { settings, eventServices, eventOwnerProfile } = useStore();
  const [activeCategory, setActiveCategory] = useState<'All' | 'Decoration' | 'DJ Sound'>('All');
  const [activeEventType, setActiveEventType] = useState<string>('All');
  const [selectedMedia, setSelectedMedia] = useState<{ url: string, type: 'image' | 'video' | 'gif' } | null>(null);

  if (!settings.isEventsSectionEnabled) return null;

  const eventTypes = ['All', 'Wedding', 'Birthday', 'New Year Party', 'Corporate Events', 'Private Functions', 'Festival Events'];

  const filteredServices = eventServices.filter(service => {
    if (!service.active) return false;
    if (activeCategory !== 'All' && service.category !== activeCategory) return false;
    if (activeEventType !== 'All' && !service.eventTypes.includes(activeEventType)) return false;
    if (service.category === 'Decoration' && !settings.isDecorationEnabled) return false;
    if (service.category === 'DJ Sound' && !settings.isDjSoundEnabled) return false;
    return true;
  }).sort((a, b) => a.order - b.order);

  const handleWhatsApp = (serviceTitle: string) => {
    const message = `Hi, I'm interested in booking ${serviceTitle} for an upcoming event.`;
    window.open(`https://wa.me/${eventOwnerProfile.whatsapp}?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleCall = () => {
    window.open(`tel:${eventOwnerProfile.phone}`, '_self');
  };

  const handleMap = () => {
    window.open(`https://maps.google.com/?q=${encodeURIComponent(eventOwnerProfile.address)}`, '_blank');
  };

  return (
    <section className="py-24 relative overflow-hidden bg-[#0a0a0a]">
      {/* Premium Background */}
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20"></div>
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-96 bg-gradient-to-b from-[#d4af37]/10 to-transparent blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/30 text-[#d4af37] mb-6"
          >
            <Sparkles size={16} />
            <span className="text-sm font-bold tracking-widest uppercase">Premium Experiences</span>
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl font-black text-white mb-6 tracking-tighter"
          >
            LUXURY <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#d4af37] to-[#f3e5ab]">EVENTS</span>
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-400 max-w-2xl mx-auto"
          >
            Unforgettable Decoration & High-End DJ Sound Systems for your special moments.
          </motion.p>
        </div>

        {/* Owner Profile Card */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto mb-20 bg-gradient-to-br from-white/5 to-black/40 border border-[#d4af37]/20 rounded-3xl p-8 backdrop-blur-xl shadow-[0_0_50px_rgba(212,175,55,0.05)] relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#d4af37]/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
          
          <div className="flex flex-col md:flex-row items-center gap-8 relative z-10">
            <div className="relative">
              <div className="w-32 h-32 md:w-40 md:h-40 rounded-full overflow-hidden border-4 border-[#d4af37]/30 p-1">
                <img src={eventOwnerProfile.imageUrl} alt={eventOwnerProfile.name} className="w-full h-full object-cover rounded-full" />
              </div>
              {eventOwnerProfile.isVerified && (
                <div className="absolute bottom-2 right-2 bg-blue-500 text-white p-1.5 rounded-full shadow-lg border-2 border-[#0a0a0a]">
                  <CheckCircle size={16} />
                </div>
              )}
            </div>
            
            <div className="flex-1 text-center md:text-left">
              <div className="flex flex-col md:flex-row md:items-center gap-3 mb-2">
                <h3 className="text-3xl font-bold text-white">{eventOwnerProfile.name}</h3>
                <span className="px-3 py-1 bg-[#d4af37]/10 text-[#d4af37] text-xs font-bold uppercase tracking-wider rounded-full border border-[#d4af37]/20 inline-block w-fit mx-auto md:mx-0">
                  Event Director
                </span>
              </div>
              
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-sm text-gray-400 mb-6">
                <div className="flex items-center gap-1.5">
                  <Star size={16} className="text-[#d4af37]" />
                  <span>{eventOwnerProfile.experience} Experience</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Sparkles size={16} className="text-[#d4af37]" />
                  <span>{eventOwnerProfile.skills}</span>
                </div>
              </div>
              
              <p className="text-gray-300 italic border-l-2 border-[#d4af37] pl-4 mb-8">
                "{eventOwnerProfile.remark}"
              </p>
              
              <div className="flex flex-wrap justify-center md:justify-start gap-4">
                <button onClick={handleCall} className="flex items-center gap-2 px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all border border-white/10">
                  <Phone size={18} />
                  <span>Call Now</span>
                </button>
                <button onClick={() => handleWhatsApp('Event Booking')} className="flex items-center gap-2 px-6 py-3 bg-[#25D366]/20 hover:bg-[#25D366]/30 text-[#25D366] rounded-full transition-all border border-[#25D366]/30">
                  <MessageCircle size={18} />
                  <span>WhatsApp</span>
                </button>
                <button onClick={handleMap} className="flex items-center gap-2 px-6 py-3 bg-white/5 hover:bg-white/10 text-gray-300 rounded-full transition-all border border-white/5">
                  <MapPin size={18} />
                  <span>Location</span>
                </button>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Filters */}
        <div className="flex flex-col items-center gap-6 mb-16">
          {/* Main Category Filter */}
          <div className="flex p-1 bg-white/5 rounded-full border border-white/10 backdrop-blur-sm">
            {['All', 'Decoration', 'DJ Sound'].map((cat, index) => (
              <button
                key={`cat-${cat}-${index}`}
                onClick={() => setActiveCategory(cat as any)}
                className={`px-6 py-2.5 rounded-full text-sm font-bold transition-all ${
                  activeCategory === cat 
                    ? 'bg-gradient-to-r from-[#d4af37] to-[#f3e5ab] text-black shadow-lg' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Event Type Filter */}
          <div className="flex flex-wrap justify-center gap-2 max-w-4xl">
            {eventTypes.map((type, index) => (
              <button
                key={`type-${type}-${index}`}
                onClick={() => setActiveEventType(type)}
                className={`px-4 py-2 rounded-full text-xs font-medium transition-all border ${
                  activeEventType === type 
                    ? 'bg-white/20 border-white/30 text-white' 
                    : 'bg-transparent border-white/10 text-gray-400 hover:border-white/20 hover:text-gray-200'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence mode="popLayout">
            {filteredServices.map((service, index) => (
              <motion.div
                key={service.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="bg-white/5 border border-white/10 rounded-3xl overflow-hidden group hover:border-[#d4af37]/50 transition-all duration-500 flex flex-col"
              >
                {/* Media Slider */}
                <div className="relative h-64 w-full bg-black overflow-hidden">
                  {service.mediaUrls.length > 0 ? (
                    <ServiceMediaSlider 
                      mediaUrls={service.mediaUrls} 
                      mediaType={service.mediaType} 
                      onMediaClick={(url, type) => setSelectedMedia({ url, type })}
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-white/5">
                      <Sparkles className="text-gray-600" size={48} />
                    </div>
                  )}
                  
                  <div className="absolute top-4 left-4 z-10">
                    <span className="px-3 py-1 bg-black/60 backdrop-blur-md text-white text-xs font-bold rounded-full border border-white/10 flex items-center gap-1.5">
                      {service.category === 'Decoration' ? <Sparkles size={12} className="text-[#d4af37]" /> : <Music size={12} className="text-[#d4af37]" />}
                      {service.category}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 flex-1 flex flex-col">
                  <h4 className="text-2xl font-bold text-white mb-2 group-hover:text-[#d4af37] transition-colors">{service.title}</h4>
                  <p className="text-gray-400 text-sm mb-6 flex-1">{service.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-6">
                    {service.eventTypes.map((type, tIndex) => (
                      <span key={`service-type-${service.id}-${type}-${tIndex}`} className="text-[10px] px-2 py-1 bg-white/5 rounded text-gray-300 border border-white/5">
                        {type}
                      </span>
                    ))}
                  </div>

                  {service.priceRange && (
                    <div className="mb-6">
                      <span className="text-xs text-gray-500 uppercase tracking-wider block mb-1">Starting from</span>
                      <span className="text-xl font-bold text-[#d4af37]">{service.priceRange}</span>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="grid grid-cols-2 gap-3 mt-auto">
                    <button 
                      onClick={handleCall}
                      className="flex items-center justify-center gap-2 py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl transition-all border border-white/10 text-sm font-medium"
                    >
                      <Phone size={16} />
                      Call
                    </button>
                    <button 
                      onClick={() => handleWhatsApp(service.title)}
                      className="flex items-center justify-center gap-2 py-3 bg-[#d4af37] hover:bg-[#f3e5ab] text-black rounded-xl transition-all text-sm font-bold shadow-[0_0_20px_rgba(212,175,55,0.3)]"
                    >
                      <MessageCircle size={16} />
                      Book Now
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filteredServices.length === 0 && (
          <div className="text-center py-20">
            <Sparkles className="mx-auto text-gray-600 mb-4" size={48} />
            <h3 className="text-2xl font-bold text-white mb-2">No Services Found</h3>
            <p className="text-gray-400">Try adjusting your filters to see available services.</p>
          </div>
        )}

      </div>

      {/* Media Modal (Reels/Image View) */}
      <AnimatePresence>
        {selectedMedia && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-xl p-4"
          >
            <button 
              onClick={() => setSelectedMedia(null)}
              className="absolute top-6 right-6 z-50 p-3 bg-white/10 hover:bg-white/20 rounded-full text-white transition-all"
            >
              <X size={24} />
            </button>

            <div className="w-full max-w-md aspect-[9/16] relative rounded-3xl overflow-hidden bg-black border border-white/10 shadow-2xl">
              {selectedMedia.type === 'video' ? (
                <video 
                  src={selectedMedia.url} 
                  className="w-full h-full object-cover"
                  autoPlay 
                  loop 
                  controls
                  playsInline
                />
              ) : (
                <img 
                  src={selectedMedia.url} 
                  alt="Preview" 
                  className="w-full h-full object-contain"
                />
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </section>
  );
}

// Helper Component for Image Slider
function ServiceMediaSlider({ mediaUrls, mediaType, onMediaClick }: { mediaUrls: string[], mediaType: string, onMediaClick: (url: string, type: any) => void }) {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (mediaUrls.length <= 1 || mediaType === 'video') return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % mediaUrls.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [mediaUrls.length, mediaType]);

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev - 1 + mediaUrls.length) % mediaUrls.length);
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev + 1) % mediaUrls.length);
  };

  return (
    <div className="relative w-full h-full group/slider cursor-pointer" onClick={() => onMediaClick(mediaUrls[currentIndex], mediaType)}>
      {mediaType === 'video' ? (
        <video 
          src={mediaUrls[0]} 
          className="w-full h-full object-cover opacity-80 group-hover/slider:opacity-100 transition-opacity"
          autoPlay 
          loop 
          muted 
          playsInline
        />
      ) : (
        <>
          <AnimatePresence mode="wait">
            <motion.img
              key={currentIndex}
              src={mediaUrls[currentIndex]}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover/slider:opacity-100 transition-opacity group-hover/slider:scale-105 duration-700"
            />
          </AnimatePresence>
          
          {mediaUrls.length > 1 && (
            <>
              <button 
                onClick={handlePrev}
                className="absolute left-2 top-1/2 -translate-y-1/2 p-1.5 bg-black/50 text-white rounded-full opacity-0 group-hover/slider:opacity-100 transition-opacity hover:bg-[#d4af37] hover:text-black"
              >
                <ChevronLeft size={20} />
              </button>
              <button 
                onClick={handleNext}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-black/50 text-white rounded-full opacity-0 group-hover/slider:opacity-100 transition-opacity hover:bg-[#d4af37] hover:text-black"
              >
                <ChevronRight size={20} />
              </button>
              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
                {mediaUrls.map((_, idx) => (
                  <div 
                    key={`dot-${idx}`} 
                    className={`h-1.5 rounded-full transition-all ${idx === currentIndex ? 'w-4 bg-[#d4af37]' : 'w-1.5 bg-white/50'}`}
                  />
                ))}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}
