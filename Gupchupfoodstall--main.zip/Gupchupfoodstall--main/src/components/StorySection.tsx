import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Volume2, VolumeX, ChevronLeft, ChevronRight, Play } from 'lucide-react';
import { useStore } from '../store/useStore';

export interface Story {
  id: string;
  title: string;
  logoUrl: string;
  mediaUrl: string;
  mediaType: 'video' | 'image';
  active: boolean;
  order: number;
}

interface StorySectionProps {
  stories: Story[];
  hideTitle?: boolean;
}

export default function StorySection({ stories, hideTitle = false }: StorySectionProps) {
  const [selectedStoryIndex, setSelectedStoryIndex] = useState<number | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const { settings } = useStore();

  const activeStories = stories.filter(s => s.active).sort((a, b) => a.order - b.order);

  useEffect(() => {
    let timer: any;
    if (selectedStoryIndex !== null) {
      setProgress(0);
      timer = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            handleNext();
            return 0;
          }
          return prev + 1;
        });
      }, 100); // 10 seconds per story (100 * 100ms)
    }
    return () => clearInterval(timer);
  }, [selectedStoryIndex]);

  const handleNext = () => {
    if (selectedStoryIndex !== null) {
      if (selectedStoryIndex < activeStories.length - 1) {
        setSelectedStoryIndex(selectedStoryIndex + 1);
      } else {
        setSelectedStoryIndex(null);
      }
    }
  };

  const handlePrev = () => {
    if (selectedStoryIndex !== null) {
      if (selectedStoryIndex > 0) {
        setSelectedStoryIndex(selectedStoryIndex - 1);
      } else {
        setSelectedStoryIndex(0);
      }
    }
  };

  if (activeStories.length === 0) return null;

  return (
    <div className={`py-8 px-4 max-w-7xl mx-auto overflow-hidden ${hideTitle ? 'py-0' : ''}`}>
      {!hideTitle && (
        <div className="flex flex-col mb-6 px-2">
          <div className="flex items-center gap-3">
            <div className="w-1.5 h-6 bg-[var(--color-neon-green)] rounded-full shadow-[0_0_10px_rgba(255,183,3,0.5)]"></div>
            <h2 className="text-xl md:text-2xl font-black text-white uppercase tracking-tighter italic">
              {settings.storySectionTitle.split(' ').map((word, i, arr) => (
                <span key={`story-part-${i}`} className={i === arr.length - 1 ? "text-[var(--color-neon-green)]" : ""}>
                  {word}{' '}
                </span>
              ))}
            </h2>
          </div>
          {settings.storySectionDescription && (
            <p className="text-gray-500 text-xs mt-1 ml-4 font-medium uppercase tracking-widest">
              {settings.storySectionDescription}
            </p>
          )}
        </div>
      )}
      
      <div className={`overflow-x-auto no-scrollbar flex gap-8 snap-x pb-8 ${hideTitle ? 'justify-center' : ''}`}>
        {activeStories.map((story, index) => (
          <motion.div 
            key={story.id} 
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.05 }}
            className="flex flex-col items-center gap-3 snap-center cursor-pointer group shrink-0"
            onClick={() => setSelectedStoryIndex(index)}
          >
            <div className="relative p-[4px] rounded-full bg-gradient-to-tr from-[var(--color-neon-green)] via-orange-500 to-red-500 group-hover:scale-110 transition-all duration-500 shadow-[0_0_20px_rgba(255,183,3,0.15)] group-hover:shadow-[0_0_40px_rgba(255,183,3,0.4)]">
              <div className="w-20 h-20 md:w-24 md:h-24 rounded-full border-4 border-black overflow-hidden bg-gray-900 relative">
                {story.logoUrl && (
                  <img 
                    src={story.logoUrl} 
                    alt={story.title} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                )}
                {story.mediaType === 'video' && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/10 transition-colors">
                    <Play size={24} className="text-white fill-white opacity-90 drop-shadow-lg" />
                  </div>
                )}
              </div>
              {/* Active Indicator */}
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-[var(--color-neon-green)] rounded-full border-4 border-black flex items-center justify-center shadow-lg">
                <div className="w-2 h-2 bg-black rounded-full animate-pulse"></div>
              </div>
            </div>
            <span className="text-[10px] md:text-xs font-black text-white/60 uppercase tracking-[0.2em] group-hover:text-[var(--color-neon-green)] transition-colors truncate w-20 md:w-24 text-center italic">
              {story.title}
            </span>
          </motion.div>
        ))}
      </div>

      {/* Story Modal */}
      <AnimatePresence>
        {selectedStoryIndex !== null && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center"
          >
            <div className="relative w-full h-full max-w-md aspect-[9/16] flex flex-col bg-black rounded-none md:rounded-2xl overflow-hidden">
              {/* Progress Bars */}
              <div className="absolute top-4 left-4 right-4 flex gap-1 z-30">
                {activeStories.map((_, idx) => (
                  <div key={`story-progress-${idx}`} className="h-1 flex-1 bg-white/20 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-white transition-all duration-100 ease-linear"
                      style={{ 
                        width: idx < selectedStoryIndex ? '100%' : idx === selectedStoryIndex ? `${progress}%` : '0%' 
                      }}
                    />
                  </div>
                ))}
              </div>

              {/* Header */}
              <div className="absolute top-8 left-4 right-4 flex items-center justify-between z-30">
                <div className="flex items-center gap-2">
                  {activeStories[selectedStoryIndex].logoUrl && (
                    <img 
                      src={activeStories[selectedStoryIndex].logoUrl} 
                      className="w-8 h-8 rounded-full border border-white/20" 
                      referrerPolicy="no-referrer"
                      alt="Logo"
                    />
                  )}
                  <span className="text-white font-bold text-sm drop-shadow-md">
                    {activeStories[selectedStoryIndex].title}
                  </span>
                </div>
                <div className="flex items-center gap-4">
                  <button onClick={() => setIsMuted(!isMuted)} className="text-white">
                    {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
                  </button>
                  <button onClick={() => setSelectedStoryIndex(null)} className="text-white">
                    <X size={24} />
                  </button>
                </div>
              </div>

              {/* Media */}
              <div className="flex-1 relative overflow-hidden rounded-none md:rounded-2xl">
                {activeStories[selectedStoryIndex].mediaType === 'video' ? (
                  activeStories[selectedStoryIndex].mediaUrl && (
                    <video 
                      key={activeStories[selectedStoryIndex].mediaUrl}
                      src={activeStories[selectedStoryIndex].mediaUrl}
                      className="w-full h-full object-contain"
                      autoPlay
                      muted={isMuted}
                      playsInline
                      onEnded={handleNext}
                    />
                  )
                ) : (
                  activeStories[selectedStoryIndex].mediaUrl && (
                    <img 
                      src={activeStories[selectedStoryIndex].mediaUrl}
                      className="w-full h-full object-contain"
                      referrerPolicy="no-referrer"
                      alt="Story Media"
                    />
                  )
                )}

                {/* Navigation Areas */}
                <div className="absolute inset-0 flex">
                  <div className="w-1/3 h-full cursor-pointer" onClick={handlePrev} />
                  <div className="w-2/3 h-full cursor-pointer" onClick={handleNext} />
                </div>
              </div>

              {/* Navigation Buttons (Desktop) */}
              <button 
                onClick={handlePrev}
                className="absolute left-[-60px] top-1/2 -translate-y-1/2 hidden md:flex bg-white/10 hover:bg-white/20 p-2 rounded-full text-white"
              >
                <ChevronLeft size={32} />
              </button>
              <button 
                onClick={handleNext}
                className="absolute right-[-60px] top-1/2 -translate-y-1/2 hidden md:flex bg-white/10 hover:bg-white/20 p-2 rounded-full text-white"
              >
                <ChevronRight size={32} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
