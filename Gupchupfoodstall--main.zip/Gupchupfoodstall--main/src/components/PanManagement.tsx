import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { Plus, Trash2, Edit2, X, Save, Image as ImageIcon, Video, FileArchive, TrendingUp, Play } from 'lucide-react';

export default function PanManagement() {
  const { 
    panCategories, 
    panItems, 
    addPanCategory, 
    updatePanCategory, 
    deletePanCategory,
    addPanItem,
    updatePanItem,
    deletePanItem
  } = useStore();
  const [newCategory, setNewCategory] = useState('');
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);

  const [itemForm, setItemForm] = useState({
    name: '',
    price: '',
    categoryId: '',
    description: '',
    ingredients: '',
    imageUrl: '',
    videoUrl: '',
    zipUrl: '',
    active: true
  });

  const addCategory = () => {
    if (!newCategory) return;
    addPanCategory({ 
      id: Math.random().toString(36).substring(7), 
      name: newCategory, 
      order: panCategories.length, 
      active: true 
    });
    setNewCategory('');
  };

  const seedDefaultCategories = async () => {
    const defaults = [
      { id: 'mithai-pan', name: 'Mithai Pan 🍬', order: 0, active: true },
      { id: 'full-moment', name: 'Full Happy Moments Pan 🎉', order: 1, active: true },
      { id: 'half-moment', name: 'Half Happy Moment Pan 😊', order: 2, active: true }
    ];
    
    for (const cat of defaults) {
      if (!panCategories.find(c => c.name === cat.name)) {
        await addPanCategory(cat);
      }
    }

    // Seed some items if none exist
    if (panItems.length === 0) {
      const defaultItems = [
        {
          id: 'item-1',
          categoryId: 'mithai-pan',
          name: 'Special Mitha Pan',
          price: 25,
          description: 'A sweet delight with premium gulkand and cherries.',
          ingredients: ['Gulkand', 'Cherry', 'Sweet Supari', 'Coconut Powder', 'Honey'],
          imageUrl: 'https://picsum.photos/seed/mithapan/400/700',
          active: true,
          order: 0
        },
        {
          id: 'item-2',
          categoryId: 'full-moment',
          name: 'Full Happy Moment Pan',
          price: 50,
          description: 'The ultimate celebration pan with rich ingredients.',
          ingredients: ['Premium Gulkand', 'Saffron', 'Silver Leaves', 'Special Masala', 'Dry Fruits'],
          imageUrl: 'https://picsum.photos/seed/fullmoment/400/700',
          active: true,
          order: 0
        }
      ];
      for (const item of defaultItems) {
        await addPanItem(item);
      }
    }
  };

  const handleOpenItemModal = (item?: any) => {
    if (item) {
      setEditingItem(item);
      setItemForm({
        name: item.name,
        price: item.price.toString(),
        categoryId: item.categoryId,
        description: item.description,
        ingredients: item.ingredients?.join(', ') || '',
        imageUrl: item.imageUrl || '',
        videoUrl: item.videoUrl || '',
        zipUrl: item.zipUrl || '',
        active: item.active
      });
    } else {
      setEditingItem(null);
      setItemForm({
        name: '',
        price: '',
        categoryId: panCategories[0]?.id || '',
        description: '',
        ingredients: '',
        imageUrl: '',
        videoUrl: '',
        zipUrl: '',
        active: true
      });
    }
    setIsItemModalOpen(true);
  };

  const handleSaveItem = async () => {
    if (!itemForm.name || !itemForm.price || !itemForm.categoryId) return;

    const newItem = {
      id: editingItem ? editingItem.id : Math.random().toString(36).substring(7),
      ...itemForm,
      price: parseFloat(itemForm.price),
      ingredients: itemForm.ingredients.split(',').map(i => i.trim()).filter(i => i !== ''),
      order: editingItem ? editingItem.order : panItems.length,
      active: itemForm.active
    };

    if (editingItem) {
      await updatePanItem(editingItem.id, newItem);
    } else {
      await addPanItem(newItem);
    }
    setIsItemModalOpen(false);
  };

  const handleDeleteItem = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      await deletePanItem(id);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h3 className="text-3xl font-black uppercase tracking-tighter">Pan Management</h3>
          <p className="text-gray-500 text-sm font-bold uppercase tracking-widest">Manage your special Assam Pan collection</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={seedDefaultCategories}
            className="flex items-center gap-2 bg-[#222] text-white font-bold px-4 py-2 rounded-lg hover:bg-[#333] transition-colors border border-[#444]"
          >
            <TrendingUp size={18} /> Seed Defaults
          </button>
          <button 
            onClick={() => handleOpenItemModal()}
            className="flex items-center gap-2 bg-[var(--color-neon-green)] text-black font-bold px-4 py-2 rounded-lg hover:bg-[#00cc00] transition-colors shadow-[0_0_15px_rgba(0,255,0,0.3)]"
          >
            <Plus size={20} /> Add Pan Item
          </button>
        </div>
      </div>
      
      {/* Categories Section */}
      <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
        <h4 className="text-lg font-bold mb-4 flex items-center gap-2">
          <Edit2 size={18} className="text-[var(--color-neon-green)]" />
          Manage Categories
        </h4>
        <div className="flex gap-2 mb-4">
          <input 
            value={newCategory} 
            onChange={(e) => setNewCategory(e.target.value)} 
            className="bg-[#222] text-white px-4 py-2 rounded-lg flex-1 border border-[#333] focus:border-[var(--color-neon-green)] outline-none"
            placeholder="New Category Name (e.g. Mithai Pan)"
          />
          <button onClick={addCategory} className="bg-[var(--color-neon-green)] text-black px-6 py-2 rounded-lg font-bold hover:scale-105 transition-transform">
            Add
          </button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {panCategories.map(cat => (
            <div key={cat.id} className="flex justify-between items-center bg-[#1a1a1a] p-3 rounded-xl border border-[#333] group hover:border-[var(--color-neon-green)] transition-all">
              <span className="font-bold">{cat.name}</span>
              <button onClick={() => deletePanCategory(cat.id)} className="text-red-500 hover:bg-red-500/10 p-2 rounded-lg transition-colors">
                <Trash2 size={18} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Items Section */}
      <div className="space-y-4">
        <h4 className="text-xl font-bold uppercase tracking-widest flex items-center gap-2">
          <Play size={20} className="text-[var(--color-neon-green)]" />
          Pan Items Gallery
        </h4>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {panItems.map(item => (
            <div key={item.id} className="bg-[#111] border border-[#333] rounded-2xl overflow-hidden group hover:border-[var(--color-neon-green)] transition-all shadow-xl">
              <div className="aspect-[9/16] relative bg-black overflow-hidden">
                {item.videoUrl ? (
                  <video src={item.videoUrl} className="w-full h-full object-cover opacity-60" muted loop autoPlay />
                ) : item.imageUrl ? (
                  <img src={item.imageUrl} className="w-full h-full object-cover opacity-60" alt={item.name} />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-gray-600 bg-[#0a0a0a]">
                    <ImageIcon size={32} />
                  </div>
                )}
                <div className="absolute top-4 right-4 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => handleOpenItemModal(item)} className="p-2 bg-black/80 text-white rounded-lg hover:bg-[var(--color-neon-green)] hover:text-black transition-colors backdrop-blur-md border border-white/10">
                    <Edit2 size={16} />
                  </button>
                  <button onClick={() => handleDeleteItem(item.id)} className="p-2 bg-black/80 text-white rounded-lg hover:bg-red-500 transition-colors backdrop-blur-md border border-white/10">
                    <Trash2 size={16} />
                  </button>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black via-black/80 to-transparent">
                  <span className="bg-[var(--color-neon-green)] text-black text-[8px] font-black px-1.5 py-0.5 rounded uppercase mb-1 inline-block tracking-tighter">
                    {panCategories.find(c => c.id === item.categoryId)?.name}
                  </span>
                  <h5 className="text-sm font-black text-white uppercase tracking-tighter leading-tight line-clamp-1">{item.name}</h5>
                  <p className="text-[var(--color-neon-green)] font-black text-xs">₹{item.price}</p>
                </div>
              </div>
            </div>
          ))}
          {panItems.length === 0 && (
            <div className="col-span-full py-20 text-center bg-[#111] border border-dashed border-[#333] rounded-3xl">
              <ImageIcon size={48} className="mx-auto text-gray-700 mb-4" />
              <h4 className="text-xl font-bold text-gray-500 uppercase tracking-widest">No Pan Items Found</h4>
              <p className="text-gray-600 mt-2">Add your first pan item to showcase it to customers!</p>
            </div>
          )}
        </div>
      </div>

      {/* Item Modal */}
      {isItemModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="bg-[#111] border border-[#333] w-full max-w-2xl rounded-3xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-[#333] flex justify-between items-center bg-[#1a1a1a]">
              <div>
                <h4 className="text-xl font-black uppercase tracking-tighter">
                  {editingItem ? 'Edit Pan Item' : 'Add New Pan Item'}
                </h4>
                <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Configure pan details and media</p>
              </div>
              <button onClick={() => setIsItemModalOpen(false)} className="text-gray-400 hover:text-white transition-colors">
                <X size={24} />
              </button>
            </div>
            <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="col-span-full">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Pan Name</label>
                  <input 
                    value={itemForm.name}
                    onChange={e => setItemForm({...itemForm, name: e.target.value})}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-xl px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all"
                    placeholder="e.g. Special Mitha Pan"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Price (₹)</label>
                  <input 
                    type="number"
                    value={itemForm.price}
                    onChange={e => setItemForm({...itemForm, price: e.target.value})}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-xl px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all"
                    placeholder="0.00"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Category</label>
                  <select 
                    value={itemForm.categoryId}
                    onChange={e => setItemForm({...itemForm, categoryId: e.target.value})}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-xl px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all"
                  >
                    <option value="">Select Category</option>
                    {panCategories.map(cat => (
                      <option key={cat.id} value={cat.id}>{cat.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Description</label>
                <textarea 
                  value={itemForm.description}
                  onChange={e => setItemForm({...itemForm, description: e.target.value})}
                  className="w-full bg-[#1a1a1a] border border-[#333] rounded-xl px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none h-24 resize-none transition-all"
                  placeholder="Describe the taste and experience..."
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Ingredients (Comma separated)</label>
                <input 
                  value={itemForm.ingredients}
                  onChange={e => setItemForm({...itemForm, ingredients: e.target.value})}
                  className="w-full bg-[#1a1a1a] border border-[#333] rounded-xl px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all"
                  placeholder="e.g. Gulkand, Supari, Cherry, Kattha, Chuna"
                />
              </div>

              <div className="space-y-6 p-6 bg-black/40 rounded-2xl border border-white/5">
                <h5 className="text-[10px] font-black text-[var(--color-neon-green)] uppercase tracking-[0.3em]">Media Assets</h5>
                
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-gray-400">
                    <ImageIcon size={14} />
                    <label className="text-[10px] font-bold uppercase tracking-wider">Image URL</label>
                  </div>
                  <input 
                    value={itemForm.imageUrl}
                    onChange={e => setItemForm({...itemForm, imageUrl: e.target.value})}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-xl px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all text-sm"
                    placeholder="https://images.unsplash.com/..."
                  />
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-gray-400">
                    <Video size={14} />
                    <label className="text-[10px] font-bold uppercase tracking-wider">Video URL (.mp4)</label>
                  </div>
                  <input 
                    value={itemForm.videoUrl}
                    onChange={e => setItemForm({...itemForm, videoUrl: e.target.value})}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-xl px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all text-sm"
                    placeholder="https://example.com/video.mp4"
                  />
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-gray-400">
                    <FileArchive size={14} />
                    <label className="text-[10px] font-bold uppercase tracking-wider">Zip File URL (Assets)</label>
                  </div>
                  <input 
                    value={itemForm.zipUrl}
                    onChange={e => setItemForm({...itemForm, zipUrl: e.target.value})}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-xl px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all text-sm"
                    placeholder="https://example.com/assets.zip"
                  />
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <input 
                  type="checkbox" 
                  id="itemActive"
                  checked={itemForm.active}
                  onChange={e => setItemForm({...itemForm, active: e.target.checked})}
                  className="w-5 h-5 accent-[var(--color-neon-green)] cursor-pointer"
                />
                <label htmlFor="itemActive" className="text-xs font-black text-white uppercase tracking-widest cursor-pointer">Active & Visible to Customers</label>
              </div>
            </div>
            <div className="p-6 border-t border-[#333] flex gap-3 bg-[#1a1a1a]">
              <button 
                onClick={() => setIsItemModalOpen(false)}
                className="flex-1 bg-[#222] text-white font-bold py-4 rounded-xl hover:bg-[#333] transition-all uppercase tracking-widest text-xs"
              >
                Cancel
              </button>
              <button 
                onClick={handleSaveItem}
                className="flex-1 bg-[var(--color-neon-green)] text-black font-black py-4 rounded-xl hover:bg-[#00cc00] transition-all flex items-center justify-center gap-2 uppercase tracking-widest text-xs shadow-[0_0_20px_rgba(0,255,0,0.2)]"
              >
                <Save size={18} />
                Save Pan Item
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
