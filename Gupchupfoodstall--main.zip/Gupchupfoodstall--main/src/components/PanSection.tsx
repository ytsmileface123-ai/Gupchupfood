import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from '../store/useStore';
import { Play, Plus, Star, Zap, ShoppingCart, Info, X, Volume2, VolumeX, Pause, Maximize2 } from 'lucide-react';

const PanVideoPlayer = ({ videoUrl, onExpand, isModal = false }: { videoUrl: string, onExpand?: () => void, isModal?: boolean }) => {
  const [isMuted, setIsMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(true);
  const videoRef = React.useRef<HTMLVideoElement>(null);

  const togglePlay = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsMuted(!isMuted);
  };

  return (
    <>
      <video 
        ref={videoRef}
        src={videoUrl} 
        className="w-full h-full object-cover" 
        muted={isMuted} 
        loop 
        autoPlay 
        playsInline
      />
      <div className={`absolute ${isModal ? 'top-6 right-6' : 'top-4 right-4'} z-30 flex flex-col gap-2`}>
        <button 
          onClick={toggleMute}
          className="bg-black/50 hover:bg-[var(--color-neon-green)] hover:text-black p-2 rounded-full backdrop-blur-md border border-white/10 transition-all duration-300 text-white shadow-lg"
          title={isMuted ? "Unmute" : "Mute"}
        >
          {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
        </button>
        <button 
          onClick={togglePlay}
          className="bg-black/50 hover:bg-[var(--color-neon-green)] hover:text-black p-2 rounded-full backdrop-blur-md border border-white/10 transition-all duration-300 text-white shadow-lg"
          title={isPlaying ? "Pause" : "Play"}
        >
          {isPlaying ? <Pause size={16} /> : <Play size={16} />}
        </button>
        {!isModal && onExpand && (
          <button 
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onExpand();
            }}
            className="bg-black/50 hover:bg-[var(--color-neon-green)] hover:text-black p-2 rounded-full backdrop-blur-md border border-white/10 transition-all duration-300 text-white shadow-lg"
            title="Open Fullscreen"
          >
            <Maximize2 size={16} />
          </button>
        )}
      </div>
    </>
  );
};

export default function PanSection() {
  const { panCategories, panItems, settings, addToCart } = useStore();
  const [activeCategory, setActiveCategory] = useState(panCategories[0]?.id || '');
  const [selectedItem, setSelectedItem] = useState<any>(null);

  useEffect(() => {
    if (!activeCategory && panCategories.length > 0) {
      setActiveCategory(panCategories[0].id);
    }
  }, [panCategories, activeCategory]);

  if (!settings.isPanEnabled) return null;

  const filteredItems = panItems.filter(item => item.categoryId === activeCategory && item.active);

  return (
    <section className="py-24 bg-black relative overflow-hidden">
      {/* Background Glows */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-[var(--color-neon-green)]/10 blur-[120px] rounded-full" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/10 blur-[120px] rounded-full" />

      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <motion.span 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-[var(--color-neon-green)] font-black uppercase tracking-[0.4em] text-xs mb-4 block"
          >
            {settings.panSectionSubtitle || 'Premium Quality'}
          </motion.span>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl font-black text-white uppercase tracking-tighter mb-4"
          >
            {settings.panSectionTitle || 'Special Assam Pan'}
          </motion.h2>
          <div className="w-24 h-1 bg-[var(--color-neon-green)] mx-auto rounded-full shadow-[0_0_10px_rgba(0,255,0,0.5)]" />
        </div>
        
        {/* Category Tabs */}
        <div className="flex gap-3 mb-12 overflow-x-auto pb-4 justify-center no-scrollbar px-4">
          {panCategories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-8 py-3 rounded-2xl font-black uppercase text-[10px] tracking-[0.2em] transition-all whitespace-nowrap border relative group/tab ${
                activeCategory === cat.id 
                  ? 'bg-[var(--color-neon-green)] text-black border-[var(--color-neon-green)] shadow-[0_0_30px_rgba(0,255,0,0.4)]' 
                  : 'bg-white/5 text-gray-400 border-white/10 hover:bg-white/10 hover:text-white hover:border-white/20'
              }`}
            >
              {activeCategory === cat.id && (
                <motion.div 
                  layoutId="activeTabGlow"
                  className="absolute inset-0 rounded-2xl bg-[var(--color-neon-green)] blur-lg opacity-20 -z-10"
                />
              )}
              {cat.name}
            </button>
          ))}
        </div>

        {/* Items Grid - Reels Style */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          <AnimatePresence mode="popLayout">
            {filteredItems.map((item, idx) => (
              <motion.div 
                key={item.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: idx * 0.05 }}
                className="group relative aspect-[4/5] rounded-[2rem] overflow-hidden bg-[#111] border border-white/5 hover:border-[var(--color-neon-green)]/50 transition-all shadow-2xl"
              >
                {/* Media Content */}
                <div className="absolute inset-0">
                  {item.videoUrl ? (
                    <PanVideoPlayer videoUrl={item.videoUrl} onExpand={() => setSelectedItem(item)} />
                  ) : (
                    <img 
                      src={item.imageUrl || 'https://picsum.photos/seed/pan/400/700'} 
                      className="w-full h-full object-cover" 
                      alt={item.name} 
                      referrerPolicy="no-referrer"
                    />
                  )}
                  {/* Overlay Gradient */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity pointer-events-none" />
                </div>

                {/* Content Overlay */}
                <div className="absolute inset-0 p-5 flex flex-col justify-end">
                  <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="bg-[var(--color-neon-green)] text-black text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-tighter">
                        Premium
                      </div>
                      <div className="flex gap-0.5">
                        {[1, 2, 3, 4, 5].map(s => <Star key={s} size={8} className="fill-[var(--color-neon-green)] text-[var(--color-neon-green)]" />)}
                      </div>
                    </div>
                    
                    <h3 className="text-xl font-black text-white uppercase tracking-tighter leading-tight mb-1 group-hover:text-[var(--color-neon-green)] transition-colors">
                      {item.name}
                    </h3>

                    {item.ingredients && item.ingredients.length > 0 && (
                      <div className="flex items-center gap-1 mb-2">
                        <Zap size={10} className="text-[var(--color-neon-green)]" />
                        <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest">
                          {item.ingredients.length} Special Ingredients
                        </span>
                      </div>
                    )}
                    
                    <p className="text-gray-400 text-[10px] font-bold uppercase tracking-widest mb-4 line-clamp-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      {item.description}
                    </p>

                    <div className="flex justify-between items-center">
                      <div className="flex flex-col">
                        <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Price</span>
                        <span className="text-2xl font-black text-[var(--color-neon-green)] tracking-tighter">₹{item.price}</span>
                      </div>
                      
                      <div className="flex gap-2">
                        <button 
                          onClick={() => setSelectedItem(item)}
                          className="bg-white/10 backdrop-blur-md p-3 rounded-2xl hover:bg-white/20 text-white transition-all"
                        >
                          <Info size={18} />
                        </button>
                        <button 
                          onClick={() => addToCart({
                            id: item.id,
                            name: item.name,
                            price: item.price,
                            imageUrl: item.imageUrl || '',
                            quantity: 1
                          })}
                          className="bg-[var(--color-neon-green)] p-3 rounded-2xl text-black hover:scale-110 active:scale-95 transition-all shadow-[0_0_15px_rgba(0,255,0,0.3)]"
                        >
                          <Plus size={18} strokeWidth={3} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Reels Style Badge */}
                <div className="absolute top-4 left-4">
                  <div className="bg-black/40 backdrop-blur-md border border-white/10 p-2 rounded-xl">
                    <Play size={12} className="text-white fill-white" />
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-20">
            <p className="text-gray-500 font-bold uppercase tracking-[0.2em]">No items found in this category</p>
          </div>
        )}
      </div>

      {/* Item Detail Modal */}
      <AnimatePresence>
        {selectedItem && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-[#0a0a0a] border border-white/10 w-full max-w-4xl max-h-[85vh] rounded-[2rem] md:rounded-[3rem] overflow-hidden shadow-2xl flex flex-col md:flex-row"
            >
              <div className="w-full md:w-1/2 h-[40vh] md:h-auto relative bg-black shrink-0">
                {selectedItem.videoUrl ? (
                  <PanVideoPlayer videoUrl={selectedItem.videoUrl} isModal={true} />
                ) : (
                  <img src={selectedItem.imageUrl} className="w-full h-full object-contain md:object-cover" alt={selectedItem.name} />
                )}
                <button 
                  onClick={() => setSelectedItem(null)}
                  className="absolute top-4 left-4 md:top-6 md:left-6 z-40 bg-black/50 backdrop-blur-md p-3 rounded-2xl text-white hover:bg-black/80 hover:text-[var(--color-neon-red)] transition-all shadow-lg border border-white/10"
                  title="Close"
                >
                  <X size={24} />
                </button>
              </div>
              <div className="w-full md:w-1/2 p-6 md:p-10 flex flex-col overflow-y-auto">
                <span className="text-[var(--color-neon-green)] font-black uppercase tracking-[0.4em] text-xs mb-4 block">
                  Product Details
                </span>
                <h3 className="text-4xl md:text-5xl font-black text-white uppercase tracking-tighter mb-6 leading-none">
                  {selectedItem.name}
                </h3>
                <p className="text-gray-400 text-lg mb-8 leading-relaxed">
                  {selectedItem.description}
                </p>

                {selectedItem.ingredients && selectedItem.ingredients.length > 0 && (
                  <div className="mb-8">
                    <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] mb-4">What's Inside</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedItem.ingredients.map((ing: string, i: number) => (
                        <span key={i} className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-xl text-[10px] font-bold text-white uppercase tracking-widest">
                          {ing}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="space-y-6 mb-10">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-[var(--color-neon-green)]">
                      <Zap size={24} />
                    </div>
                    <div>
                      <p className="text-white font-bold uppercase tracking-widest text-xs">Premium Quality</p>
                      <p className="text-gray-500 text-sm">Handcrafted with special Assam ingredients</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-[var(--color-neon-green)]">
                      <Star size={24} />
                    </div>
                    <div>
                      <p className="text-white font-bold uppercase tracking-widest text-xs">Customer Favorite</p>
                      <p className="text-gray-500 text-sm">Top rated pan in our collection</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-8 border-t border-white/10">
                  <div className="flex flex-col">
                    <span className="text-xs font-black text-gray-500 uppercase tracking-widest">Total Price</span>
                    <span className="text-4xl font-black text-[var(--color-neon-green)] tracking-tighter">₹{selectedItem.price}</span>
                  </div>
                  <button 
                    onClick={() => {
                      addToCart({
                        id: selectedItem.id,
                        name: selectedItem.name,
                        price: selectedItem.price,
                        imageUrl: selectedItem.imageUrl || '',
                        quantity: 1
                      });
                      setSelectedItem(null);
                    }}
                    className="bg-[var(--color-neon-green)] text-black font-black px-10 py-5 rounded-3xl hover:scale-105 active:scale-95 transition-all flex items-center gap-3 uppercase tracking-widest text-sm shadow-[0_0_30px_rgba(0,255,0,0.3)]"
                  >
                    <ShoppingCart size={20} />
                    Add to Cart
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
