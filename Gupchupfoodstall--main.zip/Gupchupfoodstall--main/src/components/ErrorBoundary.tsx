import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      let errorMessage = 'Something went wrong.';
      
      try {
        // Check if the error is a FirestoreErrorInfo JSON string
        const errorInfo = JSON.parse(this.state.error?.message || '');
        if (errorInfo.error && errorInfo.operationType) {
          errorMessage = `Firestore ${errorInfo.operationType} error on path: ${errorInfo.path || 'unknown'}. ${errorInfo.error}`;
        }
      } catch (e) {
        // Not a JSON error, use the default or the error message
        errorMessage = this.state.error?.message || errorMessage;
      }

      return (
        <div className="min-h-screen flex items-center justify-center bg-black text-white p-6">
          <div className="max-w-md w-full bg-red-900/20 border border-red-500/50 rounded-2xl p-8 backdrop-blur-xl shadow-2xl">
            <h2 className="text-2xl font-black uppercase mb-4 text-red-500 tracking-tighter">Unexpected Error</h2>
            <p className="text-gray-300 mb-6 font-medium leading-relaxed">
              {errorMessage}
            </p>
            <button
              onClick={() => window.location.reload()}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-black py-3 rounded-xl transition-all uppercase tracking-widest"
            >
              Reload Application
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
