import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { collection, query, onSnapshot, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';
import { useStore } from '../store/useStore';
import { ShoppingCart, Star, Info, Play, X, ChevronRight, ChevronLeft } from 'lucide-react';
import InfluencerVideo from './InfluencerVideo';

interface ChickenRate {
  weight: string;
  price: number;
}

interface ChickenItem {
  id: string;
  name: string;
  category: 'Broiler Chicken' | 'Desi Chicken';
  quality: string;
  remark: string;
  imageUrl: string;
  videoUrl: string;
  isVideoEnabled: boolean;
  rates: ChickenRate[];
  active: boolean;
  order: number;
}

export default function ChickenStoreSection() {
  const [items, setItems] = useState<ChickenItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<ChickenItem | null>(null);
  const { settings, addToCart } = useStore();

  useEffect(() => {
    const q = query(collection(db, 'chickenItems'), orderBy('order', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as ChickenItem[];
      setItems(data.filter(item => item.active));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'chickenItems');
    });
    return () => unsubscribe();
  }, []);

  if (!settings.isChickenStoreEnabled || items.length === 0) return null;

  const broilerItems = items.filter(item => item.category === 'Broiler Chicken');
  const desiItems = items.filter(item => item.category === 'Desi Chicken');

  const handleOrder = (item: ChickenItem, rate: ChickenRate) => {
    addToCart({
      id: `${item.id}-${rate.weight}`,
      cartItemId: `${item.id}-${rate.weight}`,
      name: `${item.name} (${rate.weight})`,
      price: rate.price,
      quantity: 1,
      imageUrl: item.imageUrl,
    });
  };

  return (
    <section className="py-24 relative overflow-hidden bg-black">
      {/* Background Glow */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-[var(--color-neon-green)]/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-red-500/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] font-black text-[var(--color-neon-green)] uppercase tracking-[0.3em] mb-4"
          >
            <Star size={14} className="text-yellow-400" /> {settings.chickenStoreSectionSubtitle}
          </motion.div>
          <h2 className="text-5xl md:text-8xl font-black text-white uppercase tracking-tighter leading-none italic mb-6">
            {settings.chickenStoreSectionTitle.split(' ')[0]} <span className="text-white/20">{settings.chickenStoreSectionTitle.split(' ').slice(1).join(' ')}</span>
          </h2>
        </div>

        {/* Categories Tabs/Sections */}
        <div className="space-y-24">
          {/* Broiler Section */}
          {broilerItems.length > 0 && (
            <div className="space-y-12">
              <div className="flex items-center gap-4">
                <div className="h-px flex-1 bg-gradient-to-r from-transparent to-white/10"></div>
                <h3 className="text-2xl md:text-4xl font-black text-white uppercase tracking-widest italic">Broiler Chicken</h3>
                <div className="h-px flex-1 bg-gradient-to-l from-transparent to-white/10"></div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {broilerItems.map((item) => (
                  <ChickenCard key={item.id} item={item} onOrder={handleOrder} onPreview={() => setSelectedItem(item)} />
                ))}
              </div>
            </div>
          )}

          {/* Desi Section */}
          {desiItems.length > 0 && (
            <div className="space-y-12">
              <div className="flex items-center gap-4">
                <div className="h-px flex-1 bg-gradient-to-r from-transparent to-white/10"></div>
                <h3 className="text-2xl md:text-4xl font-black text-white uppercase tracking-widest italic">Desi Chicken</h3>
                <div className="h-px flex-1 bg-gradient-to-l from-transparent to-white/10"></div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {desiItems.map((item) => (
                  <ChickenCard key={item.id} item={item} onOrder={handleOrder} onPreview={() => setSelectedItem(item)} />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Instagram Reels Style Modal */}
      <AnimatePresence>
        {selectedItem && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center p-0 md:p-4"
          >
            <div className="relative w-full h-full max-w-sm aspect-[9/16] bg-black overflow-hidden md:rounded-3xl shadow-2xl flex flex-col">
              <InfluencerVideo 
                videoUrl={selectedItem.isVideoEnabled ? selectedItem.videoUrl : selectedItem.imageUrl}
                influencerName={selectedItem.name}
                influencerImage={selectedItem.imageUrl}
                caption={selectedItem.remark}
                mediaType={selectedItem.isVideoEnabled && selectedItem.videoUrl ? 'video' : 'image'}
                isModal={true}
                noModal={true}
                showMuteButton={true}
              >
                {/* Rates in Modal */}
                <div className="grid grid-cols-2 gap-3 pt-4">
                  {selectedItem.rates.map((rate, idx) => (
                    <button
                      key={`modal-rate-${selectedItem.id}-${rate.weight}-${idx}`}
                      onClick={() => handleOrder(selectedItem, rate)}
                      className="flex flex-col items-center p-3 rounded-2xl bg-white/10 border border-white/10 hover:bg-[var(--color-neon-green)] hover:text-black transition-all group"
                    >
                      <span className="text-[10px] font-bold uppercase opacity-60">{rate.weight}</span>
                      <span className="text-lg font-black">₹{rate.price}</span>
                    </button>
                  ))}
                </div>
              </InfluencerVideo>
              
              {/* Close Button */}
              <button 
                onClick={() => setSelectedItem(null)}
                className="absolute top-6 right-6 z-[250] p-2 rounded-full bg-black/50 text-white hover:bg-black/80 transition-colors"
              >
                <X size={24} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

function ChickenCard({ item, onOrder, onPreview }: { item: ChickenItem, onOrder: (item: ChickenItem, rate: ChickenRate) => void, onPreview: () => void }) {
  const [isMuted, setIsMuted] = useState(true);

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      whileInView={{ opacity: 1, scale: 1 }}
      className="group relative bg-[#0a0a0a] border border-white/10 rounded-[2.5rem] overflow-hidden hover:border-[var(--color-neon-green)]/50 transition-all duration-500 flex flex-col h-full"
    >
      {/* Media Preview */}
      <div className="relative h-64 overflow-hidden shrink-0">
        {item.isVideoEnabled && item.videoUrl ? (
          <video 
            src={item.videoUrl}
            muted={isMuted}
            loop
            autoPlay
            playsInline
            poster={item.imageUrl}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
          />
        ) : (
          <img 
            src={item.imageUrl || `https://picsum.photos/seed/${item.name}/400/300`}
            alt={item.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-transparent" />
        
        {/* Mute Toggle Button for Video */}
        {item.isVideoEnabled && item.videoUrl && (
          <button 
            onClick={(e) => {
              e.stopPropagation();
              setIsMuted(!isMuted);
            }}
            className="absolute top-4 right-4 z-20 p-2.5 bg-black/50 backdrop-blur-md rounded-full text-white border border-white/10 hover:border-[var(--color-neon-green)]/50 transition-colors"
          >
            {isMuted ? <span className="opacity-60 text-sm">🔇</span> : <span className="text-[var(--color-neon-green)] text-sm">🔊</span>}
          </button>
        )}

        {/* Play Button Overlay (for full screen preview) */}
        <button 
          onClick={onPreview}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-all duration-500 hover:scale-110 z-10"
        >
          <Play size={32} fill="currentColor" />
        </button>

        {/* Quality Badge */}
        <div className="absolute top-4 left-4 z-10">
          <span className="px-3 py-1 rounded-full bg-black/50 backdrop-blur-md border border-white/10 text-[10px] font-black text-[var(--color-neon-green)] uppercase tracking-widest">
            {item.quality || 'Premium'}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-8 space-y-6 flex-1 flex flex-col">
        <div>
          <h4 className="text-2xl font-black text-white uppercase italic tracking-tighter mb-2 group-hover:text-[var(--color-neon-green)] transition-colors">
            {item.name}
          </h4>
          <p className="text-gray-400 text-xs line-clamp-2 italic">"{item.remark || 'Fresh and tender chicken, perfect for your favorite recipes.'}"</p>
        </div>

        {/* Rates Grid */}
        <div className="grid grid-cols-2 gap-3 mt-auto">
          {item.rates.map((rate, idx) => (
            <button
              key={`card-rate-${item.id}-${rate.weight}-${idx}`}
              onClick={() => onOrder(item, rate)}
              className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5 hover:bg-[var(--color-neon-green)] hover:text-black transition-all group/btn"
            >
              <span className="text-[10px] font-bold uppercase">{rate.weight}</span>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black">₹{rate.price}</span>
                <ShoppingCart size={14} className="opacity-0 group-hover/btn:opacity-100 transition-opacity" />
              </div>
            </button>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
