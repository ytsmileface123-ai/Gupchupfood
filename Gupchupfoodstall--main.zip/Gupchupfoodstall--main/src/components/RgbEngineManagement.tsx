import React, { useState, useEffect } from 'react';
import { useStore, RgbConfig } from '../store/useStore';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';
import { Sparkles, Save, RefreshCw, Battery, Zap, Palette, Layout, Target, Sliders } from 'lucide-react';
import { motion } from 'framer-motion';

export default function RgbEngineManagement() {
  const { settings, setSettings } = useStore();
  const [config, setConfig] = useState<RgbConfig>(settings.rgbConfig);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    setConfig(settings.rgbConfig);
  }, [settings.rgbConfig]);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const updatedSettings = { ...settings, rgbConfig: config };
      await setDoc(doc(db, 'settings', 'global'), updatedSettings);
      setSettings(updatedSettings);
      alert('RGB Engine settings saved successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'settings/global');
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = () => {
    if (window.confirm('Are you sure you want to reset RGB settings to default?')) {
      const defaultConfig: RgbConfig = {
        globalEnable: true,
        sections: {
          hero: true, menu: true, events: true, cart: true, offers: true, reels: true,
          cashback: true, moments: true, photostudio: true, influencers: true, sponsored: true,
          footerInfo: true, notifications: true, featuredInfluencers: true, stories: true,
          partnerCollab: true, riderList: true, founders: true, getDirections: true,
          openingHours: true, contact: true, chickenStore: true, banners: true
        },
        targets: { background: false, buttons: true, borders: true, cards: false, headings: true, icons: true },
        speed: 'medium',
        customSpeedMs: 3000,
        colorMode: 'multi',
        singleColor: '#d4af37',
        glowIntensity: 'medium',
        batterySaver: false
      };
      setConfig(defaultConfig);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black text-white uppercase tracking-tighter flex items-center gap-3">
            <Sparkles className="text-[#d4af37]" /> RGB Engine Control
          </h2>
          <p className="text-gray-400">Advanced Next-Gen Dynamic UI Color System</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={handleReset}
            className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white rounded-lg font-bold transition-colors flex items-center gap-2"
          >
            <RefreshCw size={18} /> Reset
          </button>
          <button 
            onClick={handleSave}
            disabled={isSaving}
            className="px-6 py-2 bg-[#d4af37] hover:bg-[#f3e5ab] text-black rounded-lg font-black transition-colors flex items-center gap-2 disabled:opacity-50"
          >
            <Save size={18} /> {isSaving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Global Control */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-[#111] border border-[#333] rounded-2xl p-6">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2 border-b border-white/10 pb-4">
            <Zap className="text-[var(--color-neon-green)]" /> Global Control
          </h3>
          
          <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/10 mb-6">
            <div>
              <h4 className="font-bold text-white text-lg">Enable RGB Engine</h4>
              <p className="text-sm text-gray-400">Turn the entire RGB system on or off</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" checked={config.globalEnable} onChange={e => setConfig({...config, globalEnable: e.target.checked})} />
              <div className="w-14 h-7 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-[#d4af37]"></div>
            </label>
          </div>

          <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/10">
            <div>
              <h4 className="font-bold text-white flex items-center gap-2"><Battery size={16} className="text-green-500" /> Battery Saver Mode</h4>
              <p className="text-sm text-gray-400">Reduce animation speed and intensity for better performance</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" checked={config.batterySaver} onChange={e => setConfig({...config, batterySaver: e.target.checked})} />
              <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-500"></div>
            </label>
          </div>
        </motion.div>

        {/* Color Mode System */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-[#111] border border-[#333] rounded-2xl p-6">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2 border-b border-white/10 pb-4">
            <Palette className="text-purple-500" /> Color Mode System
          </h3>
          
          <div className="grid grid-cols-2 gap-4 mb-6">
            {[
              { id: 'multi', label: 'Multi RGB', desc: 'Full spectrum cycling' },
              { id: 'single', label: 'Single Color', desc: 'One theme color' },
              { id: 'neon', label: 'Neon Mode', desc: 'High glow futuristic' },
              { id: 'soft', label: 'Soft Glow', desc: 'Low light premium' }
            ].map(mode => (
              <button
                key={mode.id}
                onClick={() => setConfig({...config, colorMode: mode.id as any})}
                className={`p-4 rounded-xl border text-left transition-all ${config.colorMode === mode.id ? 'bg-[#d4af37]/20 border-[#d4af37] text-white' : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10'}`}
              >
                <div className="font-bold mb-1">{mode.label}</div>
                <div className="text-xs opacity-70">{mode.desc}</div>
              </button>
            ))}
          </div>

          {config.colorMode === 'single' && (
            <div className="p-4 bg-white/5 rounded-xl border border-white/10">
              <label className="block text-sm font-bold text-gray-400 uppercase mb-2">Theme Color</label>
              <div className="flex items-center gap-4">
                <input type="color" value={config.singleColor} onChange={e => setConfig({...config, singleColor: e.target.value})} className="w-12 h-12 rounded cursor-pointer bg-transparent border-0 p-0" />
                <input type="text" value={config.singleColor} onChange={e => setConfig({...config, singleColor: e.target.value})} className="flex-1 bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white font-mono" />
              </div>
            </div>
          )}
        </motion.div>

        {/* Animation Control */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-[#111] border border-[#333] rounded-2xl p-6">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2 border-b border-white/10 pb-4">
            <Sliders className="text-blue-500" /> Animation Control
          </h3>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-gray-400 uppercase mb-3">Animation Speed</label>
              <div className="flex flex-wrap gap-3">
                {['slow', 'medium', 'fast', 'custom'].map(speed => (
                  <button
                    key={speed}
                    onClick={() => setConfig({...config, speed: speed as any})}
                    className={`px-4 py-2 rounded-lg text-sm font-bold capitalize transition-all ${config.speed === speed ? 'bg-blue-500 text-white' : 'bg-white/5 text-gray-400 hover:bg-white/10'}`}
                  >
                    {speed}
                  </button>
                ))}
              </div>
            </div>

            {config.speed === 'custom' && (
              <div>
                <label className="block text-sm font-bold text-gray-400 uppercase mb-2">Custom Speed (ms)</label>
                <input 
                  type="number" 
                  value={config.customSpeedMs} 
                  onChange={e => setConfig({...config, customSpeedMs: Number(e.target.value)})} 
                  className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white" 
                  min="100"
                  step="100"
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-bold text-gray-400 uppercase mb-3">Glow Intensity</label>
              <div className="flex gap-3">
                {['low', 'medium', 'high'].map(intensity => (
                  <button
                    key={intensity}
                    onClick={() => setConfig({...config, glowIntensity: intensity as any})}
                    className={`flex-1 py-2 rounded-lg text-sm font-bold capitalize transition-all ${config.glowIntensity === intensity ? 'bg-purple-500 text-white' : 'bg-white/5 text-gray-400 hover:bg-white/10'}`}
                  >
                    {intensity}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Apply Targets */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="bg-[#111] border border-[#333] rounded-2xl p-6">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2 border-b border-white/10 pb-4">
            <Target className="text-red-500" /> Apply Targets
          </h3>
          
          <div className="grid grid-cols-2 gap-4">
            {Object.entries(config.targets).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-white/5">
                <span className="text-sm font-bold text-gray-300 capitalize">{key}</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={value} 
                    onChange={e => setConfig({
                      ...config, 
                      targets: { ...config.targets, [key]: e.target.checked }
                    })} 
                  />
                  <div className="w-9 h-5 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-red-500"></div>
                </label>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Section Control */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="bg-[#111] border border-[#333] rounded-2xl p-6 lg:col-span-2">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2 border-b border-white/10 pb-4">
            <Layout className="text-orange-500" /> Section-wise Control
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            {Object.entries(config.sections).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/10">
                <span className="font-bold text-white capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={value} 
                    onChange={e => setConfig({
                      ...config, 
                      sections: { ...config.sections, [key]: e.target.checked }
                    })} 
                  />
                  <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-500"></div>
                </label>
              </div>
            ))}
          </div>
        </motion.div>

      </div>
    </div>
  );
}
