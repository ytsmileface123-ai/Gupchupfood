import React, { useState, useEffect } from 'react';
import { collection, query, onSnapshot, doc, updateDoc, deleteDoc, addDoc, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';
import { Plus, Trash2, Edit2, X, Play, Image as ImageIcon } from 'lucide-react';

const MediaUploadInput = ({ 
  label, 
  value, 
  onChange, 
  placeholder = "https://...",
  accept = "video/mp4,image/*,image/gif,application/zip",
  buttonText = "Upload Media (MP4/GIF/IMG/ZIP)",
  note = "Max 1MB for direct upload. Use URL for larger files."
}: { 
  label: string, 
  value: string, 
  onChange: (val: string) => void, 
  placeholder?: string,
  accept?: string,
  buttonText?: string,
  note?: string
}) => (
  <div>
    <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">{label}</label>
    <div className="flex flex-col gap-3">
      <input 
        type="url" 
        value={value || ''} 
        onChange={e => onChange(e.target.value)} 
        className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
        placeholder={placeholder} 
      />
      <div className="flex items-center gap-4">
        <label className="bg-[#222] hover:bg-[#333] text-white text-[10px] font-black py-1.5 px-3 rounded-md cursor-pointer transition-colors border border-[#444] text-center uppercase tracking-tighter flex items-center gap-2">
          <Plus size={12} /> {buttonText}
          <input 
            type="file" 
            accept={accept} 
            className="hidden" 
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                if (file.size > 1024 * 1024) {
                  console.error("File is too large (max 1MB). Use URL for larger files.");
                  // You could add a toast notification here if available
                  return;
                }
                const reader = new FileReader();
                reader.onload = (event) => {
                  onChange(event.target?.result as string);
                };
                reader.readAsDataURL(file);
              }
            }}
          />
        </label>
        {note && <span className="text-[9px] text-gray-500 italic">{note}</span>}
      </div>
    </div>
  </div>
);

export default function MomentsManagement() {
  const [moments, setMoments] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMoment, setEditingMoment] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: '',
    customerImageUrl: '',
    address: '',
    mobile: '',
    hobby: '',
    remark: '',
    date: '',
    time: '',
    day: '',
    category: 'Birthday',
    mediaUrl: '',
    mediaType: 'image' as 'image' | 'video' | 'gif',
    isStoryFormat: false,
    active: true,
    order: 0
  });

  useEffect(() => {
    const q = query(collection(db, 'moments'), orderBy('order', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMoments(data);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'moments');
    });
    return () => unsubscribe();
  }, []);

  const handleOpenModal = (moment?: any) => {
    if (moment) {
      setEditingMoment(moment);
      setFormData({
        name: moment.name || '',
        customerImageUrl: moment.customerImageUrl || '',
        address: moment.address || '',
        mobile: moment.mobile || '',
        hobby: moment.hobby || '',
        remark: moment.remark || '',
        date: moment.date || '',
        time: moment.time || '',
        day: moment.day || '',
        category: moment.category || 'Birthday',
        mediaUrl: moment.mediaUrl || '',
        mediaType: moment.mediaType || 'image',
        isStoryFormat: moment.isStoryFormat || false,
        active: moment.active ?? true,
        order: moment.order || 0
      });
    } else {
      setEditingMoment(null);
      setFormData({
        name: '',
        customerImageUrl: '',
        address: '',
        mobile: '',
        hobby: '',
        remark: '',
        date: new Date().toISOString().split('T')[0],
        time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
        day: new Date().toLocaleDateString('en-US', { weekday: 'long' }),
        category: 'Birthday',
        mediaUrl: '',
        mediaType: 'image',
        isStoryFormat: false,
        active: true,
        order: moments.length
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingMoment) {
        await updateDoc(doc(db, 'moments', editingMoment.id), formData);
      } else {
        await addDoc(collection(db, 'moments'), formData);
      }
      setIsModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, editingMoment ? OperationType.UPDATE : OperationType.CREATE, editingMoment ? `moments/${editingMoment.id}` : 'moments');
    }
  };

  const [error, setError] = useState<string | null>(null);

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'moments', id));
    } catch (error) {
      setError("Failed to delete moment.");
      handleFirestoreError(error, OperationType.DELETE, `moments/${id}`);
    }
  };

  return (
    <div className="space-y-6">
      {error && (
        <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-xl flex items-center justify-between">
          <p className="text-red-500 text-xs font-bold uppercase tracking-widest">{error}</p>
          <button onClick={() => setError(null)}><X size={14} className="text-red-500" /></button>
        </div>
      )}
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-black uppercase text-white tracking-tighter">Moments & Celebrations</h3>
        <button 
          onClick={() => handleOpenModal()}
          className="bg-[var(--color-neon-green)] text-black px-4 py-2 rounded-lg font-bold flex items-center gap-2 hover:bg-white transition-colors"
        >
          <Plus size={20} /> Add Moment
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {moments.map(moment => (
          <div key={moment.id} className="bg-[#111] border border-[#333] rounded-2xl overflow-hidden group">
            <div className={`relative ${moment.isStoryFormat ? 'aspect-[9/16]' : 'aspect-video'} bg-black`}>
              {moment.mediaType === 'video' ? (
                <video src={moment.mediaUrl} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" muted loop playsInline />
              ) : (
                <img src={moment.mediaUrl || `https://picsum.photos/seed/${moment.id}/400/300`} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
              )}
              <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[10px] font-bold text-white uppercase">
                {moment.category}
              </div>
              <div className="absolute top-2 left-2 flex gap-2">
                <button onClick={() => handleOpenModal(moment)} className="p-2 bg-blue-500/80 text-white rounded-lg hover:bg-blue-500 transition-colors backdrop-blur-sm">
                  <Edit2 size={14} />
                </button>
                <button onClick={() => handleDelete(moment.id)} className="p-2 bg-red-500/80 text-white rounded-lg hover:bg-red-500 transition-colors backdrop-blur-sm">
                  <Trash2 size={14} />
                </button>
              </div>
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black to-transparent">
                <h4 className="text-lg font-black text-white uppercase">{moment.name}</h4>
                <p className="text-xs text-gray-300">{moment.date} • {moment.time}</p>
              </div>
            </div>
            <div className="p-4 space-y-2">
              <p className="text-sm text-gray-400 line-clamp-2 italic">"{moment.remark}"</p>
              <div className="flex flex-wrap gap-2 mt-2">
                {moment.hobby && <span className="text-[10px] bg-white/5 px-2 py-1 rounded text-gray-300">{moment.hobby}</span>}
                {moment.address && <span className="text-[10px] bg-white/5 px-2 py-1 rounded text-gray-300">{moment.address}</span>}
              </div>
            </div>
          </div>
        ))}
        {moments.length === 0 && (
          <div className="col-span-full py-12 text-center text-gray-500 bg-[#111] border border-[#333] rounded-2xl border-dashed">
            <ImageIcon className="mx-auto mb-4 opacity-20" size={48} />
            <p className="font-bold">No moments added yet.</p>
          </div>
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-[#111] border border-[#333] rounded-2xl w-full max-w-2xl my-8">
            <div className="flex justify-between items-center p-6 border-b border-[#333] sticky top-0 bg-[#111] z-10 rounded-t-2xl">
              <h3 className="text-xl font-black uppercase text-white">{editingMoment ? 'Edit Moment' : 'Add Moment'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-white transition-colors">
                <X size={24} />
              </button>
            </div>
            
            <form onSubmit={handleSave} className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Customer Name</label>
                  <input type="text" required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">What did they get? (Category)</label>
                  <input type="text" required placeholder="e.g. New Bike, iPhone 15, Birthday Cake" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Mobile Number</label>
                  <input type="text" value={formData.mobile} onChange={e => setFormData({...formData, mobile: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Address / Location</label>
                  <input type="text" value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Date</label>
                  <input type="date" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Time</label>
                  <input type="time" value={formData.time} onChange={e => setFormData({...formData, time: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Day</label>
                  <input type="text" value={formData.day} onChange={e => setFormData({...formData, day: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Hobby / Interest</label>
                  <input type="text" value={formData.hobby} onChange={e => setFormData({...formData, hobby: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Remark / Experience</label>
                <textarea rows={3} value={formData.remark} onChange={e => setFormData({...formData, remark: e.target.value})} className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none resize-none" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-black/40 rounded-xl border border-white/5">
                <div className="col-span-full">
                  <MediaUploadInput 
                    label="Customer Profile Image / Logo (Optional)" 
                    value={formData.customerImageUrl} 
                    onChange={val => setFormData({...formData, customerImageUrl: val})} 
                    buttonText="Upload Profile Pic"
                  />
                </div>
                <div className="col-span-full border-t border-white/5 my-2"></div>
                <div className="col-span-full">
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Main Media Type (What they bought/celebrated)</label>
                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 text-sm text-white cursor-pointer">
                      <input type="radio" name="momentMediaType" checked={formData.mediaType === 'image'} onChange={() => setFormData({...formData, mediaType: 'image'})} className="accent-[var(--color-neon-green)]" /> Image
                    </label>
                    <label className="flex items-center gap-2 text-sm text-white cursor-pointer">
                      <input type="radio" name="momentMediaType" checked={formData.mediaType === 'video'} onChange={() => setFormData({...formData, mediaType: 'video'})} className="accent-[var(--color-neon-green)]" /> Video
                    </label>
                    <label className="flex items-center gap-2 text-sm text-white cursor-pointer">
                      <input type="radio" name="momentMediaType" checked={formData.mediaType === 'gif'} onChange={() => setFormData({...formData, mediaType: 'gif'})} className="accent-[var(--color-neon-green)]" /> GIF
                    </label>
                  </div>
                </div>
                
                <div className="col-span-full">
                  <MediaUploadInput 
                    label="Media URL" 
                    value={formData.mediaUrl} 
                    onChange={val => setFormData({...formData, mediaUrl: val})} 
                  />
                </div>

                <div className="col-span-full flex items-center gap-3">
                  <input type="checkbox" id="isStoryFormat" checked={formData.isStoryFormat} onChange={e => setFormData({...formData, isStoryFormat: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                  <label htmlFor="isStoryFormat" className="text-sm font-bold text-white">Display as Vertical Story (9:16)</label>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <input type="checkbox" id="momentActive" checked={formData.active} onChange={e => setFormData({...formData, active: e.target.checked})} className="w-5 h-5 accent-[var(--color-neon-green)]" />
                <label htmlFor="momentActive" className="text-sm font-bold text-white">Active (Visible on website)</label>
              </div>

              <div className="flex justify-end gap-4 pt-6 border-t border-[#333]">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-6 py-2 rounded-lg font-bold text-gray-400 hover:text-white transition-colors">Cancel</button>
                <button type="submit" className="bg-[var(--color-neon-green)] text-black px-8 py-2 rounded-lg font-black uppercase tracking-wider hover:bg-white transition-colors">Save Moment</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
