import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Trophy, Plus, Edit2, Trash2, Calendar, Clock, Users, Shield, 
  Sparkles, ChevronRight, Play, Pause, Volume2, VolumeX, Info, 
  MapPin, Phone, MessageCircle, Share2, Award, Star, Zap, 
  Save, X, Image as ImageIcon, Video, Link as LinkIcon, 
  CheckCircle, AlertCircle, Eye, EyeOff, Layout, List, 
  ArrowUp, ArrowDown, Search, Filter, MoreVertical, 
  UserPlus, UserMinus, Bell, Megaphone, Monitor, Smartphone
} from 'lucide-react';
import { useStore, Competition, CompetitionWinner, CompetitionManager, CompetitionAnnouncement } from '../store/useStore';
import { collection, addDoc, updateDoc, deleteDoc, doc, onSnapshot, query, orderBy, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

export default function CompetitionManagement() {
  const { 
    settings, setSettings, 
    competitions, setCompetitions,
    competitionManagers, setCompetitionManagers,
    competitionAnnouncements, setCompetitionAnnouncements
  } = useStore();

  const [activeTab, setActiveTab] = useState<'competitions' | 'managers' | 'announcements' | 'settings'>('competitions');
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch data
  useEffect(() => {
    const unsubCompetitions = onSnapshot(query(collection(db, 'competitions'), orderBy('order', 'asc')), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Competition[];
      setCompetitions(data);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'competitions'));

    const unsubManagers = onSnapshot(collection(db, 'competitionManagers'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as CompetitionManager[];
      setCompetitionManagers(data);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'competitionManagers'));

    const unsubAnnouncements = onSnapshot(collection(db, 'competitionAnnouncements'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as CompetitionAnnouncement[];
      setCompetitionAnnouncements(data);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'competitionAnnouncements'));

    return () => {
      unsubCompetitions();
      unsubManagers();
      unsubAnnouncements();
    };
  }, []);

  const handleToggleSection = async () => {
    try {
      const isEnabled = !settings.isCompetitionSectionEnabled;
      const disabledSections = settings.disabledLayoutSections || [];
      const newDisabledSections = isEnabled 
        ? disabledSections.filter(id => id !== 'competitions')
        : [...disabledSections.filter(id => id !== 'competitions'), 'competitions'];

      await setDoc(doc(db, 'settings', 'global'), {
        isCompetitionSectionEnabled: isEnabled,
        disabledLayoutSections: newDisabledSections
      }, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'settings/global');
    }
  };

  return (
    <div className="space-y-8">
      {/* Header & Main Controls */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 bg-[#111] p-8 rounded-[2.5rem] border border-[#333] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#d4af37]/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-[#d4af37]/10 flex items-center justify-center text-[#d4af37] border border-[#d4af37]/20">
              <Trophy size={20} />
            </div>
            <h2 className="text-3xl font-black text-white uppercase tracking-tighter italic">Championship <span className="text-gray-500">Control</span></h2>
          </div>
          <p className="text-gray-400 text-sm font-medium">Manage games, events, winners, and announcements from one place.</p>
        </div>

        <div className="flex items-center gap-4 relative z-10">
          <button 
            onClick={handleToggleSection}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all border ${
              settings.isCompetitionSectionEnabled 
                ? 'bg-[#d4af37]/10 border-[#d4af37]/30 text-[#d4af37]' 
                : 'bg-red-500/10 border-red-500/30 text-red-500'
            }`}
          >
            {settings.isCompetitionSectionEnabled ? <Eye size={16} /> : <EyeOff size={16} />}
            {settings.isCompetitionSectionEnabled ? 'Section Enabled' : 'Section Disabled'}
          </button>
          
          <button 
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-6 py-3 bg-[#d4af37] hover:bg-[#f3e5ab] text-black rounded-xl text-xs font-black uppercase tracking-widest transition-all shadow-[0_0_30px_rgba(212,175,55,0.3)]"
          >
            <Plus size={16} />
            Create New
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex p-1.5 bg-[#111] rounded-2xl border border-[#333] w-fit">
        {(['competitions', 'managers', 'announcements', 'settings'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-8 py-3 rounded-xl text-xs font-black transition-all duration-500 uppercase tracking-widest relative overflow-hidden group ${
              activeTab === tab 
                ? 'text-black' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            {activeTab === tab && (
              <motion.div 
                layoutId="adminTab"
                className="absolute inset-0 bg-gradient-to-r from-[#d4af37] to-[#f3e5ab]"
              />
            )}
            <span className="relative z-10 flex items-center gap-2">
              {tab === 'competitions' && <Trophy size={14} />}
              {tab === 'managers' && <Users size={14} />}
              {tab === 'announcements' && <Megaphone size={14} />}
              {tab === 'settings' && <Layout size={14} />}
              {tab}
            </span>
          </button>
        ))}
      </div>

      {/* Content Area */}
      <div className="bg-[#0a0a0a] rounded-[2.5rem] border border-[#333] p-8 min-h-[600px] relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#d4af37] to-transparent opacity-10"></div>
        
        <AnimatePresence mode="wait">
          {activeTab === 'competitions' && (
            <motion.div 
              key="competitions-tab"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-8">
                <div className="relative w-full md:w-96">
                  <input 
                    type="text" 
                    placeholder="Search competitions..." 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-[#111] border border-[#333] rounded-xl py-3 pl-12 pr-4 text-white focus:border-[#d4af37] outline-none transition-colors text-sm"
                  />
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                </div>
                
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Sort by:</span>
                  <select className="bg-[#111] border border-[#333] rounded-xl px-4 py-2 text-xs font-bold text-white outline-none focus:border-[#d4af37]">
                    <option>Order (Asc)</option>
                    <option>Date (Newest)</option>
                    <option>Status</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {competitions.filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase())).map((comp, idx) => (
                  <CompetitionAdminCard key={comp.id} competition={comp} index={idx} />
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'managers' && (
            <motion.div 
              key="managers-tab"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {competitionManagers.map((manager, idx) => (
                <ManagerAdminCard key={manager.id} manager={manager} index={idx} />
              ))}
              <button 
                onClick={() => setShowAddModal(true)}
                className="h-full min-h-[200px] border-2 border-dashed border-[#333] rounded-[2rem] flex flex-col items-center justify-center gap-4 text-gray-500 hover:border-[#d4af37] hover:text-[#d4af37] transition-all group"
              >
                <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-[#d4af37]/10 transition-all">
                  <UserPlus size={32} />
                </div>
                <span className="text-xs font-black uppercase tracking-widest">Add New Manager</span>
              </button>
            </motion.div>
          )}

          {activeTab === 'announcements' && (
            <motion.div 
              key="announcements-tab"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {competitionAnnouncements.map((ann, idx) => (
                <AnnouncementAdminCard key={ann.id} announcement={ann} index={idx} />
              ))}
              <button 
                onClick={() => setShowAddModal(true)}
                className="w-full py-8 border-2 border-dashed border-[#333] rounded-[2rem] flex items-center justify-center gap-4 text-gray-500 hover:border-[#d4af37] hover:text-[#d4af37] transition-all group"
              >
                <Megaphone size={24} />
                <span className="text-xs font-black uppercase tracking-widest">Create New Announcement</span>
              </button>
            </motion.div>
          )}

          {activeTab === 'settings' && (
            <motion.div 
              key="settings-tab"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="max-w-2xl space-y-8"
            >
              <div className="space-y-4">
                <label className="text-xs font-black text-gray-500 uppercase tracking-widest block">Section Title</label>
                <input 
                  type="text" 
                  value={settings.competitionSectionTitle}
                  onChange={(e) => setSettings({ competitionSectionTitle: e.target.value })}
                  className="w-full bg-[#111] border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors font-bold"
                />
              </div>
              
              <div className="space-y-4">
                <label className="text-xs font-black text-gray-500 uppercase tracking-widest block">Section Subtitle</label>
                <textarea 
                  value={settings.competitionSectionSubtitle}
                  onChange={(e) => setSettings({ competitionSectionSubtitle: e.target.value })}
                  className="w-full bg-[#111] border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors font-bold h-32"
                />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-4">
                  <label className="text-xs font-black text-gray-500 uppercase tracking-widest block">Section Order</label>
                  <input 
                    type="number" 
                    value={settings.competitionSectionOrder}
                    onChange={(e) => setSettings({ competitionSectionOrder: parseInt(e.target.value) })}
                    className="w-full bg-[#111] border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors font-bold"
                  />
                </div>
                <div className="space-y-4">
                  <label className="text-xs font-black text-gray-500 uppercase tracking-widest block">Theme Style</label>
                  <select className="w-full bg-[#111] border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors font-bold">
                    <option>Premium Festival</option>
                    <option>Neon Modern</option>
                    <option>Classic Gold</option>
                  </select>
                </div>
              </div>

              <button 
                onClick={async () => {
                  try {
                    await updateDoc(doc(db, 'settings', 'global'), {
                      competitionSectionTitle: settings.competitionSectionTitle,
                      competitionSectionSubtitle: settings.competitionSectionSubtitle,
                      competitionSectionOrder: settings.competitionSectionOrder
                    });
                    alert('Settings updated successfully!');
                  } catch (error) {
                    handleFirestoreError(error, OperationType.UPDATE, 'settings/global');
                  }
                }}
                className="w-full py-4 bg-[#d4af37] text-black font-black uppercase tracking-widest rounded-xl shadow-2xl hover:scale-[1.02] transition-transform"
              >
                Save Global Settings
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {showAddModal && (
          <AddEditCompetitionModal 
            onClose={() => setShowAddModal(false)} 
            type={activeTab === 'competitions' ? 'competition' : activeTab === 'managers' ? 'manager' : 'announcement'}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function CompetitionAdminCard({ competition, index }: { competition: Competition, index: number }) {
  const [isDeleting, setIsDeleting] = useState(false);
  const [showWinnerModal, setShowWinnerModal] = useState(false);

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this competition?')) return;
    setIsDeleting(true);
    try {
      await deleteDoc(doc(db, 'competitions', competition.id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `competitions/${competition.id}`);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleToggleStatus = async () => {
    const nextStatus = competition.status === 'upcoming' ? 'live' : competition.status === 'live' ? 'completed' : 'upcoming';
    try {
      await updateDoc(doc(db, 'competitions', competition.id), { status: nextStatus });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `competitions/${competition.id}`);
    }
  };

  const handleToggleActive = async () => {
    try {
      await updateDoc(doc(db, 'competitions', competition.id), { active: !competition.active });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `competitions/${competition.id}`);
    }
  };

  return (
    <div className="bg-[#111] border border-[#333] rounded-[2rem] p-6 flex flex-col md:flex-row items-center gap-6 group hover:border-[#d4af37]/30 transition-all">
      <div className="w-full md:w-48 h-32 rounded-2xl overflow-hidden border border-[#333] relative shrink-0">
        {competition.mediaType === 'video' ? (
          <video src={competition.mediaUrls[0]} className="w-full h-full object-cover" muted />
        ) : competition.mediaType === 'zip' ? (
          <div className="w-full h-full bg-[#111] flex flex-col items-center justify-center gap-2 text-[#d4af37]">
            <Layout size={32} />
            <span className="text-[8px] font-black uppercase tracking-widest">ZIP Media</span>
          </div>
        ) : (
          <img src={competition.mediaUrls[0] || "https://picsum.photos/seed/game/400/300"} className="w-full h-full object-cover" />
        )}
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <ImageIcon size={24} className="text-white" />
        </div>
      </div>

      <div className="flex-1 text-center md:text-left">
        <div className="flex flex-col md:flex-row md:items-center gap-3 mb-2">
          <h4 className="text-xl font-black text-white uppercase tracking-tight italic">{competition.name}</h4>
          <div className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest border ${
            competition.status === 'live' ? 'bg-red-500/10 border-red-500/30 text-red-500' : 'bg-blue-500/10 border-blue-500/30 text-blue-500'
          }`}>
            {competition.status}
          </div>
        </div>
        <p className="text-gray-500 text-xs line-clamp-1 mb-4">{competition.description}</p>
        
        <div className="flex flex-wrap justify-center md:justify-start gap-4">
          <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400">
            <Calendar size={12} className="text-[#d4af37]" />
            {competition.startDate}
          </div>
          <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400">
            <Clock size={12} className="text-[#d4af37]" />
            {competition.startTime}
          </div>
          <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400">
            <Award size={12} className="text-[#d4af37]" />
            {competition.winners.length} Winners
          </div>
          <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400 border-l border-[#333] pl-4">
            <Users size={12} className="text-[#d4af37]" />
            {competition.entryType}
          </div>
          <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400">
            <Shield size={12} className="text-[#d4af37]" />
            {competition.maxParticipants || '∞'}
          </div>
        </div>
      </div>

      <div className="flex flex-wrap justify-center gap-3 shrink-0">
        <button 
          onClick={() => setShowWinnerModal(true)}
          className="p-3 bg-[#d4af37]/10 hover:bg-[#d4af37] text-[#d4af37] hover:text-black rounded-xl border border-[#d4af37]/20 transition-all"
          title="Manage Winners"
        >
          <Award size={18} />
        </button>
        <button 
          onClick={handleToggleStatus}
          className="p-3 bg-blue-500/10 hover:bg-blue-500 text-blue-500 hover:text-white rounded-xl border border-blue-500/20 transition-all"
          title="Change Status"
        >
          <Zap size={18} />
        </button>
        <button 
          onClick={handleToggleActive}
          className={`p-3 rounded-xl border transition-all ${
            competition.active 
              ? 'bg-green-500/10 hover:bg-green-500 text-green-500 hover:text-white border-green-500/20' 
              : 'bg-gray-500/10 hover:bg-gray-500 text-gray-500 hover:text-white border-gray-500/20'
          }`}
          title={competition.active ? 'Hide from Website' : 'Show on Website'}
        >
          {competition.active ? <Eye size={18} /> : <EyeOff size={18} />}
        </button>
        <button 
          onClick={handleDelete}
          disabled={isDeleting}
          className="p-3 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white rounded-xl border border-red-500/20 transition-all"
          title="Delete"
        >
          <Trash2 size={18} />
        </button>
      </div>

      {/* Winner Management Modal */}
      <AnimatePresence>
        {showWinnerModal && (
          <WinnerManagementModal 
            competition={competition} 
            onClose={() => setShowWinnerModal(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function ManagerAdminCard({ manager, index }: { manager: CompetitionManager, index: number }) {
  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this manager?')) return;
    try {
      await deleteDoc(doc(db, 'competitionManagers', manager.id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `competitionManagers/${manager.id}`);
    }
  };

  return (
    <div className="bg-[#111] border border-[#333] rounded-[2rem] p-8 text-center group hover:border-[#d4af37]/30 transition-all relative overflow-hidden">
      <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
        <button onClick={handleDelete} className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg">
          <Trash2 size={16} />
        </button>
      </div>
      
      <div className="relative mb-6 inline-block">
        <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-[#333] p-1 group-hover:border-[#d4af37]/50 transition-all">
          <img src={manager.imageUrl} alt={manager.name} className="w-full h-full object-cover rounded-full" />
        </div>
      </div>
      
      <h4 className="text-xl font-black text-white uppercase tracking-tight mb-1">{manager.name}</h4>
      <div className="flex items-center justify-center gap-2 mb-4">
        <p className="text-[10px] font-black text-[#d4af37] uppercase tracking-[0.2em]">{manager.role}</p>
        {manager.experience && (
          <span className="text-[8px] font-black text-gray-500 uppercase tracking-widest bg-white/5 px-2 py-0.5 rounded border border-white/10">
            {manager.experience}
          </span>
        )}
      </div>
      
      <div className="space-y-2 mb-6">
        <div className="flex items-center justify-center gap-2 text-gray-500 text-[10px] font-bold">
          <Phone size={12} />
          {manager.mobile}
        </div>
        <div className="flex items-center justify-center gap-2 text-gray-500 text-[10px] font-bold">
          <MapPin size={12} />
          {manager.address}
        </div>
      </div>
      
      <p className="text-gray-400 text-xs italic line-clamp-2">"{manager.remark}"</p>
    </div>
  );
}

function AnnouncementAdminCard({ announcement, index }: { announcement: CompetitionAnnouncement, index: number }) {
  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this announcement?')) return;
    try {
      await deleteDoc(doc(db, 'competitionAnnouncements', announcement.id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `competitionAnnouncements/${announcement.id}`);
    }
  };

  const handleToggleActive = async () => {
    try {
      await updateDoc(doc(db, 'competitionAnnouncements', announcement.id), { active: !announcement.active });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `competitionAnnouncements/${announcement.id}`);
    }
  };

  return (
    <div className="bg-[#111] border border-[#333] rounded-2xl p-6 flex items-center justify-between gap-6 group hover:border-[#d4af37]/30 transition-all">
      <div className="flex items-center gap-4">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center border ${
          announcement.type === 'banner' ? 'bg-blue-500/10 border-blue-500/20 text-blue-500' : 
          announcement.type === 'popup' ? 'bg-purple-500/10 border-purple-500/20 text-purple-500' :
          'bg-[#d4af37]/10 border-[#d4af37]/20 text-[#d4af37]'
        }`}>
          {announcement.type === 'banner' ? <Monitor size={20} /> : 
           announcement.type === 'popup' ? <Smartphone size={20} /> :
           <Megaphone size={20} />}
        </div>
        <div>
          <p className="text-sm font-bold text-white mb-1">{announcement.text}</p>
          <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{announcement.type} Announcement</p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button 
          onClick={handleToggleActive}
          className={`p-3 rounded-xl border transition-all ${
            announcement.active 
              ? 'bg-green-500/10 hover:bg-green-500 text-green-500 hover:text-white border-green-500/20' 
              : 'bg-gray-500/10 hover:bg-gray-500 text-gray-500 hover:text-white border-gray-500/20'
          }`}
        >
          {announcement.active ? <Eye size={18} /> : <EyeOff size={18} />}
        </button>
        <button 
          onClick={handleDelete}
          className="p-3 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white rounded-xl border border-red-500/20 transition-all"
        >
          <Trash2 size={18} />
        </button>
      </div>
    </div>
  );
}

// Helper Modals (AddEditCompetitionModal, WinnerManagementModal) would be implemented here...
// For brevity, I'll implement the core logic of AddEditCompetitionModal

function AddEditCompetitionModal({ onClose, type }: { onClose: () => void, type: 'competition' | 'manager' | 'announcement' }) {
  const { competitionManagers } = useStore();
  const [formData, setFormData] = useState<any>(
    type === 'competition' ? {
      name: '',
      description: '',
      rules: '',
      entryInfo: '',
      entryType: 'Free',
      maxParticipants: 0,
      startDate: '',
      endDate: '',
      days: [],
      startTime: '',
      endTime: '',
      status: 'upcoming',
      managerId: '',
      winners: [],
      mediaUrls: [''],
      mediaType: 'image',
      active: true,
      order: 0
    } : type === 'manager' ? {
      name: '',
      role: 'Host',
      mobile: '',
      address: '',
      remark: '',
      experience: '',
      imageUrl: ''
    } : {
      text: '',
      type: 'scrolling',
      active: true
    }
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const collectionName = type === 'competition' ? 'competitions' : type === 'manager' ? 'competitionManagers' : 'competitionAnnouncements';
      await addDoc(collection(db, collectionName), {
        ...formData,
        createdAt: new Date()
      });
      onClose();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, type);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-xl p-4">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-2xl bg-[#111] border border-[#333] rounded-[2.5rem] p-8 max-h-[90vh] overflow-y-auto no-scrollbar"
      >
        <div className="flex justify-between items-center mb-8">
          <h3 className="text-2xl font-black text-white uppercase tracking-tighter italic">Add New {type}</h3>
          <button onClick={onClose} className="p-2 text-gray-500 hover:text-white">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {type === 'competition' && (
            <>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Competition Name</label>
                <input 
                  required
                  type="text" 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors"
                  placeholder="e.g. Musical Chair Championship"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Description</label>
                <textarea 
                  required
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors h-24"
                  placeholder="Tell people about the game..."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Entry Type</label>
                  <select 
                    value={formData.entryType}
                    onChange={(e) => setFormData({...formData, entryType: e.target.value})}
                    className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors"
                  >
                    <option value="Free">Free Entry</option>
                    <option value="Paid">Paid Entry</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Max Participants</label>
                  <input 
                    type="number" 
                    value={formData.maxParticipants}
                    onChange={(e) => setFormData({...formData, maxParticipants: parseInt(e.target.value)})}
                    className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors"
                    placeholder="0 for unlimited"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Start Date</label>
                  <input 
                    required
                    type="date" 
                    value={formData.startDate}
                    onChange={(e) => setFormData({...formData, startDate: e.target.value})}
                    className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">End Date</label>
                  <input 
                    required
                    type="date" 
                    value={formData.endDate}
                    onChange={(e) => setFormData({...formData, endDate: e.target.value})}
                    className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Start Time</label>
                  <input 
                    required
                    type="time" 
                    value={formData.startTime}
                    onChange={(e) => setFormData({...formData, startTime: e.target.value})}
                    className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">End Time</label>
                  <input 
                    required
                    type="time" 
                    value={formData.endTime}
                    onChange={(e) => setFormData({...formData, endTime: e.target.value})}
                    className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Select Days</label>
                <div className="flex flex-wrap gap-2">
                  {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(day => (
                    <button
                      key={day}
                      type="button"
                      onClick={() => {
                        const newDays = formData.days.includes(day) 
                          ? formData.days.filter((d: string) => d !== day)
                          : [...formData.days, day];
                        setFormData({...formData, days: newDays});
                      }}
                      className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase transition-all border ${
                        formData.days.includes(day) 
                          ? 'bg-[#d4af37] text-black border-[#d4af37]' 
                          : 'bg-black text-gray-500 border-[#333] hover:border-gray-500'
                      }`}
                    >
                      {day}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Event Manager</label>
                <select 
                  required
                  value={formData.managerId}
                  onChange={(e) => setFormData({...formData, managerId: e.target.value})}
                  className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors"
                >
                  <option value="">Select a Manager</option>
                  {competitionManagers.map(m => (
                    <option key={m.id} value={m.id}>{m.name} ({m.role})</option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest flex items-center justify-between">
                  <span>Media URLs (Comma separated or ZIP URL)</span>
                  <span className="text-[8px] text-[#d4af37] lowercase italic">*ZIP files will be processed for bulk media</span>
                </label>
                <textarea 
                  required
                  value={formData.mediaUrls.join(', ')}
                  onChange={(e) => setFormData({...formData, mediaUrls: e.target.value.split(',').map(s => s.trim())})}
                  className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors h-20"
                  placeholder="https://image1.jpg, https://image2.jpg or ZIP link"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Media Type</label>
                <div className="flex gap-4">
                  {['image', 'video', 'gif', 'zip'].map(mType => (
                    <button
                      key={mType}
                      type="button"
                      onClick={() => setFormData({...formData, mediaType: mType})}
                      className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${
                        formData.mediaType === mType 
                          ? 'bg-[#d4af37] text-black border-[#d4af37]' 
                          : 'bg-black text-gray-500 border-[#333]'
                      }`}
                    >
                      {mType}
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}

          {type === 'manager' && (
            <>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Full Name</label>
                <input 
                  required
                  type="text" 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Role</label>
                <input 
                  required
                  type="text" 
                  value={formData.role}
                  onChange={(e) => setFormData({...formData, role: e.target.value})}
                  className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors"
                  placeholder="e.g. Organizer, Host, Referee"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Mobile Number</label>
                  <input 
                    required
                    type="tel" 
                    value={formData.mobile}
                    onChange={(e) => setFormData({...formData, mobile: e.target.value})}
                    className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Address</label>
                  <input 
                    required
                    type="text" 
                    value={formData.address}
                    onChange={(e) => setFormData({...formData, address: e.target.value})}
                    className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Image URL</label>
                <input 
                  required
                  type="url" 
                  value={formData.imageUrl}
                  onChange={(e) => setFormData({...formData, imageUrl: e.target.value})}
                  className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Remark / Bio</label>
                <textarea 
                  value={formData.remark}
                  onChange={(e) => setFormData({...formData, remark: e.target.value})}
                  className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors h-24"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Experience Details</label>
                <input 
                  type="text" 
                  value={formData.experience}
                  onChange={(e) => setFormData({...formData, experience: e.target.value})}
                  className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors"
                  placeholder="e.g. 5+ Years in Event Management"
                />
              </div>
            </>
          )}

          {type === 'announcement' && (
            <>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Announcement Text</label>
                <input 
                  required
                  type="text" 
                  value={formData.text}
                  onChange={(e) => setFormData({...formData, text: e.target.value})}
                  className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Display Type</label>
                <div className="flex gap-4">
                  {['scrolling', 'banner', 'popup'].map(aType => (
                    <button
                      key={aType}
                      type="button"
                      onClick={() => setFormData({...formData, type: aType})}
                      className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${
                        formData.type === aType 
                          ? 'bg-[#d4af37] text-black border-[#d4af37]' 
                          : 'bg-black text-gray-500 border-[#333]'
                      }`}
                    >
                      {aType}
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}

          <button 
            type="submit"
            className="w-full py-4 bg-[#d4af37] text-black font-black uppercase tracking-widest rounded-xl shadow-2xl hover:scale-[1.02] transition-transform mt-8"
          >
            Save {type}
          </button>
        </form>
      </motion.div>
    </div>
  );
}

function WinnerManagementModal({ competition, onClose }: { competition: Competition, onClose: () => void }) {
  const [winners, setWinners] = useState<CompetitionWinner[]>(competition.winners || []);
  const [isAdding, setIsAdding] = useState(false);
  const [newWinner, setNewWinner] = useState<Omit<CompetitionWinner, 'id'>>({
    name: '',
    address: '',
    mobile: '',
    imageUrl: '',
    remark: '',
    achievementMessage: '',
    rank: 1
  });

  const handleAddWinner = async (e: React.FormEvent) => {
    e.preventDefault();
    const updatedWinners = [...winners, { ...newWinner, id: Date.now().toString() }];
    try {
      await updateDoc(doc(db, 'competitions', competition.id), { winners: updatedWinners });
      setWinners(updatedWinners);
      setIsAdding(false);
      setNewWinner({ name: '', address: '', mobile: '', imageUrl: '', remark: '', achievementMessage: '', rank: 1 });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `competitions/${competition.id}`);
    }
  };

  const handleDeleteWinner = async (id: string) => {
    const updatedWinners = winners.filter(w => w.id !== id);
    try {
      await updateDoc(doc(db, 'competitions', competition.id), { winners: updatedWinners });
      setWinners(updatedWinners);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `competitions/${competition.id}`);
    }
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/95 backdrop-blur-2xl p-4">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-4xl bg-[#111] border border-[#333] rounded-[2.5rem] p-8 max-h-[90vh] overflow-y-auto no-scrollbar"
      >
        <div className="flex justify-between items-center mb-8">
          <div>
            <h3 className="text-2xl font-black text-white uppercase tracking-tighter italic">Winners Hall of Fame</h3>
            <p className="text-gray-500 text-xs font-bold uppercase tracking-widest">{competition.name}</p>
          </div>
          <button onClick={onClose} className="p-2 text-gray-500 hover:text-white">
            <X size={24} />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {[1, 2, 3].map(rank => {
            const winner = winners.find(w => w.rank === rank);
            return (
              <div key={rank} className={`bg-black border rounded-[2rem] p-6 text-center relative overflow-hidden ${
                winner ? 'border-[#d4af37]/30' : 'border-[#333] border-dashed'
              }`}>
                {winner ? (
                  <>
                    <button 
                      onClick={() => handleDeleteWinner(winner.id)}
                      className="absolute top-4 right-4 text-red-500 hover:bg-red-500/10 p-2 rounded-lg"
                    >
                      <Trash2 size={16} />
                    </button>
                    <div className="w-20 h-20 rounded-full overflow-hidden border-4 border-[#d4af37]/30 mx-auto mb-4 p-1">
                      <img src={winner.imageUrl} className="w-full h-full object-cover rounded-full" />
                    </div>
                    <h5 className="text-lg font-black text-white uppercase tracking-tight mb-1">{winner.name}</h5>
                    <p className="text-[10px] font-black text-[#d4af37] uppercase tracking-widest">{rank === 1 ? '1st Place' : rank === 2 ? '2nd Place' : '3rd Place'}</p>
                  </>
                ) : (
                  <div className="py-8 flex flex-col items-center justify-center gap-4 text-gray-600">
                    <Award size={32} />
                    <p className="text-[10px] font-black uppercase tracking-widest">{rank === 1 ? '1st Place' : rank === 2 ? '2nd Place' : '3rd Place'}</p>
                    <button 
                      onClick={() => {
                        setIsAdding(true);
                        setNewWinner({...newWinner, rank: rank as 1|2|3});
                      }}
                      className="text-[10px] font-black text-[#d4af37] uppercase tracking-widest hover:underline"
                    >
                      Add Winner
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {isAdding && (
          <form onSubmit={handleAddWinner} className="bg-black/40 border border-[#333] p-8 rounded-[2rem] space-y-6">
            <div className="flex justify-between items-center mb-4">
              <h4 className="text-lg font-black text-white uppercase tracking-wider">Add {newWinner.rank === 1 ? '1st' : newWinner.rank === 2 ? '2nd' : '3rd'} Place Winner</h4>
              <button type="button" onClick={() => setIsAdding(false)} className="text-gray-500 hover:text-white">
                <X size={20} />
              </button>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Full Name</label>
                <input required type="text" value={newWinner.name} onChange={e => setNewWinner({...newWinner, name: e.target.value})} className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Mobile</label>
                <input required type="tel" value={newWinner.mobile} onChange={e => setNewWinner({...newWinner, mobile: e.target.value})} className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none" />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Address</label>
              <input required type="text" value={newWinner.address} onChange={e => setNewWinner({...newWinner, address: e.target.value})} className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none" />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Image URL</label>
              <input required type="url" value={newWinner.imageUrl} onChange={e => setNewWinner({...newWinner, imageUrl: e.target.value})} className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none" />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Achievement Message</label>
              <input type="text" value={newWinner.achievementMessage} onChange={e => setNewWinner({...newWinner, achievementMessage: e.target.value})} className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none" placeholder="e.g. Winner of Musical Chair 2024" />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Remark</label>
              <textarea value={newWinner.remark} onChange={e => setNewWinner({...newWinner, remark: e.target.value})} className="w-full bg-black border border-[#333] rounded-xl p-4 text-white focus:border-[#d4af37] outline-none h-20" />
            </div>
            <button type="submit" className="w-full py-4 bg-[#d4af37] text-black font-black uppercase tracking-widest rounded-xl">Save Winner</button>
          </form>
        )}
      </motion.div>
    </div>
  );
}
