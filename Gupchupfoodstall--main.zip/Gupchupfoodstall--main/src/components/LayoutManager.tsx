import React, { useState } from 'react';
import { 
  DndContext, 
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { motion, AnimatePresence } from 'framer-motion';
import { GripVertical, Eye, EyeOff, Plus, Trash2, Image, Monitor, Calendar, Tag, Film, Gift, Camera, UtensilsCrossed, Users, Star, Layout, Bell, Play, MapPin, Clock, Phone, ShoppingBag, Trophy, Zap, Loader2, CheckCircle2, Info } from 'lucide-react';
import { useStore, AppSettings } from '../store/useStore';

const AVAILABLE_SECTIONS = [
  { id: 'banners', name: 'Banners', icon: <Image size={16} /> },
  { id: 'hero', name: 'Hero', icon: <Monitor size={16} /> },
  { id: 'events', name: 'Events', icon: <Calendar size={16} /> },
  { id: 'offers', name: 'Offers', icon: <Tag size={16} /> },
  { id: 'reels', name: 'Reels', icon: <Film size={16} /> },
  { id: 'cashback', name: 'Cashback', icon: <Gift size={16} /> },
  { id: 'moments', name: 'Moments', icon: <Camera size={16} /> },
  { id: 'photostudio', name: 'Photo Studio', icon: <Camera size={16} /> },
  { id: 'menu', name: 'Menu', icon: <UtensilsCrossed size={16} /> },
  { id: 'influencers', name: 'Influencers', icon: <Users size={16} /> },
  { id: 'sponsored', name: 'Sponsored', icon: <Star size={16} /> },
  { id: 'footerInfo', name: 'Footer Info', icon: <Layout size={16} /> },
  { id: 'notifications', name: 'Notifications', icon: <Bell size={16} /> },
  { id: 'featuredInfluencers', name: 'Featured Influencers', icon: <Star size={16} /> },
  { id: 'stories', name: 'Stories', icon: <Play size={16} /> },
  { id: 'partnerCollab', name: 'Partner Collab', icon: <Users size={16} /> },
  { id: 'riderList', name: 'Rider List', icon: <MapPin size={16} /> },
  { id: 'founders', name: 'Founders', icon: <Users size={16} /> },
  { id: 'getDirections', name: 'Get Directions', icon: <MapPin size={16} /> },
  { id: 'openingHours', name: 'Opening Hours', icon: <Clock size={16} /> },
  { id: 'contact', name: 'Contact', icon: <Phone size={16} /> },
  { id: 'chickenStore', name: 'Chicken Store', icon: <ShoppingBag size={16} /> },
  { id: 'competitions', name: 'Competitions', icon: <Trophy size={16} /> },
  { id: 'reviews', name: 'Reviews', icon: <Star size={16} /> },
  { id: 'staff', name: 'Staff', icon: <Users size={16} /> },
  { id: 'eventBooking', name: 'Event Booking', icon: <Calendar size={16} /> },
  { id: 'deliveryZones', name: 'Delivery Zones', icon: <MapPin size={16} /> },
  { id: 'pan', name: 'Special Assam Pan', icon: <UtensilsCrossed size={16} /> },
  { id: 'other_category', name: 'Custom Section', icon: <Layout size={16} /> }
];

interface SortableItemProps {
  id: string;
  sectionId: string;
  name: string;
  icon: React.ReactNode;
  isEnabled: boolean;
  onToggleEnable: (id: string) => void;
  onDetach: (id: string) => void;
}

function SortableItem({ id, sectionId, name, icon, isEnabled, onToggleEnable, onDetach }: SortableItemProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 100 : 1,
  };

  return (
    <div 
      ref={setNodeRef} 
      style={style} 
      className={`flex items-center justify-between p-4 mb-3 rounded-xl border transition-all ${
        isDragging ? 'bg-[#222] border-[var(--color-neon-green)] shadow-[0_0_20px_rgba(0,255,0,0.2)] scale-[1.02]' : 
        isEnabled ? 'bg-[#111] border-[#333] hover:border-[#555]' : 'bg-[#0a0a0a] border-[#222] opacity-60'
      }`}
    >
      <div className="flex items-center gap-4">
        <div 
          {...attributes} 
          {...listeners}
          className="cursor-grab active:cursor-grabbing text-gray-500 hover:text-white p-1"
        >
          <GripVertical size={20} />
        </div>
        <div className={`p-2 rounded-lg ${isEnabled ? 'bg-[var(--color-neon-green)]/20 text-[var(--color-neon-green)]' : 'bg-gray-800 text-gray-400'}`}>
          {icon}
        </div>
        <div>
          <h4 className={`font-bold ${isEnabled ? 'text-white' : 'text-gray-400'}`}>{name}</h4>
          <p className="text-xs text-gray-500 font-mono">{sectionId}</p>
        </div>
      </div>
      
      <div className="flex items-center gap-2">
        <button
          onClick={() => onToggleEnable(sectionId)}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-bold transition-colors ${
            isEnabled 
              ? 'bg-[var(--color-neon-green)]/10 text-[var(--color-neon-green)] hover:bg-[var(--color-neon-green)]/20' 
              : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
          }`}
        >
          {isEnabled ? <><Eye size={16} /> Visible</> : <><EyeOff size={16} /> Hidden</>}
        </button>
        <button
          onClick={() => onDetach(sectionId)}
          className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors"
          title="Detach from layout"
        >
          <Trash2 size={18} />
        </button>
      </div>
    </div>
  );
}

export default function LayoutManager({ 
  localSettings, 
  setLocalSettings,
  handleUpdateSettings
}: { 
  localSettings: AppSettings, 
  setLocalSettings: (settings: AppSettings) => void,
  handleUpdateSettings: (settings: AppSettings) => void
}) {
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = (event: DragEndEvent, layoutIndex: number) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const newLayouts = [...(localSettings.screenLayouts || [])];
      const sections = [...newLayouts[layoutIndex].sections];
      
      const oldIndex = sections.indexOf(active.id as string);
      const newIndex = sections.indexOf(over.id as string);
      
      newLayouts[layoutIndex].sections = arrayMove(sections, oldIndex, newIndex);
      
      setLocalSettings({ ...localSettings, screenLayouts: newLayouts });
      // Auto-save on drag end for real-time feel
      handleUpdateSettings({ ...localSettings, screenLayouts: newLayouts });
    }
  };

  const toggleEnable = (sectionId: string) => {
    const disabled = localSettings.disabledLayoutSections || [];
    let newDisabled;
    
    if (disabled.includes(sectionId)) {
      newDisabled = disabled.filter(id => id !== sectionId);
    } else {
      newDisabled = [...disabled, sectionId];
    }
    
    const newSettings = { ...localSettings, disabledLayoutSections: newDisabled };
    setLocalSettings(newSettings);
    handleUpdateSettings(newSettings);
  };

  const archiveLayout = (index: number) => {
    const newLayouts = [...(localSettings.screenLayouts || [])];
    const archivedLayout = newLayouts.splice(index, 1)[0];
    const newDisabled = [...(localSettings.disabledScreenLayouts || []), archivedLayout];
    
    const newSettings = { ...localSettings, screenLayouts: newLayouts, disabledScreenLayouts: newDisabled };
    setLocalSettings(newSettings);
    handleUpdateSettings(newSettings);
  };

  const restoreLayout = (index: number) => {
    const newDisabled = [...(localSettings.disabledScreenLayouts || [])];
    const restoredLayout = newDisabled.splice(index, 1)[0];
    const newLayouts = [...(localSettings.screenLayouts || []), restoredLayout];
    
    const newSettings = { ...localSettings, screenLayouts: newLayouts, disabledScreenLayouts: newDisabled };
    setLocalSettings(newSettings);
    handleUpdateSettings(newSettings);
  };

  const [isAutoAdding, setIsAutoAdding] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'info', message: string } | null>(null);

  const handleAutoAddAll = (layoutIndex: number) => {
    setIsAutoAdding(localSettings.screenLayouts![layoutIndex].id);
    
    setTimeout(() => {
      const currentSections = localSettings.screenLayouts![layoutIndex].sections;
      const missingSections = AVAILABLE_SECTIONS.filter(s => !currentSections.includes(s.id));
      
      if (missingSections.length === 0) {
        setFeedback({ type: 'info', message: 'No new sections found' });
      } else {
        const newLayouts = [...(localSettings.screenLayouts || [])];
        newLayouts[layoutIndex].sections = [...currentSections, ...missingSections.map(s => s.id)];
        
        const newSettings = { ...localSettings, screenLayouts: newLayouts };
        setLocalSettings(newSettings);
        handleUpdateSettings(newSettings);
        setFeedback({ type: 'success', message: `✅ ${missingSections.length} sections successfully added` });
      }
      
      setIsAutoAdding(null);
      setTimeout(() => setFeedback(null), 3000);
    }, 800);
  };

  return (
    <div>
      {/* Feedback Toast */}
      <AnimatePresence>
        {feedback && (
          <motion.div
            initial={{ opacity: 0, y: -50, x: '-50%' }}
            animate={{ opacity: 1, y: 20, x: '-50%' }}
            exit={{ opacity: 0, y: -50, x: '-50%' }}
            className={`fixed top-0 left-1/2 z-[100] px-6 py-3 rounded-2xl border shadow-2xl flex items-center gap-3 backdrop-blur-xl ${
              feedback.type === 'success' 
                ? 'bg-green-500/20 border-green-500/30 text-green-400' 
                : 'bg-blue-500/20 border-blue-500/30 text-blue-400'
            }`}
          >
            {feedback.type === 'success' ? <CheckCircle2 size={20} /> : <Info size={20} />}
            <span className="font-bold text-sm uppercase tracking-wider">{feedback.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex justify-between items-center mb-8">
        <div>
          <h3 className="text-3xl font-black uppercase text-white">Smart Layout OS</h3>
          <p className="text-gray-400 mt-1">Ultra Dynamic Layout Management System</p>
        </div>
        <button 
          onClick={() => {
            const newLayouts = [...(localSettings.screenLayouts || [])];
            newLayouts.push({ id: `screen-${Date.now()}`, name: `Screen ${newLayouts.length + 1}`, sections: [] });
            setLocalSettings({ ...localSettings, screenLayouts: newLayouts });
          }}
          className="bg-[var(--color-neon-green)] text-black font-bold px-6 py-3 rounded-xl hover:bg-[#00cc00] transition-colors flex items-center gap-2 shadow-[0_0_15px_rgba(0,255,0,0.3)]"
        >
          <Plus size={20} /> Add Screen
        </button>
      </div>
      
      <div className="space-y-8">
        {(localSettings.screenLayouts || []).map((layout, index) => {
          const unattachedSections = AVAILABLE_SECTIONS.filter(s => !layout.sections.includes(s.id));
          
          return (
            <div key={layout.id} className="bg-[#0a0a0a] border border-[#222] p-6 rounded-2xl relative overflow-hidden">
              {/* Decorative background glow */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-32 bg-[var(--color-neon-green)]/5 blur-[100px] pointer-events-none"></div>
              
              <div className="relative z-10">
                <div className="flex justify-between items-center mb-6 pb-6 border-b border-[#222]">
                  <div className="flex items-center gap-4">
                    <input 
                      type="text" 
                      value={layout.name} 
                      onChange={(e) => {
                        const newLayouts = [...localSettings.screenLayouts!];
                        newLayouts[index].name = e.target.value;
                        setLocalSettings({ ...localSettings, screenLayouts: newLayouts });
                      }}
                      className="bg-transparent border-b border-transparent hover:border-[#333] focus:border-[var(--color-neon-green)] px-2 py-1 text-white outline-none font-black text-2xl transition-colors"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleAutoAddAll(index)}
                      disabled={isAutoAdding !== null}
                      className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[var(--color-neon-green)]/20 to-transparent hover:from-[var(--color-neon-green)]/30 border border-[var(--color-neon-green)]/30 rounded-xl text-[10px] font-black uppercase tracking-widest text-[var(--color-neon-green)] transition-all group"
                    >
                      {isAutoAdding === layout.id ? (
                        <Loader2 size={14} className="animate-spin" />
                      ) : (
                        <Zap size={14} className="group-hover:scale-125 transition-transform" />
                      )}
                      {isAutoAdding === layout.id ? 'Scanning...' : 'Auto Add All'}
                    </button>
                    <button 
                      onClick={() => archiveLayout(index)}
                      className="text-red-500 hover:text-red-400 hover:bg-red-500/10 p-2 rounded-lg transition-colors"
                      title="Archive Screen"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>
                
                <div className="mb-6">
                  <h4 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                    <Layout size={16} /> Attached Sections
                  </h4>
                  
                  {layout.sections.length === 0 ? (
                    <div className="text-center py-8 border-2 border-dashed border-[#333] rounded-xl text-gray-500">
                      No sections attached. Add some from below.
                    </div>
                  ) : (
                    <DndContext 
                      sensors={sensors}
                      collisionDetection={closestCenter}
                      onDragEnd={(e) => handleDragEnd(e, index)}
                    >
                      <SortableContext 
                        items={layout.sections}
                        strategy={verticalListSortingStrategy}
                      >
                        <div className="space-y-2">
                          {layout.sections.map(sectionId => {
                            const sectionDef = AVAILABLE_SECTIONS.find(s => s.id === sectionId) || { name: sectionId, icon: <Layout size={16} /> };
                            const isEnabled = !(localSettings.disabledLayoutSections || []).includes(sectionId);
                            
                            return (
                              <SortableItem 
                                key={sectionId}
                                id={sectionId}
                                sectionId={sectionId}
                                name={sectionDef.name}
                                icon={sectionDef.icon}
                                isEnabled={isEnabled}
                                onToggleEnable={toggleEnable}
                                onDetach={(id) => {
                                  const newLayouts = [...(localSettings.screenLayouts || [])];
                                  newLayouts[index].sections = newLayouts[index].sections.filter(sid => sid !== id);
                                  
                                  const newSettings = { ...localSettings, screenLayouts: newLayouts };
                                  setLocalSettings(newSettings);
                                  handleUpdateSettings(newSettings);
                                }}
                              />
                            );
                          })}
                        </div>
                      </SortableContext>
                    </DndContext>
                  )}
                </div>
                
                <div className="pt-6 border-t border-[#222]">
                  <h4 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                    <Plus size={16} /> Available Sections
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {unattachedSections.map(section => (
                      <button
                        key={section.id}
                        onClick={() => {
                          const newLayouts = [...(localSettings.screenLayouts || [])];
                          if (!newLayouts[index].sections.includes(section.id)) {
                            newLayouts[index].sections.push(section.id);
                            
                            const newSettings = { ...localSettings, screenLayouts: newLayouts };
                            setLocalSettings(newSettings);
                            handleUpdateSettings(newSettings);
                          }
                        }}
                        className="flex items-center gap-2 bg-[#111] hover:bg-[#222] border border-[#333] hover:border-[var(--color-neon-green)]/50 px-4 py-2 rounded-lg text-sm transition-all text-gray-300 hover:text-white"
                      >
                        <span className="text-[var(--color-neon-green)]">{section.icon}</span>
                        {section.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Archived Layouts */}
      {(localSettings.disabledScreenLayouts && localSettings.disabledScreenLayouts.length > 0) && (
        <div className="mt-12 pt-8 border-t-2 border-dashed border-[#222]">
          <h3 className="text-xl font-black uppercase text-gray-500 mb-6">Archived Screens</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {localSettings.disabledScreenLayouts.map((layout, index) => (
              <div key={layout.id} className="bg-[#0a0a0a] border border-[#222] p-6 rounded-2xl flex items-center justify-between">
                <h4 className="font-bold text-gray-400">{layout.name}</h4>
                <button 
                  onClick={() => restoreLayout(index)}
                  className="bg-white/5 hover:bg-[var(--color-neon-green)] hover:text-black text-white font-black px-4 py-2 rounded-lg text-xs uppercase tracking-widest transition-all"
                >
                  Restore
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
