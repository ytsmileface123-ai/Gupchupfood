import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trophy, Calendar, Clock, Users, Shield, Sparkles, ChevronLeft, ChevronRight, Play, Pause, Volume2, VolumeX, Info, MapPin, Phone, MessageCircle, Share2, Award, Star, Zap } from 'lucide-react';
import { useStore, Competition, CompetitionWinner, CompetitionManager } from '../store/useStore';

export default function CompetitionSection() {
  const { settings, competitions, competitionManagers, competitionAnnouncements } = useStore();
  const [activeTab, setActiveTab] = useState<'live' | 'upcoming' | 'completed'>('live');
  const [selectedCompetition, setSelectedCompetition] = useState<Competition | null>(null);
  const [isMuted, setIsMuted] = useState(true);

  if (!settings.isCompetitionSectionEnabled) return null;

  const filteredCompetitions = competitions.filter(comp => {
    if (!comp.active) return false;
    return comp.status === activeTab;
  }).sort((a, b) => a.order - b.order);

  const activeAnnouncements = competitionAnnouncements.filter(a => a.active);

  return (
    <section id="competitions" className="py-24 relative overflow-hidden bg-[#050505]">
      {/* Premium Background Elements */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(212,175,55,0.05)_0%,transparent_70%)]"></div>
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#d4af37] to-transparent opacity-30"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/30 text-[#d4af37] mb-6"
          >
            <Trophy size={16} className="animate-bounce" />
            <span className="text-xs font-black tracking-[0.3em] uppercase">Championship Arena</span>
          </motion.div>
          
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-8xl font-black text-white mb-6 tracking-tighter leading-none relative inline-block"
          >
            <span className="relative z-10">
              {settings.competitionSectionTitle?.split(' ')[0] || 'CHAMPION'} <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#d4af37] to-[#f3e5ab]">{settings.competitionSectionTitle?.split(' ').slice(1).join(' ') || 'MANAGEMENT'}</span>
            </span>
            <div className="absolute -inset-4 bg-[#d4af37]/20 blur-[100px] -z-10 rounded-full opacity-50"></div>
          </motion.h2>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-400 max-w-2xl mx-auto font-medium"
          >
            {settings.competitionSectionSubtitle || 'Participate in our exclusive games, show your skills, and win exciting prizes!'}
          </motion.p>
        </div>

        {/* Scrolling Announcements */}
        {activeAnnouncements.some(a => a.type === 'scrolling') && (
          <div className="mb-12 overflow-hidden bg-[#d4af37]/5 border-y border-[#d4af37]/20 py-3 relative">
            <div className="flex whitespace-nowrap animate-scroll-text">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="flex items-center gap-8 px-4">
                  {activeAnnouncements.filter(a => a.type === 'scrolling').map((ann, idx) => (
                    <div key={`${ann.id}-${i}-${idx}`} className="flex items-center gap-3">
                      <Zap size={14} className="text-[#d4af37] fill-[#d4af37]" />
                      <span className="text-sm font-bold text-white uppercase tracking-wider">{ann.text}</span>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Status Tabs */}
        <div className="flex justify-center mb-12">
          <div className="flex p-1.5 bg-white/5 rounded-2xl border border-white/10 backdrop-blur-xl">
            {(['live', 'upcoming', 'completed'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-8 py-3 rounded-xl text-sm font-black transition-all duration-500 uppercase tracking-widest relative overflow-hidden group ${
                  activeTab === tab 
                    ? 'text-black' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {activeTab === tab && (
                  <motion.div 
                    layoutId="activeTab"
                    className="absolute inset-0 bg-gradient-to-r from-[#d4af37] to-[#f3e5ab] shadow-[0_0_20px_rgba(212,175,55,0.4)]"
                  />
                )}
                <span className="relative z-10 flex items-center gap-2">
                  {tab === 'live' && <div className="w-2 h-2 rounded-full bg-red-500 animate-ping" />}
                  {tab}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Competitions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence mode="popLayout">
            {filteredCompetitions.map((comp, index) => (
              <CompetitionCard 
                key={comp.id} 
                competition={comp} 
                index={index}
                onDetails={() => setSelectedCompetition(comp)}
              />
            ))}
          </AnimatePresence>
        </div>

        {filteredCompetitions.length === 0 && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-24 bg-white/5 rounded-[3rem] border border-white/10 border-dashed"
          >
            <Trophy size={64} className="mx-auto text-gray-700 mb-6 opacity-20" />
            <h3 className="text-2xl font-bold text-gray-500 uppercase tracking-widest">No {activeTab} competitions</h3>
            <p className="text-gray-600 mt-2">Check back later for exciting updates!</p>
          </motion.div>
        )}

      </div>

      {/* Competition Details Modal */}
      <AnimatePresence>
        {selectedCompetition && (
          <CompetitionDetailsModal 
            competition={selectedCompetition} 
            onClose={() => setSelectedCompetition(null)}
            isMuted={isMuted}
            onToggleMute={() => setIsMuted(!isMuted)}
          />
        )}
      </AnimatePresence>

      {/* Global Banner Announcement */}
      {activeAnnouncements.filter(a => a.type === 'banner').map(ann => (
        <div key={ann.id} className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[60] w-full max-w-2xl px-4">
          <motion.div 
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="bg-gradient-to-r from-[#d4af37] to-[#f3e5ab] p-4 rounded-2xl shadow-2xl flex items-center justify-between gap-4 border border-white/20"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-black/20 flex items-center justify-center">
                <Zap size={20} className="text-black" />
              </div>
              <p className="text-sm font-black text-black uppercase tracking-tight">{ann.text}</p>
            </div>
            <button className="px-4 py-2 bg-black text-white text-[10px] font-black rounded-lg uppercase tracking-widest hover:scale-105 transition-transform">
              Join Now
            </button>
          </motion.div>
        </div>
      ))}

      <style>{`
        @keyframes scroll-text {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-scroll-text {
          animation: scroll-text 30s linear infinite;
        }
        @keyframes confetti {
          0% { transform: translateY(0) rotate(0deg); opacity: 1; }
          100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
        }
        .confetti-piece {
          position: absolute;
          width: 8px;
          height: 8px;
          background: #d4af37;
          top: -10px;
          animation: confetti 3s ease-out infinite;
        }
      `}</style>
    </section>
  );
}

function CountdownTimer({ targetDate }: { targetDate: string }) {
  const [timeLeft, setTimeLeft] = useState<{ days: number, hours: number, minutes: number, seconds: number } | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      const target = new Date(targetDate).getTime();
      const now = new Date().getTime();
      const difference = target - now;

      if (difference <= 0) {
        clearInterval(timer);
        setTimeLeft(null);
        return;
      }

      setTimeLeft({
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((difference % (1000 * 60)) / 1000)
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [targetDate]);

  if (!timeLeft) return null;

  return (
    <div className="flex justify-center gap-4">
      {Object.entries(timeLeft).map(([label, value]) => (
        <div key={label} className="flex flex-col items-center">
          <span className="text-sm font-black text-white leading-none">{value.toString().padStart(2, '0')}</span>
          <span className="text-[6px] font-black text-[#d4af37] uppercase tracking-widest">{label[0]}</span>
        </div>
      ))}
    </div>
  );
}

function CompetitionCard({ competition, index, onDetails }: { competition: Competition, index: number, onDetails: () => void }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="group relative bg-white/[0.03] border border-white/10 rounded-[2.5rem] overflow-hidden hover:border-[#d4af37]/50 transition-all duration-500 flex flex-col h-full"
    >
      {/* Media Preview */}
      <div className="relative h-64 overflow-hidden">
        {competition.mediaType === 'video' ? (
          <video 
            src={competition.mediaUrls[0]} 
            className="w-full h-full object-cover opacity-60 group-hover:opacity-100 group-hover:scale-110 transition-all duration-[2s]"
            autoPlay 
            loop 
            muted 
            playsInline
          />
        ) : (
          <img 
            src={competition.mediaUrls[0] || "https://picsum.photos/seed/game/800/600"} 
            className="w-full h-full object-cover opacity-60 group-hover:opacity-100 group-hover:scale-110 transition-all duration-[2s]"
            alt={competition.name}
          />
        )}
        
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent"></div>
        
        {/* Status Badge */}
        <div className="absolute top-6 left-6 z-20">
          <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] border backdrop-blur-md flex items-center gap-2 shadow-lg ${
            competition.status === 'live' 
              ? 'bg-red-500/30 border-red-500/50 text-white shadow-red-500/20' 
              : competition.status === 'upcoming'
              ? 'bg-blue-500/30 border-blue-500/50 text-white shadow-blue-500/20'
              : 'bg-gray-500/30 border-gray-500/50 text-gray-300'
          }`}>
            {competition.status === 'live' && (
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
              </span>
            )}
            {competition.status === 'live' ? 'LIVE NOW' : competition.status}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-8 flex-1 flex flex-col">
        <h3 className="text-2xl font-black text-white mb-3 group-hover:text-[#d4af37] transition-colors uppercase tracking-tight italic">
          {competition.name}
        </h3>
        <p className="text-gray-400 text-sm mb-6 line-clamp-2 font-medium leading-relaxed">
          {competition.description}
        </p>
        
        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className="flex items-center gap-2 text-gray-500">
            <Calendar size={14} className="text-[#d4af37]" />
            <span className="text-[10px] font-bold uppercase tracking-wider">{competition.startDate}</span>
          </div>
          <div className="flex items-center gap-2 text-gray-500">
            <Clock size={14} className="text-[#d4af37]" />
            <span className="text-[10px] font-bold uppercase tracking-wider">{competition.startTime}</span>
          </div>
          <div className="flex items-center gap-2 text-gray-500">
            <Users size={14} className="text-[#d4af37]" />
            <span className="text-[10px] font-bold uppercase tracking-wider">{competition.entryType} Entry</span>
          </div>
          <div className="flex items-center gap-2 text-gray-500">
            <Shield size={14} className="text-[#d4af37]" />
            <span className="text-[10px] font-bold uppercase tracking-wider">{competition.maxParticipants ? `${competition.maxParticipants} Max` : 'Unlimited'}</span>
          </div>
        </div>

        {competition.status === 'upcoming' && (
          <div className="mb-6 p-3 bg-[#d4af37]/5 rounded-xl border border-[#d4af37]/20">
            <p className="text-[8px] font-black text-[#d4af37] uppercase tracking-[0.2em] mb-1 text-center">Registration Open</p>
            <CountdownTimer targetDate={`${competition.startDate}T${competition.startTime}`} />
          </div>
        )}

        <button 
          onClick={onDetails}
          className="mt-auto w-full py-4 bg-white/5 hover:bg-[#d4af37] text-white hover:text-black rounded-2xl border border-white/10 hover:border-transparent transition-all duration-500 text-xs font-black uppercase tracking-[0.2em] flex items-center justify-center gap-2 group/btn"
        >
          View Championship Details
          <ChevronRight size={16} className="group-hover/btn:translate-x-1 transition-transform" />
        </button>
      </div>
    </motion.div>
  );
}

function CompetitionDetailsModal({ competition, onClose, isMuted, onToggleMute }: { competition: Competition, onClose: () => void, isMuted: boolean, onToggleMute: () => void }) {
  const { competitionManagers } = useStore();
  const manager = competitionManagers.find(m => m.id === competition.managerId);
  const [activeMediaIndex, setActiveMediaIndex] = useState(0);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-2xl p-4 md:p-8"
    >
      <div className="absolute inset-0 overflow-y-auto no-scrollbar py-8 flex justify-center">
        <motion.div 
          initial={{ scale: 0.9, y: 50 }}
          animate={{ scale: 1, y: 0 }}
          className="w-full max-w-6xl bg-[#0a0a0a] rounded-[3rem] border border-white/10 overflow-hidden relative shadow-[0_0_100px_rgba(212,175,55,0.1)]"
        >
          {/* Close Button */}
          <button 
            onClick={onClose}
            className="absolute top-8 right-8 z-50 p-4 bg-white/5 hover:bg-white/10 rounded-full text-white transition-all border border-white/10"
          >
            <ChevronLeft size={24} />
          </button>

          <div className="flex flex-col lg:flex-row h-full">
            {/* Left: Media Showcase (Reels Style) */}
            <div className="w-full lg:w-[450px] bg-black relative aspect-[9/16] lg:aspect-auto">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeMediaIndex}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="w-full h-full"
                >
                  {competition.mediaType === 'video' ? (
                    <video 
                      src={competition.mediaUrls[activeMediaIndex]} 
                      className="w-full h-full object-cover"
                      autoPlay 
                      loop 
                      muted={isMuted}
                      playsInline
                    />
                  ) : (
                    <img 
                      src={competition.mediaUrls[activeMediaIndex]} 
                      className="w-full h-full object-cover"
                      alt="Competition Media"
                    />
                  )}
                </motion.div>
              </AnimatePresence>

              {/* Media Controls */}
              <div className="absolute bottom-8 left-0 right-0 px-8 flex items-center justify-between z-20">
                <div className="flex gap-2">
                  {competition.mediaUrls.map((_, idx) => (
                    <button 
                      key={idx}
                      onClick={() => setActiveMediaIndex(idx)}
                      className={`h-1.5 rounded-full transition-all ${idx === activeMediaIndex ? 'w-8 bg-[#d4af37]' : 'w-2 bg-white/30'}`}
                    />
                  ))}
                </div>
                <button 
                  onClick={onToggleMute}
                  className="p-3 bg-black/40 backdrop-blur-md rounded-full text-white border border-white/10"
                >
                  {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
                </button>
              </div>

              {/* Winner Overlay (if completed) */}
              {competition.status === 'completed' && competition.winners.length > 0 && (
                <div className="absolute top-24 left-8 right-8 z-20">
                  <motion.div 
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    className="bg-gradient-to-r from-[#d4af37] to-[#f3e5ab] p-4 rounded-2xl shadow-2xl"
                  >
                    <div className="flex items-center gap-3">
                      <Award size={24} className="text-black" />
                      <div>
                        <p className="text-[10px] font-black text-black/60 uppercase tracking-widest">Grand Champion</p>
                        <p className="text-lg font-black text-black uppercase">{competition.winners.find(w => w.rank === 1)?.name}</p>
                      </div>
                    </div>
                  </motion.div>
                </div>
              )}
            </div>

            {/* Right: Details Content */}
            <div className="flex-1 p-8 md:p-12 overflow-y-auto no-scrollbar bg-gradient-to-br from-white/[0.02] to-transparent">
              <div className="mb-12">
                <div className="flex items-center gap-3 mb-4">
                  <span className="px-3 py-1 bg-[#d4af37]/10 text-[#d4af37] text-[10px] font-black uppercase tracking-widest rounded-full border border-[#d4af37]/20">
                    Championship Event
                  </span>
                  {competition.status === 'live' && (
                    <span className="flex items-center gap-2 px-3 py-1 bg-red-500/10 text-red-500 text-[10px] font-black uppercase tracking-widest rounded-full border border-red-500/20">
                      <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
                      Live Now
                    </span>
                  )}
                </div>
                <h2 className="text-4xl md:text-6xl font-black text-white mb-6 uppercase tracking-tighter italic">
                  {competition.name}
                </h2>
                <p className="text-xl text-gray-400 font-medium leading-relaxed">
                  {competition.description}
                </p>
              </div>

              {/* Schedule Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                <div className="bg-white/5 p-6 rounded-3xl border border-white/10">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-[#d4af37]/10 flex items-center justify-center text-[#d4af37]">
                      <Calendar size={24} />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Event Dates</p>
                      <p className="text-lg font-bold text-white">{competition.startDate} - {competition.endDate}</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {competition.days.map(day => (
                      <span key={day} className="px-3 py-1 bg-white/5 text-gray-400 text-[10px] font-bold rounded-lg border border-white/5">
                        {day}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="bg-white/5 p-6 rounded-3xl border border-white/10">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-blue-500/10 flex items-center justify-center text-blue-500">
                      <Clock size={24} />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Event Timing</p>
                      <p className="text-lg font-bold text-white">{competition.startTime} to {competition.endTime}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 mt-4 pt-4 border-t border-white/5">
                    <div className="flex-1">
                      <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest">Entry Type</p>
                      <p className="text-sm font-bold text-[#d4af37]">{competition.entryType}</p>
                    </div>
                    <div className="flex-1 border-l border-white/5 pl-4">
                      <p className="text-[8px] font-black text-gray-500 uppercase tracking-widest">Capacity</p>
                      <p className="text-sm font-bold text-white">{competition.maxParticipants || 'Unlimited'}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Rules & Entry */}
              <div className="space-y-6 mb-12">
                {competition.rules && (
                  <div className="bg-white/5 p-8 rounded-[2rem] border border-white/10">
                    <h4 className="flex items-center gap-3 text-lg font-black text-white uppercase tracking-wider mb-4">
                      <Shield size={20} className="text-[#d4af37]" />
                      Championship Rules
                    </h4>
                    <div className="text-gray-400 text-sm leading-relaxed whitespace-pre-line font-medium">
                      {competition.rules}
                    </div>
                  </div>
                )}
                
                {competition.entryInfo && (
                  <div className="bg-[#d4af37]/5 p-8 rounded-[2rem] border border-[#d4af37]/20">
                    <h4 className="flex items-center gap-3 text-lg font-black text-[#d4af37] uppercase tracking-wider mb-4">
                      <Info size={20} />
                      Entry Information
                    </h4>
                    <p className="text-white text-sm font-bold leading-relaxed">
                      {competition.entryInfo}
                    </p>
                  </div>
                )}
              </div>

              {/* Winners Section (if completed) */}
              {competition.status === 'completed' && competition.winners.length > 0 && (
                <div className="mb-12">
                  <h4 className="text-2xl font-black text-white uppercase tracking-tighter mb-8 flex items-center gap-3">
                    <Award size={28} className="text-[#d4af37]" />
                    Hall of Fame
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {competition.winners.sort((a, b) => a.rank - b.rank).map((winner) => (
                      <WinnerCard key={winner.id} winner={winner} />
                    ))}
                  </div>
                </div>
              )}

              {/* Manager Section */}
              {manager && (
                <div className="bg-gradient-to-br from-[#d4af37]/10 to-transparent p-8 md:p-10 rounded-[2.5rem] border border-[#d4af37]/20 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-[#d4af37]/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
                  
                  <div className="flex flex-col md:flex-row items-center gap-8 relative z-10">
                    <div className="relative">
                      <div className="w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden border-4 border-[#d4af37]/30 p-1">
                        <img src={manager.imageUrl} alt={manager.name} className="w-full h-full object-cover rounded-full" />
                      </div>
                      <div className="absolute -bottom-2 -right-2 bg-[#d4af37] text-black p-2 rounded-full shadow-lg">
                        <Users size={16} />
                      </div>
                    </div>
                    
                    <div className="flex-1 text-center md:text-left">
                      <div className="flex flex-col md:flex-row md:items-center gap-3 mb-2">
                        <h3 className="text-2xl font-black text-white uppercase tracking-tight">{manager.name}</h3>
                        <div className="flex gap-2">
                          <span className="px-3 py-1 bg-[#d4af37]/20 text-[#d4af37] text-[10px] font-black uppercase tracking-widest rounded-full border border-[#d4af37]/30">
                            {manager.role}
                          </span>
                          {manager.experience && (
                            <span className="px-3 py-1 bg-white/5 text-gray-400 text-[10px] font-black uppercase tracking-widest rounded-full border border-white/10">
                              {manager.experience}
                            </span>
                          )}
                        </div>
                      </div>
                      <p className="text-gray-400 text-sm mb-6 italic font-medium">"{manager.remark}"</p>
                      
                      <div className="flex flex-wrap justify-center md:justify-start gap-4">
                        <button className="flex items-center gap-2 px-6 py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl transition-all border border-white/10 text-xs font-bold uppercase tracking-widest">
                          <Phone size={16} />
                          Contact
                        </button>
                        <button className="flex items-center gap-2 px-6 py-3 bg-[#25D366]/20 hover:bg-[#25D366]/30 text-[#25D366] rounded-xl transition-all border border-[#25D366]/30 text-xs font-bold uppercase tracking-widest">
                          <MessageCircle size={16} />
                          WhatsApp
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}

function WinnerCard({ winner }: { winner: CompetitionWinner }) {
  const rankColors = {
    1: 'from-[#d4af37] to-[#f3e5ab]',
    2: 'from-gray-300 to-gray-500',
    3: 'from-amber-600 to-amber-800'
  };

  const rankLabels = {
    1: '1st Place',
    2: '2nd Place',
    3: '3rd Place'
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      whileHover={{ y: -10 }}
      className={`bg-white/5 rounded-3xl border border-white/10 p-6 text-center group hover:border-[#d4af37]/30 transition-all relative overflow-hidden ${winner.rank === 1 ? 'shadow-[0_0_50px_rgba(212,175,55,0.1)]' : ''}`}
    >
      {winner.rank === 1 && (
        <>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(212,175,55,0.1)_0%,transparent_70%)] pointer-events-none"></div>
          {[...Array(12)].map((_, i) => (
            <div 
              key={i} 
              className="confetti-piece"
              style={{
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                backgroundColor: i % 2 === 0 ? '#d4af37' : '#f3e5ab',
                transform: `scale(${Math.random() * 0.5 + 0.5})`
              }}
            />
          ))}
        </>
      )}
      
      <div className="relative mb-6 inline-block">
        <motion.div 
          animate={winner.rank === 1 ? { scale: [1, 1.05, 1] } : {}}
          transition={{ repeat: Infinity, duration: 2 }}
          className={`w-24 h-24 rounded-full overflow-hidden border-4 border-white/10 p-1 group-hover:border-[#d4af37]/50 transition-all relative z-10`}
        >
          <img src={winner.imageUrl} alt={winner.name} className="w-full h-full object-cover rounded-full" />
        </motion.div>
        
        <motion.div 
          initial={{ scale: 0 }}
          whileInView={{ scale: 1 }}
          className={`absolute -bottom-2 -right-2 w-10 h-10 rounded-full bg-gradient-to-br ${rankColors[winner.rank]} flex items-center justify-center text-black shadow-lg border-2 border-[#0a0a0a] z-20`}
        >
          {winner.rank === 1 ? <Trophy size={18} className="fill-black" /> : <span className="text-lg font-black">{winner.rank}</span>}
        </motion.div>
        
        {winner.rank === 1 && (
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 10, ease: "linear" }}
            className="absolute inset-[-20px] border border-dashed border-[#d4af37]/20 rounded-full pointer-events-none"
          />
        )}
      </div>
      
      <h5 className="text-lg font-black text-white uppercase tracking-tight mb-1">{winner.name}</h5>
      <p className="text-[10px] font-black text-[#d4af37] uppercase tracking-[0.2em] mb-2">{rankLabels[winner.rank]}</p>
      
      {winner.achievementMessage && (
        <p className="text-[9px] font-black text-white/60 uppercase tracking-widest mb-4 bg-white/5 py-1 px-2 rounded-lg border border-white/10">
          {winner.achievementMessage}
        </p>
      )}
      
      <div className="flex items-center justify-center gap-2 text-gray-500 text-[10px] font-bold mb-4">
        <MapPin size={12} />
        {winner.address}
      </div>
      
      <p className="text-gray-400 text-xs italic line-clamp-2">"{winner.remark}"</p>
    </motion.div>
  );
}
