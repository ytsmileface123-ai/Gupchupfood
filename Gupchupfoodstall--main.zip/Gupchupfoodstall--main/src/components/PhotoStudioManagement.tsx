import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { doc, onSnapshot, updateDoc, collection, addDoc, deleteDoc, query, orderBy, limit, serverTimestamp, setDoc } from 'firebase/firestore';
import { Plus, Trash2, Camera, Clock, DollarSign, Calendar, ToggleLeft, ToggleRight, Image as ImageIcon, X, Users } from 'lucide-react';
import { motion } from 'framer-motion';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

const DAYS_OF_WEEK = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

const SettingInput = ({ value, onChange, type = "text", className, placeholder }: any) => {
  const [localValue, setLocalValue] = useState(value);

  useEffect(() => {
    setLocalValue(value);
  }, [value]);

  if (type === 'textarea') {
    return (
      <textarea
        value={localValue}
        onChange={(e) => setLocalValue(e.target.value)}
        onBlur={() => onChange(localValue)}
        className={className}
        placeholder={placeholder}
      />
    );
  }

  return (
    <input
      type={type}
      value={localValue}
      onChange={(e) => setLocalValue(e.target.value)}
      onBlur={() => onChange(type === 'number' ? Number(localValue) : localValue)}
      className={className}
      placeholder={placeholder}
    />
  );
};

const PhotoStudioManagement: React.FC = () => {
  const [settings, setSettings] = useState<any>(null);
  const [photos, setPhotos] = useState<any[]>([]);
  const [newPhotoUrl, setNewPhotoUrl] = useState('');
  const [newCustomerName, setNewCustomerName] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribeSettings = onSnapshot(doc(db, 'photoStudioSettings', 'global'), async (snapshot) => {
      if (snapshot.exists()) {
        setSettings(snapshot.data());
      } else {
        // Initialize default settings if not exists
        try {
          await setDoc(doc(db, 'photoStudioSettings', 'global'), {
            isEnabled: true,
            pricePerPhoto: 50,
            rotationSpeed: 5,
            openDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
          });
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, 'photoStudioSettings/global');
        }
      }
    });

    const qPhotos = query(collection(db, 'customerPhotos'), orderBy('timestamp', 'desc'), limit(50));
    const unsubscribePhotos = onSnapshot(qPhotos, (snapshot) => {
      setPhotos(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    return () => {
      unsubscribeSettings();
      unsubscribePhotos();
    };
  }, []);

  const handleUpdateSettings = async (updates: any) => {
    try {
      await updateDoc(doc(db, 'photoStudioSettings', 'global'), updates);
      setErrorMessage(null);
    } catch (error: any) {
      handleFirestoreError(error, OperationType.UPDATE, 'photoStudioSettings/global');
      if (error.code === 'resource-exhausted' || error.message?.includes('too large')) {
        setErrorMessage("File is too large for database. Please use a direct URL link instead.");
      } else {
        setErrorMessage("Failed to update settings. Please try again.");
      }
    }
  };

  const handleAddPhoto = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPhotoUrl) return;

    try {
      await addDoc(collection(db, 'customerPhotos'), {
        imageUrl: newPhotoUrl,
        customerName: newCustomerName,
        timestamp: serverTimestamp()
      });
      setNewPhotoUrl('');
      setNewCustomerName('');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'customerPhotos');
    }
  };

  const handleDeletePhoto = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'customerPhotos', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `customerPhotos/${id}`);
    }
  };

  const toggleDay = (day: string) => {
    const currentDays = settings.openDays || [];
    const newDays = currentDays.includes(day)
      ? currentDays.filter((d: string) => d !== day)
      : [...currentDays, day];
    handleUpdateSettings({ openDays: newDays });
  };

  if (!settings) return <div className="p-8 text-center text-gray-500">Loading Photo Studio settings...</div>;

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h3 className="text-3xl font-black uppercase tracking-tighter flex items-center gap-3">
          <Camera className="text-pink-500" size={32} />
          Photo Studio Dashboard
        </h3>
      </div>

      {errorMessage && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-red-500/10 border border-red-500/20 p-4 rounded-xl flex items-center justify-between gap-4"
        >
          <p className="text-red-500 text-sm font-bold">{errorMessage}</p>
          <button onClick={() => setErrorMessage(null)} className="text-red-500 hover:text-red-400">
            <X size={20} />
          </button>
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Settings Panel */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
            <h4 className="text-lg font-bold mb-6 flex items-center gap-2">
              <Clock className="text-blue-400" size={20} />
              Studio Settings
            </h4>
            
            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-black/40 rounded-xl border border-white/5">
                <div>
                  <p className="font-bold text-sm">Enable Photo Studio</p>
                  <p className="text-[10px] text-gray-500">Show/hide on website</p>
                </div>
                <button 
                  onClick={() => handleUpdateSettings({ isEnabled: !settings.isEnabled })}
                  className={`p-2 rounded-lg transition-colors ${settings.isEnabled ? 'text-[var(--color-neon-green)]' : 'text-gray-600'}`}
                >
                  {settings.isEnabled ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}
                </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-black/40 rounded-xl border border-white/5">
                <div>
                  <p className="font-bold text-sm">Enable Gallery</p>
                  <p className="text-[10px] text-gray-500">Show customer photos</p>
                </div>
                <button 
                  onClick={() => handleUpdateSettings({ isGalleryEnabled: settings.isGalleryEnabled === false })}
                  className={`p-2 rounded-lg transition-colors ${settings.isGalleryEnabled !== false ? 'text-pink-400' : 'text-gray-600'}`}
                >
                  {settings.isGalleryEnabled !== false ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}
                </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-black/40 rounded-xl border border-white/5">
                <div>
                  <p className="font-bold text-sm">Enable Cameraman Profile</p>
                  <p className="text-[10px] text-gray-500">Show photographer details</p>
                </div>
                <button 
                  onClick={() => handleUpdateSettings({ isCameramanProfileEnabled: settings.isCameramanProfileEnabled === false })}
                  className={`p-2 rounded-lg transition-colors ${settings.isCameramanProfileEnabled !== false ? 'text-purple-400' : 'text-gray-600'}`}
                >
                  {settings.isCameramanProfileEnabled !== false ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}
                </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-black/40 rounded-xl border border-white/5">
                <div>
                  <p className="font-bold text-sm">Enable Event Booking</p>
                  <p className="text-[10px] text-gray-500">Show "Book for Events" card</p>
                </div>
                <button 
                  onClick={() => handleUpdateSettings({ isBookingEnabled: settings.isBookingEnabled === false })}
                  className={`p-2 rounded-lg transition-colors ${settings.isBookingEnabled !== false ? 'text-blue-400' : 'text-gray-600'}`}
                >
                  {settings.isBookingEnabled !== false ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}
                </button>
              </div>

              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2 flex items-center gap-2">
                  <DollarSign size={12} /> Price Per Photo (₹)
                </label>
                <SettingInput 
                  type="number" 
                  value={settings.pricePerPhoto}
                  onChange={(val: number) => handleUpdateSettings({ pricePerPhoto: val })}
                  className="w-full bg-black border border-[#333] rounded-xl px-4 py-3 text-white focus:border-pink-500 outline-none transition-all"
                  placeholder="e.g. 50"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2 flex items-center gap-2">
                  <Clock size={12} /> Rotation Speed (Seconds)
                </label>
                <SettingInput 
                  type="number" 
                  value={settings.rotationSpeed}
                  onChange={(val: number) => handleUpdateSettings({ rotationSpeed: val })}
                  className="w-full bg-black border border-[#333] rounded-xl px-4 py-3 text-white focus:border-pink-500 outline-none transition-all"
                  placeholder="e.g. 5"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2 flex items-center gap-2">
                  <Plus size={12} /> Section Size
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {['small', 'medium', 'large', 'full'].map(size => (
                    <button
                      key={size}
                      onClick={() => handleUpdateSettings({ sectionWidth: size })}
                      className={`px-2 py-2 rounded-lg text-[9px] font-black uppercase transition-all border ${
                        (settings.sectionWidth || 'large') === size
                          ? 'bg-blue-500/20 border-blue-500 text-blue-500'
                          : 'bg-black border-[#333] text-gray-500 hover:border-gray-600'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                  <Calendar size={12} /> Open Days
                </label>
                <div className="flex flex-wrap gap-2">
                  {DAYS_OF_WEEK.map(day => (
                    <button
                      key={day}
                      onClick={() => toggleDay(day)}
                      className={`px-3 py-1.5 rounded-lg text-[10px] font-bold transition-all border ${
                        settings.openDays?.includes(day)
                          ? 'bg-pink-500/20 border-pink-500 text-pink-500'
                          : 'bg-black border-[#333] text-gray-500 hover:border-gray-600'
                      }`}
                    >
                      {day.substring(0, 3)}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Cameraman Profile Section */}
          <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
            <h4 className="text-lg font-bold mb-6 flex items-center gap-2">
              <Users className="text-purple-400" size={20} />
              Cameraman Profile
            </h4>
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Cameraman Name</label>
                <SettingInput 
                  type="text" 
                  value={settings.cameramanName || ''}
                  onChange={(val: string) => handleUpdateSettings({ cameramanName: val })}
                  className="w-full bg-black border border-[#333] rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none transition-all"
                  placeholder="e.g. John Doe"
                />
              </div>
              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Contact Number</label>
                <SettingInput 
                  type="text" 
                  value={settings.cameramanContact || ''}
                  onChange={(val: string) => handleUpdateSettings({ cameramanContact: val })}
                  className="w-full bg-black border border-[#333] rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none transition-all"
                  placeholder="e.g. +91 9876543210"
                />
              </div>
              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Experience</label>
                <SettingInput 
                  type="text" 
                  value={settings.cameramanExperience || ''}
                  onChange={(val: string) => handleUpdateSettings({ cameramanExperience: val })}
                  className="w-full bg-black border border-[#333] rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none transition-all"
                  placeholder="e.g. 5+ Years"
                />
              </div>
              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Logo / Profile Image URL</label>
                <div className="flex flex-col gap-2">
                  <div className="flex gap-2">
                    <SettingInput 
                      type="url" 
                      value={settings.cameramanLogoUrl || ''}
                      onChange={(val: string) => handleUpdateSettings({ cameramanLogoUrl: val })}
                      className="flex-1 bg-black border border-[#333] rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none transition-all"
                      placeholder="https://..."
                    />
                    {settings.cameramanLogoUrl && (
                      <button 
                        onClick={() => handleUpdateSettings({ cameramanLogoUrl: '' })}
                        className="p-3 bg-red-500/10 text-red-500 rounded-xl border border-red-500/20 hover:bg-red-500/20 transition-colors"
                      >
                        <X size={20} />
                      </button>
                    )}
                  </div>
                  <label className="bg-[#222] hover:bg-[#333] text-white text-[10px] font-black py-2 px-4 rounded-xl cursor-pointer transition-colors border border-[#444] text-center uppercase tracking-widest flex items-center justify-center gap-2">
                    <ImageIcon size={14} /> Upload Logo
                    <input 
                      type="file" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          if (file.size > 800 * 1024) { // Slightly safer limit than 1MB
                            setErrorMessage("File is too large (max 800KB). Please use a direct URL link for larger files/videos.");
                            return;
                          }
                          const reader = new FileReader();
                          reader.onload = (event) => {
                            handleUpdateSettings({ cameramanLogoUrl: event.target?.result as string });
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                  {settings.cameramanLogoUrl && (
                    <div className="mt-2 w-16 h-16 rounded-lg overflow-hidden border border-white/10">
                      <img src={settings.cameramanLogoUrl} alt="Logo Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                  )}
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Story Media Type</label>
                <select 
                  value={settings.cameramanMediaType || 'video'}
                  onChange={(e) => handleUpdateSettings({ cameramanMediaType: e.target.value })}
                  className="w-full bg-black border border-[#333] rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none transition-all"
                >
                  <option value="image">Image</option>
                  <option value="video">Video (MP4)</option>
                  <option value="gif">GIF</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Story Media URL (Image/Video/GIF)</label>
                <div className="flex flex-col gap-2">
                  <div className="flex gap-2">
                    <SettingInput 
                      type="url" 
                      value={settings.cameramanVideoUrl || ''}
                      onChange={(val: string) => handleUpdateSettings({ cameramanVideoUrl: val })}
                      className="flex-1 bg-black border border-[#333] rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none transition-all"
                      placeholder="https://... (mp4, jpg, gif)"
                    />
                    {settings.cameramanVideoUrl && (
                      <button 
                        onClick={() => handleUpdateSettings({ cameramanVideoUrl: '' })}
                        className="p-3 bg-red-500/10 text-red-500 rounded-xl border border-red-500/20 hover:bg-red-500/20 transition-colors"
                      >
                        <X size={20} />
                      </button>
                    )}
                  </div>
                  <label className="bg-[#222] hover:bg-[#333] text-white text-[10px] font-black py-2 px-4 rounded-xl cursor-pointer transition-colors border border-[#444] text-center uppercase tracking-widest flex items-center justify-center gap-2">
                    <ImageIcon size={14} /> Upload Story Media
                    <input 
                      type="file" 
                      accept={settings.cameramanMediaType === 'video' ? 'video/mp4' : settings.cameramanMediaType === 'gif' ? 'image/gif' : 'image/*'} 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          if (file.size > 800 * 1024) {
                            setErrorMessage("File is too large (max 800KB). Please use a direct URL link for larger files/videos.");
                            return;
                          }
                          const reader = new FileReader();
                          reader.onload = (event) => {
                            handleUpdateSettings({ cameramanVideoUrl: event.target?.result as string });
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                  {settings.cameramanVideoUrl && (
                    <div className="mt-2 aspect-video rounded-lg overflow-hidden border border-white/10 bg-black flex items-center justify-center">
                      {settings.cameramanMediaType === 'video' ? (
                        <video src={settings.cameramanVideoUrl} className="max-h-full max-w-full" muted />
                      ) : (
                        <img src={settings.cameramanVideoUrl} alt="Story Preview" className="max-h-full max-w-full object-contain" referrerPolicy="no-referrer" />
                      )}
                    </div>
                  )}
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Zip File URL (Assets)</label>
                <div className="flex flex-col gap-2">
                  <div className="flex gap-2">
                    <SettingInput 
                      type="url" 
                      value={settings.cameramanZipUrl || ''}
                      onChange={(val: string) => handleUpdateSettings({ cameramanZipUrl: val })}
                      className="flex-1 bg-black border border-[#333] rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none transition-all"
                      placeholder="https://... (zip)"
                    />
                    {settings.cameramanZipUrl && (
                      <button 
                        onClick={() => handleUpdateSettings({ cameramanZipUrl: '' })}
                        className="p-3 bg-red-500/10 text-red-500 rounded-xl border border-red-500/20 hover:bg-red-500/20 transition-colors"
                      >
                        <X size={20} />
                      </button>
                    )}
                  </div>
                  <label className="bg-[#222] hover:bg-[#333] text-white text-[10px] font-black py-2 px-4 rounded-xl cursor-pointer transition-colors border border-[#444] text-center uppercase tracking-widest flex items-center justify-center gap-2">
                    <ImageIcon size={14} /> Upload Zip File
                    <input 
                      type="file" 
                      accept=".zip,application/zip,application/x-zip-compressed" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          if (file.size > 800 * 1024) {
                            setErrorMessage("File is too large (max 800KB). Please use a direct URL link for larger files.");
                            return;
                          }
                          const reader = new FileReader();
                          reader.onload = (event) => {
                            handleUpdateSettings({ cameramanZipUrl: event.target?.result as string });
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                </div>
              </div>
              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Remark / Bio</label>
                <SettingInput 
                  type="textarea"
                  value={settings.cameramanRemark || ''}
                  onChange={(val: string) => handleUpdateSettings({ cameramanRemark: val })}
                  className="w-full bg-black border border-[#333] rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none transition-all h-24 resize-none"
                  placeholder="Tell customers about the cameraman..."
                />
              </div>
              <div>
                <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Wedding/Function Booking Details</label>
                <SettingInput 
                  type="textarea"
                  value={settings.bookingDetails || ''}
                  onChange={(val: string) => handleUpdateSettings({ bookingDetails: val })}
                  className="w-full bg-black border border-[#333] rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none transition-all h-24 resize-none"
                  placeholder="Details for wedding or function bookings..."
                />
              </div>

              {/* Camera Rental Section */}
              <div className="pt-4 border-t border-white/5">
                <div className="flex items-center justify-between p-4 bg-black/40 rounded-xl border border-white/5 mb-4">
                  <div>
                    <p className="font-bold text-sm">Enable Camera Rental</p>
                    <p className="text-[10px] text-gray-500">Rent for weddings/birthdays</p>
                  </div>
                  <button 
                    onClick={() => handleUpdateSettings({ isRentalEnabled: !settings.isRentalEnabled })}
                    className={`p-2 rounded-lg transition-colors ${settings.isRentalEnabled ? 'text-purple-400' : 'text-gray-600'}`}
                  >
                    {settings.isRentalEnabled ? <ToggleRight size={32} /> : <ToggleLeft size={32} />}
                  </button>
                </div>
                
                {settings.isRentalEnabled && (
                  <div>
                    <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Rental Details (Weddings, Birthdays, etc.)</label>
                    <SettingInput 
                      type="textarea"
                      value={settings.rentalDetails || ''}
                      onChange={(val: string) => handleUpdateSettings({ rentalDetails: val })}
                      className="w-full bg-black border border-[#333] rounded-xl px-4 py-3 text-white focus:border-purple-500 outline-none transition-all h-24 resize-none"
                      placeholder="e.g. Camera available for rent for all types of functions..."
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Photo Management */}
        <div className="lg:col-span-2 space-y-6">
          {/* Add Photo Form */}
          <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
            <h4 className="text-lg font-bold mb-6 flex items-center gap-2">
              <Plus className="text-[var(--color-neon-green)]" size={20} />
              Add Customer Photo
            </h4>
            <form onSubmit={handleAddPhoto} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Customer Name (Optional)</label>
                  <input 
                    type="text" 
                    value={newCustomerName}
                    onChange={(e) => setNewCustomerName(e.target.value)}
                    className="w-full bg-black border border-[#333] rounded-xl px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all"
                    placeholder="e.g. Rahul"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">Photo URL or Upload</label>
                  <div className="flex flex-col gap-2">
                    <input 
                      type="url" 
                      value={newPhotoUrl}
                      onChange={(e) => setNewPhotoUrl(e.target.value)}
                      className="w-full bg-black border border-[#333] rounded-xl px-4 py-3 text-white focus:border-[var(--color-neon-green)] outline-none transition-all"
                      placeholder="https://..."
                    />
                    <label className="bg-[#222] hover:bg-[#333] text-white text-[10px] font-black py-2 px-4 rounded-xl cursor-pointer transition-colors border border-[#444] text-center uppercase tracking-widest flex items-center justify-center gap-2">
                      <ImageIcon size={14} /> Upload Local Photo
                      <input 
                        type="file" 
                        accept="image/*" 
                        className="hidden" 
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            if (file.size > 1024 * 1024) {
                              alert("File is too large (max 1MB). Use URL for larger files.");
                              return;
                            }
                            const reader = new FileReader();
                            reader.onload = (event) => {
                              setNewPhotoUrl(event.target?.result as string);
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>
                  </div>
                </div>
              </div>
              <button 
                type="submit"
                disabled={!newPhotoUrl}
                className="w-full bg-[var(--color-neon-green)] text-black font-black py-3 rounded-xl hover:opacity-90 transition-all disabled:opacity-50 flex items-center justify-center gap-2 uppercase tracking-widest"
              >
                <Plus size={20} /> Add to Dashboard
              </button>
            </form>
          </div>

          {/* Photos Grid */}
          <div className="bg-[#111] border border-[#333] p-6 rounded-2xl">
            <h4 className="text-lg font-bold mb-6">Recent Customer Photos</h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {photos.map(photo => (
                <div key={photo.id} className="group relative aspect-square rounded-xl overflow-hidden border border-[#333]">
                  <img 
                    src={photo.imageUrl} 
                    alt="Customer" 
                    className="w-full h-full object-contain"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-2 text-center">
                    <p className="text-[10px] font-bold text-white mb-2">{photo.customerName || 'Anonymous'}</p>
                    <button 
                      onClick={() => handleDeletePhoto(photo.id)}
                      className="p-2 bg-red-500/20 text-red-500 rounded-lg hover:bg-red-500/40 transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
              {photos.length === 0 && (
                <div className="col-span-full py-12 text-center text-gray-600 italic">
                  No photos added yet. Upload customer photos to show them on the dashboard.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PhotoStudioManagement;
