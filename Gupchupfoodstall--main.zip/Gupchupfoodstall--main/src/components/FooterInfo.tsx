import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Phone, ExternalLink, Clock, Mail, Globe, ShieldCheck, Truck, Instagram, Facebook, Youtube } from 'lucide-react';
import { useStore } from '../store/useStore';

export default function FooterInfo() {
  const { settings } = useStore();

  const infoItems = [
    {
      icon: <MapPin className="text-[var(--color-neon-red)]" size={24} />,
      title: "Location",
      content: "Chhoto Mohodipur danesh Ali Tola Tree Mohini",
      link: "https://maps.google.com"
    },
    {
      icon: <Phone className="text-[var(--color-neon-green)]" size={24} />,
      title: "Contact",
      content: "+91 98765 43210",
      link: "tel:+919876543210"
    },
    {
      icon: <Clock className="text-blue-400" size={24} />,
      title: "Hours",
      content: "Open Daily: 10 AM - 11 PM",
      link: "#"
    },
    {
      icon: <Mail className="text-purple-400" size={24} />,
      title: "Email",
      content: "hello@gupchup.com",
      link: "mailto:hello@gupchup.com"
    }
  ];

  return (
    <section className="relative py-40 px-4 overflow-hidden bg-transparent border-t border-white/5">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-[var(--color-neon-green)]/5 rounded-full blur-[150px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 md:gap-20">
          {infoItems.map((item, index) => (
            <motion.a
              key={item.title || `footer-item-${index}`}
              href={item.link}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 1, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -15 }}
              className="relative group flex flex-col items-start text-left"
            >
              <div className="text-[120px] font-black text-white/5 absolute -top-20 -left-10 select-none group-hover:text-[var(--color-neon-green)]/10 transition-colors duration-700">
                0{index + 1}
              </div>
              
              <div className="relative z-10">
                <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mb-8 group-hover:scale-110 transition-transform duration-700 shadow-2xl border border-white/10 group-hover:border-[var(--color-neon-green)]/40">
                  {item.icon}
                </div>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-8 h-px bg-[var(--color-neon-green)]"></div>
                  <h4 className="text-[10px] font-black text-[var(--color-neon-green)] uppercase tracking-[0.5em]">{item.title}</h4>
                </div>
                <p className="text-white font-black text-2xl md:text-3xl leading-tight group-hover:translate-x-2 transition-all duration-700 tracking-tighter uppercase italic">
                  {item.content}
                </p>
              </div>
            </motion.a>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 60 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4, duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          className="mt-40 glass-panel p-12 md:p-20 rounded-[4rem] border-white/10 flex flex-col lg:flex-row items-center justify-between gap-16 relative overflow-hidden group"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-[var(--color-neon-green)]/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-1000"></div>
          
          <div className="flex flex-col md:flex-row items-center gap-10 relative z-10">
            <div className="flex items-center gap-6 px-10 py-5 rounded-full bg-white/5 border border-white/10 hover:border-[var(--color-neon-green)]/40 transition-all duration-500">
              <ShieldCheck className="text-[var(--color-neon-green)]" size={24} />
              <span className="text-[10px] font-black text-white uppercase tracking-[0.4em]">Certified Quality</span>
            </div>
            <div className="flex items-center gap-6 px-10 py-5 rounded-full bg-white/5 border border-white/10 hover:border-[var(--color-neon-red)]/40 transition-all duration-500">
              <Truck className="text-[var(--color-neon-red)]" size={24} />
              <span className="text-[10px] font-black text-white uppercase tracking-[0.4em]">Express Delivery</span>
            </div>
          </div>
          
          <div className="flex flex-col md:flex-row items-center gap-10 relative z-10">
            <span className="text-[10px] font-black text-white/40 uppercase tracking-[0.6em]">Follow The Movement</span>
            <div className="flex gap-6">
              {[Globe, Instagram, Facebook, Youtube].map((Icon, i) => (
                <motion.a
                  key={`social-${i}`}
                  href="#"
                  whileHover={{ scale: 1.2, rotate: 15, backgroundColor: "var(--color-neon-green)", color: "black" }}
                  className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white transition-all duration-500 shadow-2xl"
                >
                  <Icon size={24} />
                </motion.a>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
