import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import InfluencerVideo from './InfluencerVideo';

interface ReelModalProps {
  videos: any[];
  initialIndex: number;
  onClose: () => void;
}

export const ReelModal: React.FC<ReelModalProps> = ({ videos, initialIndex, onClose }) => {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] bg-black/80 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div 
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          className="relative w-full max-w-sm aspect-[9/16] bg-black rounded-3xl overflow-hidden shadow-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="absolute top-4 right-4 z-50">
            <button onClick={onClose} className="bg-black/40 backdrop-blur-md text-white p-2 rounded-full">
              <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
            </button>
          </div>
          <div className="w-full h-full overflow-y-auto snap-y snap-mandatory">
            {videos.map((video, index) => (
              <div key={video.id} className="w-full h-full snap-start">
                <InfluencerVideo 
                  videoUrl={video.videoUrl}
                  influencerName={video.brandName || video.influencerName}
                  influencerImage={video.imageUrl || video.influencerImage}
                  caption={video.remark || video.description || video.caption}
                  logoUrl={video.logoUrl}
                  socialLink={video.socialLink || video.instagram || video.facebook || video.youtube || video.twitter}
                  musicUrl={video.musicUrl}
                  mediaType={video.mediaType}
                  zipUrl={video.zipUrl}
                />
              </div>
            ))}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
