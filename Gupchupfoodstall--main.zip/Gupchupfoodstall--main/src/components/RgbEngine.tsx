import React, { useEffect } from 'react';
import { useStore } from '../store/useStore';

export default function RgbEngine() {
  const { settings } = useStore();
  const rgb = settings.rgbConfig;

  useEffect(() => {
    if (!rgb) return;

    const root = document.documentElement;
    
    // Global Enable
    if (!rgb.globalEnable) {
      root.classList.remove('rgb-enabled');
      return;
    }
    
    root.classList.add('rgb-enabled');

    // Battery Saver
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const isBatterySaver = rgb.batterySaver || prefersReducedMotion;
    
    if (isBatterySaver) {
      root.classList.add('rgb-battery-saver');
    } else {
      root.classList.remove('rgb-battery-saver');
    }

    // Speed
    let duration = '3s';
    if (rgb.speed === 'slow') duration = '6s';
    if (rgb.speed === 'medium') duration = '3s';
    if (rgb.speed === 'fast') duration = '1.5s';
    if (rgb.speed === 'custom') duration = `${rgb.customSpeedMs}ms`;
    
    root.style.setProperty('--rgb-duration', duration);

    // Color Mode
    root.classList.remove('rgb-mode-single', 'rgb-mode-multi', 'rgb-mode-neon', 'rgb-mode-soft');
    root.classList.add(`rgb-mode-${rgb.colorMode}`);
    
    if (rgb.colorMode === 'single') {
      root.style.setProperty('--rgb-single-color', rgb.singleColor);
    }

    // Intensity
    let glowSpread = '10px';
    let glowOpacity = '0.5';
    
    if (rgb.glowIntensity === 'low') {
      glowSpread = '5px';
      glowOpacity = '0.3';
    } else if (rgb.glowIntensity === 'high') {
      glowSpread = '20px';
      glowOpacity = '0.8';
    }
    
    root.style.setProperty('--rgb-glow-spread', glowSpread);
    root.style.setProperty('--rgb-glow-opacity', glowOpacity);

    // Targets
    const targets = ['background', 'buttons', 'borders', 'cards', 'headings', 'icons'];
    targets.forEach(target => {
      if (rgb.targets[target as keyof typeof rgb.targets]) {
        root.classList.add(`rgb-target-${target}`);
      } else {
        root.classList.remove(`rgb-target-${target}`);
      }
    });

    // Sections
    const sections = [
      'hero', 'menu', 'events', 'cart', 'offers', 'reels', 'cashback', 'moments', 
      'photostudio', 'influencers', 'sponsored', 'footerInfo', 'notifications', 
      'featuredInfluencers', 'stories', 'partnerCollab', 'riderList', 'founders', 
      'getDirections', 'openingHours', 'contact', 'chickenStore', 'banners'
    ];
    sections.forEach(section => {
      if (rgb.sections[section as keyof typeof rgb.sections]) {
        root.classList.add(`rgb-section-${section}`);
      } else {
        root.classList.remove(`rgb-section-${section}`);
      }
    });

  }, [rgb]);

  return null;
}
