import React, { useState } from 'react';
import { auth, db } from '../firebase';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Loader2 } from 'lucide-react';

export const AdminLoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const userDoc = await getDoc(doc(db, 'users', userCredential.user.uid));
      
      const isAdmin = (userDoc.exists() && userDoc.data().role === 'admin') || 
                      email.toLowerCase() === 'gupchupfoodstall@gmail.com';
      
      if (isAdmin) {
        navigate('/admin');
      } else {
        await auth.signOut();
        alert(`Access Denied: You are not an administrator.`);
      }
    } catch (error) {
      console.error('Admin Auth error:', error);
      alert('Authentication failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#111] p-4">
      <div className="bg-[#1a1a1a] p-8 rounded-2xl border border-[#333] w-full max-w-md">
        <h2 className="text-2xl font-bold text-white mb-6 text-center">Admin Panel Login</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="email"
            placeholder="Admin Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-[#222] border border-[#444] rounded-lg px-4 py-2 text-white"
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-[#222] border border-[#444] rounded-lg px-4 py-2 text-white"
            required
          />
          <button type="submit" className="w-full bg-[var(--color-neon-green)] text-black font-bold py-2 rounded-lg hover:opacity-90 flex items-center justify-center" disabled={loading}>
            {loading ? <Loader2 className="animate-spin" /> : 'Login to Admin Panel'}
          </button>
          <Link to="/" className="flex items-center justify-center gap-2 text-gray-500 mt-6 text-sm hover:text-[var(--color-neon-green)] transition-colors">
            <ArrowLeft size={14} /> Back to Website
          </Link>
        </form>
      </div>
    </div>
  );
};
