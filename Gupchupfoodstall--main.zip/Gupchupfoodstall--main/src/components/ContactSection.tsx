import React from 'react';
import { motion } from 'framer-motion';
import { Phone } from 'lucide-react';
import { useStore } from '../store/useStore';

export default function ContactSection() {
  const { settings } = useStore();

  return (
    <section className="py-20 px-4 bg-black/60 backdrop-blur-lg border-t border-[#222]">
      <div className="max-w-2xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center gap-3 mb-8 justify-center">
            <Phone className="text-[var(--color-neon-green)]" size={24} />
            <h4 className="text-[var(--color-neon-green)] font-black uppercase tracking-[0.3em] text-sm">{settings.contactSectionTitle || 'Contact'}</h4>
          </div>
          <div className="space-y-6">
            <a href={`tel:${settings.contactNumbers.owner}`} className="flex items-center gap-4 p-4 rounded-2xl bg-[#111] border border-[#222] hover:border-[var(--color-neon-green)]/30 transition-all group">
              <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center group-hover:bg-[var(--color-neon-green)]/10 transition-colors">
                <Phone className="text-gray-400 group-hover:text-[var(--color-neon-green)]" size={20} />
              </div>
              <div>
                <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Owner</p>
                <p className="text-lg font-black text-white tracking-wider">+{settings.contactNumbers.owner}</p>
              </div>
            </a>
            <a href={`tel:${settings.contactNumbers.partner}`} className="flex items-center gap-4 p-4 rounded-2xl bg-[#111] border border-[#222] hover:border-[var(--color-neon-green)]/30 transition-all group">
              <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center group-hover:bg-[var(--color-neon-green)]/10 transition-colors">
                <Phone className="text-gray-400 group-hover:text-[var(--color-neon-green)]" size={20} />
              </div>
              <div>
                <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Partner</p>
                <p className="text-lg font-black text-white tracking-wider">+{settings.contactNumbers.partner}</p>
              </div>
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
