import React, { useEffect, useState } from 'react';
import { db } from '../firebase';
import { collection, query, orderBy, onSnapshot, doc, updateDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { Loader2, Package, CheckCircle, XCircle, MapPin, Phone, User, Clock, MessageCircle, Save, ArrowLeft, Utensils } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

export const OrderManagement: React.FC = () => {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);
  const [remarkInput, setRemarkInput] = useState('');
  const [deliveryTimeInput, setDeliveryTimeInput] = useState('');

  const STATUSES = ['Pending', 'Confirmed', 'Preparing', 'Out for Delivery', 'Completed'];

  useEffect(() => {
    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setOrders(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'orders');
    });
    return unsubscribe;
  }, []);

  const updateStatus = async (orderId: string, status: string) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), { 
        status,
        [`statusTimestamps.${status}`]: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `orders/${orderId}`);
    }
  };

  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const showStatusMessage = (message: string) => {
    setStatusMessage(message);
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const updateRemark = async (orderId: string) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), { adminRemark: remarkInput });
      setRemarkInput('');
      setSelectedOrder({ ...selectedOrder, adminRemark: remarkInput });
      showStatusMessage('Remark updated successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `orders/${orderId}`);
    }
  };

  const updateDeliveryTime = async (orderId: string) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), { estimatedDeliveryTime: deliveryTimeInput });
      setDeliveryTimeInput('');
      setSelectedOrder({ ...selectedOrder, estimatedDeliveryTime: deliveryTimeInput });
      showStatusMessage('Delivery time updated successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `orders/${orderId}`);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending': return 'bg-yellow-500/20 text-yellow-500 border-yellow-500/50';
      case 'Confirmed': return 'bg-blue-500/20 text-blue-500 border-blue-500/50';
      case 'Preparing': return 'bg-orange-500/20 text-orange-500 border-orange-500/50';
      case 'Out for Delivery': return 'bg-purple-500/20 text-purple-500 border-purple-500/50';
      case 'Completed': return 'bg-green-500/20 text-green-500 border-green-500/50';
      case 'Cancelled': return 'bg-red-500/20 text-red-500 border-red-500/50';
      default: return 'bg-gray-500/20 text-gray-500 border-gray-500/50';
    }
  };

  if (loading) return <div className="flex justify-center p-10"><Loader2 className="animate-spin text-white" /></div>;

  return (
    <div className="space-y-6">
      {statusMessage && (
        <div className="fixed top-20 right-6 bg-[var(--color-neon-green)] text-black px-4 py-2 rounded-lg font-bold z-[60]">
          {statusMessage}
        </div>
      )}
      
      <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-[#333]">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-black uppercase tracking-tight text-white flex items-center gap-2">
            <Package className="text-[var(--color-neon-green)]" /> Order Management
          </h2>
          <div className="bg-[#222] px-4 py-2 rounded-lg border border-[#333] text-sm font-bold">
            Total Orders: <span className="text-[var(--color-neon-green)]">{orders.length}</span>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left text-white border-collapse">
            <thead>
              <tr className="border-b border-[#333] text-gray-400 text-sm uppercase tracking-wider">
                <th className="p-4 font-bold">Order ID</th>
                <th className="p-4 font-bold">Customer</th>
                <th className="p-4 font-bold">Time</th>
                <th className="p-4 font-bold">Total</th>
                <th className="p-4 font-bold">Status</th>
                <th className="p-4 font-bold text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {orders.map(order => (
                <tr key={order.id} className="border-b border-[#222] hover:bg-[#222] transition-colors">
                  <td className="p-4 font-mono text-sm">#{order.id.slice(-6).toUpperCase()}</td>
                  <td className="p-4">
                    <div className="font-bold">{order.customerName || order.customerDetails?.name || 'Guest'}</div>
                    <div className="text-xs text-gray-500">{order.customerPhone || order.customerDetails?.mobile || 'No mobile'}</div>
                  </td>
                  <td className="p-4 text-sm text-gray-400">
                    {order.createdAt ? new Date(order.createdAt.toDate()).toLocaleString() : 'N/A'}
                  </td>
                  <td className="p-4 font-bold text-[var(--color-neon-green)]">₹{order.totalAmount}</td>
                  <td className="p-4">
                    <select 
                      value={order.status || 'Pending'} 
                      onChange={(e) => updateStatus(order.id, e.target.value)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold border outline-none cursor-pointer ${getStatusColor(order.status || 'Pending')}`}
                    >
                      <option value="Pending" className="bg-[#111] text-white">Pending</option>
                      <option value="Confirmed" className="bg-[#111] text-white">Confirmed</option>
                      <option value="Preparing" className="bg-[#111] text-white">Preparing</option>
                      <option value="Out for Delivery" className="bg-[#111] text-white">Out for Delivery</option>
                      <option value="Completed" className="bg-[#111] text-white">Completed</option>
                      <option value="Cancelled" className="bg-[#111] text-white">Cancelled</option>
                    </select>
                  </td>
                  <td className="p-4 text-right">
                    <button 
                      onClick={() => {
                        setSelectedOrder(order);
                        setRemarkInput(order.adminRemark || '');
                        setDeliveryTimeInput(order.estimatedDeliveryTime || '');
                      }}
                      className="bg-[#333] hover:bg-[#444] text-white px-4 py-2 rounded-lg text-sm font-bold transition-colors"
                    >
                      Manage
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {orders.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <Package className="mx-auto mb-4 opacity-20" size={48} />
              <p>No orders found.</p>
            </div>
          )}
        </div>
      </div>

      {/* Order Management Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/90 flex items-center justify-center p-4 z-50 backdrop-blur-sm overflow-y-auto">
          <div className="bg-[#1a1a1a] p-6 rounded-2xl border border-[#333] w-full max-w-2xl my-8 relative">
            <button 
              onClick={() => setSelectedOrder(null)} 
              className="absolute top-4 right-4 text-gray-400 hover:text-white bg-[#222] p-2 rounded-full"
            >
              <XCircle size={24} />
            </button>
            
            <div className="mb-6 pr-10">
              <button 
                onClick={() => setSelectedOrder(null)}
                className="flex items-center gap-2 text-[var(--color-neon-green)] text-sm font-bold uppercase tracking-wider mb-4 hover:opacity-80 transition-opacity"
              >
                <ArrowLeft size={16} /> Back to Orders
              </button>
              <h2 className="text-2xl font-black uppercase tracking-tight text-white">Manage Order #{selectedOrder.id.slice(-6).toUpperCase()}</h2>
              <p className="text-gray-400 text-sm">
                {selectedOrder.createdAt ? new Date(selectedOrder.createdAt.toDate()).toLocaleString() : 'Just now'}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              {/* Customer Details */}
              <div className="bg-[#222] p-4 rounded-xl border border-[#333]">
                <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-4 flex items-center gap-2">
                  <User size={16} /> Customer Details
                </h3>
                <div className="space-y-3 text-sm text-white">
                  <div className="flex items-start gap-3">
                    <User size={16} className="text-gray-400 mt-0.5 shrink-0" />
                    <div>
                      <p className="text-gray-500 text-xs">Name</p>
                      <p className="font-bold">{selectedOrder.customerName || selectedOrder.customerDetails?.name || 'Guest'}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Phone size={16} className="text-gray-400 mt-0.5 shrink-0" />
                    <div>
                      <p className="text-gray-500 text-xs">Mobile</p>
                      <p className="font-bold">{selectedOrder.customerPhone || selectedOrder.customerDetails?.mobile || 'N/A'}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <MapPin size={16} className="text-gray-400 mt-0.5 shrink-0" />
                    <div>
                      <p className="text-gray-500 text-xs">Address</p>
                      <p className="font-medium">{selectedOrder.customerAddress || selectedOrder.customerDetails?.address || 'N/A'}</p>
                    </div>
                  </div>
                  {selectedOrder.estimatedTime && (
                    <div className="flex items-start gap-3">
                      <Clock size={16} className="text-gray-400 mt-0.5 shrink-0" />
                      <div>
                        <p className="text-gray-500 text-xs">Requested Delivery Time</p>
                        <p className="font-bold text-[var(--color-neon-green)]">{selectedOrder.estimatedTime}</p>
                      </div>
                    </div>
                  )}
                  {selectedOrder.customerRemark && (
                    <div className="flex items-start gap-3">
                      <MessageCircle size={16} className="text-gray-400 mt-0.5 shrink-0" />
                      <div>
                        <p className="text-gray-500 text-xs">Customer Remark</p>
                        <p className="font-medium text-white">{selectedOrder.customerRemark}</p>
                      </div>
                    </div>
                  )}
                  {selectedOrder.orderType && (
                    <div className="flex items-start gap-3">
                      <Package size={16} className="text-gray-400 mt-0.5 shrink-0" />
                      <div>
                        <p className="text-gray-500 text-xs">Order Type</p>
                        <p className="font-bold text-white">{selectedOrder.orderType}</p>
                      </div>
                    </div>
                  )}
                  {selectedOrder.customerPreferences && (
                    <div className="flex items-start gap-3">
                      <Utensils size={16} className="text-gray-400 mt-0.5 shrink-0" />
                      <div>
                        <p className="text-gray-500 text-xs">Preferences / Allergies</p>
                        <p className="font-medium text-red-400">{selectedOrder.customerPreferences}</p>
                      </div>
                    </div>
                  )}
                  {(selectedOrder.location || selectedOrder.customerDetails?.location) && (
                    <div className="flex items-start gap-3 pt-2 border-t border-[#333]">
                      <MapPin size={16} className="text-[var(--color-neon-green)] mt-0.5 shrink-0" />
                      <div>
                        <p className="text-[var(--color-neon-green)] text-xs font-bold">Live Location Available</p>
                        <a 
                          href={`https://www.google.com/maps?q=${selectedOrder.location?.lat || selectedOrder.customerDetails?.location?.lat},${selectedOrder.location?.lng || selectedOrder.customerDetails?.location?.lng}`} 
                          target="_blank" 
                          rel="noreferrer"
                          className="text-blue-400 hover:underline text-xs"
                        >
                          View on Google Maps
                        </a>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Order Controls */}
              <div className="space-y-4">
                <div className="bg-[#222] p-4 rounded-xl border border-[#333]">
                  <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-4 flex items-center gap-2">
                    <Clock size={16} /> Delivery Time
                  </h3>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      value={deliveryTimeInput}
                      onChange={(e) => setDeliveryTimeInput(e.target.value)}
                      placeholder="e.g. 30 mins, 8:00 PM"
                      className="flex-1 bg-[#111] border border-[#444] rounded-lg px-3 py-2 text-white outline-none focus:border-[var(--color-neon-green)] text-sm"
                    />
                    <button 
                      onClick={() => updateDeliveryTime(selectedOrder.id)}
                      className="bg-[var(--color-neon-green)] text-black px-3 py-2 rounded-lg font-bold hover:opacity-90 transition-opacity"
                    >
                      <Save size={16} />
                    </button>
                  </div>
                  <div className="flex gap-2 mt-2">
                    <button onClick={() => setDeliveryTimeInput('15 mins')} className="text-xs bg-[#333] hover:bg-[#444] px-2 py-1 rounded text-gray-300">15m</button>
                    <button onClick={() => setDeliveryTimeInput('30 mins')} className="text-xs bg-[#333] hover:bg-[#444] px-2 py-1 rounded text-gray-300">30m</button>
                    <button onClick={() => setDeliveryTimeInput('45 mins')} className="text-xs bg-[#333] hover:bg-[#444] px-2 py-1 rounded text-gray-300">45m</button>
                  </div>
                </div>

                <div className="bg-[#222] p-4 rounded-xl border border-[#333]">
                  <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-4 flex items-center gap-2">
                    <MessageCircle size={16} /> Customer Remark
                  </h3>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      value={remarkInput}
                      onChange={(e) => setRemarkInput(e.target.value)}
                      placeholder="Message for customer..."
                      className="flex-1 bg-[#111] border border-[#444] rounded-lg px-3 py-2 text-white outline-none focus:border-[var(--color-neon-green)] text-sm"
                    />
                    <button 
                      onClick={() => updateRemark(selectedOrder.id)}
                      className="bg-blue-500 text-white px-3 py-2 rounded-lg font-bold hover:bg-blue-600 transition-colors"
                    >
                      <Save size={16} />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Order Items */}
            <div className="bg-[#222] p-4 rounded-xl border border-[#333] mb-6">
              <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-4 border-b border-[#333] pb-2">Ordered Items</h3>
              <div className="space-y-3">
                {selectedOrder.items.map((item: any, idx: number) => (
                  <div key={idx} className="flex justify-between items-center text-white">
                    <div className="flex items-center gap-3">
                      <span className="bg-[#333] text-gray-300 text-xs font-bold px-2 py-1 rounded">{item.quantity}x</span>
                      <span className="font-medium">{item.name}</span>
                    </div>
                    <span className="font-bold">₹{item.price * item.quantity}</span>
                  </div>
                ))}
              </div>
              <div className="border-t border-[#333] mt-4 pt-4 flex justify-between items-center">
                <span className="text-gray-400 font-bold uppercase tracking-wider">Total Amount</span>
                <span className="text-2xl font-black text-[var(--color-neon-green)]">₹{selectedOrder.totalAmount}</span>
              </div>
            </div>

            {/* Status History */}
            <div className="bg-[#222] p-4 rounded-xl border border-[#333] mb-6">
              <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-4 flex items-center gap-2">
                <Clock size={16} /> Status History
              </h3>
              <div className="space-y-3">
                {STATUSES.map((status, idx) => {
                  const timestamp = selectedOrder.statusTimestamps?.[status];
                  if (!timestamp) return null;
                  const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
                  return (
                    <div key={idx} className="flex justify-between items-center text-sm font-bold border-b border-[#333] pb-2 last:border-0 last:pb-0">
                      <span className="text-white capitalize">{status.replace('_', ' ')}</span>
                      <span className="text-gray-400 text-xs font-mono">
                        {date.toLocaleString()}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-end">
              <button 
                onClick={() => setSelectedOrder(null)} 
                className="w-full sm:w-auto bg-[#333] hover:bg-[#444] text-white font-bold py-3 px-8 rounded-xl transition-colors flex items-center justify-center gap-2"
              >
                <XCircle size={20} /> Close / Back to Orders
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
};

