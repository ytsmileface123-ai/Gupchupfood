import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { doc, onSnapshot, collection, query, orderBy, limit } from 'firebase/firestore';
import { motion, AnimatePresence } from 'framer-motion';
import { Camera, Sparkles, Clock, Calendar, CheckCircle, FileArchive, X, Play } from 'lucide-react';
import InfluencerVideo from './InfluencerVideo';

const PhotoStudioDashboard: React.FC = () => {
  const [settings, setSettings] = useState<any>(null);
  const [photos, setPhotos] = useState<any[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showStory, setShowStory] = useState(false);

  useEffect(() => {
    const unsubscribeSettings = onSnapshot(doc(db, 'photoStudioSettings', 'global'), (snapshot) => {
      if (snapshot.exists()) {
        console.log("PhotoStudioDashboard: settings =", snapshot.data());
        setSettings(snapshot.data());
      }
    });

    const qPhotos = query(collection(db, 'customerPhotos'), orderBy('timestamp', 'desc'), limit(20));
    const unsubscribePhotos = onSnapshot(qPhotos, (snapshot) => {
      setPhotos(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    return () => {
      unsubscribeSettings();
      unsubscribePhotos();
    };
  }, []);

  useEffect(() => {
    if (!settings?.isEnabled || photos.length === 0) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % photos.length);
    }, (settings.rotationSpeed || 5) * 1000);

    return () => clearInterval(interval);
  }, [settings?.isEnabled, settings?.rotationSpeed, photos.length]);

  const isStudioOpenToday = () => {
    if (!settings?.openDays || settings.openDays.length === 0) return true;
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const today = days[new Date().getDay()];
    return settings.openDays.includes(today);
  };

  if (!settings || !settings.isEnabled) return null;

  const currentPhoto = photos[currentIndex];

  const getContainerWidth = () => {
    switch (settings.sectionWidth) {
      case 'small': return 'max-w-xl';
      case 'medium': return 'max-w-3xl';
      case 'large': return 'max-w-5xl';
      case 'full': return 'max-w-full';
      default: return 'max-w-4xl';
    }
  };

  const showGallery = settings.isGalleryEnabled !== false && photos.length > 0;
  const showCameraman = settings.isCameramanProfileEnabled !== false;
  const showBooking = settings.isBookingEnabled !== false;

  return (
    <div className={`w-full ${getContainerWidth()} mx-auto px-4 py-8`}>
      {/* Unified Premium Studio Dashboard */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="relative overflow-hidden rounded-[2.5rem] md:rounded-[3.5rem] bg-[#050505] border border-white/10 shadow-[0_30px_80px_rgba(0,0,0,0.8)] group"
      >
        {/* Luxury Animated Border Glow */}
        <div className="absolute -inset-[1px] bg-gradient-to-r from-pink-500/10 via-purple-500/10 to-pink-500/10 rounded-[2.5rem] md:rounded-[3.5rem] blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
        
        {/* Background Decorative Elements */}
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-pink-600/5 rounded-full blur-[120px] -mr-40 -mt-40 animate-pulse" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-purple-600/5 rounded-full blur-[120px] -ml-40 -mb-40 animate-pulse" style={{ animationDelay: '2s' }} />
        
        <div className="relative z-10 bg-[#050505]/60 backdrop-blur-2xl">
          {/* Top Section: Hero & Photo Display */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-0 border-b border-white/5">
            {/* Left: Hero Info */}
            <div className={`${showGallery ? 'lg:col-span-7' : 'lg:col-span-12'} p-8 md:p-12 space-y-8`}>
              <motion.div 
                initial={{ x: -10, opacity: 0 }}
                whileInView={{ x: 0, opacity: 1 }}
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/[0.03] border border-white/10 text-[9px] font-black text-pink-400 uppercase tracking-[0.4em]"
              >
                <div className="w-1 h-1 rounded-full bg-pink-500 animate-ping" />
                <Camera size={12} /> The Luxury Studio Suite
              </motion.div>

              <div className="space-y-6">
                <h2 className="text-5xl md:text-7xl font-black tracking-tighter leading-[0.85] uppercase italic">
                  Get Your <br />
                  <span className="bg-clip-text text-transparent bg-gradient-to-r from-pink-500 via-white to-purple-500 bg-[length:200%_auto] animate-gradient">
                    Photo Clicked
                  </span>
                </h2>
                <p className="text-gray-400 text-sm md:text-lg max-w-md font-medium leading-relaxed opacity-70">
                  Experience professional photography in a luxury setting. Every click is a masterpiece, every moment is eternal.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 md:gap-6">
                <div className="relative p-6 rounded-[2rem] bg-white/[0.02] border border-white/5 backdrop-blur-2xl group/item hover:bg-white/[0.04] transition-all duration-500">
                  <p className="text-[9px] font-black text-gray-500 uppercase tracking-[0.2em] mb-2">Premium Rate</p>
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-3xl font-black text-white tracking-tighter">₹{settings.pricePerPhoto}</span>
                    <span className="text-[9px] text-gray-500 uppercase font-black tracking-widest">/ Shot</span>
                  </div>
                  <div className="absolute top-3 right-3 text-pink-500/20 group-hover/item:text-pink-500/40 transition-colors">
                    <Sparkles size={20} />
                  </div>
                </div>
                <div className="p-6 rounded-[2rem] bg-white/[0.02] border border-white/5 backdrop-blur-2xl">
                  <p className="text-[9px] font-black text-gray-500 uppercase tracking-[0.2em] mb-2">Studio Status</p>
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${isStudioOpenToday() ? 'bg-[var(--color-neon-green)] shadow-[0_0_15px_var(--color-neon-green)]' : 'bg-red-500 shadow-[0_0_15px_red]'}`} />
                    <p className={`text-base font-black uppercase tracking-[0.1em] ${isStudioOpenToday() ? 'text-[var(--color-neon-green)]' : 'text-red-500'}`}>
                      {isStudioOpenToday() ? 'Available' : 'Offline'}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-3">
                {['Ultra HD', 'Instant Delivery', 'Pro Studio', 'Luxury Gear'].map((feature, i) => (
                  <div key={`feature-${feature}-${i}`} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/[0.01] border border-white/5 text-[9px] font-black text-gray-400 uppercase tracking-[0.15em] hover:text-white hover:border-white/20 transition-all cursor-default">
                    <div className="w-1 h-1 rounded-full bg-pink-500" />
                    {feature}
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Photo Showcase */}
            {showGallery && (
              <div className="lg:col-span-5 relative min-h-[400px] lg:border-l border-white/5 overflow-hidden group/photo bg-black">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentIndex}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="absolute inset-0 flex items-center justify-center"
                  >
                    {/* Blurred Background to fill space without cropping */}
                    <img 
                      src={currentPhoto.imageUrl} 
                      alt="" 
                      className="absolute inset-0 w-full h-full object-cover blur-2xl opacity-30 scale-110"
                      referrerPolicy="no-referrer"
                    />
                    
                    {/* Main Image - Object Contain to show full size without cutting */}
                    <img 
                      src={currentPhoto.imageUrl} 
                      alt="Studio Capture" 
                      className="relative z-10 max-w-full max-h-full object-contain grayscale-[0.1] group-hover/photo:grayscale-0 transition-all duration-1000 shadow-[0_0_50px_rgba(0,0,0,0.5)]"
                      referrerPolicy="no-referrer"
                    />
                    
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent z-20" />
                    
                    <div className="absolute bottom-8 left-8 right-8 z-30">
                      <motion.div 
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.4 }}
                        className="space-y-1"
                      >
                        <p className="text-white font-black text-3xl tracking-tighter uppercase italic drop-shadow-2xl">
                          {currentPhoto.customerName || 'Guest'}
                        </p>
                        <div className="flex items-center gap-2 text-[9px] font-black text-pink-400 uppercase tracking-[0.3em]">
                          <div className="w-6 h-[1px] bg-pink-500" />
                          Studio Session
                        </div>
                      </motion.div>
                    </div>
                  </motion.div>
                </AnimatePresence>
                
                {/* Floating Badge */}
                <div className="absolute top-8 right-8 z-20">
                  <motion.div 
                    animate={{ y: [0, -3, 0] }}
                    transition={{ repeat: Infinity, duration: 3 }}
                    className="bg-white text-black px-6 py-2 rounded-full font-black text-[9px] shadow-[0_15px_40px_rgba(255,255,255,0.2)] border border-white/20 uppercase tracking-[0.3em] -rotate-2"
                  >
                    Live Now
                  </motion.div>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Section: Cameraman & Booking Integrated */}
          {(showCameraman || showBooking) && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
              {/* Cameraman Profile */}
              {showCameraman && (
                <div className={`${showBooking ? 'lg:col-span-7' : 'lg:col-span-12'} p-8 md:p-12 bg-white/[0.01] flex flex-col md:flex-row gap-8 items-center ${showBooking ? 'lg:border-r' : ''} border-white/5`}>
                  <div className="relative shrink-0">
                    <div className="w-32 h-32 md:w-40 md:h-40 rounded-[2.5rem] overflow-hidden border-4 border-white/[0.03] shadow-[0_20px_40px_rgba(0,0,0,0.5)] group/avatar">
                      <img 
                        src={settings.cameramanLogoUrl || "https://picsum.photos/seed/photographer/400/400"} 
                        alt="Cameraman" 
                        className="w-full h-full object-cover group-hover/avatar:scale-110 transition-transform duration-1000"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <motion.div 
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 10, ease: "linear" }}
                      className="absolute -bottom-2 -right-2 bg-gradient-to-br from-pink-500 to-purple-600 text-white p-3 rounded-[1.2rem] shadow-2xl border border-white/20"
                    >
                      <Sparkles size={18} />
                    </motion.div>
                  </div>
                  
                  <div className="flex-1 text-center md:text-left space-y-4">
                    <div>
                      <p className="text-[9px] font-black text-pink-500 uppercase tracking-[0.4em] mb-2">Artisan Photographer</p>
                      <h3 className="text-4xl md:text-5xl font-black text-white tracking-tighter uppercase italic leading-none">
                        {settings.cameramanName || 'Hasan Reza'}
                      </h3>
                    </div>
                    
                    <p className="text-gray-400 text-base italic font-medium leading-relaxed max-w-md opacity-60">
                      "{settings.cameramanRemark || 'Transforming every click into a timeless masterpiece.'}"
                    </p>
                    
                    <div className="flex flex-wrap justify-center md:justify-start gap-6">
                      <div className="flex items-center gap-2 text-[10px] font-black text-gray-300 uppercase tracking-[0.15em]">
                        <Clock size={16} className="text-pink-500" />
                        {settings.cameramanExperience || '5+ Years'}
                      </div>
                      <div className="flex items-center gap-2 text-[10px] font-black text-gray-300 uppercase tracking-[0.15em]">
                        <Calendar size={16} className="text-pink-500" />
                        Available Daily
                      </div>
                    </div>

                    <div className="flex flex-wrap justify-center md:justify-start gap-4 pt-2">
                      {settings.cameramanVideoUrl && (
                        <button 
                          onClick={() => setShowStory(true)}
                          className="px-6 py-3 rounded-xl bg-gradient-to-r from-pink-600 to-pink-500 text-white text-[10px] font-black uppercase tracking-[0.2em] hover:shadow-[0_8px_20px_rgba(236,72,153,0.3)] transition-all active:scale-95"
                        >
                          Watch Story
                        </button>
                      )}
                      {settings.cameramanZipUrl && (
                        <a 
                          href={settings.cameramanZipUrl} 
                          download
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="px-6 py-3 rounded-xl bg-white/[0.03] border border-white/10 text-white text-[10px] font-black uppercase tracking-[0.2em] hover:bg-white/[0.06] transition-all active:scale-95"
                        >
                          Portfolio
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Booking & Rental */}
              {showBooking && (
                <div className={`${showCameraman ? 'lg:col-span-5' : 'lg:col-span-12'} p-8 md:p-12 bg-gradient-to-br from-pink-600/[0.03] to-purple-600/[0.03] flex flex-col justify-center space-y-8`}>
                  <div className="space-y-4">
                    <h4 className="text-3xl font-black uppercase tracking-tighter text-white italic">Book Events</h4>
                    <p className="text-gray-400 text-sm font-medium leading-relaxed opacity-70">
                      {settings.bookingDetails || 'Weddings, Birthdays, and Corporate Functions. Professional coverage guaranteed.'}
                    </p>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-white/[0.02] border border-white/5 rounded-[2rem] p-6 backdrop-blur-3xl relative overflow-hidden group/contact">
                      <div className="absolute inset-0 bg-gradient-to-br from-pink-500/5 to-transparent opacity-0 group-hover/contact:opacity-100 transition-opacity" />
                      <p className="text-[9px] font-black text-white/30 uppercase tracking-[0.3em] mb-2 text-center relative z-10">Private Concierge</p>
                      <p className="text-3xl font-black text-white tracking-[0.15em] text-center relative z-10">{settings.cameramanContact || '7076455556'}</p>
                    </div>
                    <a 
                      href={`tel:${settings.cameramanContact}`}
                      className="group relative block w-full py-5 rounded-[2rem] bg-white text-black font-black text-center text-[10px] uppercase tracking-[0.3em] overflow-hidden transition-all hover:scale-[1.02] active:scale-95 shadow-[0_20px_40px_rgba(255,255,255,0.05)]"
                    >
                      <span className="relative z-10">Call Now</span>
                      <div className="absolute inset-0 bg-gradient-to-r from-pink-100 via-white to-pink-100 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </a>
                  </div>

                  {settings.isRentalEnabled && (
                    <div className="pt-6 border-t border-white/5">
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-[9px] font-black text-purple-400 uppercase tracking-[0.3em]">Gear Rental</p>
                        <Camera size={16} className="text-purple-400/50" />
                      </div>
                      <p className="text-gray-500 text-[10px] font-medium leading-relaxed italic">
                        {settings.rentalDetails || 'Pro cameras available for rent.'}
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </motion.div>

      {/* Story Modal */}
      <AnimatePresence>
        {showStory && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-2xl"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-sm aspect-[9/16] bg-black rounded-3xl overflow-hidden shadow-2xl"
            >
              <button 
                onClick={() => setShowStory(false)}
                className="absolute top-8 right-8 z-50 p-3 bg-black/50 text-white rounded-full hover:bg-black/80 transition-colors border border-white/10 backdrop-blur-md"
              >
                <X size={28} />
              </button>

              <div className="h-full w-full flex items-center justify-center bg-[#050505]">
                <InfluencerVideo 
                  videoUrl={settings.cameramanVideoUrl}
                  influencerName={settings.cameramanName}
                  influencerImage={settings.cameramanLogoUrl}
                  caption={settings.cameramanRemark}
                  mediaType={settings.cameramanMediaType || 'video'}
                  noModal={true}
                  isModal={true}
                  showMuteButton={true}
                />
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-12 bg-gradient-to-t from-black via-black/80 to-transparent">
                <p className="text-pink-500 text-[10px] font-black uppercase tracking-[0.4em] mb-2">Exclusive Story</p>
                <h4 className="text-white text-4xl font-black uppercase tracking-tighter italic">
                  {settings.cameramanName || 'Hasan Reza'}
                </h4>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default PhotoStudioDashboard;
