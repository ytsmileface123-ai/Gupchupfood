import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, addDoc, updateDoc, deleteDoc, doc, onSnapshot, query, orderBy, setDoc } from 'firebase/firestore';
import { Bell, Trash2, Plus, Check, X, Image as ImageIcon, Video, Music, Link as LinkIcon, Save, Edit2, Play, Pause, Settings, Sparkles, Clock, Type } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';
import { motion, AnimatePresence } from 'framer-motion';

const SettingInput = ({ value, onChange, type = "text", className, placeholder }: any) => {
  const [localValue, setLocalValue] = useState(value);

  useEffect(() => {
    setLocalValue(value);
  }, [value]);

  if (type === 'textarea') {
    return (
      <textarea
        value={localValue}
        onChange={(e) => setLocalValue(e.target.value)}
        onBlur={() => onChange(localValue)}
        className={className}
        placeholder={placeholder}
      />
    );
  }

  return (
    <input
      type={type}
      value={localValue}
      onChange={(e) => setLocalValue(e.target.value)}
      onBlur={() => onChange(type === 'number' ? Number(localValue) : localValue)}
      className={className}
      placeholder={placeholder}
    />
  );
};

const MediaUploadInput = ({ 
  label, 
  value, 
  onChange, 
  placeholder = "https://...",
  accept = "video/mp4,image/*,image/gif",
  buttonText = "Upload Media",
  note = ""
}: { 
  label: string, 
  value: string, 
  onChange: (val: string) => void, 
  placeholder?: string,
  accept?: string,
  buttonText?: string,
  note?: string
}) => (
  <div className="space-y-2">
    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">{label}</label>
    <div className="flex flex-col gap-2">
      <input 
        type="url" 
        value={value || ''} 
        onChange={e => onChange(e.target.value)} 
        className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-2 text-sm text-white focus:border-[var(--color-neon-green)] outline-none transition-all" 
        placeholder={placeholder} 
      />
      <div className="flex items-center gap-3">
        <label className="bg-white/5 hover:bg-white/10 text-white text-[9px] font-black py-1.5 px-3 rounded-md cursor-pointer transition-all border border-white/10 uppercase tracking-wider">
          {buttonText}
          <input 
            type="file" 
            accept={accept} 
            className="hidden" 
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                if (file.size > 1024 * 1024) {
                  alert("File is too large (max 1MB). Use URL for larger files.");
                  return;
                }
                const reader = new FileReader();
                reader.onload = (event) => {
                  onChange(event.target?.result as string);
                };
                reader.readAsDataURL(file);
              }
            }}
          />
        </label>
        {note && <span className="text-[8px] text-gray-500 italic">{note}</span>}
      </div>
    </div>
  </div>
);

export default function NotificationManagement() {
  const [notifications, setNotifications] = useState<any[]>([]);
  const [sectionSettings, setSectionSettings] = useState<any>({
    title: 'Exclusive',
    subtitle: 'Notices',
    rotationSpeed: 10,
    isEnabled: true
  });
  const [isAdding, setIsAdding] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({ 
    title: '', 
    description: '', 
    type: 'offer', 
    mediaUrl: '', 
    mediaType: 'image',
    musicUrl: '',
    link: '',
    isActive: true,
    order: 0
  });

  useEffect(() => {
    // Fetch global section settings
    const unsubscribeSettings = onSnapshot(doc(db, 'notificationSettings', 'global'), async (snapshot) => {
      if (snapshot.exists()) {
        setSectionSettings(snapshot.data());
      } else {
        try {
          await setDoc(doc(db, 'notificationSettings', 'global'), {
            title: 'Exclusive',
            subtitle: 'Notices',
            rotationSpeed: 10,
            isEnabled: true
          });
        } catch (error) {
          console.error("Initial notification settings creation failed:", error);
        }
      }
    });

    const q = query(collection(db, 'notifications'), orderBy('order', 'asc'));
    const unsubscribeNotifs = onSnapshot(q, (snapshot) => {
      setNotifications(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'notifications');
    });

    return () => {
      unsubscribeSettings();
      unsubscribeNotifs();
    };
  }, []);

  const handleUpdateSettings = async (updates: any) => {
    try {
      await updateDoc(doc(db, 'notificationSettings', 'global'), updates);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'notificationSettings');
    }
  };

  const handleSubmit = async () => {
    if (!form.title || !form.description) {
      alert("Please fill in title and description");
      return;
    }

    try {
      const notificationData = {
        title: form.title,
        description: form.description,
        type: form.type,
        mediaUrl: form.mediaUrl,
        mediaType: form.mediaType,
        musicUrl: form.musicUrl,
        link: form.link,
        isActive: form.isActive,
        order: form.order,
        updatedAt: new Date().toISOString()
      };

      if (editingId) {
        await updateDoc(doc(db, 'notifications', editingId), notificationData);
        setEditingId(null);
      } else {
        await addDoc(collection(db, 'notifications'), {
          ...notificationData,
          createdAt: new Date().toISOString()
        });
        setIsAdding(false);
      }
      resetForm();
      alert("Notice saved successfully!");
    } catch (error) {
      handleFirestoreError(error, editingId ? OperationType.UPDATE : OperationType.CREATE, 'notifications');
    }
  };

  const resetForm = () => {
    setForm({ 
      title: '', 
      description: '', 
      type: 'offer', 
      mediaUrl: '', 
      mediaType: 'image',
      musicUrl: '',
      link: '',
      isActive: true,
      order: 0
    });
  };

  const toggleActive = async (id: string, currentStatus: boolean) => {
    try {
      await updateDoc(doc(db, 'notifications', id), { isActive: !currentStatus });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'notifications');
    }
  };

  const deleteNotification = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this notification?")) return;
    try {
      await deleteDoc(doc(db, 'notifications', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'notifications');
    }
  };

  const startEdit = (notification: any) => {
    setForm({
      title: notification.title,
      description: notification.description,
      type: notification.type || 'offer',
      mediaUrl: notification.mediaUrl || notification.imageUrl || '',
      mediaType: notification.mediaType || 'image',
      musicUrl: notification.musicUrl || '',
      link: notification.link || '',
      isActive: notification.isActive ?? true,
      order: notification.order || 0
    });
    setEditingId(notification.id);
    setIsAdding(true);
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black text-white uppercase tracking-tighter flex items-center gap-3">
            <div className="relative">
              <div className="absolute inset-0 bg-pink-500 rounded-full blur-md animate-pulse opacity-50" />
              <Bell className="text-pink-500 relative z-10" size={32} />
            </div>
            Notification Center
          </h2>
          <p className="text-[10px] text-gray-500 uppercase tracking-[0.3em] mt-1 font-black">Luxury Management Suite</p>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setShowSettings(!showSettings)}
            className={`p-3 rounded-xl border transition-all ${showSettings ? 'bg-pink-500 border-pink-400 text-white' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'}`}
          >
            <Settings size={20} />
          </button>
          {!isAdding && (
            <button 
              onClick={() => { resetForm(); setIsAdding(true); }}
              className="flex items-center gap-2 bg-gradient-to-r from-pink-500 to-purple-500 text-white text-[10px] font-black px-6 py-3 rounded-xl uppercase tracking-widest hover:scale-105 transition-all shadow-[0_10px_30px_rgba(236,72,153,0.3)]"
            >
              <Plus size={16} /> Create Notice
            </button>
          )}
        </div>
      </div>

      <AnimatePresence>
        {showSettings && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="bg-[#111] border border-white/10 rounded-2xl p-8 space-y-8 mb-8 relative">
              <div className="absolute top-0 right-0 p-8 opacity-5">
                <Settings size={120} />
              </div>
              
              <div className="flex items-center gap-3 mb-2">
                <Sparkles className="text-pink-500" size={20} />
                <h3 className="text-sm font-black text-white uppercase tracking-widest">Global Section Settings</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-[10px] font-black text-gray-500 uppercase tracking-widest">
                    <Type size={14} /> Main Title
                  </div>
                  <SettingInput 
                    value={sectionSettings.title}
                    onChange={(val: string) => handleUpdateSettings({ title: val })}
                    className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white focus:border-pink-500 outline-none transition-all"
                    placeholder="e.g. Exclusive"
                  />
                </div>
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-[10px] font-black text-gray-500 uppercase tracking-widest">
                    <Type size={14} /> Subtitle
                  </div>
                  <SettingInput 
                    value={sectionSettings.subtitle}
                    onChange={(val: string) => handleUpdateSettings({ subtitle: val })}
                    className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white focus:border-pink-500 outline-none transition-all"
                    placeholder="e.g. Notices"
                  />
                </div>
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-[10px] font-black text-gray-500 uppercase tracking-widest">
                    <Clock size={14} /> Rotation Speed (Seconds)
                  </div>
                  <SettingInput 
                    type="number"
                    value={sectionSettings.rotationSpeed}
                    onChange={(val: number) => handleUpdateSettings({ rotationSpeed: val || 10 })}
                    className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white focus:border-pink-500 outline-none transition-all"
                  />
                </div>
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-[10px] font-black text-gray-500 uppercase tracking-widest">
                    <Bell size={14} /> Section Status
                  </div>
                  <button 
                    onClick={() => handleUpdateSettings({ isEnabled: !sectionSettings.isEnabled })}
                    className={`w-full flex items-center justify-center gap-3 px-4 py-3 rounded-xl border transition-all font-black text-[10px] uppercase tracking-widest ${sectionSettings.isEnabled ? 'bg-green-500/10 border-green-500/50 text-green-500' : 'bg-red-500/10 border-red-500/50 text-red-500'}`}
                  >
                    {sectionSettings.isEnabled ? <Check size={16} /> : <X size={16} />}
                    {sectionSettings.isEnabled ? 'Section Enabled' : 'Section Disabled'}
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {isAdding && (
        <div className="bg-[#111] border border-white/10 rounded-3xl p-8 space-y-8 animate-in fade-in slide-in-from-top-4 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-pink-500" />
          
          <div className="flex items-center justify-between border-b border-white/5 pb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-pink-500/10 rounded-lg">
                <Edit2 className="text-pink-500" size={20} />
              </div>
              <h3 className="text-lg font-black text-white uppercase tracking-tighter italic">
                {editingId ? 'Edit Exclusive Notice' : 'Compose New Notice'}
              </h3>
            </div>
            <button onClick={() => { setIsAdding(false); setEditingId(null); }} className="p-2 hover:bg-white/5 rounded-full text-gray-500 hover:text-white transition-all">
              <X size={24} />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Title</label>
                <input 
                  value={form.title} 
                  onChange={e => setForm({...form, title: e.target.value})} 
                  className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                  placeholder="e.g., Weekend Special Offer!"
                />
              </div>
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Description</label>
                <textarea 
                  value={form.description} 
                  onChange={e => setForm({...form, description: e.target.value})} 
                  className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none h-24 resize-none" 
                  placeholder="Details about the offer or event..."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Type</label>
                  <select 
                    value={form.type} 
                    onChange={e => setForm({...form, type: e.target.value})} 
                    className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                  >
                    <option value="offer">Offer</option>
                    <option value="event">Event</option>
                    <option value="combo">Combo</option>
                    <option value="discount">Discount</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Media Type</label>
                  <select 
                    value={form.mediaType} 
                    onChange={e => setForm({...form, mediaType: e.target.value})} 
                    className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none"
                  >
                    <option value="image">Image</option>
                    <option value="video">Video (.mp4)</option>
                    <option value="gif">GIF</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <MediaUploadInput 
                label="Media URL (Image/Video/GIF)" 
                value={form.mediaUrl} 
                onChange={val => setForm({...form, mediaUrl: val})} 
                accept={form.mediaType === 'video' ? 'video/mp4' : 'image/*,image/gif'}
                note={form.mediaType === 'video' ? "Upload .mp4 for video notifications" : "Upload Image or GIF"}
              />
              
              {/* Media Preview in Admin */}
              {form.mediaUrl && (
                <div className="mt-2 rounded-xl overflow-hidden border border-white/10 aspect-video bg-black relative">
                  {form.mediaType === 'video' ? (
                    <video src={form.mediaUrl} className="w-full h-full object-contain" muted loop autoPlay />
                  ) : (
                    <img src={form.mediaUrl} alt="Preview" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                  )}
                  <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[8px] font-black text-white uppercase tracking-widest border border-white/10">
                    Preview
                  </div>
                </div>
              )}

              <MediaUploadInput 
                label="Background Music (Optional)" 
                value={form.musicUrl} 
                onChange={val => setForm({...form, musicUrl: val})} 
                accept="audio/*"
                buttonText="Upload Audio"
              />
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Action Link (Optional)</label>
                <input 
                  value={form.link} 
                  onChange={e => setForm({...form, link: e.target.value})} 
                  className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                  placeholder="https://..."
                />
              </div>
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Display Order</label>
                <input 
                  type="number"
                  value={form.order} 
                  onChange={e => setForm({...form, order: parseInt(e.target.value) || 0})} 
                  className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-2 text-white focus:border-[var(--color-neon-green)] outline-none" 
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-4 pt-6 border-t border-white/5">
            <button 
              onClick={() => { setIsAdding(false); setEditingId(null); }}
              className="px-8 py-3 text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] hover:text-white transition-colors"
            >
              Discard Changes
            </button>
            <button 
              onClick={handleSubmit}
              className="flex items-center gap-3 bg-white text-black text-[10px] font-black px-10 py-4 rounded-xl uppercase tracking-[0.2em] hover:scale-105 transition-all shadow-2xl"
            >
              <Save size={16} /> {editingId ? 'Update' : 'Publish'} Notice
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {notifications.map(notification => (
          <div key={notification.id} className="group relative bg-[#111] border border-white/10 rounded-3xl overflow-hidden hover:border-pink-500/30 transition-all duration-700 shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
            {/* Preview Area */}
            <div className="aspect-[16/10] bg-black relative overflow-hidden">
              {notification.mediaType === 'video' ? (
                <video 
                  src={notification.mediaUrl || undefined} 
                  className="w-full h-full object-contain opacity-70 group-hover:opacity-100 transition-all duration-1000" 
                  muted 
                  loop 
                  playsInline 
                  autoPlay 
                />
              ) : (
                <img 
                  src={notification.mediaUrl || notification.imageUrl || "https://picsum.photos/seed/notif/400/225"} 
                  alt={notification.title} 
                  className="w-full h-full object-contain opacity-70 group-hover:opacity-100 transition-all duration-1000" 
                  referrerPolicy="no-referrer"
                />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent"></div>
              
              {/* Badges */}
              <div className="absolute top-4 left-4 flex flex-col gap-2">
                <span className="bg-pink-500 text-[8px] font-black text-white px-3 py-1 rounded-full uppercase tracking-widest shadow-xl">
                  {notification.type}
                </span>
                {notification.musicUrl && (
                  <span className="bg-white/10 backdrop-blur-md text-[8px] font-black text-white px-3 py-1 rounded-full uppercase tracking-widest border border-white/10 flex items-center gap-1.5">
                    <Music size={10} /> Audio
                  </span>
                )}
              </div>

              <div className="absolute top-4 right-4">
                <button 
                  onClick={() => toggleActive(notification.id, notification.isActive)}
                  className={`p-2 rounded-xl backdrop-blur-md border border-white/10 transition-all ${notification.isActive ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}
                >
                  {notification.isActive ? <Check size={16} /> : <X size={16} />}
                </button>
              </div>
            </div>

            <div className="p-8">
              <div className="flex items-center gap-2 text-pink-500 font-black text-[8px] uppercase tracking-[0.3em] mb-3">
                <div className="w-4 h-[1px] bg-pink-500" />
                Notice #{notification.order}
              </div>
              <h4 className="text-xl font-black text-white uppercase tracking-tighter mb-2 line-clamp-1 italic">{notification.title}</h4>
              <p className="text-xs text-gray-500 line-clamp-2 mb-6 h-8 leading-relaxed font-medium">{notification.description}</p>
              
              <div className="flex items-center justify-between pt-6 border-t border-white/5">
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => startEdit(notification)}
                    className="p-3 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-pink-500 rounded-xl transition-all"
                  >
                    <Edit2 size={16} />
                  </button>
                  <button 
                    onClick={() => deleteNotification(notification.id)}
                    className="p-3 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-red-500 rounded-xl transition-all"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
                {notification.link && (
                  <div className="p-3 bg-white/5 text-gray-500 rounded-xl">
                    <LinkIcon size={16} />
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}

        {notifications.length === 0 && !isAdding && (
          <div className="col-span-full py-32 text-center border-2 border-dashed border-white/5 rounded-[3rem] bg-white/[0.01]">
            <div className="relative inline-block mb-6">
              <div className="absolute inset-0 bg-pink-500 rounded-full blur-2xl opacity-10" />
              <Bell className="relative text-white/10" size={64} />
            </div>
            <p className="text-gray-500 font-black uppercase tracking-[0.3em] text-sm">No notices found</p>
            <button 
              onClick={() => setIsAdding(true)}
              className="mt-6 text-pink-500 text-[10px] font-black uppercase tracking-[0.2em] hover:underline flex items-center gap-2 mx-auto"
            >
              <Plus size={14} /> Create your first alert
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
