import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '../store/useStore';
import { GoogleGenAI, LiveServerMessage, FunctionDeclaration, Modality } from '@google/genai';
import { Mic, MicOff, Sparkles, X, Loader2, Volume2 } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { collection, onSnapshot, query, orderBy, limit, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/firestoreErrorHandler';

export default function NovaAssistant() {
  const { settings, addToCart } = useStore();
  const novaSettings = settings.novaAI;
  const location = useLocation();
  
  const [isOpen, setIsOpen] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const isConnectedRef = useRef(false);
  const [isListening, setIsListening] = useState(false);
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const [offers, setOffers] = useState<any[]>([]);
  const [chickenItems, setChickenItems] = useState<any[]>([]);
  const [staffList, setStaffList] = useState<any[]>([]);
  const [events, setEvents] = useState<any[]>([]);
  const [panItems, setPanItems] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentOrder, setCurrentOrder] = useState<any | null>(null);
  const [lastOrderAnnouncedId, setLastOrderAnnouncedId] = useState<string | null>(null);
  const [panCategories, setPanCategories] = useState<any[]>([]);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const randomAnnouncementTimerRef = useRef<NodeJS.Timeout | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const sessionRef = useRef<any>(null);
  const retryCountRef = useRef(0);
  const playbackQueueRef = useRef<Float32Array[]>([]);
  const isPlayingRef = useRef(false);
  const nextPlayTimeRef = useRef(0);
  const autoSpeechTimerRef = useRef<NodeJS.Timeout | null>(null);
  
  const menuLoadedRef = useRef(false);
  const offersLoadedRef = useRef(false);
  const chickenLoadedRef = useRef(false);
  const staffLoadedRef = useRef(false);
  const eventsLoadedRef = useRef(false);
  const panLoadedRef = useRef(false);

  const checkAllLoaded = () => {
    if (menuLoadedRef.current && offersLoadedRef.current && chickenLoadedRef.current && staffLoadedRef.current && eventsLoadedRef.current && panLoadedRef.current) {
      setIsLoading(false);
    }
  };

  // Wake word recognition
  const recognitionRef = useRef<any>(null);

  // Check visibility
  const isVisible = location.pathname === '/admin' || novaSettings?.assistantVisible;

  useEffect(() => {
    // Fetch menu items
    const unsubscribeMenu = onSnapshot(collection(db, 'menuItems'), (snapshot) => {
      const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMenuItems(items);
      menuLoadedRef.current = true;
      checkAllLoaded();
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'menuItems');
    });

    // Fetch offers
    const qOffers = query(collection(db, 'offers'));
    const unsubscribeOffers = onSnapshot(qOffers, (snapshot) => {
      let offersData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() as any }));
      offersData.sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateB - dateA;
      });
      setOffers(offersData.filter(o => o.active).slice(0, 5));
      offersLoadedRef.current = true;
      checkAllLoaded();
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'offers');
    });

    // Fetch chicken items
    const qChicken = query(collection(db, 'chickenItems'));
    const unsubscribeChicken = onSnapshot(qChicken, (snapshot) => {
      const chickenData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() as any }));
      setChickenItems(chickenData.filter(c => c.active));
      chickenLoadedRef.current = true;
      checkAllLoaded();
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'chickenItems');
    });

    // Fetch staff
    const qStaff = query(collection(db, 'staff'));
    const unsubscribeStaff = onSnapshot(qStaff, (snapshot) => {
      const staffData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() as any }));
      setStaffList(staffData);
      staffLoadedRef.current = true;
      checkAllLoaded();
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'staff');
    });

    // Fetch events
    const qEvents = query(collection(db, 'events'));
    const unsubscribeEvents = onSnapshot(qEvents, (snapshot) => {
      const eventsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() as any }));
      setEvents(eventsData.filter(e => e.active));
      eventsLoadedRef.current = true;
      checkAllLoaded();
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'events');
    });

    // Fetch Pan items
    const unsubscribePan = onSnapshot(doc(db, 'settings', 'pan'), (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        setPanCategories(data.categories || []);
        setPanItems(data.items || []);
      }
      panLoadedRef.current = true;
      checkAllLoaded();
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'settings/pan');
    });

    // Fetch current order if exists
    let unsubscribeOrder: any = null;
    const lastOrderId = localStorage.getItem('lastOrderId');
    if (lastOrderId) {
      import('firebase/firestore').then(({ doc, onSnapshot }) => {
        unsubscribeOrder = onSnapshot(doc(db, 'orders', lastOrderId), (docSnap) => {
          if (docSnap.exists()) {
            setCurrentOrder({ id: docSnap.id, ...docSnap.data() });
          }
        }, (error) => {
          handleFirestoreError(error, OperationType.GET, `orders/${lastOrderId}`);
        });
      });
    }

    // Fetch orders for announcements
    const qOrders = query(collection(db, 'orders'), orderBy('createdAt', 'desc'), limit(1));
    const unsubscribeOrders = onSnapshot(qOrders, (snapshot) => {
      if (!snapshot.empty) {
        const latestOrder = snapshot.docs[0];
        const orderData = { id: latestOrder.id, ...latestOrder.data() } as any;
        
        if (novaSettings.liveOrderAnnouncementsEnabled && 
            orderData.id !== lastOrderAnnouncedId && 
            (Date.now() - (orderData.createdAt?.toMillis() || 0)) < 60000) {
          
          setLastOrderAnnouncedId(orderData.id);
          
          // Generate Pro Max announcement
          let announcementPrompt = novaSettings.orderAnnouncementPrompt || `Generate a highly engaging, human-like, premium announcement for a new order.`;
          announcementPrompt = announcementPrompt
            .replace('{{customerName}}', novaSettings.showCustomerName ? orderData.customerName : 'Anonymous')
            .replace('{{items}}', novaSettings.showOrderDetails ? orderData.items?.map((i: any) => `${i.quantity} ${i.name}`).join(', ') : 'Hidden Items')
            .replace('{{status}}', orderData.status)
            .replace('{{voiceStyle}}', novaSettings.voiceStyle)
            .replace('{{brandName}}', settings.logoName);

          sessionRef.current?.then((session: any) => {
            session.sendRealtimeInput({ text: announcementPrompt });
          });
        }
      }
    });

    // Random announcement timer
    if (novaSettings.randomAnnouncementsEnabled) {
      randomAnnouncementTimerRef.current = setInterval(() => {
        if (isConnectedRef.current && !isListening && !isPlayingRef.current) {
          let prompt = novaSettings.viralStorytellingPrompt || `Generate a fun, viral-style or storytelling-based announcement about our food stall {{brandName}}.`;
          prompt = prompt
            .replace('{{brandName}}', settings.logoName)
            .replace('{{viralEnabled ? \'Viral trend/meme-style content\' : \'\'}}', novaSettings.viralEngineEnabled ? 'Viral trend/meme-style content' : '')
            .replace('{{storytellingEnabled ? \'Emotional storytelling\' : \'\'}}', novaSettings.storytellingEngineEnabled ? 'Emotional storytelling' : '')
            .replace('{{voiceStyle}}', novaSettings.voiceStyle)
            .replace('{{emotionLevel}}', novaSettings.emotionLevel?.toString() || '5');
          
          sessionRef.current?.then((session: any) => {
            session.sendRealtimeInput({ text: prompt });
          });
        }
      }, (novaSettings.announcementInterval || 60) * 1000);
    }

    return () => {
      unsubscribeMenu();
      unsubscribeOffers();
      unsubscribeOrders();
      if (unsubscribeOrder) unsubscribeOrder();
      if (randomAnnouncementTimerRef.current) clearInterval(randomAnnouncementTimerRef.current);
    };
  }, []);

  useEffect(() => {
    if (!novaSettings?.isEnabled || !isVisible) {
      setIsOpen(false);
      disconnectLiveAPI();
      return;
    }

    // Initialize Wake Word detection if in strict mode
    if (novaSettings.wakeMode === 'strict') {
      initWakeWord();
    } else {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      disconnectLiveAPI();
    };
  }, [novaSettings?.isEnabled, novaSettings?.wakeMode, novaSettings?.wakeWord, isVisible]);

  // Auto-sync business data when menu, offers, categories, or settings change
  useEffect(() => {
    if (isConnected && novaSettings?.autoAnalysisEnabled && sessionRef.current) {
      let businessDataMessage = `[SYSTEM MESSAGE: UPDATED LIVE BUSINESS DATA]\n`;
      
      businessDataMessage += `Business Name: ${settings.logoName} ${settings.logoSubName}\n`;
      businessDataMessage += `Available Categories: ${settings.categories.join(', ')}\n`;
      
      if (settings.sections?.menu?.dataAnalysis !== false) {
        businessDataMessage += `Available Menu Items:\n`;
        menuItems.forEach(item => {
          let itemDetails = `- ${item.name} (${item.category})`;
          if (novaSettings.dataVisibility?.showPrice) {
            itemDetails += `: ₹${item.price}`;
          }
          if (item.description) {
            itemDetails += `. ${item.description}`;
          }
          businessDataMessage += `${itemDetails}\n`;
        });
      }
      
      if (settings.sections?.dailyOffers?.dataAnalysis !== false && novaSettings.dataVisibility?.showOffers) {
        businessDataMessage += `\nActive Offers:\n`;
        offers.forEach(offer => {
          businessDataMessage += `- ${offer.title}: ${offer.description}\n`;
        });
      }

      if (settings.sections?.chickenStore?.dataAnalysis !== false && settings.isChickenStoreEnabled && chickenItems.length > 0) {
        businessDataMessage += `\nChicken Store Items:\n`;
        chickenItems.forEach(chicken => {
          let details = `- ${chicken.name} (${chicken.category}) - ${chicken.quality}. ${chicken.remark}`;
          if (novaSettings.dataVisibility?.showPrice && chicken.rates) {
            details += ` | Rates: ${chicken.rates.map((r: any) => `${r.weight}: ₹${r.price}`).join(', ')}`;
          }
          businessDataMessage += `${details}\n`;
        });
      }

      if (settings.sections?.staffManage?.dataAnalysis !== false && settings.isStaffEnabled && staffList.length > 0) {
        businessDataMessage += `\nStaff Members:\n`;
        staffList.forEach(staff => {
          businessDataMessage += `- ${staff.name} (${staff.category}): ${staff.experience} exp. ${staff.remark}\n`;
        });
      }

      if (settings.sections?.events?.dataAnalysis !== false && events.length > 0) {
        businessDataMessage += `\nEvents:\n`;
        events.forEach(event => {
          businessDataMessage += `- ${event.title}: ${event.description}. Date: ${event.date}, Location: ${event.location}\n`;
        });
      }

      if (settings.sections?.pan?.dataAnalysis !== false && settings.isPanEnabled && panItems.length > 0) {
        businessDataMessage += `\nSpecial Assam Pan Items:\n`;
        panItems.forEach(pan => {
          if (pan.active) {
            let details = `- ${pan.name} (${pan.category}): ₹${pan.price}. ${pan.description || ''}`;
            if (pan.ingredients && pan.ingredients.length > 0) {
              details += ` Ingredients: ${pan.ingredients.join(', ')}`;
            }
            businessDataMessage += `${details}\n`;
          }
        });
      }

      if (settings.isFounderAiEnabled && settings.isFoundersEnabled) {
        businessDataMessage += `\nFounders & Partners Info:\n`;
        businessDataMessage += `- Founder 1: ${settings.founder1Name} (${settings.founder1Role}). Story: ${settings.founder1Caption}. Socials: ${JSON.stringify(settings.founder1SocialLinks)}\n`;
        businessDataMessage += `- Founder 2: ${settings.founder2Name} (${settings.founder2Role}). Story: ${settings.founder2Caption}. Socials: ${JSON.stringify(settings.founder2SocialLinks)}\n`;
      }

      if (settings.sections?.footerInfo?.dataAnalysis !== false) {
        businessDataMessage += `\nFooter/Contact Info:\n`;
        businessDataMessage += `- Address: ${settings.address}\n`;
        businessDataMessage += `- Contact Numbers: ${JSON.stringify(settings.contactNumbers)}\n`;
        businessDataMessage += `- Opening Hours: ${JSON.stringify(settings.openingHours)}\n`;
      }

      if (settings.isSocialMediaPromotionEnabled) {
        businessDataMessage += `\nSocial Media Promotion:\n`;
        businessDataMessage += `- Message: ${settings.socialMediaPromotionMessage}\n`;
        businessDataMessage += `- Instruction: You are encouraged to verbally suggest customers visit our social media platforms (Instagram, Facebook, YouTube, Twitter, WhatsApp) using the message above.\n`;
      }

      businessDataMessage += `\nUse this updated data to suggest items, combos, and answer customer queries accurately.\n`;

      sessionRef.current.then((session: any) => {
        session.sendRealtimeInput({
          text: businessDataMessage
        });
      });
    }
  }, [menuItems, offers, settings.categories, settings.logoName, settings.logoSubName, isConnected, novaSettings?.autoAnalysisEnabled, panItems]);

  const initWakeWord = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = novaSettings.language === 'en' ? 'en-US' : 'hi-IN';

    recognition.onresult = (event: any) => {
      const last = event.results.length - 1;
      const text = event.results[last][0].transcript.trim().toLowerCase();
      
      if (text.includes(novaSettings.wakeWord.toLowerCase())) {
        setIsOpen(true);
        connectLiveAPI();
      }
    };

    recognition.onend = () => {
      if (novaSettings.isEnabled && novaSettings.wakeMode === 'strict' && !isConnectedRef.current) {
        setTimeout(() => {
          try {
            if (!isConnectedRef.current) {
              recognition.start();
            }
          } catch (e) {}
        }, 1000);
      }
    };

    try {
      recognition.start();
      recognitionRef.current = recognition;
    } catch (e) {}
  };

  const connectLiveAPI = async () => {
    if (isConnectedRef.current) return;
    
    try {
      setIsConnected(true);
      isConnectedRef.current = true;
      // @ts-ignore
      const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY;
      
      if (!apiKey) {
        console.error("API Key is missing! Please set GEMINI_API_KEY.");
        setIsConnected(false);
        return;
      }
      
      const ai = new GoogleGenAI({ apiKey });
      
      const voiceName = novaSettings.voiceType === 'female' ? 'Kore' : 
                        novaSettings.voiceType === 'male' ? 'Charon' : 'Zephyr';

      let systemInstruction = `${novaSettings.masterPrompt || `You are NOVA AI, a premium assistant for ${settings.logoName}. You are a Smart Sales Assistant, Human-like Receptionist, and Entertainment Host.`}
Tone: ${novaSettings.voiceType === 'female' ? 'Soft, polite, professional' : 'Deep, friendly, professional'}.
Language: ${novaSettings.language}.

Expertise: You are an expert on Special Assam Pan. You know all the varieties (Special Mitha Pan, Full Moment Pan, Medium Moment Pan, etc.), their prices, and ingredients. You can explain why our Pan is premium and suggest the best one based on customer preference.
`;

      if (novaSettings.aiUpdatesEnabled) {
        if (novaSettings.businessLogicPrompt) systemInstruction += `\n\nBusiness Logic:\n${novaSettings.businessLogicPrompt}`;
        if (novaSettings.salesStrategyPrompt) systemInstruction += `\n\nSales Strategy:\n${novaSettings.salesStrategyPrompt}`;
        if (novaSettings.voiceBehaviorPrompt) systemInstruction += `\n\nVoice & Cart Behavior:\n${novaSettings.voiceBehaviorPrompt}`;
      }

      // Dual Control System logic
      systemInstruction += `\n\nDual Control System Settings:\n`;
      systemInstruction += `AI Generation Mode: ${novaSettings.aiModeEnabled ? 'ENABLED' : 'DISABLED'}\n`;
      systemInstruction += `Manual Admin Mode: ${novaSettings.manualModeEnabled ? 'ENABLED' : 'DISABLED'}\n`;
      systemInstruction += `Hybrid Mode: ${novaSettings.hybridModeEnabled ? 'ENABLED' : 'DISABLED'}\n\n`;

      // Section Intelligence Engine
      systemInstruction += `\n\nSection Intelligence Engine:\n`;
      Object.entries(settings.sections).forEach(([id, config]) => {
        if (!config.enabled) {
          systemInstruction += `- Section ${id} is DISABLED. Do not mention or use data from this section.\n`;
        } else {
          systemInstruction += `- Section ${id} is ENABLED. AI Access: ${config.aiAccess ? 'YES' : 'NO'}. Customer Visibility: ${config.customerVisibility ? 'YES' : 'NO'}. Data Analysis: ${config.dataAnalysis ? 'YES' : 'NO'}.\n`;
        }
      });
      
      // Admin Permission Control System
      systemInstruction += `\n\nAdmin Permission Control System:\n`;
      systemInstruction += `Permission Mode: ${novaSettings?.permissionMode?.toUpperCase() || 'FULL'}\n`;
      if (novaSettings.permissionMode === 'disabled') {
        systemInstruction += `CRITICAL: You are in DISABLED MODE. You must NOT take any actions, manage the cart, or suggest items. Only provide basic greetings.\n`;
      } else if (novaSettings.permissionMode === 'limited') {
        systemInstruction += `CRITICAL: You are in LIMITED MODE. You can suggest items and talk, but you CANNOT manage the cart or take system actions.\n`;
      } else {
        systemInstruction += `You are in FULL PERMISSION MODE. You can manage the cart, suggest items, and handle user interactions fully.\n`;
      }
      
      if (!novaSettings.allowManageCart) {
        systemInstruction += `CRITICAL: You are NOT allowed to manage the cart. Do NOT use the addToCart tool.\n`;
      }
      if (!novaSettings.allowSuggestItems) {
        systemInstruction += `CRITICAL: You are NOT allowed to suggest items. Only answer direct questions.\n`;
      }

      // Order Status Intelligence System
      if (novaSettings.orderTrackingEnabled && currentOrder) {
        systemInstruction += `\n\nOrder Status Intelligence System:\n`;
        systemInstruction += `The customer has an active order (ID: ${currentOrder.id}).\n`;
        systemInstruction += `Current Status: ${currentOrder.status || 'Pending'}\n`;
        if (currentOrder.estimatedDeliveryTime) {
          systemInstruction += `Estimated Delivery Time: ${currentOrder.estimatedDeliveryTime}\n`;
        }
        if (currentOrder.adminRemark) {
          systemInstruction += `Admin Remark: ${currentOrder.adminRemark}\n`;
        }
        
        systemInstruction += `\nRules for responding based on order status:\n`;
        systemInstruction += `- Pending: "Sir, aapka order abhi pending hai, jaldi confirm ho jayega 👍"\n`;
        systemInstruction += `- Confirmed: "Great news! Aapka order confirm ho gaya hai ✅"\n`;
        systemInstruction += `- Preparing: "Aapka order abhi prepare ho raha hai 👨🍳"\n`;
        systemInstruction += `- Out for Delivery: "Aapka order delivery ke liye nikal chuka hai 🚚"\n`;
        systemInstruction += `- Completed: "🎉 Congratulations! Aapka order successfully deliver ho gaya hai. Aur kuch dekhna chahoge?"\n`;
        systemInstruction += `Always match this real order data. Never give wrong status.\n`;
      }

      const contentTypes = ['shayari', 'dialog', 'entertainment', 'funny', 'reaction', 'motionVibe', 'chutkule'] as const;
      
      contentTypes.forEach(type => {
        const settings = novaSettings[type];
        if (!settings.enabled) {
          systemInstruction += `DO NOT generate ${type}.\n`;
        } else if (novaSettings.manualModeEnabled || novaSettings.hybridModeEnabled) {
          if (settings.manualText) {
            systemInstruction += `Use this manual content for ${type}: "${settings.manualText}".\n`;
          }
        }
      });
      
      if (novaSettings.customInstructions) {
        systemInstruction += `\n\nCustom Instructions/Knowledge Base:\n${novaSettings.customInstructions}\n\n`;
      }

      // Advanced Intelligence Settings
      if (novaSettings.autoStableModeEnabled) {
        systemInstruction += `\n[AUTO-STABLE MODE ENABLED]: You are a fully self-adaptive business brain. You must automatically scan and understand the live business data provided in the system messages. If any item, category, or offer is added, removed, or updated, you must auto-adjust your responses immediately. Every feature must remain stable. You must always align with the current live data. Do not use outdated information.\n`;
      }
      if (novaSettings.truthFirstModeEnabled) {
        systemInstruction += `\n[TRUTH-FIRST MODE ENABLED]: STRICT RULE: You must ALWAYS provide correct and real information. No guessing allowed. No fake data allowed. If data is not found, respond politely (e.g., "Maafi chahunga, yeh item abhi available nahi hai."). Your responses must vary naturally without repetition.\n`;
      }
      if (novaSettings.autoSwitchModeEnabled) {
        systemInstruction += `\n[AUTO-SWITCH MODE ENABLED]: Intelligently switch between AI Mode, Manual Mode, and Hybrid Mode based on the context and available data. If you cannot fulfill a request using AI, gracefully fall back to manual responses or predefined templates.\n`;
      }
      if (novaSettings.costSavingModeEnabled) {
        systemInstruction += `\n[COST-SAVING MODE ENABLED]: Optimize your responses to be concise and direct. Avoid unnecessary elaboration to minimize token usage while maintaining a helpful and human-like tone.\n`;
      }

      // Auto Business Analysis Engine & Zero-Miss Master Brain
      let businessDataMessage = "";
      if (novaSettings.autoAnalysisEnabled || novaSettings.zeroMissAnalysisEnabled) {
        businessDataMessage += `[SYSTEM MESSAGE: ZERO-MISS LIVE BUSINESS DATA]\n`;
        
        if (novaSettings.deepDataIntelligenceEnabled) {
          businessDataMessage += `\n--- BUSINESS INFO & SETTINGS ---\n`;
          businessDataMessage += `Business Name: ${settings.logoName} ${settings.logoSubName}\n`;
          businessDataMessage += `Address: ${settings.address}\n`;
          businessDataMessage += `Contact: Owner ${settings.contactNumbers.owner}, Partner ${settings.contactNumbers.partner}\n`;
          businessDataMessage += `Opening Hours: ${JSON.stringify(settings.openingHours)}\n`;
          businessDataMessage += `Delivery Rules: Min Order ${settings.isMinimumOrderEnabled ? settings.minimumOrderQuantity : 'None'}, Free Delivery Threshold: ₹${settings.freeDeliveryThreshold}\n`;
          businessDataMessage += `Payment Methods: ${settings.applicablePaymentMethods.join(', ')}\n`;
          businessDataMessage += `Enabled Sections: Menu(${settings.isMenuEnabled}), Offers(${settings.isOffersEnabled}), Events(${settings.isEventsEnabled}), Reviews(${settings.isReviewsEnabled})\n`;
        }

        if (settings.sections?.menu?.dataAnalysis !== false) {
          businessDataMessage += `\n--- MENU ITEMS & CATEGORIES ---\n`;
          businessDataMessage += `Categories: ${settings.categories.join(', ')}\n`;
          menuItems.forEach(item => {
            let itemDetails = `- ${item.name} (${item.category})`;
            if (novaSettings.dataVisibility?.showPrice) {
              itemDetails += `: ₹${item.price}`;
            }
            if (item.description) {
              itemDetails += `. ${item.description}`;
            }
            if (item.isVeg !== undefined) {
              itemDetails += ` [${item.isVeg ? 'Veg' : 'Non-Veg'}]`;
            }
            businessDataMessage += `${itemDetails}\n`;
          });
        }
        
        if (settings.sections?.dailyOffers?.dataAnalysis !== false && novaSettings.dataVisibility?.showOffers) {
          businessDataMessage += `\n--- ACTIVE OFFERS ---\n`;
          offers.forEach(offer => {
            businessDataMessage += `- ${offer.title}: ${offer.description}\n`;
          });
        }

        if (settings.sections?.chickenStore?.dataAnalysis !== false && settings.isChickenStoreEnabled && chickenItems.length > 0) {
          businessDataMessage += `\n--- CHICKEN STORE ITEMS ---\n`;
          chickenItems.forEach(chicken => {
            let details = `- ${chicken.name} (${chicken.category}) - ${chicken.quality}. ${chicken.remark}`;
            if (novaSettings.dataVisibility?.showPrice && chicken.rates) {
              details += ` | Rates: ${chicken.rates.map((r: any) => `${r.weight}: ₹${r.price}`).join(', ')}`;
            }
            businessDataMessage += `${details}\n`;
          });
        }

        if (settings.sections?.staffManage?.dataAnalysis !== false && settings.isStaffEnabled && staffList.length > 0) {
          businessDataMessage += `\n--- STAFF MEMBERS ---\n`;
          staffList.forEach(staff => {
            businessDataMessage += `- ${staff.name} (${staff.category}): ${staff.experience} exp. ${staff.remark}\n`;
          });
        }

        if (settings.sections?.events?.dataAnalysis !== false && events.length > 0) {
          businessDataMessage += `\n--- EVENTS ---\n`;
          events.forEach(event => {
            businessDataMessage += `- ${event.title}: ${event.description}. Date: ${event.date}, Location: ${event.location}\n`;
          });
        }

        if (settings.sections?.pan?.dataAnalysis !== false && settings.isPanEnabled && panItems.length > 0) {
          businessDataMessage += `\n--- SPECIAL ASSAM PAN ITEMS ---\n`;
          panItems.forEach(pan => {
            if (pan.active) {
              let details = `- ${pan.name} (${pan.category}): ₹${pan.price}. ${pan.description || ''}`;
              if (pan.ingredients && pan.ingredients.length > 0) {
                details += ` Ingredients: ${pan.ingredients.join(', ')}`;
              }
              businessDataMessage += `${details}\n`;
            }
          });
        }

        if (settings.isFounderAiEnabled && settings.isFoundersEnabled) {
          businessDataMessage += `\n--- FOUNDERS & PARTNERS INFO ---\n`;
          businessDataMessage += `- Founder 1: ${settings.founder1Name} (${settings.founder1Role}). Story: ${settings.founder1Caption}\n`;
          businessDataMessage += `- Founder 2: ${settings.founder2Name} (${settings.founder2Role}). Story: ${settings.founder2Caption}\n`;
        }

        if (novaSettings.deepDataIntelligenceEnabled) {
          if (settings.sections?.eventBooking?.dataAnalysis !== false) {
            businessDataMessage += `\n--- EVENT SERVICES ---\n`;
            useStore.getState().eventServices?.forEach(event => {
              businessDataMessage += `- ${event.title} (${event.category}): ${event.priceRange}. ${event.description}\n`;
            });
          }

          if (settings.sections?.deliveryZones?.dataAnalysis !== false) {
            businessDataMessage += `\n--- DELIVERY ZONES ---\n`;
            settings.deliveryZones?.forEach(zone => {
              if (zone.active) {
                businessDataMessage += `- ${zone.city}, ${zone.district}, ${zone.state}\n`;
              }
            });
          }
        }

        businessDataMessage += `\nUse this data to suggest items, combos, and answer customer queries accurately. Only mention prices or offers if they are provided in the data above.\n`;
      }

      // Human-Like Super Brain & Zero Error Rules
      if (novaSettings.humanLikeSuperBrainEnabled) {
        systemInstruction += `\n[HUMAN-LIKE SUPER BRAIN]: You are a highly experienced shop manager and smart business analyst. Understand intent deeply, suggest best options, guide customers naturally, and avoid robotic replies. Balance helpfulness, sales, and simplicity.\n`;
      }
      if (novaSettings.zeroErrorMaxAccuracyEnabled) {
        systemInstruction += `\n[ZERO ERROR + MAX ACCURACY RULE]: STRICT RULE: No wrong information. No guessing. No outdated data. If unsure, say: "Maafi chahunga, yeh information abhi available nahi hai".\n`;
      }
      if (novaSettings.futureAutoAdaptEnabled) {
        systemInstruction += `\n[FUTURE AUTO-ADAPT SYSTEM]: You must automatically adapt to the live data provided above. If an item is missing from the data, assume it is unavailable. Never lose context of the data provided.\n`;
      }

      systemInstruction += `Always end with a subtle call-to-action (food suggestion or offer). Keep responses concise and human-like.`;

      const addToCartTool: FunctionDeclaration = {
        name: "addToCart",
        description: "Add a specific food item to the customer's cart.",
        parameters: {
          type: "OBJECT" as any,
          properties: {
            itemId: {
              type: "STRING" as any,
              description: "The ID of the menu item to add."
            },
            quantity: {
              type: "NUMBER" as any,
              description: "The quantity to add."
            }
          },
          required: ["itemId", "quantity"]
        }
      };

      const tools = [];
      if (novaSettings.allowManageCart && novaSettings.permissionMode === 'full') {
        tools.push({ functionDeclarations: [addToCartTool] });
      }

      const sessionPromise = ai.live.connect({
        model: "gemini-3.1-flash-live-preview",
        callbacks: {
          onopen: () => {
            retryCountRef.current = 0;
            startAudioCapture(sessionPromise);
            if (novaSettings.autoSpeechEnabled) {
              startAutoSpeech(sessionPromise);
            }
            if (businessDataMessage) {
              sessionPromise.then(session => {
                session.sendRealtimeInput({
                  text: businessDataMessage
                });
              });
            }
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.modelTurn?.parts) {
              for (const part of message.serverContent.modelTurn.parts) {
                if (part.inlineData && part.inlineData.data) {
                  playAudioChunk(part.inlineData.data);
                }
              }
            }
            if (message.serverContent?.interrupted) {
              playbackQueueRef.current = [];
            }
            if (message.toolCall) {
              const functionCalls = message.toolCall.functionCalls;
              if (functionCalls) {
                const functionResponses = functionCalls.map(call => {
                  if (call.name === 'addToCart') {
                    const args = call.args as any;
                    const item = menuItems.find(i => i.id === args.itemId) || panItems.find(i => i.id === args.itemId);
                    if (item) {
                      addToCart({
                        ...item,
                        cartItemId: Math.random().toString(36).substring(7),
                        quantity: args.quantity || 1
                      });
                      return {
                        id: call.id,
                        name: call.name,
                        response: { result: `Successfully added ${args.quantity} ${item.name} to cart.` }
                      };
                    } else {
                      return {
                        id: call.id,
                        name: call.name,
                        response: { error: `Item with ID ${args.itemId} not found.` }
                      };
                    }
                  }
                  return {
                    id: call.id,
                    name: call.name,
                    response: { error: "Unknown function" }
                  };
                });
                
                sessionPromise.then(session => {
                  session.sendToolResponse({ functionResponses });
                });
              }
            }
          },
          onclose: () => {
            disconnectLiveAPI();
            stopAutoSpeech();
          },
          onerror: (err) => {
            if (err instanceof Error && (err.name === 'AbortError' || err.message?.includes('aborted'))) {
              console.log("Live API connection aborted (expected).");
              disconnectLiveAPI();
              stopAutoSpeech();
            } else if (err instanceof Error && err.message?.includes('unavailable')) {
              const retryDelay = Math.min(30000, 5000 * Math.pow(2, retryCountRef.current));
              console.warn(`Live API Service Unavailable. Retrying in ${retryDelay}ms... (Attempt ${retryCountRef.current + 1})`);
              retryCountRef.current += 1;
              disconnectLiveAPI();
              stopAutoSpeech();
              setTimeout(connectLiveAPI, retryDelay);
            } else {
              console.error("Live API Error:", err);
              disconnectLiveAPI();
              stopAutoSpeech();
            }
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName } }
          },
          systemInstruction: systemInstruction,
          tools: tools.length > 0 ? tools : undefined
        }
      });
      
      sessionRef.current = sessionPromise;

    } catch (error) {
      console.error("Failed to connect to Live API:", error);
      setIsConnected(false);
      isConnectedRef.current = false;
    }
  };

  const startAutoSpeech = (sessionPromise: Promise<any>) => {
    // Only start if auto or hybrid mode is enabled
    if (!novaSettings?.autoVoiceModeEnabled && !novaSettings?.hybridVoiceModeEnabled) return;
    
    const interval = (novaSettings.voiceInterval || 30) * 1000;
    
    autoSpeechTimerRef.current = setInterval(() => {
      if (!isListening && !isPlayingRef.current) {
        sessionPromise.then(session => {
          session.sendRealtimeInput({
            text: "The user has been idle. Please say something engaging, suggest a menu item, or tell a joke based on your current mode."
          });
        });
      }
    }, interval);
  };

  const stopAutoSpeech = () => {
    if (autoSpeechTimerRef.current) {
      clearInterval(autoSpeechTimerRef.current);
      autoSpeechTimerRef.current = null;
    }
  };

  const disconnectLiveAPI = () => {
    setIsConnected(false);
    isConnectedRef.current = false;
    setIsListening(false);
    stopAutoSpeech();
    if (sessionRef.current) {
      sessionRef.current.then((session: any) => session.close()).catch(() => {});
      sessionRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    playbackQueueRef.current = [];
    isPlayingRef.current = false;
  };

  const startAudioCapture = async (sessionPromise: Promise<any>) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: {
        sampleRate: 16000,
        channelCount: 1,
        echoCancellation: true,
        noiseSuppression: true,
      } });
      streamRef.current = stream;
      
      const audioContext = new AudioContext({ sampleRate: 16000 });
      audioContextRef.current = audioContext;
      
      const source = audioContext.createMediaStreamSource(stream);
      const processor = audioContext.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;
      
      processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        const pcm16 = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          let s = Math.max(-1, Math.min(1, inputData[i]));
          pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
        }
        
        const base64Data = btoa(String.fromCharCode(...new Uint8Array(pcm16.buffer)));
        
        sessionPromise.then(session => {
          session.sendRealtimeInput({
            audio: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
          });
        });
      };
      
      source.connect(processor);
      processor.connect(audioContext.destination);
      setIsListening(true);
      
    } catch (err) {
      console.error("Error accessing microphone:", err);
      disconnectLiveAPI();
      // Provide user feedback
      alert("Microphone access is required for NOVA AI. Please allow microphone permissions in your browser settings.");
    }
  };

  const playAudioChunk = (base64Data: string) => {
    if (!audioContextRef.current) return;
    
    const binaryString = atob(base64Data);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    
    // The Live API returns PCM 24000Hz 16-bit
    const pcm16 = new Int16Array(bytes.buffer);
    const float32 = new Float32Array(pcm16.length);
    for (let i = 0; i < pcm16.length; i++) {
      float32[i] = pcm16[i] / 32768.0;
    }
    
    playbackQueueRef.current.push(float32);
    if (!isPlayingRef.current) {
      playNextChunk();
    }
  };

  const playNextChunk = () => {
    if (playbackQueueRef.current.length === 0) {
      isPlayingRef.current = false;
      return;
    }
    
    isPlayingRef.current = true;
    const chunk = playbackQueueRef.current.shift()!;
    const audioCtx = audioContextRef.current;
    if (!audioCtx) return;
    
    const buffer = audioCtx.createBuffer(1, chunk.length, 24000);
    buffer.getChannelData(0).set(chunk);
    
    const source = audioCtx.createBufferSource();
    source.buffer = buffer;
    source.connect(audioCtx.destination);
    
    const currentTime = audioCtx.currentTime;
    const startTime = Math.max(currentTime, nextPlayTimeRef.current);
    
    source.start(startTime);
    nextPlayTimeRef.current = startTime + buffer.duration;
    
    source.onended = () => {
      playNextChunk();
    };
  };

  if (!novaSettings?.isEnabled) return null;

  if (isLoading) return (
    <div className="fixed bottom-24 right-6 w-16 h-16 bg-black rounded-full flex items-center justify-center z-50 border border-[var(--color-neon-green)]">
      <Loader2 className="text-[var(--color-neon-green)] animate-spin" size={28} />
    </div>
  );

  return (
    <>
      {/* Floating Button */}
      {!isOpen && (
        <button
          onClick={() => {
            setIsOpen(true);
            connectLiveAPI();
          }}
          className="fixed bottom-24 right-6 w-16 h-16 bg-[var(--color-neon-green)] rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(0,255,0,0.4)] hover:scale-110 transition-transform z-50 group"
        >
          <Sparkles className="text-black group-hover:animate-spin" size={28} />
          <div className="absolute -top-10 bg-black text-[var(--color-neon-green)] text-xs font-bold px-3 py-1 rounded-full border border-[var(--color-neon-green)] opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
            {novaSettings.wakeMode === 'strict' ? `Say "${novaSettings.wakeWord}"` : 'Talk to NOVA'}
          </div>
        </button>
      )}

      {/* Assistant UI */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 w-80 bg-[#111] border border-[#333] rounded-2xl shadow-2xl z-50 overflow-hidden flex flex-col">
          <div className="bg-[#1a1a1a] p-4 border-b border-[#333] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="text-[var(--color-neon-green)]" size={20} />
              <h3 className="text-white font-bold">NOVA AI</h3>
            </div>
            <button 
              onClick={() => {
                setIsOpen(false);
                disconnectLiveAPI();
              }}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <X size={20} />
            </button>
          </div>
          
          <div className="p-6 flex flex-col items-center justify-center min-h-[200px] relative">
            {/* Visualizer */}
            <div className="relative w-32 h-32 flex items-center justify-center mb-4">
              {isConnected ? (
                <>
                  <div className="absolute inset-0 border-4 border-[var(--color-neon-green)] rounded-full animate-ping opacity-20"></div>
                  <div className="absolute inset-2 border-4 border-[var(--color-neon-green)] rounded-full animate-spin" style={{ animationDuration: '3s' }}></div>
                  <div className="w-20 h-20 bg-[var(--color-neon-green)] rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(0,255,0,0.5)] overflow-hidden relative">
                    {novaSettings.aiProfileVideo ? (
                      <video src={novaSettings.aiProfileVideo} autoPlay loop muted className="w-full h-full object-cover absolute inset-0" />
                    ) : novaSettings.aiProfileImage ? (
                      <img src={novaSettings.aiProfileImage} alt="NOVA AI" className="w-full h-full object-cover absolute inset-0" />
                    ) : null}
                    <div className="relative z-10 bg-black/50 w-full h-full flex items-center justify-center">
                      {isListening ? <Mic className="text-white" size={32} /> : <Volume2 className="text-white" size={32} />}
                    </div>
                  </div>
                </>
              ) : (
                <div className="w-20 h-20 bg-gray-800 rounded-full flex items-center justify-center">
                  <Loader2 className="text-gray-400 animate-spin" size={32} />
                </div>
              )}
            </div>
            
            <p className="text-center text-sm font-medium text-gray-300">
              {isConnected ? (isListening ? "Listening..." : "Speaking...") : "Connecting to NOVA..."}
            </p>
          </div>
        </div>
      )}
    </>
  );
}
