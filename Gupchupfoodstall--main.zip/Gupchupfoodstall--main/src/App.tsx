/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { motion, AnimatePresence, MotionConfig } from 'framer-motion';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import BannerSection from './components/BannerSection';
import FounderSection from './components/FounderSection';
import MenuCard from './components/MenuCard';
import CartDrawer from './components/CartDrawer';
import AdminDashboard from './components/AdminDashboard';
import { AuthPage } from './components/AuthPage';
import { AdminLoginPage } from './components/AdminLoginPage';
import { CustomerDashboard } from './components/CustomerDashboard';
import StaffSection from './components/StaffSection';
import RiderList from './components/RiderList';
import InfluencerVideo from './components/InfluencerVideo';
import StorySection from './components/StorySection';
import NotificationSection from './components/NotificationSection';
import FooterInfo from './components/FooterInfo';
import OpeningHoursSection from './components/OpeningHoursSection';
import ContactSection from './components/ContactSection';
import PartnerCollabSection from './components/PartnerCollabSection';
import GetDirectionsSection from './components/GetDirectionsSection';
import MomentsSection from './components/MomentsSection';
import ChickenStoreSection from './components/ChickenStoreSection';
import PanSection from './components/PanSection';
import EventsSection from './components/EventsSection';
import CompetitionSection from './components/CompetitionSection';
import RgbEngine from './components/RgbEngine';
import NovaAssistant from './components/NovaAssistant';
import { collection, onSnapshot, query, orderBy, limit, doc } from 'firebase/firestore';
import { db } from './firebase';
import ErrorBoundary from './components/ErrorBoundary';
import { handleFirestoreError, OperationType } from './utils/firestoreErrorHandler';
import { StallStatusBadge } from './components/StallStatusBadge';
import { MusicControl } from './components/MusicControl';
import { useStore } from './store/useStore';

import FeaturedInfluencers from './components/FeaturedInfluencers';
import CashbackDashboard from './components/CashbackDashboard';
import PhotoStudioDashboard from './components/PhotoStudioDashboard';
import CustomerReviewSection from './components/reviews/CustomerReviewSection';
import ShareButton from './components/ShareButton';
import { Instagram, Facebook, Youtube, MessageCircle, MapPin, Calendar, Star, Users, Search, ArrowRight, Music, ShoppingCart, Volume2, VolumeX } from 'lucide-react';

import { menuData } from './data/menuData';

// ... (remove MOCK_MENU)

const EventVideoPlayer = ({ videoUrl }: { videoUrl: string }) => {
  const [isMuted, setIsMuted] = useState(true);
  
  return (
    <>
      <video 
        autoPlay 
        loop 
        muted={isMuted} 
        playsInline 
        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[2s] ease-out" 
        src={videoUrl} 
      />
      <button 
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setIsMuted(!isMuted);
        }}
        className="absolute top-4 left-4 z-30 bg-black/50 hover:bg-[var(--color-neon-green)] hover:text-black p-2 rounded-full backdrop-blur-md border border-white/10 transition-all duration-300 text-white shadow-lg"
        title={isMuted ? "Unmute video" : "Mute video"}
      >
        {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
      </button>
    </>
  );
};

function Home() {
  const [filter, setFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeScreen, setActiveScreen] = useState(0);
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [offers, setOffers] = useState<any[]>([]);
  const [reels, setReels] = useState<any[]>([]);
  const [stories, setStories] = useState<any[]>([]);
  const [influencers, setInfluencers] = useState<any[]>([]);
  const [sponsoredVideos, setSponsoredVideos] = useState<any[]>([]);
  const [collaborations, setCollaborations] = useState<any[]>([]);
  const [events, setEvents] = useState<any[]>([]);
  const { 
    settings, setSettings, setReviews,
    setCompetitions, setCompetitionManagers, setCompetitionAnnouncements,
    setPanCategories, setPanItems,
    setEventServices, updateEventOwnerProfile
  } = useStore();
  const audioRef = React.useRef<HTMLAudioElement>(null);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = settings.bgMusicVolume;
    }
    document.documentElement.style.setProperty('--color-neon-green', settings.neonGreen);
    document.documentElement.style.setProperty('--color-neon-red', settings.neonRed);

    // Apply Animation Styles
    if (settings.isAnimationsEnabled === false) {
      document.body.classList.add('disable-animations');
    } else {
      document.body.classList.remove('disable-animations');
      
      let duration = '0.5s';
      let ease = 'ease-out';
      
      switch (settings.animationStyle) {
        case 'subtle':
          duration = '0.8s';
          ease = 'cubic-bezier(0.25, 0.1, 0.25, 1)';
          break;
        case 'energetic':
          duration = '0.2s';
          ease = 'cubic-bezier(0.175, 0.885, 0.32, 1.275)'; // bouncy
          break;
        case 'bouncy':
        default:
          duration = '0.5s';
          ease = 'cubic-bezier(0.68, -0.55, 0.265, 1.55)'; // bouncy
          break;
      }
      
      document.documentElement.style.setProperty('--anim-duration', duration);
      document.documentElement.style.setProperty('--anim-ease', ease);
    }

    // Apply Theme
    if (settings.theme === 'light') {
      document.documentElement.classList.add('light-mode');
      document.documentElement.classList.remove('dark-mode');
    } else {
      document.documentElement.classList.add('dark-mode');
      document.documentElement.classList.remove('light-mode');
    }
  }, [settings.bgMusicVolume, settings.neonGreen, settings.neonRed, settings.isAnimationsEnabled, settings.animationStyle, settings.theme]);

  useEffect(() => {
    const unsubscribeMenu = onSnapshot(collection(db, 'menuItems'), (snapshot) => {
      const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMenuItems(items);
      setIsLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'menuItems');
      setIsLoading(false);
    });

    const qOffers = query(collection(db, 'offers'));
    const unsubscribeOffers = onSnapshot(qOffers, (snapshot) => {
      if (!snapshot.empty) {
        let offersData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() as any }));
        // Sort by createdAt if exists, then slice
        offersData.sort((a, b) => {
          const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
          const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
          return dateB - dateA;
        });
        setOffers(offersData.filter(o => o.active).slice(0, 3));
      } else {
        // Mock offers if empty
        setOffers([
          { id: 'o1', title: 'Combo Dhamaka', description: '2 Samosa + 1 Mango Juice', price: 50, originalPrice: 60, imageUrl: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&q=80&w=800' },
          { id: 'o2', title: 'Spicy Treat', description: '1 Momos + 1 Cold Drink', price: 70, originalPrice: 80, imageUrl: 'https://images.unsplash.com/photo-1625220194771-7ebdea0b70b9?auto=format&fit=crop&q=80&w=800' }
        ]);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'offers');
    });

    const unsubscribeReels = onSnapshot(collection(db, 'reels'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setReels(data.filter((r: any) => r.active));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'reels');
    });

    const unsubscribeStories = onSnapshot(collection(db, 'stories'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setStories(data.filter((s: any) => s.active));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'stories');
    });

    const unsubscribeInfluencers = onSnapshot(collection(db, 'influencers'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setInfluencers(data);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'influencers');
    });

    const unsubscribeSponsored = onSnapshot(collection(db, 'sponsoredVideos'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setSponsoredVideos(data.filter((v: any) => v.active));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'sponsoredVideos');
    });

    const unsubscribeCollaborations = onSnapshot(collection(db, 'collaborations'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setCollaborations(data.filter((c: any) => c.active));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'collaborations');
    });

    const unsubscribeEvents = onSnapshot(query(collection(db, 'events'), orderBy('order', 'asc')), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setEvents(data.filter((e: any) => e.active));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'events');
    });

    const unsubscribePan = onSnapshot(doc(db, 'settings', 'pan'), (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        if (data.categories) setPanCategories(data.categories);
        if (data.items) setPanItems(data.items);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'settings/pan');
    });

    const unsubscribeEventServices = onSnapshot(query(collection(db, 'eventServices'), orderBy('order', 'asc')), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setEventServices(data as any);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'eventServices');
    });

    const unsubscribeEventOwnerProfile = onSnapshot(doc(db, 'settings', 'eventOwnerProfile'), (snapshot) => {
      if (snapshot.exists()) {
        updateEventOwnerProfile(snapshot.data() as any);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'settings/eventOwnerProfile');
    });

    return () => {
      unsubscribeMenu();
      unsubscribeOffers();
      unsubscribeReels();
      unsubscribeStories();
      unsubscribeInfluencers();
      unsubscribeSponsored();
      unsubscribeCollaborations();
      unsubscribeEvents();
      unsubscribePan();
      unsubscribeEventServices();
      unsubscribeEventOwnerProfile();
    };
  }, []);
  
  const filteredMenu = menuItems.filter(item => {
    const matchesCategory = filter === 'All' || item.category === filter;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const [showScrollTop, setShowScrollTop] = useState(false);
  useEffect(() => {
    const handleScroll = () => setShowScrollTop(window.scrollY > 500);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const getGlobalTransition = () => {
    switch (settings.animationStyle) {
      case 'subtle':
        return { type: 'tween', duration: 0.8, ease: [0.25, 0.1, 0.25, 1] } as const;
      case 'energetic':
        return { type: 'spring', stiffness: 300, damping: 15, mass: 0.8 } as const;
      case 'bouncy':
      default:
        return { type: 'spring', stiffness: 200, damping: 12 } as const;
    }
  };

  const sectionHero = <Hero key="hero" />;
  
  const sectionEvents = settings.isEventsEnabled && events.length > 0 && (
    <motion.section 
      key="events"
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ duration: 1 }}
      className="relative py-16 md:py-24 px-4 md:px-6 border-b border-white/5 overflow-hidden bg-black/40 backdrop-blur-sm mt-20"
    >
    {/* Background Decorative Elements */}
    <motion.div 
      animate={{ 
        scale: [1, 1.1, 1],
        opacity: [0.3, 0.6, 0.3] 
      }}
      transition={{ 
        duration: 8, 
        repeat: Infinity, 
        ease: "easeInOut" 
      }}
      className="absolute top-0 left-1/4 w-96 h-96 bg-[var(--color-neon-green)]/5 rounded-full blur-[120px]"
    />
    <motion.div 
      animate={{ 
        scale: [1, 1.2, 1],
        opacity: [0.2, 0.5, 0.2] 
      }}
      transition={{ 
        duration: 10, 
        repeat: Infinity, 
        ease: "easeInOut",
        delay: 2
      }}
      className="absolute bottom-0 right-1/4 w-96 h-96 bg-[var(--color-neon-red)]/5 rounded-full blur-[120px]"
    />

    {settings.eventsVideoUrl && (
      <video 
        autoPlay 
        loop 
        muted 
        playsInline 
        className="absolute inset-0 w-full h-full object-cover opacity-10 mix-blend-overlay pointer-events-none" 
        src={settings.eventsVideoUrl || undefined} 
      />
    )}
    
    <div className="relative z-10 max-w-7xl mx-auto">
      <div className="mb-12 text-center">
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] font-black text-[var(--color-neon-green)] uppercase tracking-[0.3em] mb-4"
        >
          <Calendar size={14} /> Upcoming Experience
        </motion.div>
        <h3 className="text-4xl md:text-6xl font-black uppercase text-white tracking-tighter leading-none">
          {settings.eventsSectionTitle || 'Special'} <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-500 to-gray-800">Events</span>
        </h3>
      </div>

      <div className="flex overflow-x-auto pb-8 gap-6 snap-x no-scrollbar">
        {events.map((event, idx) => (
          <motion.div 
            key={event.id}
            initial={{ x: 50, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            transition={{ delay: idx * 0.1 }}
            className="min-w-[300px] md:min-w-[600px] snap-center"
            id={`event-${event.id}`}
          >
            <div className="group relative bg-gradient-to-br from-[#111] to-[#0a0a0a] border border-white/5 rounded-[2.5rem] p-6 md:p-8 overflow-hidden shadow-2xl h-full flex flex-col md:flex-row gap-8 hover:border-[var(--color-neon-green)]/30 transition-colors duration-500">
              {/* Share Button */}
              {settings.isEventsShareEnabled && (
                <div className="absolute top-6 right-6 z-30">
                  <div className="bg-black/50 hover:bg-black/80 p-2 rounded-full backdrop-blur-md border border-white/10 transition-colors">
                    <ShareButton 
                      title={event.title}
                      text={`Check out this amazing event: ${event.title}!`}
                      url={`${window.location.origin}/#event-${event.id}`}
                      iconSize={16}
                    />
                  </div>
                </div>
              )}
              {/* Hover Glow */}
              <div className="absolute -inset-1 bg-gradient-to-r from-[var(--color-neon-green)] to-[var(--color-neon-red)] rounded-[2.5rem] blur opacity-0 group-hover:opacity-5 transition duration-1000"></div>
              
              <div className="w-full md:w-[320px] aspect-[9/16] rounded-[1.5rem] overflow-hidden border border-white/10 relative shrink-0 bg-black shadow-2xl">
                {event.mediaType === 'video' && event.videoUrl ? (
                  <EventVideoPlayer videoUrl={event.videoUrl} />
                ) : (
                  <img 
                    src={event.imageUrl || "https://picsum.photos/seed/event/800/1422"} 
                    alt={event.title} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[2s] ease-out" 
                  />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 pointer-events-none"></div>
                
                {/* Overlay content on media for Reels vibe */}
                <div className="absolute bottom-6 left-6 right-6 z-20">
                  <div className="inline-block bg-[var(--color-neon-red)] text-white text-[10px] font-black px-3 py-1.5 rounded-full mb-3 shadow-[0_0_15px_rgba(255,0,0,0.5)] uppercase tracking-widest">
                    Featured
                  </div>
                  <h4 className="text-2xl font-black text-white leading-tight tracking-tighter uppercase drop-shadow-lg">
                    {event.title}
                  </h4>
                </div>
              </div>

              <div className="flex-1 flex flex-col justify-center relative z-10">
                <div className="hidden md:inline-block bg-gradient-to-r from-[var(--color-neon-red)] to-rose-600 text-white text-[8px] font-black px-4 py-1.5 rounded-full mb-4 shadow-lg uppercase tracking-widest w-fit">
                  Limited Time
                </div>
                
                <h4 className="hidden md:block text-3xl md:text-5xl font-black mb-4 text-white leading-tight tracking-tighter uppercase italic">
                  {event.title}
                </h4>
                
                <p className="text-gray-400 mb-8 text-sm md:text-base font-medium leading-relaxed line-clamp-4">
                  {event.description}
                </p>

                <div className="flex flex-wrap gap-3 mb-8">
                  <div className="flex items-center gap-2 bg-white/5 backdrop-blur-xl px-4 py-2.5 rounded-xl text-[10px] font-black border border-white/10 text-white uppercase tracking-widest">
                    <Calendar size={14} className="text-[var(--color-neon-green)]" />
                    {event.date}
                  </div>
                  {event.location && (
                    <div className="flex items-center gap-2 bg-white/5 backdrop-blur-xl px-4 py-2.5 rounded-xl text-[10px] font-black border border-white/10 text-white uppercase tracking-widest">
                      <MapPin size={14} className="text-[var(--color-neon-red)]" />
                      {event.location}
                    </div>
                  )}
                </div>

                {event.couponCode && (
                  <div className="p-5 bg-gradient-to-r from-[var(--color-neon-green)]/10 to-transparent border border-[var(--color-neon-green)]/30 rounded-2xl flex items-center justify-between group/coupon overflow-hidden relative shadow-[0_0_30px_rgba(0,255,0,0.05)]">
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover/coupon:translate-x-full transition-transform duration-1000"></div>
                    <div>
                      <p className="text-[9px] font-black text-[var(--color-neon-green)] uppercase tracking-[0.2em] mb-1">Special Coupon</p>
                      <p className="text-2xl font-black text-white tracking-widest drop-shadow-md">{event.couponCode}</p>
                    </div>
                    <div className="text-right bg-[var(--color-neon-green)]/20 px-4 py-2 rounded-xl border border-[var(--color-neon-green)]/30">
                      <p className="text-[9px] font-black text-[var(--color-neon-green)] uppercase tracking-[0.2em] mb-1">Discount</p>
                      <p className="text-2xl font-black text-white">{event.discountAmount}% <span className="text-sm">OFF</span></p>
                    </div>
                  </div>
                )}

                {event.musicUrl && (
                  <div className="mt-6 p-4 bg-white/5 rounded-2xl border border-white/10 flex items-center justify-between group/music overflow-hidden relative">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-pink-500/20 flex items-center justify-center text-pink-500 animate-pulse">
                        <Music size={18} />
                      </div>
                      <div>
                        <p className="text-[8px] font-black text-gray-500 uppercase tracking-[0.2em] mb-1">Event Soundtrack</p>
                        <p className="text-xs font-bold text-white uppercase tracking-tight">
                          {event.musicUrl.toLowerCase().endsWith('.zip') ? 'Download Assets' : 'Background Music'}
                        </p>
                      </div>
                    </div>
                    
                    {event.musicUrl.toLowerCase().endsWith('.zip') ? (
                      <a 
                        href={event.musicUrl} 
                        download 
                        className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-[10px] font-black rounded-lg uppercase tracking-widest transition-all"
                      >
                        Download ZIP
                      </a>
                    ) : (
                      <audio controls className="h-8 w-32 opacity-40 hover:opacity-100 transition-opacity">
                        <source src={event.musicUrl} />
                      </audio>
                    )}
                  </div>
                )}

                <div className="mt-8 pt-6 border-t border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-[var(--color-neon-green)] animate-ping" />
                    <span className="text-[9px] font-black text-gray-500 uppercase tracking-[0.2em]">Live Status</span>
                  </div>
                  <div className="flex -space-x-2">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="w-6 h-6 rounded-full border border-black bg-gray-800 overflow-hidden">
                        <img src={`https://picsum.photos/seed/user${i+idx}/100/100`} className="w-full h-full object-cover" />
                      </div>
                    ))}
                    <div className="w-6 h-6 rounded-full border border-black bg-white/5 flex items-center justify-center text-[8px] font-black text-white">
                      +12
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </motion.section>
  );

  const sectionOffers = settings.isOffersEnabled && offers.length > 0 && (
    <section key="offers" className="relative py-20 md:py-32 px-4 md:px-6 border-b border-white/5 overflow-hidden bg-black/40 backdrop-blur-md">
      {settings.offersVideoUrl && (
        <video autoPlay loop muted playsInline className="absolute inset-0 w-full h-full object-cover opacity-10 mix-blend-screen pointer-events-none" src={settings.offersVideoUrl || undefined} />
      )}
      {/* Decorative background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-3xl h-3/4 bg-[var(--color-neon-green)]/5 blur-[120px] rounded-full pointer-events-none"></div>
      
      <div className="relative z-10 max-w-7xl mx-auto">
        <div className="mb-12 md:mb-16 text-center md:text-left flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <div className="flex items-center justify-center md:justify-start gap-3 mb-3">
              <div className="w-8 h-px bg-[var(--color-neon-red)]"></div>
              <h2 className="text-xs md:text-sm text-[var(--color-neon-red)] font-black uppercase tracking-[0.3em]">{settings.offersSectionSubtitle || 'Limited Time'}</h2>
            </div>
            <h3 className="text-4xl md:text-6xl font-black uppercase text-white tracking-tighter">
              {settings.offersSectionTitle?.split(' ')[0] || 'Daily'} <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-500 to-gray-700">{settings.offersSectionTitle?.split(' ').slice(1).join(' ') || 'Offers'}</span>
            </h3>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
          {offers.map((offer, index) => (
            <div 
              key={offer.id} 
              id={`offer-${offer.id}`} 
              className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-[#111] to-[#0a0a0a] border border-white/5 group flex flex-col sm:flex-row hover:border-[var(--color-neon-green)]/30 hover:shadow-[0_0_40px_rgba(0,255,0,0.05)] transition-all duration-500"
            >
              {/* Media Container */}
              <div className="w-full sm:w-2/5 h-56 sm:h-auto min-h-[240px] overflow-hidden relative bg-black">
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent z-10 sm:bg-gradient-to-r"></div>
                {offer.videoUrl ? (
                  <video 
                    src={offer.videoUrl} 
                    autoPlay 
                    loop 
                    muted 
                    playsInline 
                    className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 group-hover:rotate-1 transition-transform duration-700" 
                  />
                ) : (
                  <img 
                    src={offer.imageUrl || "https://picsum.photos/seed/offer/400/400"} 
                    alt={offer.title} 
                    className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 group-hover:rotate-1 transition-transform duration-700" 
                  />
                )}
                
                {/* Badges overlaid on media for mobile, or just top-left */}
                <div className="absolute top-4 left-4 z-20">
                  <div className="bg-[var(--color-neon-red)] text-white text-[10px] font-black px-3 py-1.5 rounded-full animate-pulse uppercase tracking-widest shadow-[0_0_20px_rgba(255,0,0,0.4)]">
                    HOT DEAL
                  </div>
                </div>
              </div>

              {/* Content Container */}
              <div className="p-6 md:p-8 flex-1 flex flex-col justify-center relative z-20">
                <div className="absolute top-6 right-6 flex items-center gap-2 z-30">
                  {settings.isOffersShareEnabled && (
                    <div className="bg-white/5 hover:bg-white/10 p-2 rounded-full backdrop-blur-md border border-white/10 transition-colors">
                      <ShareButton 
                        title={offer.title}
                        text={`Check out this amazing offer: ${offer.title}!`}
                        url={`${window.location.origin}/#offer-${offer.id}`}
                        iconSize={16}
                      />
                    </div>
                  )}
                </div>
                
                <h4 className="text-2xl md:text-3xl font-black text-white mb-3 uppercase tracking-tight leading-none pr-12">{offer.title}</h4>
                <p className="text-gray-400 text-sm mb-6 line-clamp-2 md:line-clamp-3 leading-relaxed">{offer.description}</p>
                
                <div className="mt-auto flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-baseline gap-3">
                    <span className="text-3xl md:text-4xl font-black text-[var(--color-neon-green)] tracking-tighter">₹{offer.price}</span>
                    {offer.originalPrice && (
                      <span className="text-lg text-gray-500 line-through font-bold decoration-[var(--color-neon-red)] decoration-2">₹{offer.originalPrice}</span>
                    )}
                  </div>
                  
                  <button 
                    onClick={() => {
                      useStore.getState().addToCart({
                        id: offer.id,
                        cartItemId: offer.id,
                        name: offer.title,
                        price: offer.price,
                        imageUrl: offer.imageUrl,
                        quantity: 1
                      });
                      useStore.getState().toggleCart();
                    }}
                    className="group/btn relative overflow-hidden bg-white/5 hover:bg-[var(--color-neon-green)] text-white hover:text-black font-black uppercase tracking-widest py-3 px-6 rounded-xl transition-all duration-300 border border-white/10 hover:border-transparent flex items-center justify-center gap-2 w-full sm:w-auto"
                  >
                    <ShoppingCart size={16} className="group-hover/btn:scale-110 transition-transform" />
                    <span>Grab</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );

  const sectionReels = settings.isReelsEnabled && reels.length > 0 && (
    <section key="reels" className="py-16 md:py-24 px-4 md:px-6 max-w-7xl mx-auto border-t border-[#222]">
      <div className="mb-12 text-center">
        <h2 className="text-sm text-[var(--color-neon-green)] uppercase tracking-widest mb-2">Daily Vibes</h2>
        <h3 className="text-3xl md:text-5xl font-black uppercase text-white">Daily <span className="text-gray-600">Reels</span></h3>
      </div>
      
      <div className="flex overflow-x-auto pb-8 gap-4 snap-x md:grid md:grid-cols-4 md:overflow-visible no-scrollbar">
        {reels.map(reel => (
          <div key={reel.id} className="min-w-[280px] snap-center md:min-w-0">
            <InfluencerVideo 
              videoUrl={reel.videoUrl}
              influencerName={reel.title}
              influencerImage={reel.logoUrl || "https://picsum.photos/seed/reel/100/100"}
              caption={reel.quote}
              logoUrl={reel.logoUrl}
              socialLink={reel.socialLink}
              musicUrl={reel.musicUrl}
              mediaType={reel.mediaType}
            />
          </div>
        ))}
      </div>
    </section>
  );

  const sectionCashback = <CashbackDashboard key="cashback" />;
  const sectionPhotoStudio = <PhotoStudioDashboard key="photostudio" />;

  const sectionMenu = settings.isMenuEnabled && (
    <motion.section 
      key="menu"
      id="menu-section"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="relative py-16 md:py-24 px-4 md:px-6 border-b border-white/5 overflow-hidden bg-black/30 backdrop-blur-md scroll-mt-20"
    >
      {settings.menuVideoUrl && (
        <video autoPlay loop muted playsInline className="absolute inset-0 w-full h-full object-cover opacity-10 mix-blend-screen pointer-events-none" src={settings.menuVideoUrl || undefined} />
      )}
      <div className="relative z-10 max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end mb-10 gap-6">
        <div>
          <h2 className="text-xs text-[var(--color-neon-green)] uppercase tracking-widest mb-2 border-l-2 border-[var(--color-neon-green)] pl-2">{settings.menuSectionSubtitle || 'Our Selection'}</h2>
          <h3 className="text-3xl md:text-5xl font-black uppercase text-white">{settings.menuSectionTitle?.split(' ')[0] || 'Menu'} <span className="text-gray-600">{settings.menuSectionTitle?.split(' ').slice(1).join(' ') || 'Specials'}</span></h3>
        </div>
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 w-full lg:w-auto">
          {/* Search Bar */}
          <div className="relative w-full sm:w-64 shrink-0">
            <input 
              type="text" 
              placeholder="Search items..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#111] border border-[#333] rounded-full py-2.5 pl-10 pr-4 text-white focus:border-[var(--color-neon-green)] outline-none transition-colors text-sm"
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
          </div>

          {/* Filters */}
          <div className="flex gap-2 overflow-x-auto pb-2 sm:pb-0 w-full no-scrollbar">
            {['All', ...(settings.categories || [])].map((cat, index) => (
              <button 
                key={`filter-${cat}-${index}`}
                onClick={() => setFilter(cat)}
                className={`px-6 py-2.5 rounded-full text-sm font-bold transition-all duration-300 whitespace-nowrap ${filter === cat ? 'bg-[var(--color-neon-green)] text-black' : 'border border-[#333] text-gray-400 hover:border-[var(--color-neon-green)]'}`}
              >
                {cat.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
      </div>

    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {filteredMenu.length > 0 ? (
        filteredMenu.map(item => (
          <MenuCard key={item.id} item={{...item, quantity: 1}} />
        ))
      ) : (
        <div className="col-span-full py-12 text-center text-gray-500">
          <Search className="mx-auto mb-4 opacity-20" size={48} />
          <p className="text-lg">No items found matching "{searchQuery}"</p>
        </div>
      )}
    </div>
    </div>
  </motion.section>
  );

  const sectionInfluencers = settings.isInfluencerSectionEnabled && influencers.length > 0 && (
    <section key="influencers" className="py-16 md:py-24 px-4 md:px-6 max-w-7xl mx-auto border-t border-[#222]">
      <div className="mb-12 text-center">
        <h2 className="text-sm text-[var(--color-neon-green)] uppercase tracking-widest mb-2">{settings.influencersSectionSubtitle || 'Influencer Love'}</h2>
        <h3 className="text-3xl md:text-5xl font-black uppercase text-white">{settings.influencersSectionTitle?.split(' ')[0] || 'Influencer'} <span className="text-gray-600">{settings.influencersSectionTitle?.split(' ').slice(1).join(' ') || 'Videos'}</span></h3>
      </div>
      
      <div className="flex overflow-x-auto pb-8 gap-4 snap-x md:grid md:grid-cols-4 md:overflow-visible no-scrollbar">
        {influencers.filter(inf => inf.videoUrl || inf.mediaType === 'image' || inf.mediaType === 'gif').map(inf => (
          <div key={inf.id} className="min-w-[280px] snap-center md:min-w-0">
            <InfluencerVideo 
              videoUrl={inf.videoUrl}
              influencerName={inf.instagramHandle || inf.name}
              influencerImage={inf.imageUrl || `https://picsum.photos/seed/${inf.id}/100/100`}
              caption={inf.quote}
              logoUrl={inf.logoUrl}
              socialLink={inf.socialLink}
              musicUrl={inf.musicUrl}
              mediaType={inf.mediaType}
            />
          </div>
        ))}
      </div>
    </section>
  );

  const sectionSponsored = settings.isSponsoredEnabled && sponsoredVideos.length > 0 && (
    <div key="sponsored" className="col-span-full lg:col-span-1">
      <div className="mb-10 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-[var(--color-neon-green)]/10 flex items-center justify-center border border-[var(--color-neon-green)]/20">
            <Star className="text-[var(--color-neon-green)]" size={24} />
          </div>
          <div>
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-[var(--color-neon-green)] block mb-1">{settings.sponsoredSectionSubtitle || 'Premium Partners'}</span>
            <h3 className="text-3xl font-black uppercase text-white tracking-tighter">{settings.sponsoredSectionTitle?.split(' ')[0] || 'Sponsored'} <span className="text-gray-500">{settings.sponsoredSectionTitle?.split(' ').slice(1).join(' ') || 'By'}</span></h3>
          </div>
        </div>
      </div>
      
      <div className="flex overflow-x-auto pb-8 gap-6 snap-x md:grid md:grid-cols-3 md:overflow-visible no-scrollbar">
        {sponsoredVideos.map((video, index) => (
          <motion.div 
            key={video.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="min-w-[280px] snap-center md:min-w-0 group relative"
          >
            {/* Card Glow */}
            <div className="absolute -inset-1 bg-gradient-to-r from-[var(--color-neon-green)]/20 to-transparent rounded-3xl blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            
            <InfluencerVideo 
              videoUrl={video.videoUrl}
              influencerName={video.sponsorName}
              influencerImage={video.logoUrl || `https://picsum.photos/seed/${video.id}/100/100`}
              caption={video.title}
              logoUrl={video.logoUrl}
              socialLink={video.socialLink}
              musicUrl={video.musicUrl}
              mediaType={video.mediaType}
              zipUrl={video.zipUrl}
            />
          </motion.div>
        ))}
      </div>
    </div>
  );

  const sectionSponsoredWrapper = (settings.isSponsoredEnabled || settings.isCollaborationsEnabled) && (
    <section key="sponsoredWrapper" className="relative py-16 md:py-24 px-4 md:px-6 bg-black/40 backdrop-blur-lg border-t border-white/5 overflow-hidden">
      <div className="relative z-10 max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12">
        {sectionSponsored}
      </div>
    </section>
  );

  const sectionFooterInfo = <FooterInfo key="footerInfo" />;
  const sectionNotifications = settings.isNotificationSectionEnabled && <NotificationSection key="notifications" />;
  const sectionFeaturedInfluencers = settings.isInfluencerSectionEnabled && influencers.length > 0 && <FeaturedInfluencers key="featuredInfluencers" influencers={influencers} />;
  const sectionStaff = (settings.isStaffEnabled ?? true) && <StaffSection key="staff" stories={stories} isStoriesEnabled={settings.isStoriesEnabled} />;
  const sectionPartnerCollab = <PartnerCollabSection key="partnerCollab" />;
  const sectionMoments = settings.isMomentsEnabled && <MomentsSection key="moments" />;
  const sectionRiderList = (settings.isRiderListEnabled ?? true) && <RiderList key="riderList" />;
  const sectionFounders = settings.isFoundersEnabled && <FounderSection key="founders" />;
  const sectionGetDirections = <GetDirectionsSection key="getDirections" />;
  const sectionOpeningHours = <OpeningHoursSection key="openingHours" />;
  const sectionContact = <ContactSection key="contact" />;

  const sectionOtherCategory = (
    <section className="py-12 px-4 relative">
      <div className="max-w-7xl mx-auto bg-[#111] border border-[#333] border-dashed rounded-2xl p-8 text-center">
        <h3 className="text-2xl font-black uppercase text-gray-500 mb-2">Other Category / Custom Feature</h3>
        <p className="text-gray-600">This section is reserved for future functions and customizations.</p>
      </div>
    </section>
  );

  const renderSectionById = (id: string) => {
    if (settings.disabledLayoutSections?.includes(id)) {
      return null;
    }

    let content = null;

    switch (id) {
      case 'hero': content = sectionHero; break;
      case 'events': content = sectionEvents; break;
      case 'eventBooking': content = <EventsSection />; break;
      case 'competitions': content = <CompetitionSection />; break;
      case 'offers': content = sectionOffers; break;
      case 'reels': content = sectionReels; break;
      case 'menu': content = sectionMenu; break;
      case 'influencers': content = sectionInfluencers; break;
      case 'photostudio': content = sectionPhotoStudio; break;
      case 'sponsored': content = sectionSponsoredWrapper; break;
      case 'openingHours': content = sectionOpeningHours; break;
      case 'contact': content = sectionContact; break;
      case 'partnerCollab': content = sectionPartnerCollab; break;
      case 'getDirections': content = sectionGetDirections; break;
      case 'cashback': content = sectionCashback; break;
      case 'moments': content = sectionMoments; break;
      case 'founders': content = sectionFounders; break;
      case 'stories': content = sectionStaff; break;
      case 'notifications': content = sectionNotifications; break;
      case 'banners': content = <BannerSection />; break;
      case 'other_category': content = sectionOtherCategory; break;
      case 'riderList': content = sectionRiderList; break;
      case 'staff': content = sectionStaff; break;
      case 'chickenStore': content = <ChickenStoreSection />; break;
      case 'pan': content = <PanSection />; break;
      case 'reviews': content = <CustomerReviewSection />; break;
      default: content = null;
    }

    if (!content) return null;

    return (
      <div id={id === 'menu' ? 'menu-section' : id} className="rgb-section">
        {content}
      </div>
    );
  };

  const hasScreenLayouts = settings.screenLayouts && settings.screenLayouts.length > 0;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-[var(--color-neon-green)] border-t-transparent rounded-full animate-spin"></div>
          <p className="text-[var(--color-neon-green)] font-bold tracking-widest uppercase animate-pulse">Loading Gupchup...</p>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <MotionConfig 
        reducedMotion={settings.isAnimationsEnabled === false ? "always" : "never"}
        transition={getGlobalTransition()}
      >
      <div className="min-h-screen bg-[var(--color-dark-bg)] relative overflow-x-hidden">
        <MusicControl />
        {/* Scroll to Top */}
        <AnimatePresence>
          {showScrollTop && (
            <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="fixed bottom-8 right-8 z-[100] p-4 bg-[var(--color-neon-green)] text-black rounded-full shadow-[0_0_30px_rgba(0,255,0,0.4)] hover:scale-110 transition-transform"
          >
            <ArrowRight className="-rotate-90" size={24} />
          </motion.button>
        )}
      </AnimatePresence>
      {/* Global Background Video & Deep Vibe Overlay */}
      {settings.globalBackgroundVideoUrl && (
        <>
          <video 
            autoPlay 
            loop 
            muted 
            playsInline 
            className="fixed inset-0 w-full h-full object-cover opacity-30 pointer-events-none z-0" 
            src={settings.globalBackgroundVideoUrl || undefined} 
          />
          <div className="fixed inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/80 pointer-events-none z-[1]"></div>
          <div className="fixed inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.4)_100%)] pointer-events-none z-[1]"></div>
        </>
      )}
      
      {settings.bgMusicUrl && (
        <audio 
          ref={audioRef}
          src={settings.bgMusicUrl || undefined} 
          autoPlay 
          loop 
          className="hidden" 
        />
      )}
      
      <div className="relative z-10">
        <Navbar />
        
        {hasScreenLayouts ? (
          <div className="flex flex-col">
            {/* Screen Navigation Tabs */}
            <div className="sticky top-[72px] z-40 bg-black/80 backdrop-blur-md border-b border-white/10 px-4 py-3 flex gap-2 overflow-x-auto no-scrollbar">
              {settings.screenLayouts?.map((layout, index) => (
                <button
                  key={layout.id || `layout-btn-${index}`}
                  onClick={() => {
                    setActiveScreen(index);
                    document.getElementById(`screen-${index}`)?.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'start' });
                  }}
                  className={`px-6 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-all duration-300 ${
                    activeScreen === index 
                      ? 'bg-[var(--color-neon-green)] text-black shadow-[0_0_15px_rgba(0,255,0,0.3)]' 
                      : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  {layout.name}
                </button>
              ))}
            </div>

            {/* Active Screen Content (Horizontal Scroll) */}
            <div 
              className="flex overflow-x-auto snap-x snap-mandatory no-scrollbar"
              onScroll={(e) => {
                const container = e.currentTarget;
                const scrollPosition = container.scrollLeft;
                const screenWidth = container.clientWidth;
                const newActiveScreen = Math.round(scrollPosition / screenWidth);
                if (newActiveScreen !== activeScreen) {
                  setActiveScreen(newActiveScreen);
                }
              }}
            >
              {settings.screenLayouts?.map((layout, index) => (
                <div 
                  key={layout.id || `layout-div-${index}`} 
                  id={`screen-${index}`}
                  className="min-w-full w-full snap-start"
                >
                  {layout.sections.map((sectionId, sIndex) => (
                    <React.Fragment key={`${sectionId}-${sIndex}`}>
                      {renderSectionById(sectionId)}
                    </React.Fragment>
                  ))}
                </div>
              ))}
            </div>
          </div>
        ) : (
          <>
            {renderSectionById('banners')}
            {renderSectionById('hero')}
            {renderSectionById('competitions')}
            {renderSectionById('events')}
            {renderSectionById('offers')}
            {renderSectionById('reels')}
            {renderSectionById('cashback')}
            {renderSectionById('moments')}
            {renderSectionById('photostudio')}
            {renderSectionById('menu')}
            {renderSectionById('influencers')}
            {renderSectionById('sponsored')}
            {renderSectionById('footerInfo')}
            {renderSectionById('notifications')}
            {renderSectionById('featuredInfluencers')}
            {renderSectionById('stories')}
            {renderSectionById('partnerCollab')}
            {renderSectionById('riderList')}
            {renderSectionById('founders')}
            {renderSectionById('getDirections')}
            {renderSectionById('openingHours')}
            {renderSectionById('contact')}
          </>
        )}

      {/* Footer */}
      <footer id="footerInfo" className="relative bg-black/60 backdrop-blur-xl border-t border-white/5 py-12 px-4 mt-20 overflow-hidden rgb-section">
        {settings.footerVideoUrl && (
          <video autoPlay loop muted playsInline className="absolute inset-0 w-full h-full object-cover opacity-10 mix-blend-screen pointer-events-none" src={settings.footerVideoUrl || undefined} />
        )}
        <div className="relative z-10 max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="text-center md:text-left">
            <h2 className="text-2xl font-black uppercase text-white mb-2">{settings.footerName}</h2>
            <p className="text-gray-400 text-sm flex items-center justify-center md:justify-start gap-2">
              <MapPin size={16} className="text-[var(--color-neon-red)]" />
              Chhoto Mohodipur danesh Ali Tola Tree Mohini
            </p>
          </div>
          
          <div className="flex gap-4">
            {settings.socialLinks?.instagram && (
              <a href={settings.socialLinks.instagram} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-[#111] border border-[#333] flex items-center justify-center text-gray-400 hover:text-[var(--color-neon-green)] hover:border-[var(--color-neon-green)] transition-all">
                <Instagram size={20} />
              </a>
            )}
            {settings.socialLinks?.facebook && (
              <a href={settings.socialLinks.facebook} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-[#111] border border-[#333] flex items-center justify-center text-gray-400 hover:text-[var(--color-neon-green)] hover:border-[var(--color-neon-green)] transition-all">
                <Facebook size={20} />
              </a>
            )}
            {settings.socialLinks?.youtube && (
              <a href={settings.socialLinks.youtube} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-[#111] border border-[#333] flex items-center justify-center text-gray-400 hover:text-[var(--color-neon-green)] hover:border-[var(--color-neon-green)] transition-all">
                <Youtube size={20} />
              </a>
            )}
            {settings.socialLinks?.twitter && (
              <a href={settings.socialLinks.twitter} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-[#111] border border-[#333] flex items-center justify-center text-gray-400 hover:text-[var(--color-neon-green)] hover:border-[var(--color-neon-green)] transition-all">
                <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current" aria-hidden="true">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.008 5.96H5.078z" />
                </svg>
              </a>
            )}
            {settings.socialLinks?.whatsapp && (
              <a href={settings.socialLinks.whatsapp} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-[#111] border border-[#333] flex items-center justify-center text-gray-400 hover:text-[var(--color-neon-green)] hover:border-[var(--color-neon-green)] transition-all">
                <MessageCircle size={20} />
              </a>
            )}
            
            {/* Fallback if no links are set */}
            {!settings.socialLinks?.instagram && !settings.socialLinks?.facebook && !settings.socialLinks?.youtube && !settings.socialLinks?.twitter && !settings.socialLinks?.whatsapp && (
              <>
                <a href="#" className="w-10 h-10 rounded-full bg-[#111] border border-[#333] flex items-center justify-center text-gray-400 hover:text-[var(--color-neon-green)] hover:border-[var(--color-neon-green)] transition-all">
                  <Instagram size={20} />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-[#111] border border-[#333] flex items-center justify-center text-gray-400 hover:text-[var(--color-neon-green)] hover:border-[var(--color-neon-green)] transition-all">
                  <Facebook size={20} />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-[#111] border border-[#333] flex items-center justify-center text-gray-400 hover:text-[var(--color-neon-green)] hover:border-[var(--color-neon-green)] transition-all">
                  <Youtube size={20} />
                </a>
              </>
            )}
          </div>
        </div>
        <div className="relative z-10 max-w-7xl mx-auto mt-8 pt-8 border-t border-[#222] text-center text-xs text-gray-600">
          © {new Date().getFullYear()} {settings.footerName}. All rights reserved.
        </div>
      </footer>
      </div>
      </div>
      </MotionConfig>
    </ErrorBoundary>
  );
}

import FoodItemPage from './components/FoodItemPage';

export default function App() {
  const { 
    setSettings, setReviews,
    setCompetitions, setCompetitionManagers, setCompetitionAnnouncements
  } = useStore();
  const [isAppLoading, setIsAppLoading] = useState(true);

  useEffect(() => {
    // Fetch Settings
    const unsubscribeSettings = onSnapshot(doc(db, 'settings', 'global'), (doc) => {
      if (doc.exists()) {
        setSettings(doc.data() as any);
      }
      setIsAppLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'settings/global');
      setIsAppLoading(false);
    });

    const unsubscribeReviews = onSnapshot(collection(db, 'reviews'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setReviews(data as any);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'reviews');
    });

    const unsubCompetitions = onSnapshot(query(collection(db, 'competitions'), orderBy('order', 'asc')), (snapshot) => {
      setCompetitions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as any);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'competitions'));

    const unsubManagers = onSnapshot(collection(db, 'competitionManagers'), (snapshot) => {
      setCompetitionManagers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as any);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'competitionManagers'));

    const unsubAnnouncements = onSnapshot(collection(db, 'competitionAnnouncements'), (snapshot) => {
      setCompetitionAnnouncements(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as any);
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'competitionAnnouncements'));

    return () => {
      unsubscribeSettings();
      unsubscribeReviews();
      unsubCompetitions();
      unsubManagers();
      unsubAnnouncements();
    };
  }, []);

  const settings = useStore(state => state.settings);
  useEffect(() => {
    if (settings?.appLogoUrl) {
      // Update standard favicon
      let link = document.querySelector("link[rel~='icon']") as HTMLLinkElement;
      if (!link) {
        link = document.createElement('link');
        link.rel = 'icon';
        document.head.appendChild(link);
      }
      link.href = settings.appLogoUrl;

      // Update Apple Touch Icon (for iOS PWA)
      let appleLink = document.querySelector("link[rel='apple-touch-icon']") as HTMLLinkElement;
      if (!appleLink) {
        appleLink = document.createElement('link');
        appleLink.rel = 'apple-touch-icon';
        document.head.appendChild(appleLink);
      }
      appleLink.href = settings.appLogoUrl;
    }
  }, [settings?.appLogoUrl]);

  if (isAppLoading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-[var(--color-neon-green)] border-t-transparent rounded-full animate-spin"></div>
          <p className="text-[var(--color-neon-green)] font-bold tracking-widest uppercase animate-pulse">Initializing App...</p>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <RgbEngine />
      <Router>
        <NovaAssistant />
        <CartDrawer />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/menu/:id" element={<FoodItemPage />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin-login" element={<AdminLoginPage />} />
          <Route path="/auth" element={<AuthPage />} />
          <Route path="/dashboard" element={<CustomerDashboard />} />
        </Routes>
      </Router>
    </ErrorBoundary>
  );
}

